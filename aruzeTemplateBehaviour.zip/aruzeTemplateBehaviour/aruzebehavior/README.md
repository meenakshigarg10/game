# AruzeBehavior

Version 1.1

All the Aruze Behavior is implemented here. No feature related stuff is present in this behavior.

Game client will extend this behavior to implement aruze behavior.

## Update ##
4/12/2020
Issues fixed
1. Broken: Win banner is displayed on resuming the game when win threshold is met during gamble win amount
2. History: Win banner changes to big win banner when history is replayed
3. Broken: On resuming the game win banner changes to big win banner when win amount is changed during gamble
4. Free Game: Game gets stuck in the next spin when 20 feature symbol is displayed on the grid

## Update ##
14/1/2020
Issues fixed
1. Info Page was unable to open when we pressed on infoButton.

## Update ##
18/1/2020
Issues fixed
1. BigWin Enabled During retrigger in Freegame.

## Update ##
19/1/2020
Issues fixed
1. Suspended win presentation when any enabled button is pressed while tickup is running.

## Update ##
22/1/2020
Issues fixed
1. BigWin During retrigger Win amt Update in Freegame.
2. Disable Spacebar During Setting Panel, Help and Paytable open.
3. Disable button panel when close sent by Gamble to handle Postloading.
4. To do Loader Hide after Gamble request response Received, in case of Basegame Broken for Postloading. 


## Update ##
25/1/2020
Issues fixed
1. Code Clean

2/4/2021
1. NYX integration
2. setLanguage function updated

2/23/2021
1. Move event "SHOW_BROKEN_GAME_FG" to behaviour from game end.
2/3/2021
1. Change accessbility of `view` object and `subscribe` function from private to protected. 

16/3/2021
1. FreePlay unused event constant.
2. FreeGameController alpha tween redundant code remove. 

25/3/2021
1. Basegame Model: getIsBigWIn (Threshold has been changed).
2. Freegame Model: getIsBigWIn (Threshold has been changed).

03/4/2021
1. SeetingPannel.View: play sound on Setting button pop Close button pressed.
2. Basegame ButtonController: Play sound when Setting button pressed.
3. BigWinControllerFg: Sound key updated for level 1 big win.

04/06/2021
1. onShowBigWin function updated to check big win in free game
