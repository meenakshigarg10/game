'use strict';
var config = require("../gruntConfig.json");
module.exports = function replacePath(grunt) {
    grunt.registerMultiTask('replacePath', "Replaces a string with other in the provided files", function () {
        var options = this.options({
            global: true,
            ignoreCase: true,
        });
        var i, list, replaced, flag = '';
        for (i = 0; i < this.files.length; i++) {
            flag = '' + (options.global) ? "g" : "" + (options.ignoreCase) ? "i" : "";
            grunt.log.writeln(this.target + ': ' + JSON.stringify(this.files[i].src));
            list = grunt.file.read(this.files[i].src);
            replaced = list.replace(new RegExp(options.pattern.find, flag), options.pattern.replace);
            grunt.file.write(this.files[i].src + ".bak", list);
            grunt.file.write(this.files[i].dest, "/* tslint:disable */\n"+replaced);
        }
    });

    return {
        options: config.replacePath.options,
        all: {
            files: config.replacePath.files
        }
    }

};