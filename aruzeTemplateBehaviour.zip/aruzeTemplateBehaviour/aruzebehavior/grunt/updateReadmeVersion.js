'use strict';
var config = require("../gruntConfig.json");
module.exports = function updateReadmeVersion(grunt) {
    grunt.registerMultiTask('updateReadmeVersion', "Replaces a string with other in the provided files", function () {
        const options = this.options({});
        const cwd = process.cwd();
        const fs = require("fs");
        const pkg = require("../package.json");
        const version = pkg.version;

        const readme = grunt.file.read("readme.md");
        grunt.file.write("readme.md", readme.replace(/> Version (\d+).(\d+).(\d+)/, "> Version " + version));
    });

    return {
        readme:[]
    }

};