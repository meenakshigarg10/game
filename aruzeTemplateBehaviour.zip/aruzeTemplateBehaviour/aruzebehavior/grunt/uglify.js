/**
 * Created by Asharma on 26-09-2016.
 */
'use strict';
var config = require("../gruntConfig.json");
module.exports = function uglify(grunt) {
    return {
        build: {
            options: config.uglify.options,
            src: config.ts.default.out,
            dest: config.uglify.dest
        }
    }
};