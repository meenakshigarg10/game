/**
 * Created by Asharma on 26-09-2016.
 */
'use strict';
const config = require("../gruntConfig.json");
module.exports = function ts(grunt) {
    return {
        default: config.ts.default,
        // loader: config.ts.loader,
        options: config.ts.options
    }
};