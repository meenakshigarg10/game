/**
 * Created by Asharma on 26-09-2016.
 */
'use strict';
var config = require("../gruntConfig.json");
module.exports = function tslint(grunt) {
    return {
        options: config.tslint.options,
        files: {
            src: ["<%= tsPath %>**/*.ts"]
        }
    }
};