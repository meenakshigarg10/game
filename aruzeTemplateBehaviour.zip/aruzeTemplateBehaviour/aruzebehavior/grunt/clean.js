/**
 * Created by Asharma on 26-09-2016.
 */
'use strict';
var config = require("../gruntConfig.json");
module.exports = function clean(grunt) {
    return {
        options: config.clean.options,
        build: [config.paths.buildPath],
        tsd: ["<%= tsdPath %>"],
        docs: ["<%= docsPath %>"],
        js: ["<%= jsPath %>"]
    }
};