'use strict';
const config = require("../gruntConfig.json");
module.exports = function less(grunt) {
    return {
        options: config.less.options,
        build: {
            files : config.less.build.files,
            options: config.less.build.options
        },
        dev: {
            src : config.less.dev.src,
            dest: config.less.dev.dest,
            options: config.less.dev.options
        }
    }
};