/**
 * Created by Asharma on 26-09-2016.
 */
'use strict';
var config = require("../gruntConfig.json");
module.exports = function typedoc(grunt) {
    return {
        build: {
            options: config.tsDoc.options,
            src: config.tsDoc.src
        }
    }
};