/**
 * Created by Asharma on 26-09-2016.
 */
'use strict';
var config = require("../gruntConfig.json");
module.exports = function copy(grunt) {
    return {
        options:config.copyBehavior.options,
        tag: {
            files: config.copyBehavior.tag.filesList
        }
    }
    /*return {
        options:config.copy.options,
        tag: {
            files: config.copy.tag.filesList
        }
    }*/
};