/**
 * Created by Sumit Sethi on 1/2/2021.
 */
'use strict';
var config = require("../gruntConfig.json");
module.exports = function usebanner(grunt) {
    return {
        dist: config.usebanner.dist
    }
};
