var config = require("./gruntConfig.json");
var fileSys = require("fs");
var buildConfig;
module.exports = function (grunt) {
    if(fileSys.existsSync("./copy_build.json")) {
        buildConfig = grunt.file.readJSON("./copy_build.json");
    }
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        name: "<%= pkg.name %>",
        version: "<%= pkg.version %>",
        sourcePath: config.paths.sourcePath,
        buildPath: config.paths.buildPath,
        docsPath: config.paths.buildPath + config.paths.documentPath,
        tsdPath: config.paths.buildPath + config.paths.typingsPath,
        jsPath: config.paths.buildPath + config.paths.jsPath,
        tsPath: "<%= sourcePath %>" + config.paths.tsPath,
        lessPath: "<%= sourcePath %>" + config.paths.lessPath,
        cssPath: "<%= buildPath %>" + config.paths.cssPath,
        copyBuildPath: (buildConfig)? buildConfig.buildPath : "",
        templateBehaviorTsdPath: buildConfig.buildPath + config.paths.templateBehaviorTsdPath,
		now: new Date()
    });
    
    require('load-grunt-tasks')(grunt);
    require('grunt-config-dir')(grunt, {
        configDir: require('path').resolve('grunt'),
        fileExtensions: ['js']
    }, function (err) {
        grunt.log.error(err)
    });

	grunt.registerTask('default', ['build']);
    grunt.registerTask('debug', ['clean:build', "tslint", "ts", "uglify", "updateReadmeVersion", "usebanner", "copy"]);
    grunt.registerTask('build', ['clean:build', "tslint", "ts", "uglify", "updateReadmeVersion", "replacePath", "usebanner"]);
};