/// <reference path="../base/base-core.d.ts" />
/// <reference path="../slot/slot-core.d.ts" />
/// <reference path="../phaser.d.ts" />
declare namespace ingenuity.betssonui {
    class Constants {
        static CLOCK_MINUTE_TIMER: number;
        static TOOL_TIP_TIMING: number;
        static CASH_INCREMENT_TIME: number;
        static BetBtnId: string;
        static SettingBtnId: string;
        static SoundOnBtnId: string;
        static SoundOffBtnId: string;
        static BackBtnId: string;
        static MidBetSettingBtnId: string;
        static MidGameSettingBtnId: string;
        static MidAutoplaySettingBtnId: string;
        static MidStartAutoplayBtnId: string;
        static BET_SETTING_PANEL: string;
        static AUTOPLAY_SETTING_PANEL: string;
        static GAME_SETTING_PANEL: string;
        static INFO_SETTING_PANEL: string;
        static PAYTABLE_SETTING_PANEL: string;
        static MIDDLE_CONTAINER_X: number;
        static MIDDLE_CONTAINER_Y: number;
        static TOOL_TIP_DELAY_TIMER: string;
        static TOP_UI_CLOCK_UPDATE: string;
        static INFO_BUTTON: string;
        static PAYTABLE_BUTTON: string;
    }
}
declare namespace ingenuity.betssonui {
    let BetssonEventConstants: {
        INITIALIZE_BS_UI: string;
        INITIALIZE_CLOCK_UI_IN_TOP_BAR: string;
        CLEAR_CLOCK_TIMER: string;
        UNSUBSCRIBE_CLOCK_EVENTS: string;
        UPDATE_BS_COIN_VALUE: string;
        UPDATE_BS_BALANCE: string;
        INCREASE_BS_BALANCE: string;
        UPDATE_BS_WIN: string;
        UPDATE_BS_BET_VALUE: string;
        BS_BET_BTN_CLICKED: string;
        DISABLED_BS_BET_BTN: string;
        RESET_BS_WIN_METER: string;
        DISABLED_BS_SETTING_BTN: string;
        CHANGE_VISIBILITY_OF_SETTING_PANEL: string;
        DISABLED_BS_PANEL: string;
        BS_SOUND_STATUS_CHANGED: string;
        SHOW_TOTAL_BET_LABEL: string;
        MIDDLE_BET_SETTING_PRESS: string;
        RESET_ALL_MIDDLE_SETTINGS_BTNS_AND_VIEWS: string;
        MIDDLE_AUTOPLAY_SETTING_PRESS: string;
        SUBSCRIBE_AGAIN_ON_MAIN_MIDDLE_PANEL_OPEN: string;
        GENERATE_BET_SETTING_OPTION: string;
        SELECT_BET_OPTION: string;
        GENERATE_AUTOPLAY_SETTING_OPTION: string;
        GENERATE_AUTOPLAY_UKGC_SETTING_OPTION: string;
        MIDDLE_BACK_BTN_PRESS: string;
        CLICK_AUTOPLAY_OPTION: string;
        CLICK_BS_START_AUTOPLAY: string;
        OPEN_BS_AUTOPLAY_PANEL: string;
        GENERATE_GAME_SETTING_OPTION: string;
        CLICK_ALL_SOUNDS_GAME_SETTING_OPTION: string;
        UPDATE_SOUND_STATUS: string;
        INFO_BUTTON_CLICKED: string;
        UNSUBSCRIBE_INFO_CLASS_EVENTS: string;
        HIDE_INFO_VIEW: string;
        BS_DEDUCT_STAKE_VALUE: string;
        BS_WIN_VALUE: string;
        BS_STOP_AUTOPLAY: string;
        BS_END_AUTOPLAY: string;
        SHOW_LOSS_LIMIT_REACHED_MSG: string;
        SHOW_WIN_LIMIT_REACHED_MSG: string;
        HIDE_LOSS_LIMIT_REACHED_MSGS: string;
    };
}
declare namespace ingenuity.betssonui {
    class InitializeBetsonsUIComponent {
        private baseGameView;
        private bsMainTopView;
        private bsMainBottomView;
        private bsMainMiddleView;
        private bsMainTopClockController;
        private bsMainTopCoinValueController;
        private bsMainUKGCMsgController;
        private bsBottomCashController;
        private bsBottomWinController;
        private bsBottomBetController;
        private bsTopSoundController;
        private bsBottomSettingController;
        private bsMainMiddleController;
        private bsMainMiddleBetSettingController;
        private bsMainMiddleGameSettingController;
        private bsMainMiddleBetOptionController;
        private bsMainMiddleAutoPlaySettingController;
        private bsMiddleAutoplayOptionController;
        private bsMainMiddleUKGCAutoplayOptionController;
        private bsMainMiddleGameSettingOptionController;
        private bsMainInfoPanerlController;
        private bsMainModel;
        constructor();
        protected initializeBetssonUIController(): void;
        protected initializeBSTopController(): void;
        protected initializeBSBottomController(): void;
        protected initializeBSMiddleController(): void;
        private initilaizeConfigurations();
        protected initializeBaseGameView(): void;
        protected initializeBSTopView(): void;
        protected initializeBSBottomView(): void;
        protected initializeBSMiddleView(): void;
        protected initializeBetssonUIModel(): void;
        protected initializeBetssonUIView(): void;
        protected initializeValuesInTopAndBottomView(): void;
        private updateCoinValueInBottomBar();
        private updateCashValueInBottomBar();
        private updateBetValueInBottomBar();
        private updateWinValueInBottomBar();
        protected incrementValueInCashMeter(): void;
    }
}
declare namespace ingenuity.betssonui {
    class BetssonUIMain {
        assetsLoadedCounter: number;
        constructor(mainDiv?: string, deviceConfig?: any, loadStateObj?: IGameStates);
        private subscribeEvents();
        protected disabledBSPanel(): void;
        private onInitializeCurrencyAndFormat();
        protected onInitializeBetsonsUI(evt: IEvent): void;
    }
}
declare namespace ingenuity.betssonui {
    class BSToggleButton extends ui.ToggleButton {
        protected isOn: boolean;
        protected enabled: boolean;
        constructor(json: IToggleButton, game: Phaser.Game);
        onBtnOnPressed(): void;
        onBtnOffPressed(): void;
    }
}
declare namespace ingenuity.betssonui {
    class BSButtonBase extends ui.ButtonBase {
        constructor(json: IButton, game: Phaser.Game, x?: number, y?: number, key?: string, callback?: any, callbackContext?: any, overFrame?: string, outFrame?: string, downFrame?: string, upFrame?: string, disabledFrame?: string);
        keepSelectedBtn(): void;
    }
}
declare namespace ingenuity.core.constructors {
    let betssonui: {
        InitializeBetsonsUIComponent: typeof ingenuity.betssonui.InitializeBetsonsUIComponent;
    };
}
declare namespace ingenuity {
}
declare namespace ingenuity.betssonui {
    class BottomBetController {
        view: BSMainBottomView;
        model: Model;
        // btnBet: BSButtonBase;
        private boolIsToolTipVisible;
        private btnXPosition;
        private btnYPosition;
        constructor(view: BSMainBottomView, model: Model);
        private initializeComponents();
        private bindHandlers();
        private onDownHideToolTip(btn?);
        private onOverShowToolTip(btn?);
        private onOutHideToolTip(btn?);
        private showBottomBetToolTip();
        protected onBetButtonPress(btn?: BSButtonBase): void;
        private changeToolTipVisibility();
        private subscribeEvents();
        private disabledBetButton();
        private updateBottomBarBetValueComponent(evt);
    }
}
declare namespace ingenuity.betssonui {
    class BottomCashController {
        view: BSMainBottomView;
        model: Model;
        cashMeter: ui.MeterBitmap;
        constructor(view: BSMainBottomView, model: Model);
        private initializeIncrementMeter();
        private subscribeEvents();
        private updateBottomBarCashValueComponent(evt);
        private increaseBottomBarCashValueComponent(evt);
        updateCashTickUp(type?: string): void;
    }
}
declare namespace ingenuity.betssonui {
    class BottomSettingController {
        view: BSMainBottomView;
        btnSetting: BSButtonBase;
        constructor(view: BSMainBottomView);
        private subscribeEvents();
        private disabledSettingButton();
        private initializeComponents();
        private bindHandlers();
        private onSettingButtonPress(btn?);
    }
}
declare namespace ingenuity.betssonui {
    class TopSoundController {
        view: BSMainBottomView;
        btnSoundOn: BSButtonBase;
        btnSoundOff: BSButtonBase;
        private btnXPosition;
        private btnYPosition;
        private boolIsToolTipVisible;
        constructor(view: BSMainBottomView);
        private bindHandlers();
        private onShowButtonState(evt);
        private onSoundOnButtonPress(btn?);
        private onDownHideToolTip(btn?);
        private onOverShowToolTip(btn?);
        private onOutHideToolTip(btn?);
        private showAudioToolTip();
        private onSoundOffButtonPress(btn?);
        private initializeSoundButtons();
        private subscribeEvents();
    }
}
declare namespace ingenuity.betssonui {
    class BottomWinController {
        view: BSMainBottomView;
        model: Model;
        constructor(view: BSMainBottomView, model: Model);
        private subscribeEvents();
        private resetBottomBarWinComponent();
        private updateBottomBarWinValueComponent(evt);
    }
}
declare namespace ingenuity.betssonui {
    class BSMainInfoPanelController {
        private infoButton;
        private paytableButton;
        private model;
        private view;
        constructor(view: BSMainMiddleView, model: Model);
        protected addEventListeners(): void;
        protected unsubscribeEvents(): void;
        private initializeComponents();
        private bindHandlers();
        private openUpTheInfo();
        private showMainContainerIFrame();
        private openUpThePaytable();
        resize(): void;
        private handleInfoButtonClick();
        private onCloseClicked();
    }
}
declare namespace ingenuity.betssonui {
    class MiddleAutoplayOptionController {
        private model;
        spinsNumberConfigArra: any[];
        private yStartPosition;
        private xStartPosition;
        private xPosition;
        private yPosition;
        private configOptionsConatinerArray;
        private currentSelectedContainer;
        private tempOptionsConatinerArray;
        constructor(model: Model);
        private subscribeEvents();
        private selectFirstAutoplayOption();
        private generateAutoplayOption(evt);
        private generateXandYPositionFirstRow(i);
        private generateXandYPositionSecondRow(i);
        private generateXandYPositionThirdRow(i);
        createAutoPlayOptionsContainer(configSettings: any[], jsonValue: any, parentContainer: ui.Container): void;
        private bindEventsOnOptions(option);
        protected onInputDownHandle(evt: any): void;
        private setSelectedOptionAutoplaySpinValue(currentlySelectedContainer);
        private checkforClickOnSameOption(currentlySelectedContainer);
        private resetPreviouslySelectedOption(currentlySelectedContainer);
    }
}
declare namespace ingenuity.betssonui {
    class MiddleAutoplayPanelController {
        private view;
        private btnMidAutoplaySetting;
        private btnStartAutoplay;
        private model;
        constructor(view: BSMainMiddleView, model: Model);
        private subscribeEvents();
        private resetAutoplaySettingBtnAndPanel();
        private resetDataOnAutoplayStop(evt);
        private accumulateStakeValue(evt);
        private accumulateWinValue(evt);
        private checkForWinLimitAndLosslimit(singleWinValue);
        private initializeComponents();
        private generateUKGCAutoplaySettingOptionBtns();
        private generateAutoplaySettingOptionBtns();
        private bindHandlers();
        private onMidStartAutoPlayBtnPress(btn?);
        private middleAutoplaySettingPress();
        private autoPlaySettingButtonPressed();
        private onMidAutoPlaySettingBtnPress(btn?);
    }
}
declare namespace ingenuity.betssonui {
    class MiddleBetSettingOptionController {
        private model;
        coinConfigArra: any[];
        private yStartPosition;
        private xStartPosition;
        private xPosition;
        private yPosition;
        private configOptionsConatinerArray;
        private currentSelectedContainer;
        private tempOptionsConatinerArray;
        constructor(model: Model);
        private subscribeEvents();
        private selectBetOption(evt);
        private generateBetSettingOption(evt);
        private generateXandYPositionFirstRow(i);
        private generateXandYPositionSecondRow(i);
        private generateXandYPositionThirdRow(i);
        createBetSettingOptionsContainer(configSettings: any[], jsonValue: any, parentContainer: ui.Container): void;
        private selectBetOptionInBetSettingPanel();
        private bindEventsOnOptions(option);
        protected onInputDownHandle(evt: any): void;
        private setSelectedOptionTotalBetValue(currentlySelectedContainer);
        private updateBottomBarBetMeter(currentTotalBet);
        private checkforClickOnSameOption(currentlySelectedContainer);
        private resetPreviouslySelectedOption(currentlySelectedContainer);
    }
}
declare namespace ingenuity.betssonui {
    class MiddleBetSettingPanelController {
        private view;
        private btnMidBetSetting;
        private model;
        constructor(view: BSMainMiddleView, model: Model);
        private subscribeEvents();
        private resetBetSettingBtnAndPanel();
        private initializeComponents();
        private generateBetOptions();
        private bindHandlers();
        private middleBetSettingPress();
        private betsettingButtonPressed();
        private selectDefaultBetOptionInBetSettingPanel();
        private onMidBetSettingBtnPress(btn?);
    }
}
declare namespace ingenuity.betssonui {
    class MiddleGameSettingOptionController {
        private model;
        coinConfigArra: any[];
        private yStartPosition;
        private xStartPosition;
        private soundEffectsGameSettingOptionToggle;
        private musicGameSettingOptionToggle;
        private showCoinsGameSettingOptionToggle;
        private showIntroGameSettingOptionToggle;
        private turboSpinsSettingOptionToggle;
        private allSoundsGameSettingOptionToggle;
        constructor(model: Model);
        private subscribeEvents();
        private generateGameSettingOption(evt);
        private configOptionObj;
        createGameSettingOptionsContainer(configSettings: any[], jsonValue: any, parentContainer: ui.Container): void;
        private bindEventsOnOptions(option);
        protected onInputallSoundsDownHandle(evt: any): void;
        protected checkGameSettingSoundStatus(evt: IEvent): void;
        protected onInputSoundEffectsDownHandle(evt: any): void;
        protected onInputMusicDownHandle(evt: any): void;
        protected onInputShowCoinsDownHandle(evt: any): void;
        protected onInputShowIntroDownHandle(evt: any): void;
        protected onInputTurboSpinsDownHandle(evt: any): void;
    }
}
declare namespace ingenuity.betssonui {
    class MiddleGameSettingPanelController {
        private view;
        private btnMidGameSetting;
        private model;
        constructor(view: BSMainMiddleView, model: Model);
        private subscribeEvents();
        private resetBetSettingBtnAndPanel();
        private initializeComponents();
        private generateGameSettingOptionBtns();
        private bindHandlers();
        private gameSettingButtonPressed();
        private onMidGameSettingBtnPress(btn?);
    }
}
declare namespace ingenuity.betssonui {
    class MiddleSettingPanelController {
        private view;
        private btnBack;
        private middleConVisibilityStatus;
        private model;
        constructor(view: BSMainMiddleView, model: Model);
        private subscribeEvents();
        private showMidSettingPanelOnBottonBetPressed(evt);
        private showMiddleAutoplaySettingPanel(evt);
        private onBottomSettingBtnPressed(evt);
        private changeVisibilitySettingPanel();
        private initializeComponents();
        private bindHandlers();
        private onBackButtonPress(btn?);
    }
}
declare namespace ingenuity.betssonui {
    class MiddleUKGCAutoplayOptionController {
        private model;
        private spinsNumberConfigArra;
        private winLimitConfigArra;
        private lossLimitConfigArra;
        private yStartPosition;
        private xStartPosition;
        private xPosition;
        private yPosition;
        private spinsNumberConatinerArray;
        private winLimitConatinerArray;
        private lossLimitConatinerArray;
        private currentSelectedContainer;
        private tempSpinsNumberOptionsConatinerArray;
        private tempWinLimitOptionsConatinerArray;
        private tempLossLimitOptionsConatinerArray;
        private SPINS_COUNTER;
        private LOSS_LIMITS;
        private WIN_LIMITS;
        constructor(model: Model);
        private subscribeEvents();
        private accumulateStakeValue(evt);
        private accumulateWinValue(evt);
        private generateUKGCAutoplayOption(evt);
        private generateUKGCOptions(jsonValue, parentContainer);
        private selectDefaultOptions();
        private setSpinsCounterOptionsPositions(i);
        private setLossLimitsOptionsPositions(i);
        private setWinLimitsOptionsPositions(i);
        private createOptions(key, configSettings, jsonValue, parentContainer);
        private selectAutoplaySpinOption();
        private selectWinLimitOption();
        private selectLossLimitOption();
        private bindEventsOnOptions(option, key);
        protected onLossLimitOptionPress(evt: any): void;
        protected onWinLimitOptionPress(evt: any): void;
        protected onSpinCounterOptionPress(evt: any): void;
        private setSelectedOptionAutoplaySpinValue(currentlySelectedContainer);
        private setSelectedOptionsValues(type, value);
        private checkforClickOnSameOption(currentlySelectedContainer, previousSelectedContainerArray);
        private resetPreviouslySelectedOption(currentlySelectedContainer);
    }
}
declare namespace ingenuity.betssonui {
    class TopClockController {
        view: BSMainTopView;
        constructor(view: BSMainTopView);
        private subscribeEvents();
        private unSubscribeClockEvents();
        private intializeTopBarClockComponent();
        private startClockUpdateTimer();
        private updateClockTime();
        private clearClockTimer();
        private getMinuteToComplete();
        private getCurrentTime();
    }
}
declare namespace ingenuity.betssonui {
    class TopCoinValueController {
        view: BSMainTopView;
        constructor(view: BSMainTopView);
        private subscribeEvents();
        private updateTopBarCoinValueComponent(evt);
    }
}
declare namespace ingenuity.betssonui {
    class TopUKGCLimitsController {
        view: BSMainTopView;
        constructor(view: BSMainTopView);
        private subscribeEvents();
        private showWinLimitReachedMsg(evt);
        private showLossLimitReachedMsg(evt);
        private hideLimitsReachedMsg(evt);
    }
}
declare namespace ingenuity.betssonui {
    class Model {
        private showValuesInCredits;
        private boolSettingButtonPressed;
        private betOptionsConfigArra;
        private selectBetOptionConfig;
        private currentSelectedTotalBetValue;
        private autoplayOptionsConfigArra;
        private autoplayOptionsWinLimitArra;
        private autoplayOptionsLossLimitArra;
        private currentSelectedAutoSpinCount;
        private currentSelectedWinLimitValue;
        private currentSelectedLossLimitValue;
        private isInUKGCRegulation;
        private currentBetAccumulatedUKGC;
        private currentWinAccumulatedUKGC;
        private betOptionJSON;
        private autoplayOptionJSON;
        private gameSettingOptionJSON;
        constructor();
        setCurrentAccumulatedBetValueForUKGC(value: number): void;
        setCurrentAccumulatedWinValueForUKGC(value: number): void;
        resetUKGCData(): void;
        getCurrentAccumulatedBetValueForUKGC(): number;
        getCurrentAccumulatedWinValueForUKGC(): number;
        setCurrentSelectedWinLimitValue(value: any): void;
        getCurrentSelectedWinLimitValue(): any;
        setCurrentSelectedLossLimitValue(value: any): void;
        getCurrentSelectedLossLimitValue(): any;
        getIsInUKGCRegulation(): boolean;
        setIsInUKGCRegulation(value: boolean): void;
        setCurrentSelectedAutoSpinCount(value: any): void;
        getCurrentSelectedAutoSpinCount(): any;
        setCurrentSelectedTotalBet(value: number): void;
        getCurrentSelectedTotalBet(): number;
        setShowValuesInCredits(value: boolean): void;
        getBetOptionsConfigurations(): any[];
        setBetOptionsConfigurations(value: any[]): void;
        getDefaultSelectedBetConfigurations(): any;
        setDefaultSelectedBetConfigurations(value: any[]): void;
        getAutoplayNumbersConfigurations(): any[];
        setAutoplayNumbersConfigurations(value: any[]): void;
        getAutoplayWinLimitConfigurations(): any[];
        setAutoplayWinLimitConfigurations(value: any[]): void;
        getAutoplayLossLimitConfigurations(): any[];
        setAutoplayLossLimitConfigurations(value: any[]): void;
        getIsShowValuesInCredits(): boolean;
        setSettingButtonPressed(value: boolean): void;
        getSettingButtonPressed(): boolean;
        setBetOptionsViewJSON(optionsJson: any): void;
        getBetOptionsViewJSON(): any;
        setAutoplayOptionsViewJSON(optionsJson: any): void;
        getAutoplayOptionsViewJSON(): any;
        setGameSettingOptionsViewJSON(optionsJson: any): void;
        getGameSettingOptionsViewJSON(): any;
    }
}
declare namespace ingenuity.betssonui {
    class BSMainBottomView extends ui.BaseView {
        lblCashValue: ui.MeterBitmap;
        lblWinValue: ui.MeterBitmap;
        lblBetValue: ui.MeterBitmap;
        btnSoundOn: BSButtonBase;
        btnSoundOff: BSButtonBase;
        toolTipContainer: ui.Container;
        toolTipLabel: ui.Label;
        constructor(json: any);
        private initializeViewComponents();
        setCashValue(value: string, isValueInCredit: boolean): void;
        setWinValue(value: string, isValueInCredit: boolean): void;
        showToolTip(objXPosition: number, objYPosition: number, toolTipText: string): void;
        disabledBtn(btn: BSButtonBase): void;
        hideToolTip(): void;
        private changeToolTipVisibility();
        setBetValue(value: string, isValueInCredit: boolean): void;
        disabledAndHideSoundOnButton(): void;
        disabledAndHideSoundOffButton(): void;
        resize(e?: any): void;
    }
}
declare namespace ingenuity.betssonui {
    class BSMainAutoPlayOptionsView extends ui.BaseView {
        constructor(optionContainer: ui.Container, json: any, x: number, y: number, autoSpinCount: any);
        protected setAutoPlaySpinCounts(autoSpinCount: any): void;
        resize(e?: any): void;
    }
}
declare namespace ingenuity.betssonui {
    class BSMainBetSettingOptionsView extends ui.BaseView {
        constructor(optionContainer: ui.Container, json: any, x: number, y: number, totalBet: number, coinValue: number, coinSize: number, optionNumber: number);
        resize(e?: any): void;
        protected setTotalBets(totalBet: number): void;
        protected setCoinValues(coinValue: number): void;
        protected setCoinSize(coinSize: number): void;
    }
}
declare namespace ingenuity.betssonui {
    class BSMainGameSettingOptionsView extends ui.BaseView {
        constructor(optionContainer: ui.Container, json: any, config: any);
        resize(e?: any): void;
    }
}
declare namespace ingenuity.betssonui {
    class BSMainMiddleView extends ui.BaseView {
        private mainMiddleContainer;
        private betSettingPanel;
        private gameSettingPanel;
        private currentVisibleContainer;
        private currentPressedBtn;
        private currentHeading;
        private betSettingPanelHeading;
        private gameSettingPanelHeading;
        private autoPlaySettingPanel;
        private autoPlaySettingPanelHeading;
        private currencySymbol;
        private infoSettingPanel;
        private infoSettingPanelHeading;
        private paytableSettingPanel;
        private paytableSettingPanelHeading;
        constructor(json: any);
        private initializeViewComponents();
        hideBetSubSettingsPanel(): void;
        hideAutoplaySubSettingsPanel(): void;
        resize(e?: any): void;
        private hideMiddleSettingPanel();
        visibleSubSettingsPanel(SubSettingPanelName: string, btn: BSButtonBase): void;
        private hideCurrentVisibleSubPanel();
        private hideInfoIframe();
        private hidePaytableIframe();
        private visibleBetSubSettingsPanel(btn);
        private visibleGameSubSettingsPanel(btn);
        private visibleAutoPlaySubSettingsPanel(btn);
        private visibleInfoSubSettingsPanel(btn);
        private showIFrmaeParent();
        private visiblePaytableSubSettingsPanel(btn);
        private setThisPanelForCurrentView(container, btn, heading);
        private getCurrentVisiblePanel();
        private getCurrentPressedBtn();
        private getCurrentHeading();
        changeVisibilityOfSettingPanel(becomeVisible: boolean): void;
    }
}
declare namespace ingenuity.betssonui {
    class BSMainTopView extends ui.BaseView {
        private lblClockValue;
        private lblCoinValue;
        private lossLimitReachedMsg;
        private winLimitReachedMsg;
        constructor(json: any);
        private initializeViewComponents();
        resize(e?: any): void;
        setTimeInClock(value: string): void;
        showWinLimitMsg(): void;
        showLossLimitMsg(): void;
        hideLimitMsgs(): void;
        setCoinValue(value: string, isValueInCredit: boolean): void;
    }
}
declare namespace ingenuity.betssonui {
    class BaseGameView extends ui.BaseView {
        constructor(json: any);
        resize(e?: any): void;
    }
}
declare namespace ingenuity.betssonui {
    class PaytableView extends ui.BaseView {
        constructor(json: any);
        private initializePaytable();
        private subscribeEvents();
        resize(e?: any): void;
    }
}
