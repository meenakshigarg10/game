/* tslint:disable */
/// <reference path="../base/base-core.d.ts" />
declare namespace ingenuity {
    interface IInitGameResponse extends IObject {
        user?: IObject;
    }
    interface IBetResponse extends IObject {
        bet?: IObject;
    }
}
declare namespace ingenuity.platform {
    const EventConstants: {
        ENVIRONMENT_READY: string;
        HIDE_LOADER: string;
        ASSETS_LOADED: string;
        INIT_GAME: string;
        INIT_GAME_RESPONSE_RECEIVED: string;
        GAME_CLOSE_RESPONSE_RECEIVED: string;
        OPEN_GAME_COMPLETE: string;
        LOADING_STARTED: string;
        LOADING_PROGRESS: string;
        LOADING_COMPLETE: string;
        GAME_INITIALISED: string;
        GAME_STATUS_CHANGED: string;
        SOUND_STATUS_CHANGED: string;
        SHOW_GAME: string;
        PLACE_BET: string;
        PLACE_BET_RESPONSE: string;
        SELECT_FREE_SPIN_RESPONSE: string;
        GAMEPLAY_STARTED: string;
        GAMEPLAY_STARTED_RESPONSE: string;
        GAMEPLAY_ENDED: string;
        GAMEPLAY_ENDED_RESPONSE: string;
        BALANCE_UPDATED: string;
        JACKPOT_UPDATED: string;
        FULLSCREEN_MODE_ON: string;
        FULLSCREEN_MODE_OFF: string;
        TOTALWIN_UPDATED: string;
        TOTALBET_UPDATED: string;
        PAYTABLE_STATUS_CHANGED: string;
        AUTOPLAY_LIMIT_REACHED: string;
        GAME_VERSION_UPDATE: string;
        GAME_READY_FOR_UNLOAD: string;
        MENU_OPEN: string;
        MENU_CLOSED: string;
        POPUP_SHOW: string;
        TOPBAR_CHANGED: string;
        POPUP_CLOSE: string;
        ENVIROMENT_ERROR: string;
        OPERATOR_CHANGES_BET: string;
        SCREEN_INTRECTION_BLOCK: string;
        GAME_SUSPENDED: string;
        REQUEST_STATUS: string;
        LOADING_TYPE: string;
        GAME_STATE_CHANGED: string;
        SOUND_STATE_CHANGED: string;
        AUTOPLAY_ACTIVATED_GAME: string;
        AUTOPLAY_ACTIVATED_CONFIRMATION: string;
        RESIZE: string;
        BONUS_BET_RESPONSE: string;
        FREE_BET_RESPONSE: string;
        PARSE_JACKPOT_RESPONSE: string;
        BET_PARSED: string;
        BROKEN_BASE_GAME: string;
        BROKEN_FREE_GAME: string;
        FREE_GAME_ENDED: string;
        OPEN_GAME_PROCESSED: string;
        ERROR_RECEIVED_FROM_SERVER: string;
        SPIN_RESPONSE_PROCESSED: string;
        CLOSE_RESPONSE_PROCESSED: string;
        PARSE_EXTENDEDSPINSTYLES: string;
        SHOW_ERROR: string;
        PARSE_BONUS_RESPOSE: string;
        BONUS_PICK: string;
        FREE_BET: string;
        ERROR_IN_LOADING: string;
        GAME_CLOSE: string;
        FREE_GAME_STARTED: string;
    };
}
declare namespace ingenuity.platform.base {
    abstract class AbstractModel {
        private balance;
        private userBalance;
        private currentBetIndex;
        private defaultNumChips;
        private defaultChipSize;
        private currentWin;
        private totalWin;
        private currentBet;
        private minBet;
        private maxBet;
        private currentTotalBet;
        private currentGameState;
        private numChips;
        private chipSize;
        protected stakeArray: number[];
        private defaultBet;
        private numChipOptions;
        private currencyCode;
        private arrayNumChipUsed;
        private arrayNumChips;
        private isCredit;
        private playForFun;
        constructor();
        getBalance(): number;
        setBalance(value: number): void;
        getIsCredit(): boolean;
        setIsCredit(value: boolean): void;
        getUserBalance(): number;
        setUserBalance(value: number): void;
        getCurrentBetIndex(): number;
        setCurrentBetIndex(value: number): void;
        getDefaultNumChips(): number;
        setDefaultNumChips(value: number): void;
        getDefaultChipSize(): number;
        setDefaultChipSize(value: number): void;
        getCurrentWin(): number;
        setCurrentWin(value: number): void;
        getTotalWin(): number;
        setTotalWin(value: number): void;
        getCurrentBet(): number;
        setCurrentBet(value: number): void;
        getCurrentTotalBet(): number;
        setCurrentTotalBet(value: number): void;
        getCurrentGameState(): number;
        setCurrentGameState(value: number): void;
        getNumChips(): number;
        setNumChips(value: number): void;
        getChipSize(): number;
        setChipSize(value: number): void;
        getDefaultBet(): number;
        setDefaultBet(value: number): void;
        getNumChipOptions(): number[];
        setNumChipOptions(value: number[]): void;
        getCurrencyCode(): string;
        setCurrencyCode(value: string): void;
        getArrayNumChipUsed(): number[];
        setArrayNumChipUsed(value: number[]): void;
        getArrayNumChips(): number[];
        setArrayNumChips(value: number[]): void;
        resetForBet(): void;
        setPlayForFun(value: boolean): void;
        getPlayForFun(): boolean;
        setMaxBet(bet: number): void;
        getMaxBet(): number;
        setMinBet(bet: number): void;
        getMinBet(): number;
        getAllowBetOptions(): number[];
        setAllowBetOptions(stakeArray: number[]): void;
    }
}
declare namespace ingenuity.platform.base {
    abstract class AbstractParser {
        protected model: AbstractModel;
        constructor(model: AbstractModel);
        protected bindEvent(): void;
        protected abstract onInitResponseReceived(e?: IEvent): void;
        protected abstract parseInitResponse(response: IInitGameResponse): void;
        protected abstract parseBrokenResponse(response: IInitGameResponse): void;
        protected abstract onBetResponseReceived(e?: IEvent): void;
        protected abstract parseBetResponse(response: IBetResponse): void;
        protected onGameStartResponseReceived(e?: IEvent): void;
        protected onGameEndResponseReceived(e?: IEvent): void;
        protected onGameCloseResponseReceived(e?: IEvent): void;
        protected parseCloseResponse(response: IBetResponse): void;
    }
}
declare namespace ingenuity.platform.base {
    abstract class AbstractServerComm {
        protected model: AbstractModel;
        constructor(model: AbstractModel);
        protected bindEvent(): void;
        protected abstract sendInitRequest(evt?: IEvent): void;
        protected abstract sendBetRequest(evt?: IEvent): void;
        protected sendCloseGameRequest(evt?: IEvent): void;
    }
}
declare namespace ingenuity.platform.base {
    abstract class AbstractWrapper {
        constructor();
        protected bindEvent(): void;
        protected insufficientFund(evt?: IEvent): void;
        protected abstract environmentReady(evt?: IEvent): void;
        protected loadingStarted(evt?: IEvent): void;
        protected loadingInProgress(evt?: IEvent): void;
        protected loadingComplete(evt?: IEvent): void;
        protected soundStatusChanged(evt?: IEvent): void;
        protected enviormentError(evt?: IEvent): void;
        protected loadingError(evt?: IEvent): void;
        protected sendUpdateSignal(evt?: IEvent): void;
        protected gameCycleStarted(evt?: IEvent): void;
        protected gameCycleComplete(evt?: IEvent): void;
        protected balanceUpdated(evt?: IEvent): void;
        protected gameSuspended(evt?: IEvent): void;
        protected enviormentResize(evt?: IEvent): void;
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let base: {
        Model: typeof platform.base.AbstractModel;
        Parser: typeof platform.base.AbstractParser;
        ServerComm: typeof platform.base.AbstractServerComm;
        Wrapper: typeof platform.base.AbstractWrapper;
    };
}
declare namespace ingenuity {
    interface IWinLineObject extends IObject {
        positions: number[][];
        no: number;
        winSymLen: number;
        win: number;
        id: number;
    }
}
declare namespace ingenuity.platform.baseslot {
    const EventConstants: {
        FREE_BET: string;
        PLACE_FREE_GAME_BET_RESPONSE: string;
    };
}
declare namespace ingenuity.platform.baseslot {
    class Model extends base.AbstractModel {
        private currentTriggeringWin;
        private currentNumPaylines;
        private maxPaylines;
        private paylineCost;
        private triggerNumPaylines;
        private numRows;
        private numCols;
        private reelGrid;
        private triggerScatterWinData;
        private hasWin;
        private waysWinUniquePositions;
        private winLinesData;
        private scatterWinData;
        private waysWinData;
        private triggerReelGrid;
        private reelStops;
        private restoreFreeGame;
        private restoreBaseGame;
        private hasScatterWins;
        private hasRespin;
        private hasFreeGamesWin;
        private hasReFreeSpinWin;
        private freshFreeSpins;
        private hasTriggeringWin;
        private waysGame;
        private hasWaysWins;
        private hasLineWins;
        private triggerReelStops;
        private triggerWaysWinData;
        private triggerWinLinesData;
        private defaultActivePaylines;
        private freeSpinWin;
        private freeSpinNum;
        private oldFreeSpinNum;
        private freeSpinsRemaining;
        private freeSpinGuaranteedWin;
        private freeSpinMultiplierStatus;
        private freeSpinMultiplyGuaranteedWin;
        private freeSpinMultiplier;
        private freeReelSet;
        private fiveOfAKind;
        private reelSetIndex;
        private multiplier;
        private recover;
        private triggerMultiplier;
        private triggerReelSetIndex;
        private isGameIdle;
        private selectedLines;
        private retriggerFreeSpins;
        private isFreeSpinRetrigger;
        private waysWinAllUniquePositions;
        protected defaultGrid: string[][];
        protected freeSpinGrid: string[][];
        protected defaultStops: number[];
        protected isFreshFreePlay: boolean;
        protected isBrokenFreePlay: boolean;
        constructor();
        setSelectedLines(value: number | number[]): void;
        getSelectedLines(): number | number[];
        setIsGameIdle(value: boolean): void;
        getIsGameIdle(): boolean;
        setTriggerReelSetIndex(value: number): void;
        getTriggerReelSetIndex(): number;
        setTriggerMultiplier(value: number): void;
        getTriggerMultiplier(): number;
        setReelSetIndex(value: number): void;
        getReelSetIndex(): number;
        setMultiplier(value: number): void;
        getMultiplier(): number;
        getRecover(): boolean;
        setRecover(value: boolean): void;
        getCurrentTriggeringWin(): number;
        setCurrentTriggeringWin(value: number): void;
        getCurrentNumPaylines(): number;
        setCurrentNumPaylines(value: number): void;
        getMaxPaylines(): number;
        setMaxPaylines(value: number): void;
        getPaylineCost(): number;
        setPaylineCost(value: number): void;
        getTriggerNumPaylines(): number;
        setTriggerNumPaylines(value: number): void;
        getNumRows(): number;
        setNumRows(value: number): void;
        getNumCols(): number;
        setNumCols(value: number): void;
        getReelGrid(): number[][];
        setReelGrid(value: number[][]): void;
        getTriggerScatterWinData(): IWinLineObject[];
        setTriggerScatterWinData(value: IWinLineObject[]): void;
        getHasWin(): boolean;
        setHasWin(value: boolean): void;
        getWaysWinUniquePositions(): IObject[];
        setWaysWinUniquePositions(value: IObject[]): void;
        getWaysWinAllUniquePositions(): number[][];
        setWaysWinAllUniquePositions(value: number[][]): void;
        getWinLinesData(): IWinLineObject[];
        setWinLinesData(value: IWinLineObject[]): void;
        getScatterWinData(): IWinLineObject[];
        setScatterWinData(value: IWinLineObject[]): void;
        getWaysWinData(): IWinLineObject[];
        setWaysWinData(value: IWinLineObject[]): void;
        getTriggerReelGrid(): number[][];
        setTriggerReelGrid(value: number[][]): void;
        getReelStops(): number[];
        setReelStops(value: number[]): void;
        getRestoreFreeGame(): boolean;
        setRestoreFreeGame(value: boolean): void;
        getRestoreBaseGame(): boolean;
        setRestoreBaseGame(value: boolean): void;
        getHasScatterWins(): boolean;
        setHasScatterWins(value: boolean): void;
        getHasRespin(): boolean;
        setHasRespin(value: boolean): void;
        getHasFreeGamesWin(): boolean;
        setHasFreeGamesWin(value: boolean): void;
        getHasReFreeSpinWin(): boolean;
        setHasReFreeSpinWin(value: boolean): void;
        getFreshFreeSpins(): boolean;
        setFreshFreeSpins(value: boolean): void;
        getHasTriggeringWin(): boolean;
        setHasTriggeringWin(value: boolean): void;
        getWaysGame(): boolean;
        setWaysGame(value: boolean): void;
        getHasWaysWins(): boolean;
        setHasWaysWins(value: boolean): void;
        getHasLineWins(): boolean;
        setHasLineWins(value: boolean): void;
        getTriggerReelStops(): number[];
        setTriggerReelStops(value: number[]): void;
        getTriggerWaysWinData(): IWinLineObject[];
        setTriggerWaysWinData(value: IWinLineObject[]): void;
        getTriggerWinLinesData(): IWinLineObject[];
        setTriggerWinLinesData(value: IWinLineObject[]): void;
        getDefaultActivePaylinesCout(): number;
        getDefaultActivePaylines(): number[];
        setDefaultActivePaylines(value: number[]): void;
        getFreeSpinWin(): number;
        setFreeSpinWin(value: number): void;
        getFreeSpinNum(): number;
        setFreeSpinNum(value: number): void;
        getOldFreeSpinNum(): number;
        setOldFreeSpinNum(value: number): void;
        getFreeSpinsRemaining(): number;
        setFreeSpinsRemaining(value: number): void;
        getFreeSpinGuaranteedWin(): number;
        setFreeSpinGuaranteedWin(value: number): void;
        getFreeSpinMultiplierStatus(): number;
        setFreeSpinMultiplierStatus(value: number): void;
        getFreeSpinMultiplyGuaranteedWin(): number;
        setFreeSpinMultiplyGuaranteedWin(value: number): void;
        getFreeSpinMultiplier(): number;
        setFreeSpinMultiplier(value: number): void;
        getFreeReelSet(): number;
        setFreeReelSet(value: number): void;
        clearFreeSpinData(): void;
        set5OfKind(value: boolean): void;
        get5OfKind(): boolean;
        setRetriggerFreeSpins(value: number): void;
        getRetriggerFreeSpins(): number;
        setIsFreeSpinRetriggered(value: boolean): void;
        getIsFreeSpinRetriggered(): boolean;
        getDefaultGrid(): string[][];
        getfreeSpinGrid(): string[][];
        getDefaultStops(): number[];
        getHasFreshFreePlay(): boolean;
        setHasFreshFreePlay(bool: boolean): void;
        getHasBrokenFreePlay(): boolean;
        setHasBrokenFreePlay(bool: boolean): void;
        resetForBet(): void;
    }
}
declare namespace ingenuity.platform.baseslot {
    abstract class Parser extends base.AbstractParser {
        protected bindEvent(): void;
        protected abstract onFreeBetResponseReceived(e?: IEvent): void;
        protected abstract parseFreeBetResponse(response: IBetResponse): void;
    }
}
declare namespace ingenuity.platform.baseslot {
    abstract class ServerComm extends base.AbstractServerComm {
        protected bindEvent(): void;
        protected abstract sendFreeBetRequest(e?: IEvent): void;
    }
}
declare namespace ingenuity.platform.baseslot {
    abstract class Wrapper extends base.AbstractWrapper {
        constructor();
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let baseSlot: {
        Model: typeof platform.baseslot.Model;
        Parser: typeof platform.baseslot.Parser;
        ServerComm: typeof platform.baseslot.ServerComm;
        Wrapper: typeof platform.baseslot.Wrapper;
    };
}
declare namespace ingenuity.platform.aruze {
    class BrowserUtils {
        static getQueryString(param: string): string;
    }
}
declare namespace ingenuity.platform.aruze {
    const EventConstants: {
        PARSE_URL_PARAMS: string;
        ERROR_AT_WEBSOCKET_CONNECTION: string;
        SEND_END_REQUEST: string;
        SET_FREE_SPIN: string;
        FAILED_RECEIVED: string;
        ERROR_RECEIVED: string;
        END_GAME_RESONSE_RECEIVED: string;
        SESSION_EXPIRED: string;
        SEND_FREE_PLAY_REQUEST: string;
        SEND_CHEAT_REQUEST: string;
        CLOSE_XMLHTTPCONNECTION: string;
        URL_PARAMS_PROCESSED: string;
        INITIALIZED_WRAPPER: string;
        INITIALIZED_WRAPPERED_DONE: string;
        SEND_WRAPPER_READY: string;
        CHECK_AND_SEND_WRAPPER_READY: string;
        GET_UPDATE_BALANCE: string;
        GET_UPDATE_BALANCE_AFTER_BET: string;
        GET_UPDATE_BALANCE_AFTER_CLOSE: string;
        GET_UPDATE_BALANCE_ON_BROKEN: string;
        GET_UPDATE_BALANCE_ON_HISTORY: string;
        GET_UPDATE_BALANCE_ON_FREEGAME: string;
        START_REPLAY: string;
        END_REPLAY: string;
        UPDATED_BALANCE_RECEIVED: string;
        PARSE_FREE_SPIN_RESPONSE_HISTORY: string;
        UPDATE_FEATURE_IN_HISTORY: string;
        SEND_SELECT_FREE_SPIN_REQUEST: string;
        UPDATE_LOADER_PERCENTAGE: string;
        LOGIC_ONSTAKE_CHANGE: string;
        UPDATE_BS_WIN: string;
        DISABLED_ALL_BUTTONS: string;
        ENABLED_ALL_BUTTONS: string;
        GAME_PAUSE: string;
        GAME_RESUME: string;
        WRAPPER_READY: string;
        WRAPPER_PAUSE: string;
        WRAPPER_RESUME: string;
        UPDATE_WRAPPER_WIN: string;
        UPDATE_SOUND_STATE: string;
        ON_AUTO_PLAY_CLICKED: string;
        ON_STOP_AUTO_PLAY_CLICKED: string;
        BS_SOUND_STATUS_CHANGED: string;
        CLICK_BS_START_AUTOPLAY: string;
        INGAME_STOP: string;
        SPINS_COMPLETE: string;
        AUTOPLAY_DELAY: string;
        ENABLE_FEATURE_AFTER_WIN_LIMIT_POPUP: string;
        STOP_AUTOPLAY_BY_WRAPPER: string;
        LOSSLIMIT_REACHED: string;
        WINLIMIT_REACHED: string;
        SINGLE_WINLIMIT_REACHED: string;
        STOP_ON_WIN: string;
        STOP_ON_JACKPOT: string;
        SELECT_CARD_REQUEST: string;
        GAMBLE_RESPONSE_RECEIVED: string;
        GAMBLE_RESPONSE_PROCESSED: string;
        GAMBLE_ENABLE_REQUEST: string;
        GAMBLE_ENABLE_RESPONSE_RECEIVED: string;
        GAMBLE_BROKEN_RESPONSE_RECEIVED: string;
        SET_TICKET_DATA: string;
        GET_TICKET_DATA: string;
        GET_TICKET_DATA_RECEVIED: string;
        UPDATE_GAME_WIN_AMOUNT: string;
        PARSE_JP_METER_DATA: string;
        ENABLE_AUTOPLAY_FROM_WRAPPER: string;
    };
}
declare namespace ingenuity.slot.slotConstants.aruze {
    const SlotEventConstants: {
        SUSPEND_WINPRESENTATION: string;
        LOGIC_ONSTAKE_CHANGE: string;
        ENABLED_ALL_BUTTONS: string;
        SUBSCRIBE_EVENTS_ON_REEL_START_BG: string;
        RESET_METERS: string;
        SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
        SET_BET: string;
    };
}
declare namespace ingenuity.uiConstants.aruze {
    const eventConstants: {
        UPDATE_BS_BALANCE: string;
    };
}
declare namespace ingenuity.platform.aruze {
    class Constants {
        static LANG: string;
        static GAME_NAME: string;
        static GAME_ID: string;
        static GAME_TYPE: string;
        static RPC_URL: string;
        static GAME_CONTENT: string;
        static LANGUAGE: string;
        static HISTORY_MODE: string;
        static SCATTER_SYMBOL_ID: number;
        static SPIN_ACTION: string;
        static CLOSE_ACTION: string;
        static FREE_SPIN_ACTION: string;
        static SELECT_FREE_SPIN: string;
        static SOUND_MUTE: string;
        static SOUND_UNMUTE: string;
        static AUTOPLAY_DIALOG_CLOSED: string;
        static AUTOPLAY_STARTED: string;
        static AUTOPLAY_STOPPED: string;
        static AUTOPLAY_NEXT: string;
        static SET_STAKE_LIMITS: string;
        static STAKE_CHANGE: string;
        static account_data_received: string;
        static SET_AUTOPLAY_ENABLED: string;
    }
}
declare namespace ingenuity.platform.aruze {
    class Model extends baseslot.Model {
        private stake;
        private currentReelSetIndex;
        private wildMultiplier;
        private nextAction;
        private currentAction;
        private status;
        private serverVersion;
        private bettype;
        private linesWinAllUniquePositions;
        protected isScatterWithWin: boolean;
        protected gameMode: string;
        protected gameHistoryResponse: JSON;
        protected freeGameResponse: ingenuity.platform.aruze.IFreeSpinData;
        protected freeSpinCount: number;
        protected freeSpinWinAmt: number;
        private selectedFreespinIndex;
        private unpickedFreespinIndex;
        protected freegameBetType: string;
        protected ticketId: string;
        protected isFreeGameBroken: boolean;
        protected defaultGrid: string[][];
        protected triggeringGrid: number[][];
        protected defaultStops: number[];
        protected sendGetAccount: boolean;
        protected sendGetAccountAfterClose: boolean;
        protected errorOnBet: boolean;
        protected sendCloseRequest: boolean;
        protected isCloseResponseReceived: boolean;
        protected gambleWinAmt: number;
        localGambleAvai: number;
        protected gambleAvailable: boolean;
        drawnGambleCard: string[];
        randomCard: string[];
        protected playerSelectedGambleCard: string;
        protected gambleHistoryResponse: JSON;
        protected hasTurbo: boolean;
        protected hasSpinStop: boolean;
        protected hasAutoPlay: boolean;
        protected isAutoPlayRequired: boolean;
        protected gameWinAmt: number;
        protected isAutoPlayRunning: boolean;
        protected closeResponse: any;
        protected isAutoPlayNext: boolean;
        protected isGameWrapperReady: boolean;
        constructor();
        setIsGameWrapperReady(val: boolean): void;
        getIsGameWrapperReady(): boolean;
        setIsCloseResponseReceived(val: boolean): void;
        getIsCloseResponseReceived(): boolean;
        getSendGetAccount(): boolean;
        setSendGetAccount(value: boolean): void;
        getSendGetAccountAfterClose(): boolean;
        setSendGetAccountAfterClose(value: boolean): void;
        getSendCloseRequest(): boolean;
        setSendCloseRequest(value: boolean): void;
        getErrorOnBet(): boolean;
        setErrorOnBet(value: boolean): void;
        getFreegameBetType(): string;
        setFreegameBetType(value: string): void;
        getFreeSpinWinAmt(): number;
        setFreeSpinWinAmt(value: number): void;
        getFreeSpinCount(): number;
        setFreeSpinCount(value: number): void;
        getFreeGameResponse(): any;
        setFreeGameResponse(value: any): void;
        getGameHistoryResponse(): JSON;
        setGameHistoryResponse(value: JSON): void;
        getGameMode(): string;
        setGameMode(value: string): void;
        setTicketId(value: string): void;
        getTicketId(): string;
        setFreeGameBroken(value: boolean): void;
        getFreeGameBroken(): boolean;
        selectedFreespin(val: number): void;
        unpickedFreespin(val: number[]): void;
        getselectedFreespin(): number;
        getunpickedFreespin(): number[];
        getIsScatterWithWin(): boolean;
        setIsScatterWithWin(value: boolean): void;
        private gameState;
        private playToken;
        private demoMode;
        private vendor;
        private operator;
        private language;
        private bankURL;
        private homeURL;
        private realityCheckMinutes;
        private realityCheckElapsedMinutes;
        private realityCheckLobbyUrl;
        protected currencyCodeStr: string;
        protected thousandSeparator: string;
        protected freeSpinTrigger: boolean;
        protected decimalSeparator: string;
        private realityCheckHistoryUrl;
        protected isFreePlayModeOn: boolean;
        protected baseGameWinAmt: number;
        setGameState(value: string): void;
        getGameState(): string;
        setBaseGameWinAmt(value: number): void;
        getBaseGameWinAmt(): number;
        setGameStatus(data: string): void;
        getGameStatus(): string;
        getIsdemoMode(): string;
        setIsdemoMode(demoMode: string): void;
        getVendor(): string;
        setVendor(vendor: string): void;
        getOperator(): string;
        setOperator(operator: string): void;
        getLanguage(): string;
        setLanguage(lang: string): void;
        getBankURL(): string;
        setBankURL(bnkURL: string): void;
        getHomeURL(): string;
        setHomeURL(homeURL: string): void;
        getCurrencyCode(): string;
        setCurrencyCode(value: string): void;
        getDecimalSeparator(): string;
        setDecimalSeparator(value: string): void;
        getThousandSeparator(): string;
        setThousandSeparator(value: string): void;
        getRealityCheckMinutes(): string;
        setRealityCheckMinutes(RCM: string): void;
        getRealityCheckElapsedMinutes(): string;
        setRealityCheckElapsedMinutes(RCEM: string): void;
        getRealityCheckLobbyUrl(): string;
        setRealityCheckLobbyUrl(RCLU: string): void;
        getRealityCheckHistoryUrl(): string;
        setRealityCheckHistoryUrl(RCHU: string): void;
        setServerVersion(data: string): void;
        getServerVersion(): string;
        setNextAction(data: string): void;
        getNextAction(): string;
        setAction(data: string): void;
        getAction(): string;
        setStake(value: number[]): void;
        getStake(): number[];
        getCurrentBet(): number;
        getNextBet(): number;
        getPreviousBet(): number;
        setCurrentReelSetIndex(value: number): void;
        getCurrentReelSetIndex(): number;
        setWildMultiplier(value: number): void;
        getWildMultiplier(): number;
        setBetType(value: string): void;
        getBetType(): string;
        setFreePlayModeOn(data: boolean): void;
        getFreePlayModeOn(): boolean;
        getPlayToken(): string;
        setPlayToken(token: string): void;
        getIsFreeSpintriggered(): boolean;
        getLinesWinAllUniquePositions(): number[][];
        setLinesWinAllUniquePositions(value: number[][]): void;
        getTriggeringReelGridOnFgReturn(): number[][];
        setTriggeringReelGridOnFgReturn(value: number[][]): void;
        setGambleWinAmount(value: number): void;
        getGambleWinAmount(): number;
        setIsGambleAvailable(val: boolean): void;
        getIsGambleAvailable(): boolean;
        setGambleDrawnCard(val: string): void;
        getGambleDrawnCard(): string[];
        getRandomCardData(): string[];
        setPlayerSelectedGambleSymbol(val: string): void;
        getPlayerSelectedGambleSymbol(): string;
        setGambleResponseInHistory(val: JSON): void;
        getGambleResponseInHistory(): JSON;
        resetForBet(): void;
        setIsTurboEnable(val: boolean): void;
        getIsTurboEnable(): boolean;
        setIsSpinStopAvailable(val: boolean): void;
        getIsSpinStopAvailable(): boolean;
        getIsScatterWins(): boolean;
        setIsAutoPlayEnable(val: boolean): void;
        getIsAutoPlayEnable(): boolean | null;
        setIsAPRequired(val: boolean): void;
        getIsAPRequired(): boolean | null;
        setIsAutoPlayRunning(val: boolean): void;
        getIsAutoPlayRunning(): boolean;
        setCloseResponse(val: boolean): void;
        getCloseResponse(): boolean;
        setGameWinAmt(data: number): void;
        getGameWinAmt(): number;
    }
}
declare namespace ingenuity.platform.aruze {
    interface IResponseInit {
        game: IResponseStatus;
        config?: IResponseConfig;
        spin?: IResponseSlot;
        currentResponse?: IResponseSlot;
        spinRequest?: IResponseBet;
        freespin?: IFreeSpinData;
        freeSpin?: IFreeSpinData;
        spinResponse?: IResponseSlot;
    }
    interface IResponseStatus {
        action: string;
        nextAction: string;
        status: string;
        balance: number;
        totalWin: number;
        recover: boolean;
        version: string;
        ticketId: string;
    }
    interface IResponseSlot {
        reelSetIndex?: number;
        stops?: number[];
        st?: number[];
        grid?: string[][];
        g?: string[][];
        winnings: IResponseWin[];
        randomSymbol?: any;
        winAmount?: number;
        triggeringWinnings?: number;
        multiplier?: number;
        wildMultiplier: number;
        wM: number;
        spinsAwarded?: number;
        spinsRemaining?: number;
    }
    interface IResponseConfig {
        minBet: number;
        maxBet: number;
        defaultStake: string | number;
        stakeValues: number[];
        currency: string;
        defaultLineCount: number;
        hasTurbo?: boolean;
        hasSpinStop?: boolean;
        hasAutoPlay?: boolean;
    }
    interface IResponseWin {
        count: number;
        offset: number[];
        offsetsList: number[][];
        symbol: string;
        payline: number;
        payout: number;
    }
    interface IResponseBet {
        selectedLines: number;
        betPerLine: number;
        totalBet: number;
    }
    interface IFreeSpinData {
        spinsAwarded: number;
        spinsRemaining: number;
        spinsRetrigger: number;
        totalWin?: number;
        offsets?: number[];
        trigger: ITriggerData;
        stops?: number[];
        grid?: string[][];
        winnings: IResponseWin[];
        winAmount?: number;
        wildMultiplier: number;
        wM: number;
        reelSetIndex?: number;
        multiplier?: number;
    }
    interface ITriggerData {
        symbol: string;
        offset: number[];
    }
}
declare namespace ingenuity.platform.aruze {
    class Parser extends baseslot.Parser {
        protected model: Model;
        protected windowHref: string;
        constructor(model: Model);
        bindEvent(): void;
        protected updateGameWinAmt(): void;
        protected onInitResponseReceived(evt?: IEvent): void;
        protected parseInitResponse(response: IResponseInit): void;
        protected parseBrokenResponse(response: platform.aruze.IResponseInit): void;
        protected processDefaultBet(data: any): void;
        protected onBetResponseReceived(evt?: IEvent): void;
        protected processFreeSpinsData(freeSpindata: any): void;
        protected processGame(data: platform.aruze.IResponseStatus): void;
        protected updateBalance(evt: any): void;
        protected processConfig(data: IResponseConfig): void;
        protected processSlot(data: IResponseSlot): void;
        protected processTriggeringSpin(data: IResponseSlot): void;
        protected processView(data: string[][]): void;
        protected processTriggeringView(data: string[][]): void;
        protected processWinOffset(data: number[]): number[][];
        protected processWins(data: IResponseWin[]): void;
        protected processWaysWins(data: IResponseWin[]): void;
        protected processTriggeringWins(data: IResponseWin[]): void;
        protected parseBetResponse(response: IResponseInit): void;
        protected onFreeBetResponseReceived(evt?: IEvent): void;
        protected parseFreeBetResponse(response: IResponseInit): void;
        protected multiDimensionalUnique(arr: any): any;
        protected onGameCloseResponseReceived(evt?: IEvent): void;
        protected parseCloseResponse(response: IResponseInit): void;
        updateReelset(grid: number[][], reelStart: number, reelEnd: number, symbolIndex: number): number[][];
        protected parseFreeBetResponseHistory(evt: IEvent): void;
        protected processReelGrid(data: string[][]): void;
        protected parseSelectFreeSpinResponse(data: any): void;
        protected setGambleResponse(response: any): void;
        protected parseGambleResponse(response: any): void;
        protected gambleServerDrawnCard(gambleData: any): void;
        protected playerSelectedGambleSymbol(gambleData: any): void;
        protected setGambleWinAmount(gambleData: any): void;
    }
}
declare namespace ingenuity.platform.aruze {
    class ServerComm extends baseslot.ServerComm {
        protected model: Model;
        protected gameWrapper: any;
        protected bindEvent(): void;
        protected onInitializWrapper(evt: IEvent): void;
        protected sendInitRequest(evt?: IEvent): void;
        parseParam(): void;
        protected updateBalanceAfterBet(data: any): void;
        protected updateBalance(data: any): void;
        protected updateBalanceAfterClose(data: any): void;
        protected updateBalanceOnBroken(data: any): void;
        protected updateBalanceInFreeGame(data: any): void;
        protected sendHistoryRequest(): void;
        protected onEndReplay(evt: any): void;
        protected sendBetRequest(evt?: IEvent): void;
        protected sendFreeBetRequest(evt?: IEvent): void;
        protected sendCloseGameRequest(evt?: IEvent): void;
        protected sendSelectFreeSpinRequest(evt?: IEvent): void;
        protected sendGambleRequest(evt: IEvent): void;
        protected setTicketData(e: IEvent): void;
        protected getTicketData(): void;
        protected gambleEnableRequest(): void;
        protected getJackpotData(): void;
    }
}
declare namespace ingenuity.core.constructors.platforms {
    let aruze: {
        Model: typeof platform.aruze.Model;
        Parser: typeof platform.aruze.Parser;
        ServerComm: typeof platform.aruze.ServerComm;
    };
}
declare namespace ingenuity.platform.aruze {
    interface IRequestInit {
        action: string;
    }
    interface IRequestSpin {
        action: string;
        bet?: number;
        bettype?: string;
        cheat?: string | number[];
    }
}
declare namespace ingenuity.platform.aruze {
    class WrapperController extends baseslot.Wrapper {
        protected gameWrapper: any;
        protected sV: number[];
        protected bindEvent(): void;
        protected bindWrapperEvent(): void;
        protected setUpdatedBalance(evt: any): void;
        setWrapper(wrapper: any): void;
        protected environmentReady(): void;
        protected sendWrapperReady(): void;
        protected onGamePause(): void;
        protected onGameResume(): void;
        protected onInitializedWrapper(evt: IEvent): void;
        protected onStakeChange(evt?: IEvent): void;
        protected updateWinAmount(evt: IEvent): void;
        protected updateWrapperMuteState(evt: IEvent): void;
        protected updateGameStatue(): void;
        protected onSound(evt: any): void;
        protected offSound(evt: any): void;
        protected onAutoPlayStart(evt: any): void;
        protected onAutoPlayNext(evt: any): void;
        protected onAutoPlayStop(evt: IEvent): void;
        protected onAutoPlayStopFromWrapper(evt: any): void;
        protected autoplayEnabled(evt: any): void;
        protected openAutoPlayPopup(evt: any): void;
        protected closeAutoPlayPopup(evt: any): void;
        protected setLoaderProgress(evt: any): void;
        protected getUpdatedStack(evt: any): void;
        protected getChangedStack(evt: any): void;
        setBet(evt: IEvent): void;
    }
}
