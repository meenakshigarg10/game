/** 
	Pixi Bridge v1.0.6 
	©Ingenuity Gaming Pvt. Ltd.
	Published: Tue Sep 24 2019 16:29:33 GMT+0530 (India Standard Time) 
**/
/* tslint:disable */
/* tslint:disable */
/// <reference path="../pixi/pixi.d.ts" />
/// <reference path="../pixi-particles.d.ts" />
/// <reference path="../howler-core.d.ts" />
/// <reference path="../adapter-interface/adapter-interface.d.ts" />
/// <reference path="../pixi-spine.d.ts" />
declare namespace ingenuity.bridge {
    const enum RENDERER_TYPE {
        UNKNOWN = 0,
        WEBGL = 1,
        CANVAS = 2,
        AUTO = 3
    }
    const KeyCode: IObject;
    const PointerMode: {
        CURSOR: number;
        CONTACT: number;
    };
    let _Device: Device;
    const UNKNOWN = 0;
    const WEBGL = 1;
    const CANVAS = 2;
    const AUTO = 3;
    const HEADLESS = 3;
    const NONE = 0;
    const LEFT = 1;
    const RIGHT = 2;
    const UP = 3;
    const DOWN = 4;
    const SPRITE = 0;
    const BUTTON = 1;
    const IMAGE = 2;
    const GRAPHICS = 3;
    const TEXT = 4;
    const TILESPRITE = 5;
    const BITMAPTEXT = 6;
    const GROUP = 7;
    const RENDERTEXTURE = 8;
    const TILEMAP = 9;
    const TILEMAPLAYER = 10;
    const EMITTER = 11;
    const POLYGON = 12;
    const BITMAPDATA = 13;
    const CANVAS_FILTER = 14;
    const WEBGL_FILTER = 15;
    const ELLIPSE = 16;
    const SPRITEBATCH = 17;
    const RETROFONT = 18;
    const POINTER = 19;
    const ROPE = 20;
    const CIRCLE = 21;
    const RECTANGLE = 22;
    const LINE = 23;
    const MATRIX = 24;
    const POINT = 25;
    const ROUNDEDRECTANGLE = 26;
    const CREATURE = 27;
    const VIDEO = 28;
    const PENDING_ATLAS = -1;
    const HORIZONTAL = 0;
    const VERTICAL = 1;
    const LANDSCAPE = 0;
    const PORTRAIT = 1;
    const ANGLE_UP = 270;
    const ANGLE_DOWN = 90;
    const ANGLE_LEFT = 180;
    const ANGLE_RIGHT = 0;
    const ANGLE_NORTH_EAST = 315;
    const ANGLE_NORTH_WEST = 225;
    const ANGLE_SOUTH_EAST = 45;
    const ANGLE_SOUTH_WEST = 135;
    const TOP_LEFT = 0;
    const TOP_CENTER = 1;
    const TOP_RIGHT = 2;
    const LEFT_TOP = 3;
    const LEFT_CENTER = 4;
    const LEFT_BOTTOM = 5;
    const CENTER = 6;
    const RIGHT_TOP = 7;
    const RIGHT_CENTER = 8;
    const RIGHT_BOTTOM = 9;
    const BOTTOM_LEFT = 10;
    const BOTTOM_CENTER = 11;
    const BOTTOM_RIGHT = 12;
    /**
     * Various blend modes supported by bridge.
     *
     * IMPORTANT - The WebGL renderer only supports the NORMAL, ADD, MULTIPLY and SCREEN blend modes.
     * Anything else will silently act like NORMAL.
     * @ref DEMO (Official): https://pixijs.io/examples/#/demos-basic/blendmodes.js
     * @ref DEMO (with images): https://codepen.io/ianmcgregor/pen/CtjeI
     */
    const blendModes: typeof PIXI.BLEND_MODES;
    const scaleModes: {
        DEFAULT: number;
        LINEAR: number;
        NEAREST: number;
    };
    /**
     * The ideal target FPS.
     * IMPORTANT: don't change it unless quite necessary.
     */
    let FPS: number;
    let defaultRenderer: number;
    let EDisplayObject: typeof PIXI.DisplayObject;
    let EContainer: typeof PIXI.Container;
    let EGraphics: typeof PIXI.Graphics;
    let ECircle: typeof PIXI.Circle;
    let EEllipse: typeof PIXI.Ellipse;
    let EPolygon: typeof PIXI.Polygon;
    let ERectangle: typeof PIXI.Rectangle;
    let ERoundedRectangle: typeof PIXI.RoundedRectangle;
    let EPoint: typeof PIXI.Point;
    let ESprite: typeof PIXI.Sprite;
    let EAnimation: typeof PIXI.AnimatedSprite;
    let EBaseTexture: typeof PIXI.BaseTexture;
    let ESpritesheet: typeof PIXI.Spritesheet;
    let ETexture: typeof PIXI.Texture;
    let EText: typeof PIXI.Text;
    let EObservablePoint: typeof PIXI.ObservablePoint;
    let EBitmapText: typeof PIXI.BitmapText;
    let EParticleContainer: typeof PIXI.ParticleContainer;
    let EMatrix: typeof PIXI.Matrix;
    let ERenderTexture: typeof PIXI.RenderTexture;
}
declare namespace ingenuity.bridge {
    class Animation implements IAnimation {
        currentFrame: Frame;
        static SPEED_PRECISION: number;
        delay: number;
        frame: number;
        frameTotal: number;
        game: Game;
        isFinished: boolean;
        isPaused: boolean;
        isPlaying: boolean;
        killOnComplete: boolean;
        loop: boolean;
        loopCount: number;
        name: string;
        onComplete: Signal;
        onLoop: Signal;
        onStart: Signal;
        onUpdate: Signal;
        isReversed: boolean;
        speed: number;
        protected frameData: FrameData;
        protected frames: Array<number>;
        protected pauseStartTime: number;
        protected frameIndex: number;
        protected frameDiff: number;
        protected frameSkip: number;
        protected parent: Sprite;
        protected timeLastFrame: number;
        protected timeNextFrame: number;
        animationSpeed: number;
        private currentTime;
        private textures;
        private frameRate;
        protected prvFrameIndex: number;
        constructor(game: Game, parent: Sprite, texture: Array<Texture>, name: string, frameData: FrameData, frames: Array<number>, frameRate?: number, loop?: boolean);
        complete(): void;
        destroy(): void;
        static generateFrameNames(prefix: string, start: number, stop: number, suffix?: string, zeroPad?: number): string[];
        /**
         * Advances by the given number of frames in the Animation, taking the loop value into consideration.
         * @param quantity
         */
        next(quantity?: number): this;
        /**
         * Moves backwards the given number of frames in the Animation, taking the loop value into consideration.
         * @param quantity
         */
        previous(quantity?: number): this;
        /**
         * Plays this animation.
         * @param frameRate
         * @param loop
         * @param killOnComplete
         */
        play(frameRate?: number, loop?: boolean, killOnComplete?: boolean): this;
        /**
         * Stop this animation.
         * @param resetFrame
         * @param dispatchComplete
         */
        stop(resetFrame?: boolean, dispatchComplete?: boolean): this;
        /**
         * Internally this update is called every frame when animating.
         * The primary purpose of it is to dispatch signals, like: onLoop, onCompelete, onUpdate etc.
         */
        update(): boolean;
        gotoAndStop(frameNumber: number): void;
        updateFrameData(frameData: FrameData): void;
        readonly currFrame: number;
        /**
         * @returns whether you're checking for updates.
         */
        /**
        * The onUpdate signale is disabled by default due to its intensive nature. If you want to listen to it, then set `enableUpdate` as true.
        */
        enableUpdate: boolean;
        /**
         * @returns whether the animation is running in reverse order.
         */
        /**
        * Sets the reverse order.
        */
        reversed: boolean;
        /**
         * @returns whether the animation is paused right now.
         */
        /**
        * Pause the animation.
        */
        paused: boolean;
        /**
         * Called when the Game enters a paused state.
         */
        onPause(): void;
        /**
         * Called when the Game resumes from a paused state.
         */
        onResume(): void;
    }
}
declare namespace ingenuity.bridge {
    class AnimationManager implements IAnimationManager {
        currentAnim: Animation;
        currentFrame: Frame;
        frameDataObj: FrameData;
        game: Game;
        isLoaded: boolean;
        sprite: Sprite;
        updateIfVisible: boolean;
        private outputFrames;
        private anims;
        texture: Array<Texture>;
        constructor(sprite: Sprite);
        loadFrameData(frameData: FrameData, frame: string | number): boolean;
        add(name: string, frames?: number[] | string[], frameRate?: number, loop?: boolean, useNumericIndex?: boolean): Animation;
        private createTextureArrayFromNames;
        private createTextureArrayFromNumber;
        play(name: string, frameRate?: number, loop?: boolean, killOnComplete?: boolean): Animation;
        stop(name?: string, resetFrame?: boolean): void;
        update(): boolean;
        /**
         * Advances by the given number of frames in the Animation, taking the loop value into consideration.
         * @param quantity
         */
        next(quantity?: number): Animation;
        /**
         * Moves backwards the given number of frames in the Animation, taking the loop value into consideration.
         * @param quantity
         */
        previous(quantity?: number): Animation;
        getAnimation(name: string): Animation;
        destroy(): void;
        readonly frameData: FrameData;
        readonly frameTotal: number;
        paused: boolean;
        frame: number;
        readonly name: string;
        frameName: string;
    }
}
declare namespace ingenuity.bridge {
    class AnimationParser {
        static spriteSheet(game: Game, key: string, frameWidth: number, frameHeight: number, frameMax?: number, margin?: number, spacing?: number, skipFrames?: number): FrameData;
        static JSONData(game: Game, json: any): FrameData;
        static JSONDataPyxel(game: Game, json: any): FrameData;
        static JSONDataHash(game: Game, json: any): FrameData;
        static XMLData(game: Game, xml: any): FrameData;
    }
}
declare namespace ingenuity.bridge {
    class Frame implements IFrame {
        index: number;
        x: number;
        y: number;
        bottom: number;
        centerX: number;
        centerY: number;
        distance: number;
        height: number;
        name: string;
        right: number;
        rotated: boolean;
        sourceSizeH: number;
        sourceSizeW: number;
        spriteSourceSizeH: number;
        spriteSourceSizeW: number;
        spriteSourceSizeX: number;
        spriteSourceSizeY: number;
        trimmed: boolean;
        uuid: string;
        width: number;
        constructor(index: number, x: number, y: number, width: number, height: number, name: string);
        resize(width: number, height: number): void;
        setTrim(trimmed: boolean, actualWidth?: number, actualHeight?: number, destX?: number, destY?: number, destWidth?: number, destHeight?: number): void;
        clone(): Frame;
        getRect(out?: Rectangle): Rectangle;
    }
}
declare namespace ingenuity.bridge {
    class FrameData implements IFrameData {
        frames: Frame[];
        protected frameNames: any;
        constructor();
        addFrame(frame: Frame): Frame;
        getFrame(index: number): Frame;
        getFrameByName(name: any): Frame;
        checkFrameName(name: any): boolean;
        clone(): FrameData;
        getFrameRange(start: number, end: number, output: Frame[]): Frame[];
        getFrames(frames?: number[], useNumericIndex?: boolean, output?: Frame[]): Frame[];
        getFrameIndexes(frames?: number[] | string[], useNumericIndex?: boolean, output?: number[]): number[];
        destroy(): void;
        readonly total: number;
    }
}
declare namespace ingenuity.bridge {
    class Camera implements ICamera {
        x: number;
        y: number;
        game: Game;
        view: Rectangle;
        constructor(game: Game, id: number, x: number, y: number, width: number, height: number);
        setSize(width: number, height: number): void;
        width: number;
        height: number;
    }
}
declare namespace ingenuity.bridge {
    let GenericConstants: {
        SPINE_NAMESPACE: string;
        VIDEO_NAMESPACE: string;
    };
}
declare namespace ingenuity.bridge {
    interface ISpineData {
        atlas: string;
        json: any;
        images: any;
    }
    /**
     * Built-in FilterTypes.
     */
    const enum IFilterType {
        ALPHA_FILTER = 1,
        BLUR_FILTER = 2,
        BLUR_FILTER_PASS = 3,
        COLOR_MATRIX_FILTER = 4,
        DISPLACEMENT_FILTER = 5,
        FXAA_FILTER = 6,
        NOISE_FILTER = 7
    }
}
declare namespace ingenuity.bridge {
    class BitmapImage extends ESprite implements IImage {
        alive: boolean;
        angle: number;
        bottom: number;
        cameraOffset: Point;
        fixedToCamera: boolean;
        centerX: number;
        centerY: number;
        cropRect: Rectangle;
        /**
         * An empty Object that belongs to this image.
         * This value isn't ever used internally by Quest, but may be used by your own code, or
         * by any Plugins, to store data that needs to be associated with the Game Object,
         * without polluting the Game Object directly.
         */
        data: IObject;
        deltaX: number;
        deltaY: number;
        deltaZ: number;
        destroyPhase: boolean;
        events: Events;
        exists: boolean;
        frameData: FrameData;
        frame: string | number;
        frameName: string;
        fresh: boolean;
        game: Game;
        inCamera: boolean;
        input: InputHandler;
        inWorld: boolean;
        key: string | IRenderTexture | IVideo | Texture;
        lifespan: number;
        left: number;
        name: string;
        offsetX: number;
        offsetY: number;
        position: Point;
        right: number;
        scale: Point;
        scaleMax: Point;
        scaleMin: Point;
        smoothed: boolean;
        top: number;
        z: number;
        src: string;
        animations: AnimationManager;
        textures: Texture[];
        constructor(game: Game, x?: number, y?: number, key?: string, frame?: string | number, texture?: any);
        inputEnabled: boolean;
        loadFrameData(frameData: FrameData, frame: string | number): boolean;
        setFrame(frame: string | number, frameData: FrameData): void;
        private createTextureArray;
    }
}
declare namespace ingenuity.bridge {
    class BitmapText extends EBitmapText implements IBitmapText {
        game: Game;
        anchor: Point;
        fontSize: number;
        constructor(game: Game, text: string, json: any);
        setText(text: string): this;
    }
}
declare namespace ingenuity.bridge {
    class Sprite extends EAnimation implements ISprite {
        anchor: PIXI.ObservablePoint;
        blendMode: number;
        exists: boolean;
        shader: PIXI.Filter | PIXI.Shader;
        texture: any;
        tint: number;
        alive: boolean;
        angle: number;
        animations: AnimationManager;
        autoCull: boolean;
        bottom: number;
        centerX: number;
        centerY: number;
        checkWorldBounds: boolean;
        components: any;
        cropRect: IRectangle;
        customRender: boolean;
        data: any;
        protected frameId: any;
        fresh: boolean;
        inWorld: boolean;
        key: any;
        left: number;
        lifespan: number;
        maxHealth: number;
        name: string;
        offsetX: number;
        offsetY: number;
        previousPosition: IPoint;
        previousRotation: number;
        position: any;
        right: number;
        scale: any;
        scaleMin: IPoint;
        scaleMax: IPoint;
        smoothed: boolean;
        top: number;
        tintedTexture: HTMLCanvasElement;
        transformCallback: Function;
        transformCallbackContext: any;
        world: IPoint;
        x: number;
        y: number;
        z: number;
        game: Game;
        events: Events;
        textureArray: Array<Texture>;
        protected cropObj: any;
        input: InputHandler;
        onInputOver: Signal;
        onInputOut: Signal;
        onInputDown: Signal;
        onInputUp: Signal;
        frame?: string | number;
        frameName?: string;
        /**
         * When multiple spritesheets are present, which is this stores the name of the target spritesheet.
         */
        protected targetSpritesheet: string;
        /**
         * When multiple spritesheets are present, the frame index is in respect to it targetSpritesheet. To consider all the available spritesheets, use tagetFrameOffset.
         */
        protected tagetFrameOffset: number;
        /**
         * Creates a Sprite, which can be an image, animation, or a group of animations.
         * @param game
         * @param x
         * @param y
         * @param key The name of spritesheet. You can also provide it as an Spritesheets[]
         * @param frame
         * @param texture
         */
        constructor(game: Game, x?: number, y?: number, key?: string | string[] | any, frame?: string | number, texture?: any[]);
        /**
         * Handles when an array of spritesheet is given to select `frames` from.
         * It combines all the frames in all the spritesheets and then creates a final TextureArray. However using animation in such cases might be tricky.
         * @param key An array of spritesheets or images.
         * @param frame the frame to show.
         */
        protected initSpritesheets(key: string[], frame?: string | number): void;
        /**
         * When a single spritesheet (or an image) is provided to select frames from.
         * @param key Spritesheet, or an image.
         * @param frame Frame to select.
         */
        protected initSpritesheet(key: string, frame?: string | number): void;
        /**
         * Further initial settings needed after AnimationManager is initialized.
         * This sets `this.key` and loads frameData from a target spritesheet.
         * @param targetSheet
         * @param frame
         */
        protected postInit(targetSheet: string, frame?: string | number): void;
        /**
         * Enable/disable input on this sprite.
         */
        inputEnabled: boolean;
        /**
         * Sets the frame.
         * @param frame
         */
        setFrame(frame: Frame): void;
        protected createTextureArray(frames: Array<string>): void;
        /**
         * Changes the base texture of the sprite. The old texture is removed and the new one is referenced or fetched from the Cache.
         *
         * If your sprite is using a frame from a texture atlas and you just wish to change to another frame, then see the `frame` or `frameName` properties instead.
         *
         * You should only use `loadTexture` if you want to replace the base texture entirely.
         *
         * Calling this method causes a WebGL texture update, so use sparingly or in low-intensity portions of your game, or if you know the new texture is already on the GPU.
         * @param key This is the image or texture used by the Sprite during rendering.
         * @param frame frame of spritesheet.
         * @param stopAnimation Whether to stop already playing animation on the sprite.
         */
        loadTexture(key: string, frame?: any, stopAnimation?: boolean): void;
        /**
         * Overridden to call this sprite's currentAnim.update() that dispatches anim events like,
         * onLoop, onComplete etc.
         * @param deltaTime
         */
        update(deltaTime: number): void;
        setTexture(texture: Texture | PIXI.Texture, destroyBase?: boolean): void;
    }
}
declare namespace ingenuity.bridge {
    class Button extends BitmapImage implements IButton {
        static STATE_OVER: string;
        static STATE_OUT: string;
        static STATE_DOWN: string;
        static STATE_UP: string;
        type: number;
        physicsType: number;
        onOverSound: any;
        onOutSound: any;
        onDownSound: any;
        onUpSound: any;
        onOverSoundMarker: string;
        onOutSoundMarker: string;
        onDownSoundMarker: string;
        onUpSoundMarker: string;
        onInputOver: Signal;
        onInputOut: Signal;
        onInputDown: Signal;
        onInputUp: Signal;
        onOverMouseOnly: boolean;
        freezeFrames: boolean;
        forceOut: boolean;
        [key: string]: any;
        [key: number]: any;
        /**
         * Create a new `Button` object. A Button is a special type of Sprite that is set-up to handle Pointer events automatically.
         *
         * The four states a Button responds to are:
         *
         * * 'Over' - when the Pointer moves over the Button. This is also commonly known as 'hover'.
         * * 'Out' - when the Pointer that was previously over the Button moves out of it.
         * * 'Down' - when the Pointer is pressed down on the Button. I.e. touched on a touch enabled device or clicked with the mouse.
         * * 'Up' - when the Pointer that was pressed down on the Button is released again.
         *
         * A different texture/frame and activation sound can be specified for any of the states.
         *
         * Frames can be specified as either an integer (the frame ID) or a string (the frame name); the same values that can be used with a Sprite constructor.
         *
         * @class Button
         * @constructor
         * @extends Image
         * @param {Game} game Current game instance.
         * @param {number} [x=0] - X position of the Button.
         * @param {number} [y=0] - Y position of the Button.
         * @param {string} [key] - The image key (in the Game.Cache) to use as the texture for this Button.
         * @param {function} [callback] - The function to call when this Button is pressed.
         * @param {object} [callbackContext] - The context in which the callback will be called (usually 'this').
         * @param {string|integer} [overFrame] - The frame / frameName when the button is in the Over state.
         * @param {string|integer} [outFrame] - The frame / frameName when the button is in the Out state.
         * @param {string|integer} [downFrame] - The frame / frameName when the button is in the Down state.
         * @param {string|integer} [upFrame] - The frame / frameName when the button is in the Up state.
         */
        constructor(game: Game, x?: number, y?: number, key?: string, callback?: Function, callbackContext?: object, overFrame?: string | number, outFrame?: string | number, downFrame?: string | number, upFrame?: string | number);
        /**
         * Clears all of the frames set on this Button.
         *
         * @method Button#clearFrames
         */
        clearFrames(): void;
        /**
         * Called when this Button is removed from the World.
         *
         * @method Button#removedFromWorld
         * @protected
         */
        protected removedFromWorld(): void;
        /**
         * Set the frame name/ID for the given state.
         *
         * @method Button#setStateFrame
         * @private
         * @param {object} state - See `STATE_*`
         * @param {number|string} frame - The number or string representing the frame.
         * @param {boolean} switchImmediately - Immediately switch to the frame if it was set - and this is true.
         */
        protected setStateFrame(state: any, frame: number | string, switchImmediately: boolean): void;
        /**
         * Change the frame to that of the given state, _if_ the state has a frame assigned _and_ if the frames are not currently "frozen".
         *
         * @method Button#changeStateFrame
         * @private
         * @param {object} state - See `STATE_*`
         * @return {boolean} True only if the frame was assigned a value, possibly the same one it already had.
         */
        protected changeStateFrame(state: any): boolean;
        /**
         * Used to manually set the frames that will be used for the different states of the Button.
         *
         * Frames can be specified as either an integer (the frame ID) or a string (the frame name); these are the same values that can be used with a Sprite constructor.
         *
         * @method Button#setFrames
         * @public
         * @param {string|integer} [overFrame] - The frame / frameName when the button is in the Over state.
         * @param {string|integer} [outFrame] - The frame / frameName when the button is in the Out state.
         * @param {string|integer} [downFrame] - The frame / frameName when the button is in the Down state.
         * @param {string|integer} [upFrame] - The frame / frameName when the button is in the Up state.
         */
        setFrames(overFrame: number | string, outFrame: number | string, downFrame: number | string, upFrame: number | string): void;
        /**
         * Set the sound/marker for the given state.
         *
         * @method Button#setStateSound
         * @private
         * @param {object} state - See `STATE_*`
         * @param {Sound|AudioSprite} [sound] - Sound.
         * @param {string} [marker=''] - Sound marker.
         */
        private setStateSound;
        /**
         * Play the sound for the given state, _if_ the state has a sound assigned.
         *
         * @method Button#playStateSound
         * @private
         * @param {object} state - See `STATE_*`
         * @return {boolean} True only if a sound was played.
         */
        private playStateSound;
        /**
         * Sets the sounds to be played whenever this Button is interacted with. Sounds can be either full Sound objects, or markers pointing to a section of a Sound object.
         * The most common forms of sounds are 'hover' effects and 'click' effects, which is why the order of the parameters is overSound then downSound.
         *
         * Call this function with no parameters to reset all sounds on this Button.
         *
         * @method Button#setSounds
         * @public
         * @param {Sound|AudioSprite} [overSound] - Over Button Sound.
         * @param {string} [overMarker] - Over Button Sound Marker.
         * @param {Sound|AudioSprite} [downSound] - Down Button Sound.
         * @param {string} [downMarker] - Down Button Sound Marker.
         * @param {Sound|AudioSprite} [outSound] - Out Button Sound.
         * @param {string} [outMarker] - Out Button Sound Marker.
         * @param {Sound|AudioSprite} [upSound] - Up Button Sound.
         * @param {string} [upMarker] - Up Button Sound Marker.
         */
        setSounds(overSound: any, overMarker: string, downSound: any, downMarker: string, outSound: any, outMarker: string, upSound: any, upMarker: string): void;
        /**
         * The Sound to be played when a Pointer moves over this Button.
         *
         * @method Button#setOverSound
         * @public
         * @param {Sound|AudioSprite} sound - The Sound that will be played.
         * @param {string} [marker] - A Sound Marker that will be used in the playback.
         */
        setOverSound(sound: any, marker: string): void;
        /**
         * The Sound to be played when a Pointer moves out of this Button.
         *
         * @method Button#setOutSound
         * @public
         * @param {Sound|AudioSprite} sound - The Sound that will be played.
         * @param {string} [marker] - A Sound Marker that will be used in the playback.
         */
        setOutSound(sound: any, marker: string): void;
        /**
         * The Sound to be played when a Pointer presses down on this Button.
         *
         * @method Button#setDownSound
         * @public
         * @param {Sound|AudioSprite} sound - The Sound that will be played.
         * @param {string} [marker] - A Sound Marker that will be used in the playback.
         */
        setDownSound(sound: any, marker: string): void;
        /**
         * The Sound to be played when a Pointer has pressed down and is released from this Button.
         *
         * @method Button#setUpSound
         * @public
         * @param {Sound|AudioSprite} sound - The Sound that will be played.
         * @param {string} [marker] - A Sound Marker that will be used in the playback.
         */
        setUpSound(sound: any, marker: string): void;
        /**
         * Internal function that handles input events.
         *
         * @method Button#onInputOverHandler
         * @protected
         * @param {Button} sprite - The Button that the event occurred on.
         * @param {Pointer} pointer - The Pointer that activated the Button.
         */
        protected onInputOverHandler(btn: any, evt: Pointer, isOver: boolean): void;
        /**
         * Internal function that handles input events.
         *
         * @method Button#onInputOutHandler
         * @protected
         * @param {Button} sprite - The Button that the event occurred on.
         * @param {Pointer} pointer - The Pointer that activated the Button.
         */
        protected onInputOutHandler(btn: any, evt: Pointer, isOver: boolean): void;
        /**
         * Internal function that handles input events.
         *
         * @method Button#onInputDownHandler
         * @protected
         * @param {Button} sprite - The Button that the event occurred on.
         * @param {Pointer} pointer - The Pointer that activated the Button.
         */
        protected onInputDownHandler(btn: any, evt: Pointer, isOver: boolean): void;
        /**
         * Internal function that handles input events.
         *
         * @method Button#onInputUpHandler
         * @protected
         * @param {Button} sprite - The Button that the event occurred on.
         * @param {Pointer} pointer - The Pointer that activated the Button.
         */
        protected onInputUpHandler(btn: any, evt: Pointer, isOver: boolean): void;
    }
}
/**
 * This is the central cache for all the loaded game assets.
 * Accessible via: game.cache
 */
declare namespace ingenuity.bridge {
    class Cache implements ICache {
        static CANVAS: number;
        static IMAGE: number;
        static TEXTURE: number;
        static SOUND: number;
        static TEXT: number;
        static PHYSICS: number;
        static TILEMAP: number;
        static BINARY: number;
        static BITMAPDATA: number;
        static BITMAPFONT: number;
        static JSON: number;
        static XML: number;
        static VIDEO: number;
        static SHADER: number;
        static RENDER_TEXTURE: number;
        static SPINE: any;
        static DEFAULT: any;
        static MISSING: any;
        static DEFAULT_KEY: string;
        static DEFAULT_SRC: string;
        static MISSING_KEY: string;
        static MISSING_SRC: string;
        static READY_TIMEOUT: number;
        private _pendingCount;
        onReady: Signal;
        private game;
        private urlResolver;
        autoResolveURL: boolean;
        private cache;
        spine: any;
        private cacheMap;
        private urlMap;
        private urlTemp;
        constructor(game: Game);
        readonly isReady: boolean;
        addSpine(key: string, data: any): void;
        /**
         *
         * @param key key used to load spine.
         * @param property can be :- 1.atlas 2.json 3.images
         */
        getSpine(key: string): ISpineData;
        addBinary(key: string, binaryData: any): void;
        addBitmapFont(key: string, url: string, data: any, atlasData: any, atlasType: string, xSpacing?: number, ySpacing?: number): void;
        addBitmapFontFromAtlas(key: string, atlasKey: string, atlasFrame: string, dataKey: string, dataType?: string, xSpacing?: number, ySpacing?: number): void;
        addCanvas(key: string, canvas: HTMLCanvasElement, context?: CanvasRenderingContext2D): void;
        private addImages;
        /**
   * Adds a default image to be used in special cases such as WebGL Filters.
   * It uses the special reserved key of `__default`.
   * This method is called automatically when the Cache is created.
   * This image is skipped when `Cache.destroy` is called due to its internal requirements.
   *
   * @method Cache#addDefaultImage
   * @protected
   */
        addDefaultImage(): void;
        protected addImageAsync(key: string, src: any, callback: Function): void;
        private removePending;
        private addPending;
        private checkReady;
        private ready;
        addImage(key: string, url: string, data: any): any;
        addJSON(key: string, url: string, data: any): void;
        addMissingImage(): void;
        addRenderTexture(key: string, texture: any): void;
        addShader(key: string, url: string, data: any): void;
        addSound(key: string, url: string, data: any, webAudio: boolean, audioTag: boolean): void;
        addSpriteSheet(key: string, url: string, data: any, frameWidth: number, frameHeight: number, frameMax?: number, margin?: number, spacing?: number, skipFrames?: number): void;
        addText(key: string, url: string, data: any): void;
        addTextureAtlas(key: string, url: string, data: any, atlasData: any, format: number): void;
        addTilemap(key: string, url: string, mapData: any, format: number): void;
        addPhysicsData(key: string, url: string, mapData: any, format: number): void;
        addVideo(key: string, url: string, data: any, isBlob?: boolean): void;
        addXML(key: string, url: string, data: any): void;
        checkBinaryKey(key: string): boolean;
        checkBitmapDataKey(key: string): boolean;
        checkBitmapFontKey(key: string): boolean;
        checkCanvasKey(key: string): boolean;
        checkImageKey(key: string): boolean;
        checkJSONKey(key: string): boolean;
        checkKey(cache: number, key: string): boolean;
        checkRenderTextureKey?(key: string): boolean;
        checkShaderKey?(key: string): boolean;
        checkSoundKey(key: string): boolean;
        checkTextKey(key: string): boolean;
        checkTextureKey(key: string): boolean;
        checkTilemapKey(key: string): boolean;
        checkURL?(url: string): any;
        checkXMLKey(key: string): boolean;
        checkVideoKey(key: string): boolean;
        checkSpine(key: string): boolean;
        getBinary(key: string): any;
        getBitmapFont(key: string): any;
        getCanvas(key: string): HTMLCanvasElement;
        getFrame(key: string, cache?: number): IFrame;
        getFrameByIndex(key: string, index: number, cache?: number): IFrame;
        getFrameByName(key: string, name: string, cache?: number): IFrame;
        getFrameCount(key: string, cache?: number): number;
        getFrameData(key: string, cache?: number): IFrameData;
        getImage(key: string, full?: boolean): HTMLImageElement | any;
        getItem(key: string, cache: number, method?: string, property?: string): any;
        getJSON(key: string, clone?: boolean): any;
        getKeys(cache: number): string[];
        getRenderTexture?(key: string): any;
        getShader(key: string): string;
        getSound(key: string): any;
        getSoundData(key: string): any;
        getSpriteSheetKey(key: string): boolean;
        getText(key: string): string;
        getTextKeys(): string[];
        getTexture?(key: string): IRenderTexture;
        getTextureAtlasKey(key: string): boolean;
        getTextureFrame(key: string): IFrame;
        getTilemap(key: string): any;
        getTilemapData(key: string): any;
        getURL(url: string): any;
        getXML(key: string): any;
        getVideo(key: string): any;
        hasFrameData(key: string, cache: number): boolean;
        removeBinary(key: string): void;
        removeBitmapData(key: string): void;
        removeBitmapFont(key: string): void;
        removeCanvas(key: string): void;
        removeImage(key: string, destroyBaseTexture?: boolean): void;
        removeJSON(key: string): void;
        removeRenderTexture(key: string): void;
        removeShader(key: string): void;
        removeSound(key: string): void;
        removeSpriteSheet(key: string): void;
        removeText(key: string): void;
        removeTextureAtlas(key: string): void;
        removeTilemap(key: string): void;
        removeXML(key: string): void;
        removeVideo(key: string): void;
        removeSpine(key: string): void;
        destroy(): void;
        private resolveURL;
    }
}
declare namespace ingenuity.bridge {
    class Canvas {
        /**
         * Creates a `canvas` DOM element. The element is not automatically added to the document.
         *
         * @method Canvas.create
         * @param {object} parent - The object that will own the canvas that is created.
         * @param {number} [width=256] - The width of the canvas element.
         * @param {number} [height=256] - The height of the canvas element..
         * @param {string} [id=(none)] - If specified, and not the empty string, this will be set as the ID of the canvas element. Otherwise no ID will be set.
         * @param {boolean} [skipPool=false] - If `true` the canvas will not be placed in the CanvasPool global.
         * @return {HTMLCanvasElement} The newly created canvas element.
         */
        static create(parent: any, width: number, height: number, id: string, skipPool: boolean): Canvas;
        /**
         * Sets the background color behind the canvas. This changes the canvas style property.
         *
         * @method Canvas.setBackgroundColor
         * @param {HTMLCanvasElement} canvas - The canvas to set the background color on.
         * @param {string} [color='rgb(0,0,0)'] - The color to set. Can be in the format 'rgb(r,g,b)', or '#RRGGBB' or any valid CSS color.
         * @return {HTMLCanvasElement} Returns the source canvas.
         */
        setBackgroundColor(canvas: any, color: string): Canvas;
        /**
         * Sets the touch-action property on the canvas style. Can be used to disable default browser touch actions.
         *
         * @method Canvas.setTouchAction
         * @param {HTMLCanvasElement} canvas - The canvas to set the touch action on.
         * @param {string} [value] - The touch action to set. Defaults to 'none'.
         * @return {HTMLCanvasElement} The source canvas.
         */
        setTouchAction(canvas: any, value: string): Canvas;
        /**
         * Sets the user-select property on the canvas style. Can be used to disable default browser selection actions.
         *
         * @method Canvas.setUserSelect
         * @param {HTMLCanvasElement} canvas - The canvas to set the touch action on.
         * @param {string} [value] - The touch action to set. Defaults to 'none'.
         * @return {HTMLCanvasElement} The source canvas.
         */
        setUserSelect(canvas: any, value: string): Canvas;
        /**
         * Adds the given canvas element to the DOM. The canvas will be added as a child of the given parent.
         * If no parent is given it will be added as a child of the document.body.
         *
         * @method Canvas.addToDOM
         * @param {HTMLCanvasElement} canvas - The canvas to be added to the DOM.
         * @param {string|HTMLElement} parent - The DOM element to add the canvas to.
         * @param {boolean} [overflowHidden=true] - If set to true it will add the overflow='hidden' style to the parent DOM element.
         * @return {HTMLCanvasElement} Returns the source canvas.
         */
        addToDOM(canvas: any, parent: any, overflowHidden: boolean): Canvas;
        /**
         * Removes the given canvas element from the DOM.
         *
         * @method Canvas.removeFromDOM
         * @param {HTMLCanvasElement} canvas - The canvas to be removed from the DOM.
         */
        removeFromDOM(canvas: any): void;
        /**
         * Sets the transform of the given canvas to the matrix values provided.
         *
         * @method Canvas.setTransform
         * @param {CanvasRenderingContext2D} context - The context to set the transform on.
         * @param {number} translateX - The value to translate horizontally by.
         * @param {number} translateY - The value to translate vertically by.
         * @param {number} scaleX - The value to scale horizontally by.
         * @param {number} scaleY - The value to scale vertically by.
         * @param {number} skewX - The value to skew horizontaly by.
         * @param {number} skewY - The value to skew vertically by.
         * @return {CanvasRenderingContext2D} Returns the source context.
         */
        setTransform(context: any, translateX: number, translateY: number, scaleX: number, scaleY: number, skewX: number, skewY: number): any;
        /**
         * Sets the Image Smoothing property on the given context. Set to false to disable image smoothing.
         * By default browsers have image smoothing enabled, which isn't always what you visually want, especially
         * when using pixel art in a game. Note that this sets the property on the context itself, so that any image
         * drawn to the context will be affected. This sets the property across all current browsers but support is
         * patchy on earlier browsers, especially on mobile.
         *
         * @method Canvas.setSmoothingEnabled
         * @param {CanvasRenderingContext2D} context - The context to enable or disable the image smoothing on.
         * @param {boolean} value - If set to true it will enable image smoothing, false will disable it.
         * @return {CanvasRenderingContext2D} Returns the source context.
         */
        static setSmoothingEnabled(context: any, value: boolean): any;
        /**
         * Gets the Smoothing Enabled vendor prefix being used on the given context, or null if not set.
         *
         * @method Canvas.getSmoothingPrefix
         * @param {CanvasRenderingContext2D} context - The context to enable or disable the image smoothing on.
         * @return {string|null} Returns the smoothingEnabled vendor prefix, or null if not set on the context.
         */
        static getSmoothingPrefix(context: any): string | null;
        /**
         * Returns `true` if the given context has image smoothing enabled, otherwise returns `false`.
         *
         * @method Canvas.getSmoothingEnabled
         * @param {CanvasRenderingContext2D} context - The context to check for smoothing on.
         * @return {boolean} True if the given context has image smoothing enabled, otherwise false.
         */
        static getSmoothingEnabled(context: any): boolean;
        /**
         * Sets the CSS image-rendering property on the given canvas to be 'crisp' (aka 'optimize contrast' on webkit).
         * Note that if this doesn't given the desired result then see the setSmoothingEnabled.
         *
         * @method Canvas.setImageRenderingCrisp
         * @param {HTMLCanvasElement} canvas - The canvas to set image-rendering crisp on.
         * @return {HTMLCanvasElement} Returns the source canvas.
         */
        setImageRenderingCrisp(canvas: any): any;
        /**
         * Sets the CSS image-rendering property on the given canvas to be 'bicubic' (aka 'auto').
         * Note that if this doesn't given the desired result then see the CanvasUtils.setSmoothingEnabled method.
         *
         * @method Canvas.setImageRenderingBicubic
         * @param {HTMLCanvasElement} canvas The canvas to set image-rendering bicubic on.
         * @return {HTMLCanvasElement} Returns the source canvas.
         */
        setImageRenderingBicubic(canvas: any): any;
    }
}
declare namespace ingenuity.bridge {
    class CanvasPool {
        static pool: any;
        static create(parent: any, width: number, height: number): any;
        /**
         * Gets the first free canvas index from the pool.
         *
         * @method getFirst
         * @static
         * @return {number}
         */
        static getFirst(): number;
        static remove(parent: any): void;
        static removeByCanvas(canvas: any): void;
        static getTotal(): number;
        static getFree(): number;
    }
}
declare namespace ingenuity.bridge {
    class Circle extends ECircle implements ICircle {
        constructor(x?: number, y?: number, radius?: number);
        diameter: number;
        clone(): Circle;
        contains(x: number, y: number): boolean;
        static _contains(a: Circle, x: number, y: number): boolean;
        getBounds(): Rectangle;
        setTo(x: number, y: number, radius: number): Circle;
        circumferencePoint(): void;
        left: number;
        right: number;
        top: number;
        bottom: number;
    }
}
declare namespace ingenuity.bridge {
    class Container extends EContainer implements IContainer {
        json: IContainerJSON;
        onChildInputUp: Signal;
        game: Game;
        anchor: Point | any;
        signals: {
            [key: string]: Signal;
        };
        children: any[];
        name: string;
        renderable: boolean;
        rotation: number;
        visible: boolean;
        scale: any;
        total: number;
        /** If `exists = true` the container is updated every frame, otherwise it is skipped. */
        exists: boolean;
        _cursor: DisplayObject;
        cursorIndex: number;
        onDestroy: Signal;
        inputEnableChildren: boolean;
        readonly length: number;
        static DEFAULT_VALUES: {
            boundsStroke: number;
            boundsColor: number;
            boundsAlpha: number;
            boundsStroke_2: number;
            boundsColor_2: number;
            boundsAlpha_2: number;
        };
        constructor(json: any, game: Game, parent?: PIXI.Container, name?: string, addToStage?: boolean, enableBody?: boolean, physicsBodyType?: number);
        enablePixiInteractionEvents(): void;
        worldScale: Point;
        pageCursor: DisplayObject;
        next(): DisplayObject;
        previous(): DisplayObject;
        inputEnabled: boolean;
        setPivot(x: number, y?: number): void;
        setAnchor(x: number, y?: number): void;
        getJson(): any;
        /**
         * A event binder which in background binds an event to a signal
         * @param type Event string type.
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         */
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): this;
        /**
         * Removes the event binding with an event
         * @param type Event type.Must be mentioned in the events.EventConstants
         * @param handler - Binding Function.if not defined then it will remove all handlers from this event
         * @param scope - handler bind to an object.
         */
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): this;
        /**
         * Returns if the event is already subscribed
         * @param type
         */
        hasEvent(type: string): boolean;
        update(): void;
        /**
         * Fires a custom event
         * @param type event name/type to be fired
         * @param data data to be sent with event
         */
        fireEvent(type: string, data?: any, handler?: (evt?: IEvent | any, data?: IObject) => void, scope?: any): void;
        addChildAt(child: any, index: number): any;
        addChild(child: any, ...additionalChildren: any[]): any;
        removeChild(child: any): any;
        removeChildAt(index: number): any;
        /**
         * Displays the Bounds of the container
         * @param targetCoordinateSpace
         */
        showBounds(targetCoordinateSpace?: DisplayObject): void;
        fetchTextureFromAtlas(key: string, frame: string | number): Texture;
        /**
         * Get the first display object that exists, or doesn't exist.
         *
         * @param {boolean} [exists=true] - If true, find the first existing child; otherwise find the first non-existing child.
         * @return {any} The first child, or null if none found.
         */
        getFirstExists(exists?: boolean): any;
        /**
         * Returns the name of container & length of children"s in String
         * Example output: ```[Container (name: XYZ, numChildren: 5)]```
         */
        toString(): string;
        forEach(callback?: Function, callbackContext?: IObject, checkExists?: boolean): void;
        create(x: number, y: number, key: string, frame?: string | number, exists?: boolean, index?: number): Sprite | BitmapImage | DisplayObject | Graphics | Video;
        add(child: DisplayObject | Sprite | Graphics | BitmapImage | Video, silent?: boolean, index?: number): Sprite | BitmapImage | DisplayObject | Graphics | Video;
        bringToTop(child: any): void;
        sendToBack(child: any): void;
        /** ============ getters and setters ============ */
        left: number;
        right: number;
        top: number;
        bottom: number;
        centerX: number;
        centerY: number;
        destroy(options?: any): void;
        removeAll(destroy?: boolean, silent?: boolean, destroyTexture?: boolean): void;
        /**
         * Searches the Container for the first instance of a child with the `name`
         * property matching the given argument. Should more than one child have
         * the same name only the first instance is returned.
         *
         * Prefer using this.getChildByName(string).
         *
         * @param name
         */
        getByName(name: string): any;
        /**
         * Get the index position of the given child in this group.
         * @param child
         */
        getIndex(child: DisplayObject): number;
        /**
         * Reverses all children in this container.
         *
         * This operation applies only to immediate children and does not propagate to subgroups.
         */
        reverse(): void;
    }
}
declare namespace ingenuity.bridge {
    class DisplayObject extends EDisplayObject implements IDisplayObject {
    }
}
/**
 * This class overrides the PIXI.DisplayObject
 */
declare namespace ingenuity.bridge {
    class DisplayObjectContainer extends DisplayObject implements IDisplayObjectContainer {
        children: IDisplayObject[];
        height: number;
        width: number;
        ignoreChildInput: boolean;
        constructor(game?: Game);
        addChild(child: IDisplayObject): IDisplayObject;
        addChildAt(child: IDisplayObject, index: number): IDisplayObject;
        getBounds(skipUpdate?: boolean, rect?: Rectangle): Rectangle;
        getChildAt(index: number): IDisplayObject;
        getChildIndex(child: IDisplayObject): number;
        getLocalBounds(rect?: Rectangle): Rectangle;
        removeChild(child: IDisplayObject): IDisplayObject;
        removeChildAt(index: number): IDisplayObject;
        removeChildren(beginIndex?: number, endIndex?: number): IDisplayObject[];
        removeStageReference(): void;
        setChildIndex(child: IDisplayObject, index: number): void;
        swapChildren(child: IDisplayObject, child2: IDisplayObject): void;
        contains(child: IDisplayObject): boolean;
    }
}
declare namespace ingenuity.bridge {
    class Ellipse extends EEllipse implements IEllipse {
        constructor(x?: number, y?: number, width?: number, height?: number);
        clone(): Ellipse;
        contains(x: number, y: number): boolean;
        static _contains(a: Ellipse, x: number, y: number): boolean;
        getBounds(): Rectangle;
        setTo(x: number, y: number, width: number, height: number): Ellipse;
    }
}
declare namespace ingenuity.bridge {
    class Events implements IEvents {
        protected parent: any;
        onAddedToGroup: Signal;
        onRemovedFromGroup: Signal;
        onDestroy: Signal;
        onKilled: Signal;
        onRevived: Signal;
        onOutOfBounds: Signal;
        onEnterBounds: Signal;
        onInputOver: Signal;
        onInputOut: Signal;
        onInputDown: Signal;
        onInputUp: Signal;
        onDragStart: Signal;
        onDragUpdate: Signal;
        onDragStop: Signal;
        onAnimationStart: Signal;
        onAnimationComplete: Signal;
        onAnimationLoop: Signal;
        onRemovedFromWorld: Signal;
        [key: string]: any;
        [key: number]: any;
        constructor(sprite: any);
        destroy(): void;
    }
}
/**
 * The Graphics class contains methods used to draw primitive shapes such as lines, circles and rectangles to the display, and to color and fill them.
 * Note that because Graphics can share a GraphicsGeometry with other instances,
 * it is necessary to call destroy() to properly dereference the underlying GraphicsGeometry and avoid a memory leak.
 * Alternatively, keep using the same Graphics instance and call clear() between redraws.
 */
declare namespace ingenuity.bridge {
    class Graphics extends EGraphics implements IGraphics {
        name: string;
        position: any;
        json: any;
        pivot: Point;
        parent: any;
        renderable: boolean;
        rotation: number;
        visible: boolean;
        scale: Point;
        input: InputHandler;
        onInputOver: Signal;
        onInputOut: Signal;
        onInputDown: Signal;
        onInputUp: Signal;
        events: Events;
        game: Game;
        constructor(game?: Game, x?: number, y?: number);
        private addInputHandlers;
        protected onInputDownHandler(btn: any, evt: PointerEvent, isOver: boolean): void;
        protected onInputUpHandler(btn: any, evt: PointerEvent, isOver: boolean): void;
        protected onInputOverHandler(btn: any, evt: PointerEvent, isOver: boolean): void;
        protected onInputOutHandler(btn: any, evt: PointerEvent, isOver: boolean): void;
        inputEnabled: boolean;
        update(): void;
        generateCanvasTexture(scaleMode?: number, resolution?: number): PIXI.Texture;
    }
}
declare namespace ingenuity.bridge {
    class Loader implements ILoader {
        static TEXTURE_ATLAS_JSON_ARRAY: number;
        static TEXTURE_ATLAS_JSON_HASH: number;
        static TEXTURE_ATLAS_XML_STARLING: number;
        static PHYSICS_LIME_CORONA_JSON: number;
        static PHYSICS_bridge_JSON: number;
        static TEXTURE_ATLAS_JSON_PYXEL: number;
        onLoadStart: Signal;
        onLoadComplete: Signal;
        onPackComplete: Signal;
        onFileStart: Signal;
        onFileComplete: Signal;
        onFileError: Signal;
        protected game: Game;
        protected cache: Cache;
        private resetLocked;
        private isLoading;
        private hasLoaded;
        protected crossOrigin: boolean;
        baseURL: string;
        protected path: string;
        private headers;
        private useXDomainRequest;
        private onSoundLoaded;
        private _warnedAboutXDomainRequest;
        protected enableParallel: boolean;
        private maxParallelDownloads;
        private _withSyncPointDepth;
        private _fileList;
        private _flightQueue;
        private _processingHead;
        private _fileLoadStarted;
        private _totalPackCount;
        private _totalFileCount;
        private _loadedPackCount;
        private _loadedFileCount;
        constructor(game: Game);
        readonly progressFloat: number;
        readonly progress: number;
        resize(width?: number, height?: number): void;
        checkKeyExists(type: string, key: string): boolean;
        getAssetIndex(type: string, key: string): number;
        getAsset(type: string, key: string): any;
        reset(hard?: boolean, clearEvents?: boolean): void;
        addToFileList(type: string, key: string, url: string | string[] | object[], properties?: any, overwrite?: boolean, extension?: string): Loader;
        replaceInFileList(type: string, key: string, url: string, properties: any): Loader;
        pack(key: string, url: string, data?: any, callbackContext?: any): Loader;
        image(key: string, url?: any, overwrite?: boolean): Loader;
        images(keys: string[], urls?: any): Loader;
        text(key: string, url?: string, overwrite?: boolean): Loader;
        json(key: string, url?: string, overwrite?: boolean): Loader;
        shader(key: string, url?: string, overwrite?: boolean): Loader;
        xml(key: string, url?: string, overwrite?: boolean): Loader;
        script(key: string, url?: string, callback?: any, callbackContext?: any): Loader;
        binary(key: string, url?: string, callback?: any, callbackContext?: any): Loader;
        spritesheet(key: string, url: string, frameWidth: number, frameHeight: number, frameMax: number, margin: number, spacing: number): Loader;
        audio(key: string, urls?: string | string[] | object[], autoDecode?: boolean): Loader;
        protected onSoundLoadComplete(): void;
        audioSprite(key: string, urls?: string | string[] | object[], jsonURL?: string, jsonData?: string | object, autoDecode?: boolean): Loader;
        audiosprite(key: string, urls?: string | string[] | object[], jsonURL?: string, jsonData?: string | object, autoDecode?: boolean): Loader;
        video(key: string, urls?: string | string[] | object[], loadEvent?: string, asBlob?: boolean): Loader;
        tilemap(key: string, url?: string, data?: any, format?: number): Loader;
        bitmapFont(key: string, textureURL?: string, atlasURL?: string, atlasData?: object, xSpacing?: number, ySpacing?: number): Loader;
        atlasJSONArray(key: string, textureURL: string, atlasURL: string, atlasData?: object): Loader;
        atlasJSONHash(key: string, textureURL: string, atlasURL: string, atlasData?: object): Loader;
        atlasXML(key: string, textureURL: string, atlasURL: string, atlasData?: object): Loader;
        atlas(key: string, textureURL: string, atlasURL: string, atlasData?: object, format?: any): Loader;
        spine(key: string, url: string): Loader;
        withSyncPoint(callback: any, callbackContext: object): Loader;
        addSyncPoint(type: string, key: string): Loader;
        removeFile(type: string, key: string): void;
        removeAll(): void;
        start(): void;
        protected transformUrl(url: string, file?: any): boolean | string | any;
        protected totalLoadedFiles(): number;
        totalQueuedFiles(): number;
        protected totalLoadedPacks(): number;
        totalQueuedPacks(): number;
        private processLoadQueue;
        private finishedLoading;
        private asyncComplete;
        processPack(pack: any): void;
        private loadFile;
        private loadImageTag;
        private loadVideoTag;
        private loadAudioTag;
        private xhrLoad;
        private xhrLoadWithXDR;
        private getVideoURL;
        private getAudioURL;
        private fileError;
        private fileComplete;
        private jsonLoadComplete;
        private csvLoadComplete;
        private xmlLoadComplete;
        private parseXml;
        private updateProgress;
    }
}
declare namespace ingenuity.bridge {
    class LoaderParser {
        static bitmapFont(xml: any, baseTexture: any, xSpacing: number, ySpacing: number): any;
        static xmlBitmapFont(xml: any, baseTexture: any, xSpacing: number, ySpacing: number): any;
        static jsonBitmapFont(json: any, baseTexture: any, xSpacing: number, ySpacing: number): any;
        static finalizeBitmapFont(baseTexture: any, bitmapFontData: any): any;
    }
}
/**
 * Emitter is a lightweight particle emitter that uses PIXI.particles.Emitter.
 * It can be used for one-time explosions or for continuous effects like rain and fire.
 * All it really does is launch Particle objects out at set intervals, and fixes their positions and velocities accordingly.
 * Prefer creating Emitters via the Particle Manager.
 * Example use:
 * 1. game.add.emitter() through GameObjectFactory, or
 * 2. game.particles.createEmitter()
 *
 * @class bridge.Emitter
 *
 * To test out your config goto: https://pixijs.io/pixi-particles-editor/
 */
declare namespace ingenuity.bridge {
    class Emitter extends PIXI.particles.Emitter implements IEmitter {
        private _focusPaused;
        name: string;
        game: Game;
        constructor(particleParent: PIXI.Container | PIXI.ParticleContainer, particleImages: Array<PIXI.Texture | _IAnimEmitterData>, config: any, game: bridge.Game);
        /**
         * Utility function to pause the emission on focus loss.
         * Don't set it from outside. It needs to be called from bridge only.
         * If you need to pause/resume an emitter, pause it using emitter.autoupdate = false.
         */
        focusPause(): this;
        /**
         * Utility function to resume the paused emission on focus gain.
         * It needs to be called from bridge only.
         * If you need to pause/resume an emitter, resume it using emitter.autoupdate = true.
         */
        focusResume(): this;
        /**
         * @returns The id of the Emitter.
         * You can also use emitter.name
         */
        getId(): string;
        /**
         * Modify the textures of the emitter, even while running
         */
        modifyTexture(emitterData: IEmitterData): void;
        /**
         * Whether the emitter is active or not.
         */
        on: boolean;
        destroy(): void;
    }
}
/**
 * The ParticleContainer class is a really fast version of the Container built solely for speed, so use when you need a lot of sprites or particles.
 * The tradeoff of the ParticleContainer is that most advanced functionality will not work.
 * ParticleContainer implements the basic object transform (position, scale, rotation) and some advanced functionality like tint.
 * Other more advanced functionality like masking, children, filters, etc will not work on sprites in this batch.
 *
 * @ref http://pixijs.download/dev/docs/PIXI.ParticleContainer.html
 */
declare namespace ingenuity.bridge {
    class ParticleContainer extends EParticleContainer {
    }
}
declare namespace ingenuity.bridge {
    /**
     * Emitter anim Data as passed to Emitter.
     * Never create an Emitter direcly.
     */
    interface _IAnimEmitterData {
        framerate: number | string;
        loop: boolean;
        textures: Array<PIXI.Texture>;
    }
    interface IEmitters {
        [name: string]: Emitter;
    }
    /**
     * The Particle Manager for the game.
     * It controlls all the particle emitters and update them on every game update loop.
     * Always create particles via the Particle manager.
     */
    class Particles {
        emitters: IEmitters;
        game: Game;
        ID: number;
        private _paused;
        private _focusPaused;
        constructor(game: Game);
        /**
         * Adds a new Particle Emitter to the Particle Manager.
         * @param emitter - The emitter to be added to the particle manager.
         * @return The emitter that was added.
         */
        add(emitter: Emitter): Emitter;
        /**
         * Create an emitter
         * @param emitter
         * @param emitterData Image configurations for the particle
         * @param config
         */
        createEmitter(particleParent: bridge.Container, emitterData: IEmitterData | IAnimEmitterData, config: any): Emitter;
        /**
         * Returns an array of frames.
         * @param emitterData
         */
        generateFramesNormal(emitterData: IEmitterData): Array<PIXI.Texture>;
        /**
         * Returns an array of modified frames suitable for animated particles.
         * @param emitterData
         */
        generateFramesAnim(emitterData: IAnimEmitterData): Array<_IAnimEmitterData>;
        /**
         * Internal function to pause on focus loss.
         */
        private _focusPauseAll;
        /**
         * Internal function to resume on focus gain
         */
        private _focusResumeAll;
        isPaused(): boolean;
        /**
         * Pause all emitters
         */
        pauseAll(): void;
        /**
         * Resume all emitters.
         */
        resumeAll(): void;
        /**
         * Remove an existing Particle Emitter from the Particle Manager.
         * @method bridge.Particles#remove
         * @param emitter - The emitter to remove.
         */
        remove(emitterId: Emitter | string | number): void;
        /**
         * @param id
         * @returns Return the requested emitter, if found, otherwise returns null.
         */
        getEmitterById(id: string): Emitter;
        /**
         * This function does the initial settings for EmitterData
         * @param emitterData
         */
        initEmitterData(emitterData: IEmitterData | IAnimEmitterData): IEmitterData | IAnimEmitterData;
    }
}
declare namespace ingenuity.bridge {
    class Point extends EPoint implements IPoint {
        constructor(x?: number, y?: number);
        set(x?: number, y?: number): Point;
        clone(): Point;
        copyFrom(sourcePoint: Point): Point;
    }
}
declare namespace ingenuity.bridge {
    class Polygon extends EPolygon implements IPolygon {
        constructor(points: any[] | number[]);
        clone(): Polygon;
        contains(x: number, y: number): boolean;
        static _contains(a: Polygon, x: number, y: number): boolean;
        setTo(points: Array<Array<number> | Point | number>): Polygon;
    }
}
declare namespace ingenuity.bridge {
    class Rectangle extends ERectangle implements IRectangle {
        private _right;
        private _left;
        private _top;
        private _bottom;
        constructor(x?: number, y?: number, width?: number, height?: number);
        left: number;
        /**
         * returns the right edge of the rectangle
         *
         * @member {number}
         */
        right: number;
        /**
         * returns the top edge of the rectangle
         *
         * @member {number}
         */
        top: number;
        static sameDimensions(a: any, b: any): boolean;
        /**
         * returns the bottom edge of the rectangle
         *
         * @member {number}
         */
        bottom: number;
        static clone(a: any, output?: Rectangle): Rectangle;
        contains(x: number, y: number): boolean;
        static _contains(a: Rectangle, x: number, y: number): boolean;
        scale(x: number, y?: number): Rectangle;
        setTo(x: number, y: number, width: number, height: number): Rectangle;
        /**
        * Resize the Rectangle by providing a new width and height.
        * The x and y positions remain unchanged.
        *
        * @method Rectangle#resize
        * @param {number} width - The width of the Rectangle. Should always be either zero or a positive value.
        * @param {number} height - The height of the Rectangle. Should always be either zero or a positive value.
        * @return {Rectangle} This Rectangle object
        */
        resize(width: number, height: number): Rectangle;
    }
}
declare namespace ingenuity.bridge {
    class RenderTexture extends ERenderTexture implements IRenderTexture {
    }
}
declare namespace ingenuity.bridge {
    class RoundedRectangle extends ERoundedRectangle implements IRoundedRectangle {
        constructor(x?: number, y?: number, width?: number, height?: number, radius?: number);
        clone(): RoundedRectangle;
        contains(x: number, y: number): boolean;
        static _contains(a: RoundedRectangle, x: number, y: number): boolean;
    }
}
declare namespace ingenuity.bridge {
    class ScaleManager implements IScaleManager {
        static EXACT_FIT: number;
        static NO_SCALE: number;
        static SHOW_ALL: number;
        static RESIZE: number;
        static USER_SCALE: number;
        static MODES: string[];
        screenOrientation: string;
        game: Game;
        protected dom: DOM;
        width: number;
        height: number;
        minWidth: number;
        maxWidth: number;
        minHeight: number;
        maxHeight: number;
        forceLandscape: boolean;
        forcePortrait: boolean;
        incorrectOrientation: boolean;
        private _pageAlignHorizontally;
        private _pageAlignVertically;
        private _createdFullScreenTarget;
        fullScreenTarget: HTMLElement;
        aspectRatio: number;
        offset: Point;
        onOrientationChange: Signal;
        enterIncorrectOrientation: Signal;
        leaveIncorrectOrientation: Signal;
        hasPixiSetFullScreen: boolean;
        onFullScreenInit: Signal;
        onFullScreenChange: Signal;
        onFullScreenError: Signal;
        scaleFactor: Point;
        scaleFactorInversed: Point;
        compatibility: {
            supportsFullScreen: boolean;
            orientationFallback: string;
            noMargins: boolean;
            scrollTo: Point;
            forceMinimumDocumentHeight: boolean;
            canExpandParent: boolean;
            clickTrampoline: string;
        };
        margin: {
            left: number;
            top: number;
            right: number;
            bottom: number;
            x: number;
            y: number;
        };
        bounds: Rectangle;
        sourceAspectRatio: number;
        protected event: any;
        windowConstraints: {
            right: string;
            bottom: string;
        };
        parentIsWindow: boolean;
        parentScaleFactor: Point;
        trackParentInterval: number;
        onSizeChange: Signal;
        private onResize;
        private onResizeContext;
        private _pendingScaleMode;
        private _scaleMode;
        private _fullScreenScaleMode;
        parentNode: HTMLElement;
        private _fullScreenRestore;
        private _gameSize;
        private _userScaleFactor;
        private _userScaleTrim;
        private _lastUpdate;
        private _updateThrottle;
        private _updateThrottleReset;
        private _parentBounds;
        private _tempBounds;
        private _lastReportedCanvasSize;
        private _lastReportedGameSize;
        private _booted;
        constructor(game: Game, width: number, height: number);
        private _orientationChange;
        private _windowResize;
        private _fullScreenChange;
        private _fullScreenError;
        readonly isFullScreen: boolean;
        readonly currentScaleMode: number;
        readonly boundingParent: HTMLElement;
        readonly isPortrait: boolean;
        readonly isLandscape: boolean;
        scaleMode: number;
        fullScreenScaleMode: number;
        pageAlignHorizontally: boolean;
        pageAlignVertically: boolean;
        readonly isGamePortrait: boolean;
        readonly isGameLandscape: boolean;
        /**
         * Classify the orientation, per `getScreenOrientation`.
         *
         * @method ScaleManager#classifyOrientation
         * @private
         * @param {string} orientation - The orientation string, e.g. 'portrait-primary'.
         * @return {?string} The classified orientation: 'portrait', 'landscape`, or null.
         */
        private classifyOrientation;
        boot(): void;
        /**
         * Load configuration settings.
         *
         * @method ScaleManager#parseConfig
         * @protected
         * @param {object} config - The game configuration object.
         */
        parseConfig(config: IGameConfig): void;
        /**
         * Calculates and sets the game dimensions based on the given width and height.
         *
         * This should _not_ be called when in fullscreen mode.
         *
         * @method ScaleManager#setupScale
         * @protected
         * @param {number|string} width - The width of the game.
         * @param {number|string} height - The height of the game.
         */
        setupScale(width: number, height: number): void;
        /**
         * Returns the computed Parent size/bounds that the Display canvas is allowed/expected to fill.
         *
         * If in fullscreen mode or without parent (see {@link #parentIsWindow}),
         * this will be the bounds of the visual viewport itself.
         *
         * This function takes the {@link #windowConstraints} into consideration - if the parent is partially outside
         * the viewport then this function may return a smaller than expected size.
         *
         * Values are rounded to the nearest pixel.
         *
         * @method ScaleManager#getParentBounds
         * @protected
         * @param {Rectangle} [target=(new Rectangle)] - The rectangle to update; a new one is created as needed.
         * @return {Rectangle} The established parent bounds.
         */
        getParentBounds(target: Rectangle): Rectangle;
        /**
         * Set the actual Game size.
         * Use this instead of directly changing `game.width` or `game.height`.
         *
         * The actual physical display (Canvas element size) depends on various settings including
         * - Scale mode
         * - Scaling factor
         * - Size of Canvas's parent element or CSS rules such as min-height/max-height;
         * - The size of the Window
         *
         * @method ScaleManager#setGameSize
         * @public
         * @param {integer} width - _Game width_, in pixels.
         * @param {integer} height - _Game height_, in pixels.
         */
        setGameSize(width: number, height: number): void;
        /**
         * Set a User scaling factor used in the USER_SCALE scaling mode.
         *
         * The target canvas size is computed by:
         *
         *     canvas.width = (game.width * hScale) - hTrim
         *     canvas.height = (game.height * vScale) - vTrim
         *
         * This method can be used in the {@link ScaleManager#setResizeCallback resize callback}.
         *
         * @method ScaleManager#setUserScale
         * @param {number} hScale - Horizontal scaling factor.
         * @param {numer} vScale - Vertical scaling factor.
         * @param {integer} [hTrim=0] - Horizontal trim, applied after scaling.
         * @param {integer} [vTrim=0] - Vertical trim, applied after scaling.
         */
        setUserScale(hScale: number, vScale: number, hTrim: number, vTrim: number): void;
        /**
         * Sets the callback that will be invoked before sizing calculations.
         *
         * This is the appropriate place to call {@link #setUserScale} if needing custom dynamic scaling.
         *
         * The callback is supplied with two arguments `scale` and `parentBounds` where `scale` is the ScaleManager
         * and `parentBounds`, a Rectangle, is the size of the Parent element.
         *
         * This callback
         * - May be invoked even though the parent container or canvas sizes have not changed
         * - Unlike {@link #onSizeChange}, it runs _before_ the canvas is guaranteed to be updated
         * - Will be invoked from `preUpdate`, _even when_ the game is paused
         *
         * See {@link #onSizeChange} for a better way of reacting to layout updates.
         *
         * @method ScaleManager#setResizeCallback
         * @public
         * @param {function} callback - The callback that will be called each time a window.resize event happens or if set, the parent container resizes.
         * @param {object} context - The context in which the callback will be called.
         */
        setResizeCallback(callback: Function, context: IObject): void;
        /**
         * Signals a resize - IF the canvas or Game size differs from the last signal.
         *
         * This also triggers updates on {@link #grid} (FlexGrid) and, if in a RESIZE mode, `game.state` (StateManager).
         *
         * @method ScaleManager#signalSizeChange
         * @private
         */
        private signalSizeChange;
        /**
         * Set the min and max dimensions for the Display canvas.
         *
         * _Note:_ The min/max dimensions are only applied in some cases
         * - When the device is not in an incorrect orientation; or
         * - The scale mode is EXACT_FIT when not in fullscreen
         *
         * @method ScaleManager#setMinMax
         * @public
         * @param {number} minWidth - The minimum width the game is allowed to scale down to.
         * @param {number} minHeight - The minimum height the game is allowed to scale down to.
         * @param {number} [maxWidth] - The maximum width the game is allowed to scale up to; only changed if specified.
         * @param {number} [maxHeight] - The maximum height the game is allowed to scale up to; only changed if specified.
         * @todo These values are only sometimes honored.
         */
        setMinMax(minWidth: number, minHeight: number, maxWidth: number, maxHeight: number): void;
        /**
         * The ScaleManager.preUpdate is called automatically by the core Game loop.
         *
         * @method ScaleManager#preUpdate
         * @protected
         */
        preUpdate(): void;
        /**
         * Update method while paused.
         *
         * @method ScaleManager#pauseUpdate
         * @private
         */
        protected pauseUpdate(): void;
        /**
         * Updates the current orientation and dispatches orientation change events.
         *
         * @method ScaleManager#updateOrientationState
         * @private
         * @return {boolean} True if the orientation state changed which means a forced update is likely required.
         */
        private updateOrientationState;
        /**
         * Invoked when the game is resumed.
         *
         * @method ScaleManager#_gameResumed
         * @private
         */
        private _gameResumed;
        /**
         * window.orientationchange event handler.
         *
         * @method ScaleManager#orientationChange
         * @private
         * @param {Event} event - The orientationchange event data.
         */
        private orientationChange;
        /**
         * Queues/marks a size/bounds check as needing to occur (from `preUpdate`).
         *
         * @method ScaleManager#queueUpdate
         * @private
         * @param {boolean} force - If true resets the parent bounds to ensure the check is dirty.
         */
        private queueUpdate;
        /**
         * window.resize event handler.
         *
         * @method ScaleManager#windowResize
         * @private
         * @param {Event} event - The resize event data.
         */
        private windowResize;
        /**
         * Called automatically when the browser fullscreen request fails;
         * or called when a fullscreen request is made on a device for which it is not supported.
         *
         * @method ScaleManager#fullScreenError
         * @private
         * @param {Event} [event=undefined] - The fullscreenerror event; undefined if invoked on a device that does not support the Fullscreen API.
         */
        private fullScreenError;
        /**
         * Cleans up the previous fullscreen target, if such was automatically created.
         * This ensures the canvas is restored to its former parent, assuming the target didn't move.
         *
         * @method ScaleManager#cleanupCreatedTarget
         * @private
         */
        private cleanupCreatedTarget;
        /**
         * Called automatically when the browser enters of leaves fullscreen mode.
         *
         * @method ScaleManager#fullScreenChange
         * @private
         * @param {Event} [event=undefined] - The fullscreenchange event
         */
        private fullScreenChange;
        /**
         * Used to prepare/restore extra fullscreen mode settings.
         * (This does move any elements within the DOM tree.)
         *
         * @method ScaleManager#prepScreenMode
         * @private
         * @param {boolean} enteringFullscreen - True if _entering_ fullscreen, false if _leaving_.
         */
        private prepScreenMode;
        /**
         * Update the dimensions taking the parent scaling factor into account.
         *
         * @method ScaleManager#updateDimensions
         * @private
         * @param {number} width - The new width of the parent container.
         * @param {number} height - The new height of the parent container.
         * @param {boolean} resize - True if the renderer should be resized, otherwise false to just update the internal vars.
         */
        private updateDimensions;
        /**
         * Update relevant scaling values based on the ScaleManager dimension and game dimensions,
         * which should already be set. This does not change {@link #sourceAspectRatio}.
         *
         * @method ScaleManager#updateScalingAndBounds
         * @private
         */
        private updateScalingAndBounds;
        /**
         * Force the game to run in only one orientation.
         *
         * This enables generation of incorrect orientation signals and affects resizing but does not otherwise rotate or lock the orientation.
         *
         * Orientation checks are performed via the Screen Orientation API, if available in browser. This means it will check your monitor
         * orientation on desktop, or your device orientation on mobile, rather than comparing actual game dimensions. If you need to check the
         * viewport dimensions instead and bypass the Screen Orientation API then set: `ScaleManager.compatibility.orientationFallback = 'viewport'`
         *
         * @method ScaleManager#forceOrientation
         * @public
         * @param {boolean} forceLandscape - true if the game should run in landscape mode only.
         * @param {boolean} [forcePortrait=false] - true if the game should run in portrait mode only.
         */
        forceOrientation(forceLandscape: boolean, forcePortrait: boolean): void;
        /**
         * "Reset" the Display canvas and set the specified width/height.
         *
         * @method ScaleManager#resetCanvas
         * @private
         * @param {string} [cssWidth=(current width)] - The css width to set.
         * @param {string} [cssHeight=(current height)] - The css height to set.
         */
        private resetCanvas;
        /**
         * Updates the game / canvas position and size.
         *
         * @method ScaleManager#updateLayout
         * @private
         */
        private updateLayout;
        /**
         * Updates the Game state / size.
         *
         * The canvas margins may always be adjusted, even if alignment is not in effect.
         *
         * @method ScaleManager#reflowGame
         * @private
         */
        private reflowGame;
        /**
         * Scroll to the top - in some environments. See `compatibility.scrollTo`.
         *
         * @method ScaleManager#scrollTop
         * @private
         */
        private scrollTop;
        /**
         * The "refresh" methods informs the ScaleManager that a layout refresh is required.
         *
         * The ScaleManager automatically queues a layout refresh (eg. updates the Game size or Display canvas layout)
         * when the browser is resized, the orientation changes, or when there is a detected change
         * of the Parent size. Refreshing is also done automatically when public properties,
         * such as {@link #scaleMode}, are updated or state-changing methods are invoked.
         *
         * The "refresh" method _may_ need to be used in a few (rare) situtations when
         *
         * - a device change event is not correctly detected; or
         * - the Parent size changes (and an immediate reflow is desired); or
         * - the ScaleManager state is updated by non-standard means; or
         * - certain {@link #compatibility} properties are manually changed.
         *
         * The queued layout refresh is not immediate but will run promptly in an upcoming `preRender`.
         *
         * @method ScaleManager#refresh
         * @public
         */
        refresh(): void;
        /**
         * Updates the width/height to that of the window.
         *
         * @method ScaleManager#setMaximum
         * @private
         */
        private setMaximum;
        /**
         * Updates the width/height such that the game is stretched to the available size.
         * Honors {@link #maxWidth} and {@link #maxHeight} when _not_ in fullscreen.
         *
         * @method ScaleManager#setExactFit
         * @private
         */
        private setExactFit;
        /**
         * Updates the width/height such that the game is scaled proportionally.
         *
         * @method ScaleManager#setShowAll
         * @private
         * @param {boolean} expanding - If true then the maximizing dimension is chosen.
         */
        private setShowAll;
        /**
         * Updates the Display canvas size.
         *
         * The canvas margins may always be adjusted, even alignment is not in effect.
         *
         * @method ScaleManager#reflowCanvas
         * @private
         */
        private reflowCanvas;
        /**
         * Update the canvas position/margins - for alignment within the parent container.
         *
         * The canvas margins _must_ be reset/cleared prior to invoking this.
         *
         * @method ScaleManager#alignCanvas
         * @private
         * @param {boolean} horizontal - Align horizontally?
         * @param {boolean} vertical - Align vertically?
         */
        private alignCanvas;
        /**
         * Creates a fullscreen target. This is called automatically as as needed when entering
         * fullscreen mode and the resulting element is supplied to {@link #onFullScreenInit}.
         *
         * Use {@link #onFullScreenInit} to customize the created object.
         *
         * @method ScaleManager#createFullScreenTarget
         * @protected
         */
        createFullScreenTarget(): HTMLDivElement;
        /**
         * Start the browsers fullscreen mode - this _must_ be called from a user input Pointer or Mouse event.
         *
         * The Fullscreen API must be supported by the browser for this to work - it is not the same as setting
         * the game size to fill the browser window. See {@link ScaleManager#compatibility compatibility.supportsFullScreen} to check if the current
         * device is reported to support fullscreen mode.
         *
         * The {@link #fullScreenFailed} signal will be dispatched if the fullscreen change request failed or the game does not support the Fullscreen API.
         *
         * @method ScaleManager#startFullScreen
         * @public
         * @param {boolean} [antialias] - Changes the anti-alias feature of the canvas before jumping in to fullscreen (false = retain pixel art, true = smooth art). If not specified then no change is made. Only works in CANVAS mode.
         * @param {boolean} [allowTrampoline=undefined] - Internal argument. If `false` click trampolining is suppressed.
         * @return {boolean} Returns true if the device supports fullscreen mode and fullscreen mode was attempted to be started. (It might not actually start, wait for the signals.)
         */
        startFullScreen(antialias?: boolean, allowTrampoline?: boolean): boolean;
        /**
         * Stops / exits fullscreen mode, if active.
         *
         * @method ScaleManager#stopFullScreen
         * @public
         * @return {boolean} Returns true if the browser supports fullscreen mode and fullscreen mode will be exited.
         */
        stopFullScreen(): boolean;
        /**
         * Takes a Sprite or Image object and scales it to fit the given dimensions.
         * Scaling happens proportionally without distortion to the sprites texture.
         * The letterBox parameter controls if scaling will produce a letter-box effect or zoom the
         * sprite until it fills the given values. Note that with letterBox set to false the scaled sprite may spill out over either
         * the horizontal or vertical sides of the target dimensions. If you wish to stop this you can crop the Sprite.
         *
         * @method ScaleManager#scaleSprite
         * @protected
         * @param {Sprite|Image} sprite - The sprite we want to scale.
         * @param {integer} [width] - The target width that we want to fit the sprite in to. If not given it defaults to ScaleManager.width.
         * @param {integer} [height] - The target height that we want to fit the sprite in to. If not given it defaults to ScaleManager.height.
         * @param {boolean} [letterBox=false] - True if we want the `fitted` mode. Otherwise, the function uses the `zoom` mode.
         * @return {Sprite} The scaled sprite.
         */
        scaleSprite(sprite: Sprite | BitmapImage | any, width: number, height: number, letterBox: boolean): Sprite | BitmapImage | any;
        /**
         * Destroys the ScaleManager and removes any event listeners.
         * This should probably only be called when the game is destroyed.
         *
         * @method ScaleManager#destroy
         * @protected
         */
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    class Sound implements ISound {
        private howl;
        key?: string;
        private playid?;
        private _volume;
        private _muted;
        private _loop;
        onMarkerComplete: Signal;
        onLoop: Signal;
        /**
         * Creates a new sound object with given `Howl` and `Sound Sprite Key`
         * @param howl The howl object that contains this sound
         * @param key The Key of the sound in sound sprite.
         */
        constructor(howl: Howl, key?: string);
        /**
         * Gets or Sets the volume of this sound.
         * @type {number}
         */
        volume: number;
        /**
         * Gets or sets the muted state of this sound.
         * @type {boolean}
         */
        muted: boolean;
        /**
         * To make it backward-compatible with game still using mute
         */
        /**
        * To make it compatible with game still using mute
        */
        mute: boolean;
        /**
         * Gets if the sound is playing. Setting it to false pauses the sound if it is playing.
         * @type {boolean}
         */
        soundPlaying: boolean;
        /**
         * get or set the looping state of this sound
         */
        loop: boolean;
        /**
         * Play this sound.
         * @param loop Set the sound to loop.
         */
        play(loop?: boolean): Sound;
        /**
         * Function to be executed on the end of sound.
         */
        protected onSoundEnd(soundId?: number): void;
        /**
         * Pause this sound.
         */
        pause(): Sound;
        /**
         * Stop this sound.
         */
        stop(): Sound;
        /**
         * Fade volume of currently playing sound to a new value. Can be used to both fade in and fade out;
         * @param toVolume Sound volume to fade till.
         * @param duration Duration in milliseconds of the time it take to fade the sound.
         * @param tocallback Callback Function to execute once volume has reached the `toVolume`
         */
        fade(toVolume: number, duration?: number, tocallback?: Function): Sound;
    }
}
/**
 * If you need sounds in groups, use this class via soundManager#addGroup method.
 * Example:
 * 1. sfx
 * 2. Background music.
 */
declare namespace ingenuity.bridge {
    class SoundGroup implements ISoundGroup {
        private sounds;
        constructor();
        add(sound: Sound): SoundGroup;
        muteGroup(): SoundGroup;
        unmuteGroup(): SoundGroup;
        stopGroup(): SoundGroup;
    }
}
declare namespace ingenuity.bridge {
    class SoundManager implements ISoundManager {
        noAudio: boolean;
        touchLocked: boolean;
        context: AudioContext;
        usingWebAudio: boolean;
        usingAudioTag: boolean;
        channels: number;
        masterGain: GainNode;
        onLoadComplete: Signal;
        game: Game;
        private _howls;
        private _sounds;
        private _groups;
        private _pausedSounds;
        private _enabled;
        private _muted;
        protected defaultKey: string;
        private _unlockSource;
        onTouchUnlock: Signal;
        allowMultiple: boolean;
        constructor(game: Game);
        /**
         * Gets or sets weather Sound Manager is Enabled. Set to False to disable.
         * @type {boolean}
         */
        enabled: boolean;
        /**
         * Gets or sets the muted state of Sound Manager.
         * @type {boolean}
         */
        muted: boolean;
        /**
         * Add a new sound or sound sprite to this manager.
         * @param sound The Sound File
         * @param {string[]} sound Sound Files in preference of order.
         * @param {object} sound An object describing a sound sprite.
         * @param {string[]} sound.resources Sound Files Array.
         * @param {Array} sound.spritemap sound-sprite frames information
         */
        add(sound: string | Array<any> | IObject, key: string): SoundManager;
        play(soundId: string, volume?: number, loop?: boolean, key?: string): Sound;
        pause(soundId: string, key?: string): void;
        resume(soundId: string, key?: string): void;
        isSoundPlaying(soundId: string, key?: string): boolean;
        stop(soundId: string, key?: string): void;
        muteSound(value: boolean, soundId: string, key?: string): void;
        unmuteSound(soundId: string, key?: string): void;
        isSoundMuted(soundId: string, key?: string): boolean;
        addSprite(sound?: string): SoundManager;
        /**
         * Returns the sound object associated with the given soundId. Returns `undefined` if no matching sound object found.
         * @param key The soundId of the associated sound object.
         * @returns {iSound} Matching Sound Object.
         */
        getSoundByKey(soundId: string, key?: string): Sound | undefined;
        /**
         * Adds a new Sound Group in the mangar.
         * @param groupId ID/Key of the new group to create.
         * @returns {HowlerSoundGroup} Returns the newly created sound group, or an existing group if the ID already exists.
         */
        addGroup(groupId: string): SoundGroup;
        /**
         * Get a Sound Group by its ID/Key.
         * @param groupId The ID of the group to get.
         * @returns {HowlerSoundGroup | undefined} HowlerSoundGroup that belongs to this ID, or `undefined` in case now matching Group is found
         */
        getGroup(groupId: string): SoundGroup | undefined;
        /**
         * Pause all playing sounds.
         */
        pauseAllSounds(): void;
        /**
         * Resume all Sounds that were paused by manager.
         */
        resumeAllSounds(): void;
        /**
         * Stop all the sounds.
         */
        stopAllSounds(): void;
        /**
         * Sets the Master volume. All
         * @param volume
         */
        setMasterVolume(volume: number): ISoundManager;
        getMasterVolume(): number;
        /**
         * Gets/Sets the soundManager master volume. They're synonymous to setMasterVolume() and getMasterVolume().
         * volume is in the range [0, 1].
         * Prefer setMasterVolume() and getMasterVolume();
         */
        volume: number;
        destroy(key: string): void;
        boot(): void;
        setTouchLock(): void;
        unlock(): boolean;
        setTouchUnlock(): void;
        resumeWebAudio(): Promise<void>;
    }
}
declare namespace ingenuity.bridge {
    class Spine extends PIXI.spine.Spine implements ISpine {
        game: Game;
        anchor: Point;
        onEvent: Signal;
        onComplete: Signal;
        onEnd: Signal;
        onInterrupt: Signal;
        onStart: Signal;
        onDispose: Signal;
        events: Events;
        input: InputHandler;
        onInputOver: Signal;
        onInputOut: Signal;
        onInputDown: Signal;
        onInputUp: Signal;
        constructor(game: Game, x: number, y: number, key: string, premultipliedAlpha?: boolean);
        angle: number;
        private setPivot;
        private static fetchSpineData;
        setAnimationByName(trackIndex: number, animationName: string, loop?: boolean): PIXI.spine.core.TrackEntry;
        setToSetupPose(): void;
        /**
         * @returns whether this spine takes input or not.
         */
        /**
        * Enables it to take input.
        */
        inputEnabled: boolean;
    }
}
declare namespace ingenuity.bridge {
    class Spritesheet extends ESpritesheet {
        private frameKeysNames;
        constructor(baseTexture: any, data: IObject, resolutionFilename?: string);
        protected _processFrames(initialFrameIndex: number): void;
    }
}
declare namespace ingenuity.bridge {
    class Stage implements IStage {
        exists: boolean;
        currentRenderOrderID: number;
        smoothed: boolean;
        children: any[];
        height: number;
        width: number;
        ignoreChildInput: boolean;
        protected game: Game;
        protected hiddenVar: string;
        constructor(game?: Game);
        /**
         * By default if the game loses focus the game will pause. You can stop that behaviour by setting this property to true.
         */
        readonly disableVisibilityChange: boolean;
        boot(): void;
        add(): void;
        preUpdate(): void;
        update(): void;
        render(): void;
        postUpdate(): void;
        updateTransform(): void;
        checkVisibility(): void;
        destroy(): void;
        visibilityChange(event: Event): void;
        protected onChange(event: Event): void;
        protected onClick(event: Event): void;
    }
}
declare namespace ingenuity.bridge {
    class Text extends EText implements IText {
        game: Game;
        /**
         * Modify following default static values as needed.
         */
        static DEFAULT_VALUES: {
            fontFamily: string;
            align: string;
            fill: string;
            stroke: string;
            strokeThickness: number;
            wordWrap: boolean;
            wordWrapWidth: number;
            boundsAlignH: string;
            boundsAlignV: string;
            miterLimit: number;
        };
        private textBounds;
        protected dirty: boolean;
        constructor(game: Game, x: number, y: number, text?: string, style?: ITextStyleBridge, canvas?: HTMLCanvasElement);
        boundsAlignH: string;
        boundsAlignV: string;
        lineSpacing: number;
        fontSize: number | string;
        /**
         * This methods converts the @bridge textstyleoptions to @PIXI Textstyle
         * Exclusion :- bridge Textstyle @interface ITextStyleBridge doesn't include any shadow effects while Pixi TextstyleOptions @interface PIXI.Textstyle does.
         * shadowing will be handled in base core separately.
         * @method Text#getPixiTextStyle
         * @private @static
         * @param style : Style as defined in bridge.Textstyle, passed by base-core, @interface ITextStyleBridge
         * @returns @instance PIXI.Textstyle
         */
        private static getPixiTextStyle;
        /**
        * This methods extracts the fontstyle options @interface PIXI.Textstyle from font('bold 20 Arial') string
        * by breaking down the individual style values {fontWeight:bold,fontStyle:Arial,fontSize:20pt }
        * @method Text#fontToComponents
        * @private @static
        * @param font : font string as passed by bridge.Textstyle @interface ITextStylebridge e.g :- 'bold 20pt Arial'.
        * @returns @instance PIXI.TexTextStyleOptions
        */
        private static fontToComponents;
        /**
* Sets a drop shadow effect on the Text. You can specify the horizontal and vertical distance of the drop shadow with the `x` and `y` parameters.
* The color controls the shade of the shadow (default is black) and . be either an `rgba` or `hex` value.
* The blur is the strength of the shadow. A value of zero means a hard shadow, a value of 10 means a very soft shadow.
* To remove a shadow already in place you can call this method with no parameters set.
*
* @method bridge.Text#setShadow
* @param {number} [x=0] - The shadowOffsetX value in pixels. This is how far offset horizontally the shadow effect will be.
* @param {number} [y=0] - The shadowOffsetY value in pixels. This is how far offset vertically the shadow effect will be.
* @param {string} [color='rgba(0,0,0,1)'] - The color of the shadow, as given in CSS rgba or hex format. Set the alpha component to 0 to disable the shadow.
* @param {number} [blur=0] - The shadowBlur value. Make the shadow softer by applying a Gaussian blur to it. A number from 0 (no blur) up to approx. 10 (depending on scene).
* @param {boolean} [shadowStroke=true] - Apply the drop shadow to the Text stroke (if set).//Not supported in pixi now. @no-use
* @param {boolean} [shadowFill=true] - Apply the drop shadow to the Text fill (if set).
* @return {bridge.Text} This Text instance.
*/
        setShadow(x?: number, y?: number, color?: string, blur?: number, shadowStroke?: boolean, shadowFill?: boolean): Text;
        /**
* The text to be displayed by this Text object.
* Use a \n to insert a carriage return and split the text.
* The text will be rendered with any style currently set.
*
* Use the optional `immediate` argument if you need the Text display to update immediately.
*
* If not it will re-create the texture of this Text object during the next time the render
* loop is called.
*
* @method Text#setText
* @param {string} [text] - The text to be displayed. Set to an empty string to clear text that is already present.
* @param {boolean} [immediate=false] - Update the texture used by this Text object immediately (true) or automatically during the next render loop (false).
* @return {Text} This Text instance.
*/
        setText(text: string, immediate?: boolean): Text;
        /**
        * Private Method to set up an imaginary rectangle which will act as a container
        * Alignment and anchor positions will be set according to this rectangle
        * @param x Rectangle's x coordinate
        * @param y Rectangle's y coordinate
        * @param width Rectangle's Width
        * @param height Rectangle's Height
        * @return @Text
        */
        setTextBounds(x?: number, y?: number, width?: number, height?: number): Text;
        /**
 * Updates the texture based on the canvas dimensions.
 *
 * @method Text#updateTexture
 * @private
 */
        updateTexture(): void;
        /**
    * Set the style of the text by passing a single style object to it.
    *
    * @method bridge.Text#setStyle
    * @param {object} [style] - The style properties to be set on the Text.
    * @param {string} [style.font='bold 20pt Arial'] - The style and size of the font.
    * @param {string} [style.fontStyle=(from font)] - The style of the font (eg. 'italic'): overrides the value in `style.font`.
    * @param {string} [style.fontVariant=(from font)] - The variant of the font (eg. 'small-caps'): overrides the value in `style.font`.
    * @param {string} [style.fontWeight=(from font)] - The weight of the font (eg. 'bold'): overrides the value in `style.font`.
    * @param {string|number} [style.fontSize=(from font)] - The size of the font (eg. 32 or '32px'): overrides the value in `style.font`.
    * @param {string} [style.fill='black'] - A canvas fillstyle that will be used on the text eg 'red', '#00FF00'.
    * @param {string} [style.align='left'] - Horizontal alignment of each line in multiline text. Can be: 'left', 'center' or 'right'. Does not affect single lines of text (see `textBounds` and `boundsAlignH` for that).
    * @param {string} [style.boundsAlignH='left'] - Horizontal alignment of the text within the `textBounds`. Can be: 'left', 'center' or 'right'.
    * @param {string} [style.boundsAlignV='top'] - Vertical alignment of the text within the `textBounds`. Can be: 'top', 'middle' or 'bottom'.
    * @param {string} [style.stroke='black'] - A canvas stroke style that will be used on the text stroke eg 'blue', '#FCFF00'.
    * @param {number} [style.strokeThickness=0] - A number that represents the thickness of the stroke. Default is 0 (no stroke).
    * @param {boolean} [style.wordWrap=false] - Indicates if word wrap should be used.
    * @param {number} [style.wordWrapWidth=100] - The width in pixels at which text will wrap.
    * @param {boolean} [update=false] - Immediately update the Text object after setting the new style? Or wait for the next frame.
    * @return {bridge.Text} This Text instance.
    */
        setStyle(style?: ITextStyleBridge, update?: boolean): Text;
        protected updateText(respectDirty?: boolean): void;
    }
}
declare namespace ingenuity.bridge {
    class Texture extends ETexture implements ITexture {
        static TextureSilentFail: boolean;
        frame: Rectangle;
        crop: Rectangle;
        noFrame: boolean;
        baseTexture: IBaseTexture;
        trim: Rectangle;
        valid: boolean;
        isTiling: boolean;
        requiresUpdate: boolean;
        requiresReTint: boolean;
        scope: any;
        rotated: boolean;
        constructor(baseTexture: any, frame?: Rectangle, crop?: Rectangle, trim?: Rectangle);
        width: number;
        /**
         * The height of the Texture in pixels.
         *
         * @member {number}
         */
        height: number;
        /**
         * TODO: Make parameters compulsory, once pixi.d.ts is updated.
         * @param canvas
         * @param scaleMode
         */
        static fromCanvas(canvas?: any, scaleMode?: number): Texture;
        onBaseTextureLoaded(): void;
        destroy(destroyBase: boolean): void;
        setFrame(frame: Rectangle): void;
    }
}
declare namespace ingenuity.bridge {
    class Tilemap {
        static CSV: number;
        static TILED_JSON: number;
        static NORTH: number;
        static EAST: number;
        static SOUTH: number;
        static WEST: number;
    }
}
declare namespace ingenuity.bridge {
    class Touch implements ITouch {
        game: Game;
        touchLockCallbacks: IObject[];
        preventDefault: boolean;
        enabled: boolean;
        private _onTouchStart;
        private _onTouchEnd;
        private _onTouchMove;
        private _onTouchEnter;
        private _onTouchLeave;
        private _onTouchCancel;
        callbackContext: IObject;
        touchMoveCallback: Function;
        touchEnterCallback: Function;
        touchLeaveCallback: Function;
        touchCancelCallback: Function;
        active: boolean;
        event: any;
        constructor(game: Game);
        /**
         * Starts the event listeners running.
         * @method Touch#start
         */
        start(): void;
        /**
         * Adds a callback that is fired when a browser touchstart or touchend event is received.
         *
         * This is used internally to handle audio and video unlocking on mobile devices.
         *
         * If the callback returns 'true' then the callback is automatically deleted once invoked.
         *
         * The callback is added to the Touch.touchLockCallbacks array and should be removed with Touch.removeTouchLockCallback.
         *
         * @method Touch#addTouchLockCallback
         * @param {function} callback - The callback that will be called when a touchstart event is received.
         * @param {object} context - The context in which the callback will be called.
         * @param {boolean} [onEnd=false] - Will the callback fire on a touchstart (default) or touchend event?
         */
        addTouchLockCallback(callback: Function, context: Object, onEnd?: boolean): void;
        /**
         * Removes the callback at the defined index from the Touch.touchLockCallbacks array
         *
         * @method Touch#removeTouchLockCallback
         * @param {function} callback - The callback to be removed.
         * @param {object} context - The context in which the callback exists.
         * @return {boolean} True if the callback was deleted, otherwise false.
         */
        removeTouchLockCallback(callback: Function, context: Object): boolean;
        /**
         * The handler for the touchmove events.
         * @method bridge.Touch#onTouchMove
         * @param {TouchEvent} event - The native event from the browser. This gets stored in Touch.event.
         */
        onTouchMove(event: TouchEvent): void;
        /**
         * For touch enter and leave its a list of the touch points that have entered or left the target.
         * Doesn't appear to be supported by most browsers on a canvas element yet.
         * @method bridge.Touch#onTouchLeave
         * @param {TouchEvent} event - The native event from the browser. This gets stored in Touch.event.
         */
        onTouchLeave(event: TouchEvent): void;
        /**
         * The internal method that handles the touchstart event from the browser.
         * Will only handle audio/video unlocking for now
         * @method Touch#onTouchStart
         * @param {TouchEvent} event - The native event from the browser. This gets stored in Touch.event.
         */
        onTouchStart(event: TouchEvent): void;
        /**
         * The handler for the touchend events.
         * @method Touch#onTouchEnd
         * @param {TouchEvent} event - The native event from the browser. This gets stored in Touch.event.
         */
        onTouchEnd(event: TouchEvent): void;
        /**
         * For touch enter and leave its a list of the touch points that have entered or left the target.
         * Doesn't appear to be supported by most browsers on a canvas element yet.
         * @method bridge.Touch#onTouchEnter
         * @param {TouchEvent} event - The native event from the browser. This gets stored in Touch.event.
         */
        onTouchEnter(event: TouchEvent): void;
        /**
         * Touch cancel - touches that were disrupted (perhaps by moving into a plugin or browser chrome).
         * Occurs for example on iOS when you put down 4 fingers and the app selector UI appears.
         * @method bridge.Touch#onTouchCancel
         * @param {TouchEvent} event - The native event from the browser. This gets stored in Touch.event.
         */
        onTouchCancel(event: TouchEvent): void;
        /**
         * Stop the event listeners.
         * @method Touch#stop
         */
        stop(): void;
    }
}
declare namespace ingenuity.bridge {
    class Video extends PIXI.Sprite implements IVideo {
        game: Game;
        video: HTMLVideoElement;
        key: string;
        url: string;
        baseTexture: IBaseTexture;
        type: number;
        disableTextureUpload: boolean;
        touchLocked: boolean;
        onPlay: ISignal;
        onChangeSource: ISignal;
        onComplete: ISignal;
        onAccess: ISignal;
        onError: ISignal;
        onTimeout: ISignal;
        timeout: number;
        private _timeOutID;
        videoStream: MediaStream;
        isStreaming: boolean;
        retryLimit: number;
        retry: number;
        retryInterval: number;
        private _retryID;
        private _codeMuted;
        private _muted;
        private _codePaused;
        private _paused;
        private _autoplay;
        private _endCallback;
        private _playCallback;
        textureFrame: PIXI.Rectangle | Rectangle;
        playbackRate: number;
        loop: boolean;
        readonly playing: boolean;
        paused: boolean;
        /**
  * Internal handler called automatically by the Video.paused setter.
  *
  * @method Video#setResume
  * @private
  */
        private setResume;
        /**
 * Internal handler called automatically by the Video.paused setter.
 *
 * @method Video#setPause
 * @private
 */
        private setPause;
        currentTime: number;
        readonly duration: number;
        readonly progress: number;
        mute: boolean;
        /**
* Internal handler called automatically by the Video.mute setter.
*
* @method Video#setMute
* @private
*/
        private setMute;
        /**
* Internal handler called automatically by the Video.mute setter.
*
* @method Video#unsetMute
* @private
*/
        private unsetMute;
        volume: number;
        constructor(game: Game, key: string, url?: string);
        private createTextureFrame;
        /**
    * Connects to an external media stream for the webcam, rather than using a local one.
    *
    * @method Video#connectToMediaStream
    * @param {HTMLVideoElement} video - The HTML Video Element that the stream uses.
    * @param {MediaStream} stream - The Video Stream data.
    * @return {Video} This Video object for method chaining.
    */
        connectToMediaStream(video: HTMLVideoElement, stream: MediaStream): Video;
        /**
   * Instead of playing a video file this method allows you to stream video data from an attached webcam.
   *
   * As soon as this method is called the user will be prompted by their browser to "Allow" access to the webcam.
   * If they allow it the webcam feed is directed to this Video. Call `Video.play` to start the stream.
   *
   * If they block the webcam the onError signal will be dispatched containing the NavigatorUserMediaError
   * or MediaStreamError event.
   *
   * You can optionally set a width and height for the stream. If set the input will be cropped to these dimensions.
   * If not given then as soon as the stream has enough data the video dimensions will be changed to match the webcam device.
   * You can listen for this with the onChangeSource signal.
   *
   * @method Video#startMediaStream
   * @param {boolean} [captureAudio=false] - Controls if audio should be captured along with video in the video stream.
   * @param {integer} [width] - The width is used to create the video stream. If not provided the video width will be set to the width of the webcam input source.
   * @param {integer} [height] - The height is used to create the video stream. If not provided the video height will be set to the height of the webcam input source.
   * @return {Video} This Video object for method chaining or false if the device doesn't support getUserMedia.
   */
        startMediaStream(captureAudio?: boolean, width?: number, height?: number): Video | boolean;
        /**
    * @method Video#getUserMediaError
    * @private
    */
        private getUserMediaError;
        /**
    * @method Video#getUserMediaTimeout
    * @private
    */
        private getUserMediaTimeout;
        /**
   * @method Video#getUserMediaSuccess
   * @private
   */
        private getUserMediaSuccess;
        createVideoTexture(key: string, url?: string): void;
        forceLoaded(width: number, height: number): void;
        /**
* Enables the video on mobile devices, usually after the first touch.
* If the SoundManager hasn't been unlocked then this will automatically unlock that as well.
* Only one video can be pending unlock at any one time.
*
* @method Video#unlock
*/
        unlock(): boolean;
        createVideoFromURL(url: string, autoplay?: boolean): Video;
        /**
* Internal callback that monitors the download progress of a video after changing its source.
*
* @method Video#checkVideoProgress
* @private
*/
        private checkVideoProgress;
        createVideoFromBlob(blob: Blob): Video;
        /**
 * Sets the _Input Manager touch callback to be Video.unlock.
 * Required for mobile video unlocking. Mostly just used internally.
 *
 * @method Video#setTouchLock
 */
        setTouchLock(): void;
        /**
* Called automatically if the video source changes and updates the internal texture dimensions.
* Then dispatches the onChangeSource signal.
*
* @method Video#updateTexture
* @param {object} [event] - The event which triggered the texture update.
* @param {integer} [width] - The new width of the video. If undefined `video.videoWidth` is used.
* @param {integer} [height] - The new height of the video. If undefined `video.videoHeight` is used.
*/
        updateTexture(event?: any, width?: number, height?: number): void;
        /**
* On some mobile browsers you cannot play a video until the user has explicitly touched the video to allow it.
* bridge handles this via the `setTouchLock` method. However if you have 3 different videos, maybe an "Intro", "Start" and "Game Over"
* split into three different Video objects, then you will need the user to touch-unlock every single one of them.
*
* You can avoid this by using just one Video object and simply changing the video source. Once a Video element is unlocked it remains
* unlocked, even if the source changes. So you can use this to your benefit to avoid forcing the user to 'touch' the video yet again.
*
* As you'd expect there are limitations. So far we've found that the videos need to be in the same encoding format and bitrate.
* This method will automatically handle a change in video dimensions, but if you try swapping to a different bitrate we've found it
* cannot render the new video on iOS (desktop browsers cope better).
*
* When the video source is changed the video file is requested over the network. Listen for the `onChangeSource` signal to know
* when the new video has downloaded enough content to be able to be played. Previous settings such as the volume and loop state
* are adopted automatically by the new video.
*
* @method Video#changeSource
* @param {string} src - The new URL to change the video.src to.
* @param {boolean} [autoplay=true] - Should the video play automatically after the source has been updated?
* @return {Video} This Video object for method chaining.
*/
        changeSource(src: string, autoplay?: boolean): this;
        /**
   * Called when the video completes playback (reaches and ended state).
   * Dispatches the Video.onComplete signal.
   *
   * @method Video#complete
   */
        complete(): void;
        /**
 * Starts this video playing if it's not already doing so.
 *
 * @method Video#play
 * @param {boolean} [loop=false] - Should the video loop automatically when it reaches the end? Please note that at present some browsers (i.e. Chrome) do not support *seamless* video looping.
 * @param {number} [playbackRate=1] - The playback rate of the video. 1 is normal speed, 2 is x2 speed, and so on. You cannot set a negative playback rate.
 * @return {Video} This Video object for method chaining.
 */
        play(loop?: boolean, playbackRate?: number): this;
        /**
     * Called when the video starts to play. Updates the texture.
     *
     * @method Video#playHandler
     * @private
     */
        private playHandler;
        destroy(): void;
        /**
     * Removes the Video element from the DOM by calling parentNode.removeChild on itself.
     * Also removes the autoplay and src attributes and nulls the reference.
     *
     * @method Video#removeVideoElement
     */
        removeVideoElement(): void;
        /**
 * Stops the video playing.
 *
 * This removes all locally set signals.
 *
 * If you only wish to pause playback of the video, to resume at a later time, use `Video.paused = true` instead.
 * If the video hasn't finished downloading calling `Video.stop` will not abort the download. To do that you need to
 * call `Video.destroy` instead.
 *
 * If you are using a video stream from a webcam then calling Stop will disconnect the MediaStream session and disable the webcam.
 *
 * @method Video#stop
 * @return {Video} This Video object for method chaining.
 */
        stop(): this;
    }
}
/**
 * A collection of easing methods defining ease-in and ease-out curves.
 * For tweens, we need a set of data spread in range of [start_value, end_value].
 * Easing defines the step gap between two consecutive values in above mentioned data spread.
 * @default Linear.None - increase the values linearly
 */
declare namespace ingenuity.bridge.Easing {
    /**
     * Linear easing.
     *
     * @class Easing.Linear
     */
    class Linear {
        /**
         * Linear Easing (no variation).
         *
         * @method Easing.Linear#None
         * @param {number} k - The value to be tweened.
         * @returns {number} k.
         */
        static None(k: number): number;
    }
    /**
     * Quadratic easing.
     *
     * @class Easing.Quadratic
     */
    class Quadratic {
        /**
         * Ease-in.
         *
         * @method Easing.Quadratic#In
         * @param {number} k - The value to be tweened.
         * @returns {number} k^2.
         */
        static In(k: number): number;
        /**
         * Ease-out.
         *
         * @method Easing.Quadratic#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} k* (2-k).
         */
        static Out(k: number): number;
        /**
         * Ease-in/out.
         *
         * @method Easing.Quadratic#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Cubic easing.
     *
     * @class Easing.Cubic
     */
    class Cubic {
        /**
         * Cubic ease-in.
         *
         * @method Easing.Cubic#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Cubic ease-out.
         *
         * @method Easing.Cubic#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Cubic ease-in/out.
         *
         * @method Easing.Cubic#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Quartic easing.
     *
     * @class Easing.Quartic
     */
    class Quartic {
        /**
         * Quartic ease-in.
         *
         * @method Easing.Quartic#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Quartic ease-out.
         *
         * @method Easing.Quartic#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Quartic ease-in/out.
         *
         * @method Easing.Quartic#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Quintic easing.
     *
     * @class Easing.Quintic
     */
    class Quintic {
        /**
         * Quintic ease-in.
         *
         * @method Easing.Quintic#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Quintic ease-out.
         *
         * @method Easing.Quintic#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Quintic ease-in/out.
         *
         * @method Easing.Quintic#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Sinusoidal easing.
     *
     * @class Easing.Sinusoidal
     */
    class Sinusoidal {
        /**
         * Sinusoidal ease-in.
         *
         * @method Easing.Sinusoidal#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Sinusoidal ease-out.
         *
         * @method Easing.Sinusoidal#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Sinusoidal ease-in/out.
         *
         * @method Easing.Sinusoidal#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Exponential easing.
     *
     * @class Easing.Exponential
     */
    class Exponential {
        /**
         * Exponential ease-in.
         *
         * @method Easing.Exponential#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Exponential ease-out.
         *
         * @method Easing.Exponential#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Exponential ease-in/out.
         *
         * @method Easing.Exponential#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Circular easing.
     *
     * @class Easing.Circular
     */
    class Circular {
        /**
         * Circular ease-in.
         *
         * @method Easing.Circular#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Circular ease-out.
         *
         * @method Easing.Circular#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Circular ease-in/out.
         *
         * @method Easing.Circular#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Elastic easing.
     *
     * @class Easing.Elastic
     */
    class Elastic {
        /**
         * Elastic ease-in.
         *
         * @method Easing.Elastic#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Elastic ease-out.
         *
         * @method Easing.Elastic#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Elastic ease-in/out.
         *
         * @method Easing.Elastic#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Back easing.
     *
     * @class Easing.Back
     */
    class Back {
        /**
         * Back ease-in.
         *
         * @method Easing.Back#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Back ease-out.
         *
         * @method Easing.Back#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Back ease-in/out.
         *
         * @method Easing.Back#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    /**
     * Bounce easing.
     *
     * @class Easing.Bounce
     */
    class Bounce {
        /**
         * Bounce ease-in.
         *
         * @method Easing.Bounce#In
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static In(k: number): number;
        /**
         * Bounce ease-out.
         *
         * @method Easing.Bounce#Out
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static Out(k: number): number;
        /**
         * Bounce ease-in/out.
         *
         * @method Easing.Bounce#InOut
         * @param {number} k - The value to be tweened.
         * @returns {number} The tweened value.
         */
        static InOut(k: number): number;
    }
    let Default: Function;
    let Power0: Function;
    let Power1: Function;
    let Power2: Function;
    let Power3: Function;
    let Power4: Function;
}
/**
 * Class to make an Event object which can be passed to dispatcher's fireEvent function
 */
declare namespace ingenuity.bridge {
    class Event implements IEvent {
        /**
         * Type of the event can be one from the EventConstants
         * @private
         */
        type: string;
        /**
         * Trigger time data, which will be passed to the function
         */
        data: any;
        /**
         * Time at which this event was sent for execution.
         */
        timeStamp: number;
        target: any;
        /** Is event removed */
        removed: boolean;
        /**
         * Event Class.
         * @param type Create a Constant in eventConstants and then pass it as the type of the event.
         * @param data Any data which you want to pass on to the handler. It will be available as event.data.
         */
        constructor(type: string, data?: any);
        /**
         * Marks the event and handler for removal. Can be used as event.remove() inside the handler function
         */
        remove(): void;
        /**
         * Returns the event as string
         */
        toString(): string;
    }
}
/**
 * Event constants for the Event and Event Dispatcher. It can be extended to be used at other modules.<br>
 * @example
 * ```typescript
 * utils.extendObj(events.EventConstants, {<Your Events Here>}, overwrite); ```
 */
declare namespace ingenuity.bridge {
    let EventConstants: {
        PLAY_SOUND: string;
        STOP_SOUND: string;
        RESIZE: string;
        METER_TICKUP_STARTED: string;
        METER_TICKUP_FINISHED: string;
        STOP_METER_TICKUP: string;
        INFO_CLOSED: string;
        SLIDER_VALUE_CHANGE: string;
        BUTTON_PRESSED: string;
        BUTTON_RELESED: string;
        SHOW_PAYTABLE: string;
        INSUFFICIENT_FUNDS: string;
        SOUND_PLAY_COMPLETE: string;
        SOUND_PLAY_FAILED: string;
        SOUND_PLAY_LOOP: string;
        ERROR_LOADING_SOUND: string;
        GAME_STAGE_CLICKED: string;
        SHOW_ERROR: string;
        PRIORITIZE_LOADING_STAGE: string;
        BASEGAME_ASSETS_LOADED: string;
        BASEGAME_POSTLOAD_ASSETS_LOADED: string;
        FREEGAME_ASSETS_LOADED: string;
        INFO_ASSETS_LOADED: string;
        BONUS_ASSETS_LOADED: string;
        ALL_ASSETS_LOADED: string;
        UPDATE_LOADING_PROGRESS: string;
        FILE_LOAD_ERROR: string;
        STATE_LOADED: string;
        COMPONENT_CREATED: string;
        LOAD_STATE: string;
        REMOVE_STATE_CACHE: string;
    };
}
declare namespace ingenuity.bridge {
    class EventDispatcher implements IEventDispatcher {
        /** Contains list of subscribed events */
        private subscribedEvents;
        /**
         * Custom Event handler class. It can be use to listen and fire custom events.
         */
        constructor();
        /**
         * Binds a handler to an Event
         * @param type Event string type. Most of the Events are available @ bridge.events.EventConstants
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         * @returns {Function} The handler function which can be saved so that it can be unsubscribe or unbind
         */
        on(type: string, handler: (evt?: IEvent, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): any;
        /**
         * Unbinds the handler from an event
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         */
        off(type: string, handler?: (evt?: IEvent, data?: IObject) => void, scope?: any): void;
        /**
         * Unsubscribe the event for a particular scope
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         * @param scope scope for which event needs to be unsubscribed
         */
        offForScope(type: string, scope: any, handler?: (evt?: IEvent, data?: IObject) => void): void;
        /**
         * Checks whether a handler is bound to specified event
         * @param type event type/name to check
         */
        hasEvent(type: string): boolean;
        /**
         * Fires or triggers an event and runs the handler functions bound or subscribed to the event
         * @param type: string|Event Either pass an event or data. If you are passing Event then data can be passed to its constructor
         * @param data Any which is to be passed along the event. It is available as event.data
         */
        fireEvent(type: string | Event, data?: any): void;
    }
}
declare namespace ingenuity.bridge {
    class Game implements IGame {
        stage: Container | PIXI.Container | Stage | any;
        state: IStateManager;
        cache: Cache;
        tweens: ITweenManager;
        camera: Camera;
        add: GameObjectFactory;
        time: Time;
        scale: IScaleManager;
        plugins: IPluginManager;
        renderer: ICanvasRenderer | IRenderer;
        device: Device;
        sound: SoundManager;
        canvas: HTMLCanvasElement;
        height: number;
        id: number;
        width: number;
        parent: HTMLElement;
        renderType: number;
        resolution: number;
        isBooted: boolean;
        config: IDefaultConfig;
        load: Loader;
        transparent: boolean;
        antialias: boolean;
        clearBeforeRender: boolean;
        onPause: Signal;
        onResume: Signal;
        onBlur: Signal;
        onFocus: Signal;
        protected defaultConfig: IDefaultConfig;
        input: Input;
        private isPause;
        private codePaused;
        private stageManager;
        private loadStateObj;
        ticker: PIXI.Ticker;
        raf: any;
        deltaTime: number;
        particles: Particles;
        /** this.rnd can be used to generate Random Data between/for some parameters  */
        rnd: RandomDataGenerator;
        math: Maths;
        constructor(config: IDefaultConfig);
        /**
         * This function will add inputSignals on PIXI.Container which will be dispatched by
         * InputHandler when any interaction will happen.
         * We are adding these signals to the prototype because extending PIXI.Container to our custom container is not physible
         * as we have to change the "parent" reference in every class which extends PIXI.Container
         * Neither we can define these signals directly on PIXI.Container because every time someone instantiates PIXI.Container ,
         * these signals properties will be lost ,to overcome this problem added these props to prototype of PIXI.Container
         *
         */
        inputSigToContainer(): void;
        protected registerStates(loadState?: any, initialState?: string): void;
        paused: boolean;
        boot(event?: Event): void;
        gamePaused(event: Event): void;
        gameResumed(event: Event): void;
        destroy(): void;
        focusLoss(event: Event): void;
        focusGain(event: Event): void;
        private parseConfig;
    }
}
declare namespace ingenuity.bridge {
    class GameObjectFactory implements IObjectFactory {
        game: Game;
        constructor(game: Game);
        tween(object: any): ITween;
        emitter(particleParent: Container | null, emitterData: IEmitterData, config: any): Emitter;
        audioSprite(key: string): SoundManager;
        text(x: number, y: number, text?: string, style?: ITextStyleBridge, canvas?: HTMLCanvasElement): Text;
        /**
         * A WebGL shader/filter that can be applied to Sprites.
         * @param filterType The name of the filter you wish to create, for example `BlurFilter` or `AlphaFilter`
         */
        filter(filterType: string | IFilterType, ...params: any[]): bridge.Filter;
    }
}
declare namespace ingenuity.bridge {
    class ArraySet implements IArraySet {
        list: Array<any>;
        position: number;
        constructor(list?: any[]);
        readonly total: number;
        readonly first: any;
        readonly next: any;
        /**
          * Adds a new element to the end of the list.
          * If the item already exists in the list it is not moved.
          *
          * @method ArraySet#add
          * @param {any} item - The element to add to this list.
          * @return {any} The item that was added.
          */
        add(item: any): any;
        /**
         * Gets the index of the item in the list, or -1 if it isn't in the list.
         *
         * @method ArraySet#getIndex
         * @param {any} item - The element to get the list index for.
         * @return {integer} The index of the item or -1 if not found.
         */
        getIndex(item: any): number;
        /**
         * Gets an item from the set based on the property strictly equaling the value given.
         * Returns null if not found.
         *
         * @method ArraySet#getByKey
         * @param {string} property - The property to check against the value.
         * @param {any} value - The value to check if the property strictly equals.
         * @return {any} The item that was found, or null if nothing matched.
         */
        getByKey(property: string, value: any): any;
        /**
        * Checks for the item within this list.
        *
        * @method ArraySet#exists
        * @param {any} item - The element to get the list index for.
        * @return {boolean} True if the item is found in the list, otherwise false.
        */
        exists(item: any): boolean;
        /**
         * Removes all the items.
         *
         * @method ArraySet#reset
         */
        reset(): void;
        /**
         * Removes the given element from this list if it exists.
         *
         * @method ArraySet#remove
         * @param {any} item - The item to be removed from the list.
         * @return {any} item - The item that was removed.
         */
        remove(item: any): any;
        /**
         * Sets the property `key` to the given value on all members of this list.
         *
         * @method ArraySet#setAll
         * @param {any} key - The property of the item to set.
         * @param {any} value - The value to set the property to.
         */
        setAll(key: any, value: any): void;
        /**
         * Calls a function on all members of this list, using the member as the context for the callback.
         *
         * If the `key` property is present it must be a function.
         * The function is invoked using the item as the context.
         *
         * @method ArraySet#callAll
         * @param {string} key - The name of the property with the function to call.
         * @param {...*} parameter - Additional parameters that will be passed to the callback.
         */
        callAll(key: string, ...param: any[]): void;
        /**
         * Removes every member from this ArraySet and optionally destroys it.
         *
         * @method ArraySet#removeAll
         * @param {boolean} [destroy=false] - Call `destroy` on each member as it's removed from this set.
         */
        removeAll(destroy?: boolean): void;
    }
}
declare namespace ingenuity.bridge {
    class DeviceButton implements IDeviceButton {
        parent: Pointer | SinglePad | any;
        game: Game;
        event: IObject;
        isDown: boolean;
        isUp: boolean;
        timeDown: number;
        timeUp: number;
        repeats: number;
        altKey: boolean;
        shiftKey: boolean;
        ctrlKey: boolean;
        value: number;
        buttonCode: number;
        onDown: Signal;
        onUp: Signal;
        onFloat: Signal;
        constructor(parent: Pointer | SinglePad, buttonCode: number);
        readonly duration: number;
        /**
         * Called automatically by bridge.Pointer and bridge.SinglePad.
         * Handles the button down state.
         *
         * @method DeviceButton#start
         * @protected
         * @param {object} [event] - The DOM event that triggered the button change.
         * @param {number} [value] - The button value. Only get for Gamepads.
         */
        start(event: IObject, value?: number): void;
        /**
         * Called automatically by bridge.Pointer and bridge.SinglePad.
         * Handles the button up state.
         *
         * @method bridge.DeviceButton#stop
         * @protected
         * @param {object} [event] - The DOM event that triggered the button change.
         * @param {number} [value] - The button value. Only get for Gamepads.
         */
        stop(event: IObject, value?: number): void;
        /**
         * Called automatically by bridge.SinglePad.
         *
         * @method DeviceButton#padFloat
         * @protected
         * @param {number} value - Button value
         */
        padFloat(value: number): void;
        /**
         * Returns the "just pressed" state of this button.
         * Just pressed is considered true if the button was pressed down within the duration given (default 250ms).
         *
         * @method   DeviceButton#justPressed
         * @param {number} [duration=250] - The duration in ms below which the button is considered as being just pressed.
         * @return {boolean} True if the button is just pressed otherwise false.
         */
        justPressed(duration: number): boolean;
        /**
         * Returns the "just released" state of this button.
         * Just released is considered as being true if the button was released within the duration given (default 250ms).
         *
         * @method DeviceButton#justReleased
         * @param {number} [duration=250] - The duration in ms below which the button is considered as being just released.
         * @return {boolean} True if the button is just released otherwise false.
         */
        justReleased(duration: number): boolean;
        /**
         * Resets this DeviceButton, changing it to an isUp state and resetting the duration and repeats counters.
         *
         * @method DeviceButton#reset
         */
        reset(): void;
        /**
         * Destroys this DeviceButton, this disposes of the onDown, onUp and onFloat signals
         * and clears the parent and game references.
         *
         * @method DeviceButton#destroy
         */
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    class Input implements IInput {
        static MAX_POINTERS: number;
        static MOUSE_OVERRIDES_TOUCH: number;
        static MOUSE_TOUCH_COMBINE: number;
        static TOUCH_OVERRIDES_MOUSE: number;
        game: Game;
        hitCanvas: HTMLCanvasElement;
        hitContext: CanvasRenderingContext2D;
        moveCallbacks: Array<any>;
        customCandidateHandler: Function;
        customCandidateHandlerContext: Object;
        pollRate: number;
        enabled: boolean;
        multiInputOverride: number;
        position: Point;
        speed: Point;
        circle: Circle;
        scale: Point;
        maxPointers: number;
        tapRate: number;
        doubleTapRate: number;
        holdRate: number;
        justPressedRate: number;
        justReleasedRate: number;
        recordPointerHistory: boolean;
        recordRate: number;
        recordLimit: number;
        pointer1: Pointer;
        pointer2: Pointer;
        pointer3: Pointer;
        pointer4: Pointer;
        pointer5: Pointer;
        pointer6: Pointer;
        pointer7: Pointer;
        pointer8: Pointer;
        pointer9: Pointer;
        pointer10: Pointer;
        pointers: Pointer[];
        activePointer: Pointer;
        mousePointer: Pointer;
        mouse: Mouse;
        keyboard: Keyboard;
        touch: Touch;
        mspointer: MSPointer;
        gamepad: Gamepad;
        resetLocked: boolean;
        onDown: Signal;
        onUp: Signal;
        onTap: Signal;
        onHold: Signal;
        /** Ignore input on items having priority ID less than the minPriorityID */
        minPriorityID: number;
        interactiveItems: ArraySet;
        private _onClickTrampoline;
        private _localPoint;
        private _pollCounter;
        private _oldPosition;
        private _x;
        private _y;
        x: number;
        y: number;
        constructor(game: Game);
        readonly pollLocked: boolean;
        readonly totalInactivePointers: number;
        readonly totalActivePointers: number;
        readonly worldX: number;
        readonly worldY: number;
        /**
         * Starts the Input Manager running.
         *
         * @method Input#boot
         * @protected
         */
        boot(): void;
        /**
         * Stops all of the Input Managers from running.
         *
         * @method Input#destroy
         */
        destroy(): void;
        /**
         * Adds a callback that is fired every time `Pointer.processInteractiveObjects` is called.
         * The purpose of `processInteractiveObjects` is to work out which Game Object the Pointer is going to
         * interact with. It works by polling all of the valid game objects, and then slowly discounting those
         * that don't meet the criteria (i.e. they aren't under the Pointer, are disabled, invisible, etc).
         *
         * Eventually a short-list of 'candidates' is created. These are all of the Game Objects which are valid
         * for input and overlap with the Pointer. If you need fine-grained control over which of the items is
         * selected then you can use this callback to do so.
         *
         * The callback will be sent 3 parameters:
         *
         * 1) A reference to the Pointer object that is processing the Items.
         * 2) An array containing all potential interactive candidates. This is an array of `InputHandler` objects, not Sprites.
         * 3) The current 'favorite' candidate, based on its priorityID and position in the display list.
         *
         * Your callback MUST return one of the candidates sent to it.
         *
         * @method Input#setInteractiveCandidateHandler
         * @param {function} callback - The callback that will be called each time `Pointer.processInteractiveObjects` is called. Set to `null` to disable.
         * @param {object} context - The context in which the callback will be called.
         */
        setInteractiveCandidateHandler(callback: Function, context: any): void;
        /**
         * Adds a callback that is fired every time the activePointer receives a DOM move event such as a mousemove or touchmove.
         *
         * The callback will be sent 4 parameters:
         *
         * A reference to the Pointer object that moved,
         * The x position of the pointer,
         * The y position,
         * A boolean indicating if the movement was the result of a 'click' event (such as a mouse click or touch down).
         *
         * It will be called every time the activePointer moves, which in a multi-touch game can be a lot of times, so this is best
         * to only use if you've limited input to a single pointer (i.e. mouse or touch).
         *
         * The callback is added to the Input.moveCallbacks array and should be removed with Input.deleteMoveCallback.
         *
         * @method Input#addMoveCallback
         * @param {function} callback - The callback that will be called each time the activePointer receives a DOM move event.
         * @param {object} context - The context in which the callback will be called.
         */
        addMoveCallback(callback: Function, context: any): void;
        /**
         * Removes the callback from the Input.moveCallbacks array.
         *
         * @method Input#deleteMoveCallback
         * @param {function} callback - The callback to be removed.
         * @param {object} context - The context in which the callback exists.
         */
        deleteMoveCallback(callback: Function, context: any): void;
        /**
         * Add a new Pointer object to the Input Manager.
         * By default Input creates 3 pointer objects: `mousePointer` (not include in part of general pointer pool), `pointer1` and `pointer2`.
         * This method adds an additional pointer, up to a maximum of Input.MAX_POINTERS (default of 10).
         *
         * @method Input#addPointer
         * @return {Pointer|null} The new Pointer object that was created; null if a new pointer could not be added.
         */
        addPointer(): Pointer;
        /**
         * Updates the Input Manager. Called by the core Game loop.
         *
         * @method Input#update
         * @public
         */
        update(): void;
        /**
         * Reset all of the Pointers and Input states.
         *
         * The optional `hard` parameter will reset any events or callbacks that may be bound.
         * Input.reset is called automatically during a State change or if a game loses focus / visibility.
         * To control control the reset manually set {@link InputManager.resetLocked} to `true`.
         *
         * @method Input#reset
         * @public
         * @param {boolean} [hard=false] - A soft reset won't reset any events or callbacks that are bound. A hard reset will.
         */
        reset(hard?: boolean): void;
        /**
         * Resets the speed and old position properties.
         *
         * @method Input#resetSpeed
         * @param {number} x - Sets the oldPosition.x value.
         * @param {number} y - Sets the oldPosition.y value.
         */
        resetSpeed(x: number, y: number): void;
        /**
         * Find the first free Pointer object and start it, passing in the event data.
         * This is called automatically by Touch and MSPointer.
         *
         * @method Input#startPointer
         * @protected
         * @param {any} event - The event data from the Touch event.
         * @return {Pointer} The Pointer object that was started or null if no Pointer object is available.
         */
        startPointer(event: any): Pointer;
        /**
         * Updates the matching Pointer object, passing in the event data.
         * This is called automatically and should not normally need to be invoked.
         *
         * @method Input#updatePointer
         * @protected
         * @param {any} event - The event data from the Touch event.
         * @return {Pointer} The Pointer object that was updated; null if no pointer was updated.
         */
        updatePointer(event: any): Pointer;
        /**
         * Stops the matching Pointer object, passing in the event data.
         *
         * @method Input#stopPointer
         * @protected
         * @param {any} event - The event data from the Touch event.
         * @return {Pointer} The Pointer object that was stopped or null if no Pointer object is available.
         */
        stopPointer(event: any): Pointer;
        /**
         * Returns the total number of active pointers, not exceeding the specified limit
         *
         * @name Input#countActivePointers
         * @private
         * @property {number} [limit=(max pointers)] - Stop counting after this.
         * @return {number} The number of active pointers, or limit - whichever is less.
         */
        protected countActivePointers(limit?: number): number;
        /**
         * Get the first Pointer with the given active state.
         *
         * @method Input#getPointer
         * @param {boolean} [isActive=false] - The state the Pointer should be in - active or inactive?
         * @return {Pointer} A Pointer object or null if no Pointer object matches the requested state.
         */
        getPointer(isActive?: boolean): Pointer;
        /**
         * Get the Pointer object whos `pointerId` property matches the given value.
         *
         * The pointerId property is not set until the Pointer has been used at least once, as its populated by the DOM event.
         * Also it can change every time you press the pointer down if the browser recycles it.
         *
         * @method Input#getPointerFromId
         * @param {number} pointerId - The `pointerId` (not 'id') value to search for.
         * @return {Pointer} A Pointer object or null if no Pointer object matches the requested identifier.
         */
        getPointerFromId(pointerId: number): Pointer;
        /**
         * This will return the local coordinates of the specified displayObject based on the given Pointer.
         *
         * @method Input#getLocalPosition
         * @param {Sprite|Image} displayObject - The DisplayObject to get the local coordinates for.
         * @param {Pointer} pointer - The Pointer to use in the check against the displayObject.
         * @return {Point} A point containing the coordinates of the Pointer position relative to the DisplayObject.
         */
        getLocalPosition(displayObject: any, pointer: Pointer, output?: Point): Point;
        /**
         * Get the Pointer object whos `identifier` property matches the given identifier value.
         *
         * The identifier property is not set until the Pointer has been used at least once, as its populated by the DOM event.
         * Also it can change every time you press the pointer down, and is not fixed once set.
         * Note: Not all browsers set the identifier property and it's not part of the W3C spec, so you may need getPointerFromId instead.
         *
         * @method Input#getPointerFromIdentifier
         * @param {number} identifier - The Pointer.identifier value to search for.
         * @return {Pointer} A Pointer object or null if no Pointer object matches the requested identifier.
         */
        getPointerFromIdentifier(identifier: number): Pointer;
        /**
         * Tests if the pointer hits the given object.
         *
         * @method Input#hitTest
         * @param {DisplayObject} displayObject - The displayObject to test for a hit.
         * @param {Pointer} pointer - The pointer to use for the test.
         * @param {Point} localPoint - The local translated point.
         */
        hitTest(displayObject: any, pointer: Pointer, localPoint: Point): boolean;
        /**
         * Used for click trampolines. See {@link Pointer.addClickTrampoline}.
         *
         * @method Input#onClickTrampoline
         * @private
         */
        private onClickTrampoline;
    }
}
declare namespace ingenuity.bridge {
    class InputHandler implements IInputHandler {
        sprite: BitmapImage | any;
        game: Game;
        enabled: boolean;
        checked: boolean;
        priorityID: number;
        useHandCursor: boolean;
        _draggedPointerID: number;
        private _setHandCursor;
        isDragged: boolean;
        allowHorizontalDrag: boolean;
        allowVerticalDrag: boolean;
        bringToTop: boolean;
        snapOffset: Point;
        snapOnDrag: boolean;
        snapOnRelease: boolean;
        snapX: number;
        snapY: number;
        snapOffsetX: number;
        snapOffsetY: number;
        pixelPerfectOver: boolean;
        pixelPerfectClick: boolean;
        pixelPerfectAlpha: number;
        draggable: boolean;
        boundsRect: Rectangle;
        boundsSprite: BitmapImage | any;
        scaleLayer: boolean;
        dragOffset: Point;
        dragFromCenter: boolean;
        dragStopBlocksInputUp: boolean;
        dragStartPoint: Point;
        dragDistanceThreshold: number;
        dragTimeThreshold: number;
        downPoint: Point;
        snapPoint: Point;
        private _dragPoint;
        private _dragPhase;
        private _pendingDrag;
        private _dragTimePass;
        private _dragDistancePass;
        private _wasEnabled;
        private _tempPoint;
        private _pointerData;
        constructor(sprite: any);
        /**
         * Starts the Input Handler running. This is called automatically when you enable input on a Sprite, or can be called directly if you need to set a specific priority.
         *
         * @method InputHandler#start
         * @param {number} [priority=0] - Higher priority sprites take click priority over low-priority sprites when they are stacked on-top of each other.
         * @param {boolean} [useHandCursor=false] - If true the Sprite will show the hand cursor on mouse-over (doesn't apply to mobile browsers)
         * @return {Sprite} The Sprite object to which the Input Handler is bound.
         */
        start(priority?: number, useHandCursor?: boolean): BitmapImage | any;
        /**
         * Handles when the parent Sprite is added to a new Group.
         *
         * @method InputHandler#addedToGroup
         * @private
         */
        private addedToGroup;
        /**
         * Handles when the parent Sprite is removed from a Group.
         *
         * @method InputHandler#removedFromGroup
         * @private
         */
        private removedFromGroup;
        /**
         * Resets the Input Handler and disables it.
         * @method InputHandler#reset
         */
        reset(): void;
        /**
         * Stops the Input Handler from running.
         * @method InputHandler#stop
         */
        stop(): void;
        /**
         * Clean up memory.
         * @method InputHandler#destroy
         */
        destroy(): void;
        /**
         * Checks if the object this InputHandler is bound to is valid for consideration in the Pointer move event.
         * This is called by Pointer and shouldn't typically be called directly.
         *
         * @method InputHandler#validForInput
         * @protected
         * @param {number} highestID - The highest ID currently processed by the Pointer.
         * @param {number} highestRenderID - The highest Render Order ID currently processed by the Pointer.
         * @param {boolean} [includePixelPerfect=true] - If this object has `pixelPerfectClick` or `pixelPerfectOver` set should it be considered as valid?
         * @return {boolean} True if the object this InputHandler is bound to should be considered as valid for input detection.
         */
        validForInput(highestID: number, highestRenderID: number, includePixelPerfect?: boolean): boolean;
        /**
         * Is this object using pixel perfect checking?
         *
         * @method InputHandler#isPixelPerfect
         * @return {boolean} True if the this InputHandler has either `pixelPerfectClick` or `pixelPerfectOver` set to `true`.
         */
        isPixelPerfect(): boolean;
        /**
         * The x coordinate of the Input pointer, relative to the top-left of the parent Sprite.
         * This value is only set when the pointer is over this Sprite.
         *
         * @method InputHandler#pointerX
         * @param {integer} [pointerId=0]
         * @return {number} The x coordinate of the Input pointer.
         */
        pointerX(pointerId?: number): number;
        /**
         * The y coordinate of the Input pointer, relative to the top-left of the parent Sprite
         * This value is only set when the pointer is over this Sprite.
         *
         * @method InputHandler#pointerY
         * @param {integer} [pointerId=0]
         * @return {number} The y coordinate of the Input pointer.
         */
        pointerY(pointerId?: number): number;
        /**
         * If the Pointer is down this returns true.
         * This *only* checks if the Pointer is down, not if it's down over any specific Sprite.
         *
         * @method InputHandler#pointerDown
         * @param {integer} [pointerId=0]
         * @return {boolean} - True if the given pointer is down, otherwise false.
         */
        pointerDown(pointerId?: number): boolean;
        /**
         * If the Pointer is up this returns true.
         * This *only* checks if the Pointer is up, not if it's up over any specific Sprite.
         *
         * @method InputHandler#pointerUp
         * @param {integer} [pointerId=0]
         * @return {boolean} - True if the given pointer is up, otherwise false.
         */
        pointerUp(pointerId?: number): boolean;
        /**
         * A timestamp representing when the Pointer first touched the touchscreen.
         *
         * @method InputHandler#pointerTimeDown
         * @param {integer} [pointerId=(check all)]
         * @return {number}
         */
        pointerTimeDown(pointerId?: number): boolean;
        /**
         * A timestamp representing when the Pointer left the touchscreen.
         *
         * @method InputHandler#pointerTimeUp
         * @param {integer} [pointerId=0]
         * @return {number}
         */
        pointerTimeUp(pointerId?: number): number;
        /**
         * Is the Pointer over this Sprite?
         *
         * @method InputHandler#pointerOver
         * @param {integer} [pointerId=(check all)] The ID number of a Pointer to check. If you don't provide a number it will check all Pointers.
         * @return {boolean} - True if the given pointer (if a index was given, or any pointer if not) is over this object.
         */
        pointerOver(pointerId: number): boolean;
        /**
         * Is the Pointer outside of this Sprite?
         *
         * @method InputHandler#pointerOut
         * @param {integer} [pointerId=(check all)] The ID number of a Pointer to check. If you don't provide a number it will check all Pointers.
         * @return {boolean} True if the given pointer (if a index was given, or any pointer if not) is out of this object.
         */
        pointerOut(pointerId: number): boolean;
        /**
         * A timestamp representing when the Pointer first touched the touchscreen.
         *
         * @method InputHandler#pointerTimeOver
         * @param {integer} [pointerId=0]
         * @return {number}
         */
        pointerTimeOver(pointerId?: number): number;
        /**
         * A timestamp representing when the Pointer left the touchscreen.
         *
         * @method InputHandler#pointerTimeOut
         * @param {integer} [pointerId=0]
         * @return {number}
         */
        pointerTimeOut(pointerId?: number): number;
        /**
         * Is this sprite being dragged by the mouse or not?
         *
         * @method InputHandler#pointerDragged
         * @param {integer} [pointerId=0]
         * @return {boolean} True if the pointer is dragging an object, otherwise false.
         */
        pointerDragged(pointerId?: number): number;
        /**
         * Checks if the given pointer is both down and over the Sprite this InputHandler belongs to.
         * Use the `fastTest` flag is to quickly check just the bounding hit area even if `InputHandler.pixelPerfectOver` is `true`.
         *
         * @method InputHandler#checkPointerDown
         * @param {Pointer} pointer
         * @param {boolean} [fastTest=false] - Force a simple hit area check even if `pixelPerfectOver` is true for this object?
         * @return {boolean} True if the pointer is down, otherwise false.
         */
        checkPointerDown(pointer: Pointer, fastTest?: boolean): boolean;
        /**
        * Checks if the given pointer is over the Sprite this InputHandler belongs to.
        * Use the `fastTest` flag is to quickly check just the bounding hit area even if `InputHandler.pixelPerfectOver` is `true`.
        *
        * @method InputHandler#checkPointerOver
        * @param {Pointer} pointer
        * @param {boolean} [fastTest=false] - Force a simple hit area check even if `pixelPerfectOver` is true for this object?
        * @return {boolean}
        */
        checkPointerOver(pointer: Pointer, fastTest?: boolean): boolean;
        /**
         * Runs a pixel perfect check against the given x/y coordinates of the Sprite this InputHandler is bound to.
         * It compares the alpha value of the pixel and if >= InputHandler.pixelPerfectAlpha it returns true.
         *
         * @method InputHandler#checkPixel
         * @param {number} x - The x coordinate to check.
         * @param {number} y - The y coordinate to check.
         * @param {Pointer} [pointer] - The pointer to get the x/y coordinate from if not passed as the first two parameters.
         * @return {boolean} true if there is the alpha of the pixel is >= InputHandler.pixelPerfectAlpha
         */
        checkPixel(x: number, y: number, pointer?: Pointer): boolean;
        /**
         * Internal Update method. This is called automatically and handles the Pointer
         * and drag update loops.
         *
         * @method InputHandler#update
         * @protected
         * @param {Pointer} pointer
         * @return {boolean} True if the pointer is still active, otherwise false.
         */
        update(pointer?: Pointer): boolean;
        /**
         * Internal method handling the pointer over event.
         *
         * @method InputHandler#_pointerOverHandler
         * @private
         * @param {Pointer} pointer - The pointer that triggered the event
         * @param {boolean} [silent=false] - If silent is `true` then this method will not dispatch any Signals from the parent Sprite.
         */
        _pointerOverHandler(pointer: Pointer, silent?: boolean): Pointer;
        /**
         * Internal method handling the pointer out event.
         *
         * @method InputHandler#_pointerOutHandler
         * @private
         * @param {Pointer} pointer - The pointer that triggered the event.
         * @param {boolean} [silent=false] - If silent is `true` then this method will not dispatch any Signals from the parent Sprite.
         */
        _pointerOutHandler(pointer: Pointer, silent?: boolean): Pointer;
        /**
         * Internal method handling the touched / clicked event.
         *
         * @method InputHandler#_touchedHandler
         * @private
         * @param {Pointer} pointer - The pointer that triggered the event.
         */
        _touchedHandler(pointer: Pointer): Pointer;
        /**
         * Internal method handling the drag threshold timer.
         *
         * @method InputHandler#dragTimeElapsed
         * @private
         * @param {Pointer} pointer
         */
        private dragTimeElapsed;
        /**
         * Internal method handling the pointer released event.
         * @method InputHandler#_releasedHandler
         * @private
         * @param {Pointer} pointer
         */
        protected _releasedHandler(pointer: Pointer): void;
        /**
         * Called as a Pointer actively drags this Game Object.
         *
         * @method InputHandler#updateDrag
         * @private
         * @param {Pointer} pointer - The Pointer causing the drag update.
         * @param {boolean} fromStart - True if this is the first update, immediately after the drag has started.
         * @return {boolean}
         */
        private updateDrag;
        /**
         * Returns true if the pointer has entered the Sprite within the specified delay time (defaults to 500ms, half a second)
         *
         * @method InputHandler#justOver
         * @param {integer} [pointerId=0]
         * @param {number} delay - The time below which the pointer is considered as just over.
         * @return {boolean}
         */
        justOver(pointerId?: number, delay?: number): boolean;
        /**
         * Returns true if the pointer has left the Sprite within the specified delay time (defaults to 500ms, half a second)
         *
         * @method InputHandler#justOut
         * @param {integer} [pointerId=0]
         * @param {number} delay - The time below which the pointer is considered as just out.
         * @return {boolean}
         */
        justOut(pointerId?: number, delay?: number): boolean;
        /**
         * Returns true if the pointer has touched or clicked on the Sprite within the specified delay time (defaults to 500ms, half a second)
         *
         * @method InputHandler#justPressed
         * @param {integer} [pointerId=0]
         * @param {number} delay - The time below which the pointer is considered as just over.
         * @return {boolean}
         */
        justPressed(pointerId?: number, delay?: number): boolean;
        /**
         * Returns true if the pointer was touching this Sprite, but has been released within the specified delay time (defaults to 500ms, half a second)
         *
         * @method InputHandler#justReleased
         * @param {integer} [pointerId=0]
         * @param {number} delay - The time below which the pointer is considered as just out.
         * @return {boolean}
         */
        justReleased(pointerId?: number, delay?: number): boolean;
        /**
         * If the pointer is currently over this Sprite this returns how long it has been there for in milliseconds.
         *
         * @method InputHandler#overDuration
         * @param {integer} [pointerId=0]
         * @return {number} The number of milliseconds the pointer has been over the Sprite, or -1 if not over.
         */
        overDuration(pointerId?: number): number;
        /**
         * If the pointer is currently over this Sprite this returns how long it has been there for in milliseconds.
         *
         * @method InputHandler#downDuration
         * @param {integer} [pointerId=0]
         * @return {number} The number of milliseconds the pointer has been pressed down on the Sprite, or -1 if not over.
         */
        downDuration(pointerId?: number): number;
        /**
         * Allow this Sprite to be dragged by any valid pointer.
         *
         * When the drag begins the Sprite.events.onDragStart event will be dispatched.
         *
         * When the drag completes by way of the user letting go of the pointer that was dragging the sprite, the Sprite.events.onDragStop event is dispatched.
         *
         * You can control the thresholds over when a drag starts via the properties:
         *
         * `Pointer.dragDistanceThreshold` the distance, in pixels, that the pointer has to move
         * before the drag will start.
         *
         * `Pointer.dragTimeThreshold` the time, in ms, that the pointer must be held down on
         * the Sprite before the drag will start.
         *
         * You can set either (or both) of these properties after enabling a Sprite for drag.
         *
         * For the duration of the drag the Sprite.events.onDragUpdate event is dispatched. This event is only dispatched when the pointer actually
         * changes position and moves. The event sends 5 parameters: `sprite`, `pointer`, `dragX`, `dragY` and `snapPoint`.
         *
         * @method InputHandler#enableDrag
         * @param {boolean} [lockCenter=false] - If false the Sprite will drag from where you click it minus the dragOffset. If true it will center itself to the tip of the mouse pointer.
         * @param {boolean} [bringToTop=false] - If true the Sprite will be bought to the top of the rendering list in its current Group.
         * @param {boolean} [pixelPerfect=false] - If true it will use a pixel perfect test to see if you clicked the Sprite. False uses the bounding box.
         * @param {boolean} [alphaThreshold=255] - If using pixel perfect collision this specifies the alpha level from 0 to 255 above which a collision is processed.
         * @param {Rectangle} [boundsRect=null] - If you want to restrict the drag of this sprite to a specific Rectangle, pass the Rectangle here, otherwise it's free to drag anywhere.
         * @param {Sprite} [boundsSprite=null] - If you want to restrict the drag of this sprite to within the bounding box of another sprite, pass it here.
         */
        enableDrag(lockCenter?: boolean, bringToTop?: boolean, pixelPerfect?: boolean, alphaThreshold?: number, boundsRect?: Rectangle, boundsSprite?: any): void;
        /**
         * Stops this sprite from being able to be dragged.
         * If it is currently the target of an active drag it will be stopped immediately; also disables any set callbacks.
         *
         * @method InputHandler#disableDrag
         */
        disableDrag(): void;
        /**
         * Called by Pointer when drag starts on this Sprite. Should not usually be called directly.
         *
         * @method InputHandler#startDrag
         * @param {Pointer} pointer
         */
        startDrag(pointer: Pointer): void;
        /**
         * Warning: EXPERIMENTAL
         *
         * @method InputHandler#globalToLocalX
         * @param {number} x
         */
        globalToLocalX(x: number): number;
        /**
         * Warning: EXPERIMENTAL
         *
         * @method InputHandler#globalToLocalY
         * @param {number} y
         */
        globalToLocalY(y: number): number;
        /**
         * Called by Pointer when drag is stopped on this Sprite. Should not usually be called directly.
         *
         * @method InputHandler#stopDrag
         * @param {Pointer} pointer
         */
        stopDrag(pointer: Pointer): void;
        /**
         * Restricts this sprite to drag movement only on the given axis. Note: If both are set to false the sprite will never move!
         *
         * @method InputHandler#setDragLock
         * @param {boolean} [allowHorizontal=true] - To enable the sprite to be dragged horizontally set to true, otherwise false.
         * @param {boolean} [allowVertical=true] - To enable the sprite to be dragged vertically set to true, otherwise false.
         */
        setDragLock(allowHorizontal?: boolean, allowVertical?: boolean): void;
        /**
         * Make this Sprite snap to the given grid either during drag or when it's released.
         * For example 16x16 as the snapX and snapY would make the sprite snap to every 16 pixels.
         *
         * @method InputHandler#enableSnap
         * @param {number} snapX - The width of the grid cell to snap to.
         * @param {number} snapY - The height of the grid cell to snap to.
         * @param {boolean} [onDrag=true] - If true the sprite will snap to the grid while being dragged.
         * @param {boolean} [onRelease=false] - If true the sprite will snap to the grid when released.
         * @param {number} [snapOffsetX=0] - Used to offset the top-left starting point of the snap grid.
         * @param {number} [snapOffsetY=0] - Used to offset the top-left starting point of the snap grid.
         */
        enableSnap(snapX: number, snapY: number, onDrag?: boolean, onRelease?: boolean, snapOffsetX?: number, snapOffsetY?: number): void;
        /**
         * Stops the sprite from snapping to a grid during drag or release.
         *
         * @method InputHandler#disableSnap
         */
        disableSnap(): void;
        /**
         * Bounds Rect check for the sprite drag
         *
         * @method InputHandler#checkBoundsRect
         */
        checkBoundsRect(): void;
        /**
         * Parent Sprite Bounds check for the sprite drag.
         *
         * @method InputHandler#checkBoundsSprite
         */
        checkBoundsSprite(): void;
    }
}
declare namespace ingenuity.bridge {
    class Key implements IKey {
        game: Game;
        private _enabled;
        event: KeyboardEvent;
        isDown: boolean;
        isUp: boolean;
        altKey: boolean;
        ctrlKey: boolean;
        shiftKey: boolean;
        timeDown: number;
        duration: number;
        timeUp: number;
        repeats: number;
        keyCode: number;
        onDown: Signal;
        onHoldCallback: Function;
        onHoldContext: Object;
        onUp: Signal;
        private _justDown;
        private _justUp;
        constructor(game: Game, keyCode: number);
        readonly justDown: boolean;
        readonly justUp: boolean;
        enabled: boolean;
        /**
         * Called automatically by Keyboard.
         *
         * @method Key#update
         * @protected
         */
        update(): void;
        /**
         * Called automatically by Keyboard.
         *
         * @method Key#processKeyDown
         * @param {KeyboardEvent} event - The DOM event that triggered this.
         * @protected
         */
        processKeyDown(event: KeyboardEvent): void;
        /**
         * Called automatically by Keyboard.
         *
         * @method Key#processKeyUp
         * @param {KeyboardEvent} event - The DOM event that triggered this.
         * @protected
         */
        processKeyUp(event: KeyboardEvent): void;
        /**
         * Resets the state of this Key.
         *
         * This sets isDown to false, isUp to true, resets the time to be the current time, and _enables_ the key.
         * In addition, if it is a "hard reset", it clears clears any callbacks associated with the onDown and onUp events and removes the onHoldCallback.
         *
         * @method Key#reset
         * @param {boolean} [hard=true] - A soft reset won't reset any events or callbacks; a hard reset will.
         */
        reset(hard?: boolean): void;
        /**
         * Returns `true` if the Key was pressed down within the `duration` value given, or `false` if it either isn't down,
         * or was pressed down longer ago than then given duration.
         *
         * @method Key#downDuration
         * @param {number} [duration=50] - The duration within which the key is considered as being just pressed. Given in ms.
         * @return {boolean} True if the key was pressed down within the given duration.
         */
        downDuration(duration?: number): boolean;
        /**
         * Returns `true` if the Key was pressed down within the `duration` value given, or `false` if it either isn't down,
         * or was pressed down longer ago than then given duration.
         *
         * @method Key#upDuration
         * @param {number} [duration=50] - The duration within which the key is considered as being just released. Given in ms.
         * @return {boolean} True if the key was released within the given duration.
         */
        upDuration(duration?: number): boolean;
    }
}
declare namespace ingenuity.bridge {
    class Keyboard implements IKeyboard {
        game: Game;
        enabled: boolean;
        event: KeyboardEvent;
        pressEvent: KeyboardEvent;
        callbackContext: Object;
        onDownCallback: Function;
        onPressCallback: Function;
        onUpCallback: Function;
        private _keys;
        private _capture;
        private _onKeyDown;
        private _onKeyPress;
        private _onKeyUp;
        private _i;
        private _k;
        constructor(game: Game);
        readonly lastChar: string;
        readonly lastKey: Key;
        /**
         * Add callbacks to the Keyboard handler so that each time a key is pressed down or released the callbacks are activated.
         *
         * @method Keyboard#addCallbacks
         * @param {object} context - The context under which the callbacks are run.
         * @param {function} [onDown=null] - This callback is invoked every time a key is pressed down.
         * @param {function} [onUp=null] - This callback is invoked every time a key is released.
         * @param {function} [onPress=null] - This callback is invoked every time the onkeypress event is raised.
         */
        addCallbacks(context: object, onDown: Function, onUp: Function, onPress: Function): void;
        /**
         * If you need more fine-grained control over a Key you can create a new Key object via this method.
         * The Key object can then be polled, have events attached to it, etc.
         *
         * @method Keyboard#addKey
         * @param {integer} keycode - The {@link KeyCode keycode} of the key.
         * @return {Key} The Key object which you can store locally and reference directly.
         */
        addKey(keycode: number): Key;
        /**
         * A practical way to create an object containing user selected hotkeys.
         *
         * For example,
         *
         *     addKeys( { 'up': KeyCode.W, 'down': KeyCode.S, 'left': KeyCode.A, 'right': KeyCode.D } );
         *
         * would return an object containing properties (`up`, `down`, `left` and `right`) referring to {@link Key} object.
         *
         * @method Keyboard#addKeys
         * @param {object} keys - A key mapping object, i.e. `{ 'up': KeyCode.W, 'down': KeyCode.S }` or `{ 'up': 52, 'down': 53 }`.
         * @return {object} An object containing the properties mapped to {@link Key} values.
         */
        addKeys(keys: IObject): IObject;
        /**
         * Removes a Key object from the Keyboard manager.
         *
         * @method Keyboard#removeKey
         * @param {integer} keycode - The {@link KeyCode keycode} of the key to remove.
         */
        removeKey(keycode: number): void;
        /**
         * Creates and returns an object containing 4 hotkeys for Up, Down, Left and Right.
         *
         * @method Keyboard#createCursorKeys
         * @return {object} An object containing properties: `up`, `down`, `left` and `right` of {@link Key} objects.
         */
        createCursorKeys(): IObject;
        /**
         * Starts the Keyboard event listeners running (keydown and keyup). They are attached to the window.
         * This is called automatically by Input and should not normally be invoked directly.
         *
         * @method Keyboard#start
         * @protected
         */
        start(): void;
        /**
         * Stops the Keyboard event listeners from running (keydown, keyup and keypress). They are removed from the window.
         *
         * @method Keyboard#stop
         */
        stop(): void;
        /**
         * Stops the Keyboard event listeners from running (keydown and keyup). They are removed from the window.
         * Also clears all key captures and currently created Key objects.
         *
         * @method Keyboard#destroy
         */
        destroy(): void;
        /**
         * By default when a key is pressed bridge will not stop the event from propagating up to the browser.
         * There are some keys this can be annoying for, like the arrow keys or space bar, which make the browser window scroll.
         *
         * The `addKeyCapture` method enables consuming keyboard event for specific keys so it doesn't bubble up to the the browser
         * and cause the default browser behavior.
         *
         * Pass in either a single keycode or an array/hash of keycodes.
         *
         * @method Keyboard#addKeyCapture
         * @param {integer|integer[]|object} keycode - Either a single {@link KeyCode keycode} or an array/hash of keycodes such as `[65, 67, 68]`.
         */
        addKeyCapture(keycode: any): void;
        /**
         * Removes an existing key capture.
         *
         * @method Keyboard#removeKeyCapture
         * @param {integer} keycode - The {@link KeyCode keycode} to remove capturing of.
         */
        removeKeyCapture(keycode: number): void;
        /**
         * Clear all set key captures.
         *
         * @method Keyboard#clearCaptures
         */
        clearCaptures(): void;
        /**
         * Updates all currently defined keys.
         *
         * @method Keyboard#update
         */
        update(): void;
        /**
         * Process the keydown event.
         *
         * @method Keyboard#processKeyDown
         * @param {KeyboardEvent} event
         * @protected
         */
        protected processKeyDown(event: KeyboardEvent): void;
        /**
         * Process the keypress event.
         *
         * @method Keyboard#processKeyPress
         * @param {KeyboardEvent} event
         * @protected
         */
        protected processKeyPress(event: KeyboardEvent): void;
        /**
         * Process the keyup event.
         *
         * @method Keyboard#processKeyUp
         * @param {KeyboardEvent} event
         * @protected
         */
        protected processKeyUp(event: KeyboardEvent): void;
        /**
         * Resets all Keys.
         *
         * @method Keyboard#reset
         * @param {boolean} [hard=true] - A soft reset won't reset any events or callbacks that are bound to the Keys. A hard reset will.
         */
        reset(hard?: boolean): void;
        /**
         * Returns `true` if the Key was pressed down within the `duration` value given, or `false` if it either isn't down,
         * or was pressed down longer ago than then given duration.
         *
         * @method Keyboard#downDuration
         * @param {integer} keycode - The {@link KeyCode keycode} of the key to check: i.e. KeyCode.UP or KeyCode.SPACEBAR.
         * @param {number} [duration=50] - The duration within which the key is considered as being just pressed. Given in ms.
         * @return {boolean} True if the key was pressed down within the given duration, false if not or null if the Key wasn't found.
         */
        downDuration(keycode: number, duration: number): boolean;
        /**
         * Returns `true` if the Key was pressed down within the `duration` value given, or `false` if it either isn't down,
         * or was pressed down longer ago than then given duration.
         *
         * @method Keyboard#upDuration
         * @param {KeyCode|integer} keycode - The keycode of the key to check, i.e. KeyCode.UP or KeyCode.SPACEBAR.
         * @param {number} [duration=50] - The duration within which the key is considered as being just released. Given in ms.
         * @return {boolean} True if the key was released within the given duration, false if not or null if the Key wasn't found.
         */
        upDuration(keycode: number, duration: number): boolean;
        /**
         * Returns true of the key is currently pressed down. Note that it can only detect key presses on the web browser.
         *
         * @method Keyboard#isDown
         * @param {integer} keycode - The {@link KeyCode keycode} of the key to check: i.e. KeyCode.UP or KeyCode.SPACEBAR.
         * @return {boolean} True if the key is currently down, false if not or null if the Key wasn't found.
         */
        isDown(keycode: number): boolean;
    }
}
declare namespace ingenuity.bridge {
    class Mouse implements IMouse {
        static NO_BUTTON: number;
        static LEFT_BUTTON: number;
        static MIDDLE_BUTTON: number;
        static RIGHT_BUTTON: number;
        static BACK_BUTTON: number;
        static FORWARD_BUTTON: number;
        static WHEEL_UP: number;
        static WHEEL_DOWN: number;
        game: Game;
        input: Input;
        callbackContext: any;
        mouseDownCallback: Function;
        mouseUpCallback: Function;
        mouseOutCallback: Function;
        mouseOverCallback: Function;
        mouseMoveCallback: Function;
        mouseWheelCallback: Function;
        /** If capture=true the DOM mouse events will have event.preventDefault applied to them. */
        capture: boolean;
        button: number;
        wheelDelta: number;
        enabled: boolean;
        locked: boolean;
        stopOnGameOut: boolean;
        pointerLock: Signal;
        event: MouseEvent;
        private _onMouseDown;
        private _onMouseMove;
        private _onMouseUp;
        private _onMouseOut;
        private _onMouseOver;
        private _onMouseWheel;
        private _onMouseUpGlobal;
        private _onMouseOutGlobal;
        private _wheelEvent;
        private _pointerLockChange;
        constructor(game: Game);
        start(): void;
        /**
         * The internal method that handles the mouse up event from the browser.
         * @method Mouse#onMouseUp
         * @param {MouseEvent} event - The native event from the browser. This gets stored in Mouse.event.
         */
        onMouseUp(event: MouseEvent): void;
        /**
         * The internal method that handles the mouse down event from the browser.
         * @method Mouse#onMouseDown
         * @param {MouseEvent} event - The native event from the browser. This gets stored in Mouse.event.
         */
        onMouseDown(event: MouseEvent): void;
        /**
         * The internal method that handles the mouse move event from the browser.
         * @method Mouse#onMouseMove
         * @param {MouseEvent} event - The native event from the browser. This gets stored in Mouse.event.
         */
        onMouseMove(event: MouseEvent): void;
        /**
         * The internal method that handles the mouse up event from the window.
         *
         * @method Mouse#onMouseUpGlobal
         * @param {MouseEvent} event - The native event from the browser. This gets stored in Mouse.event.
         */
        onMouseUpGlobal(event: MouseEvent): void;
        /**
         * The internal method that handles the mouse out event from the window.
         *
         * @method Mouse#onMouseOutGlobal
         * @param {MouseEvent} event - The native event from the browser. This gets stored in Mouse.event.
         */
        onMouseOutGlobal(event: MouseEvent): void;
        /**
         * The internal method that handles the mouse out event from the browser.
         *
         * @method Mouse#onMouseOut
         * @param {MouseEvent} event - The native event from the browser. This gets stored in Mouse.event.
         */
        onMouseOut(event: MouseEvent): void;
        /**
         * The internal method that handles the mouse over event from the browser.
         *
         * @method Mouse#onMouseOver
         * @param {MouseEvent} event - The native event from the browser. This gets stored in Mouse.event.
         */
        onMouseOver(event: MouseEvent): void;
        /**
         * The internal method that handles the mouse wheel event from the browser.
         *
         * @method Mouse#onMouseWheel
         * @param {MouseEvent} event - The native event from the browser.
         */
        onMouseWheel(event: MouseEvent): void;
        /**
         * If the browser supports it you can request that the pointer be locked to the browser window.
         * This is classically known as 'FPS controls', where the pointer can't leave the browser until the user presses an exit key.
         * If the browser successfully enters a locked state the event Mouse.pointerLock will be dispatched and the first parameter will be 'true'.
         * @method Mouse#requestPointerLock
         */
        requestPointerLock(): void;
        /**
         * Internal pointerLockChange handler.
         *
         * @method Mouse#pointerLockChange
         * @param {Event} event - The native event from the browser. This gets stored in Mouse.event.
         */
        pointerLockChange(event: any): void;
        /**
         * Internal release pointer lock handler.
         * @method Mouse#releasePointerLock
         */
        releasePointerLock(): void;
        /**
         * Stop the event listeners.
         * @method Mouse#stop
         */
        stop(): void;
    }
}
declare namespace ingenuity.bridge {
    class MSPointer implements IMSPointer {
        game: Game;
        input: Input;
        callbackContext: Object;
        pointerDownCallback: Function;
        pointerMoveCallback: Function;
        pointerUpCallback: Function;
        capture: boolean;
        button: number;
        event: MSPointerEvent;
        enabled: boolean;
        private _onMSPointerDown;
        private _onMSPointerMove;
        private _onMSPointerUp;
        private _onMSPointerUpGlobal;
        private _onMSPointerOut;
        private _onMSPointerOver;
        constructor(game: Game);
        start(): void;
        /**
         * The function that handles the PointerDown event.
         *
         * @method MSPointer#onPointerDown
         * @param {PointerEvent} event - The native DOM event.
         */
        onPointerDown(event: any): void;
        /**
         * The function that handles the PointerMove event.
         * @method MSPointer#onPointerMove
         * @param {PointerEvent} event - The native DOM event.
         */
        onPointerMove(event: any): void;
        /**
         * The function that handles the PointerUp event.
         * @method bridge.MSPointer#onPointerUp
         * @param {PointerEvent} event - The native DOM event.
         */
        onPointerUp(event: any): void;
        /**
         * The internal method that handles the mouse up event from the window.
         *
         * @method bridge.MSPointer#onPointerUpGlobal
         * @param {PointerEvent} event - The native event from the browser. This gets stored in MSPointer.event.
         */
        onPointerUpGlobal(event: any): void;
        /**
         * The internal method that handles the pointer out event from the browser.
         *
         * @method bridge.MSPointer#onPointerOut
         * @param {PointerEvent} event - The native event from the browser. This gets stored in MSPointer.event.
         */
        onPointerOut(event: any): void;
        /**
         * The internal method that handles the pointer out event from the browser.
         *
         * @method bridge.MSPointer#onPointerOut
         * @param {PointerEvent} event - The native event from the browser. This gets stored in MSPointer.event.
         */
        onPointerOver(event: any): void;
        /**
         * Stop the event listeners.
         * @method bridge.MSPointer#stop
         */
        stop(): void;
    }
}
declare namespace ingenuity.bridge {
    class Pointer implements IPointer {
        static NO_BUTTON: number;
        static LEFT_BUTTON: number;
        static RIGHT_BUTTON: number;
        static MIDDLE_BUTTON: number;
        static BACK_BUTTON: number;
        static FORWARD_BUTTON: number;
        static ERASER_BUTTON: number;
        game: Game;
        id: number;
        pointerMode: number;
        type: number;
        exists: boolean;
        identifier: number;
        pointerId: number;
        target: any;
        button: number;
        leftButton: DeviceButton;
        middleButton: DeviceButton;
        rightButton: DeviceButton;
        backButton: DeviceButton;
        forwardButton: DeviceButton;
        eraserButton: DeviceButton;
        private _holdSent;
        private _history;
        private _nextDrop;
        private _stateReset;
        withinGame: boolean;
        clientX: number;
        clientY: number;
        pageX: number;
        pageY: number;
        screenX: number;
        screenY: number;
        rawMovementX: number;
        rawMovementY: number;
        movementX: number;
        movementY: number;
        x: number;
        y: number;
        isMouse: boolean;
        isDown: boolean;
        isUp: boolean;
        timeDown: number;
        timeUp: number;
        previousTapTime: number;
        totalTouches: number;
        msSinceLastClick: number;
        targetObject: any;
        interactiveCandidates: Array<any>;
        active: boolean;
        dirty: boolean;
        position: Point;
        positionDown: Point;
        positionUp: Point;
        circle: Circle;
        private _clickTrampolines;
        private _trampolineTargetObject;
        /**
         * @constructor
         * @param game
         * @param id
         * @param pointerMode
         */
        constructor(game: Game, id: number, pointerMode: number);
        readonly duration: number;
        /**
         * Resets the states of all the button booleans.
         *
         * @method Pointer#resetButtons
         * @protected
         */
        resetButtons(): void;
        /**
         * Called by updateButtons.
         *
         * @method Pointer#processButtonsDown
         * @param {integer} buttons - The DOM event.buttons property.
         * @param {MouseEvent} event - The DOM event.
         */
        private processButtonsDown;
        /**
         * Called by updateButtons.
         *
         * @method Pointer#processButtonsUp
         * @private
         * @param {integer} buttons - The DOM event.buttons property.
         * @param {MouseEvent} event - The DOM event.
         */
        private processButtonsUp;
        /**
         * Called when the event.buttons property changes from zero.
         * Contains a button bitmask.
         *
         * @method Pointer#updateButtons
         * @protected
         * @param {MouseEvent} event - The DOM event.
         */
        updateButtons(event: MouseEvent): void;
        /**
         * Called when the Pointer is pressed onto the touchscreen.
         * @method Pointer#start
         * @param {any} event - The DOM event from the browser.
         */
        start(event: any): Pointer;
        /**
         * Called by the Input Manager.
         * @method Pointer#update
         */
        update(): void;
        /**
         * Called when the Pointer is moved.
         *
         * @method Pointer#move
         * @param {MouseEvent|PointerEvent} event - The event passed up from the input handler.
         * @param {boolean} [fromClick=false] - Was this called from the click event?
         */
        move(event: MouseEvent | PointerEvent, fromClick?: boolean): Pointer;
        /**
         * Process all interactive objects to find out which ones were updated in the recent Pointer move.
         *
         * @method Pointer#processInteractiveObjects
         * @protected
         * @param {boolean} [fromClick=false] - Was this called from the click event?
         * @return {boolean} True if this method processes an object (i.e. a Sprite becomes the Pointers currentTarget), otherwise false.
         */
        processInteractiveObjects(fromClick: boolean): boolean;
        /**
         * This will change the `Pointer.targetObject` object to be the one provided.
         *
         * This allows you to have fine-grained control over which object the Pointer is targeting.
         *
         * Note that even if you set a new Target here, it is still able to be replaced by any other valid
         * target during the next Pointer update.
         *
         * @method Pointer#swapTarget
         * @param {InputHandler} newTarget - The new target for this Pointer. Note this is an `InputHandler`, so don't pass a Sprite, instead pass `sprite.input` to it.
         * @param {boolean} [silent=false] - If true the new target AND the old one will NOT dispatch their `onInputOver` or `onInputOut` events.
         */
        swapTarget(newTarget: any, silent: boolean): void;
        /**
         * Called when the Pointer leaves the target area.
         *
         * @method Pointer#leave
         * @param {MouseEvent|PointerEvent} event - The event passed up from the input handler.
         */
        leave(event: MouseEvent | PointerEvent): void;
        /**
         * Called when the Pointer leaves the touchscreen.
         *
         * @method Pointer#stop
         * @param {MouseEvent|PointerEvent|TouchEvent} event - The event passed up from the input handler.
         */
        stop(event: MouseEvent | PointerEvent | TouchEvent | any): Pointer;
        /**
         * The Pointer is considered justPressed if the time it was pressed onto the touchscreen or clicked is less than justPressedRate.
         * Note that calling justPressed doesn't reset the pressed status of the Pointer, it will return `true` for as long as the duration is valid.
         * If you wish to check if the Pointer was pressed down just once then see the Sprite.events.onInputDown event.
         * @method Pointer#justPressed
         * @param {number} [duration] - The time to check against. If none given it will use InputManager.justPressedRate.
         * @return {boolean} true if the Pointer was pressed down within the duration given.
         */
        justPressed(duration: number): boolean;
        /**
         * The Pointer is considered justReleased if the time it left the touchscreen is less than justReleasedRate.
         * Note that calling justReleased doesn't reset the pressed status of the Pointer, it will return `true` for as long as the duration is valid.
         * If you wish to check if the Pointer was released just once then see the Sprite.events.onInputUp event.
         * @method Pointer#justReleased
         * @param {number} [duration] - The time to check against. If none given it will use InputManager.justReleasedRate.
         * @return {boolean} true if the Pointer was released within the duration given.
         */
        justReleased(duration: number): boolean;
        /**
         * Add a click trampoline to this pointer.
         *
         * A click trampoline is a callback that is run on the DOM 'click' event; this is primarily
         * needed with certain browsers (ie. IE11) which restrict some actions like requestFullscreen
         * to the DOM 'click' event and rejects it for 'pointer*' and 'mouse*' events.
         *
         * This is used internally by the ScaleManager; click trampoline usage is uncommon.
         * Click trampolines can only be added to pointers that are currently down.
         *
         * @method Pointer#addClickTrampoline
         * @protected
         * @param {string} name - The name of the trampoline; must be unique among active trampolines in this pointer.
         * @param {function} callback - Callback to run/trampoline.
         * @param {object} callbackContext - Context of the callback.
         * @param {object[]|null} callbackArgs - Additional callback args, if any. Supplied as an array.
         */
        addClickTrampoline(name: string, callback: Function, callbackContext: any, callbackArgs: any[]): void;
        /**
         * Fire all click trampolines for which the pointers are still referring to the registered object.
         * @method Pointer#processClickTrampolines
         */
        processClickTrampolines(): void;
        /**
         * Resets the Pointer properties. Called by InputManager.reset when you perform a State change.
         * @method Pointer#reset
         */
        reset(): void;
        /**
         * Resets the movementX and movementY properties. Use in your update handler after retrieving the values.
         * @method Pointer#resetMovement
         */
        resetMovement(): void;
    }
}
declare namespace ingenuity.bridge {
    class SinglePad implements ISinglePad {
        game: Game;
        private _padParent;
        index: number;
        connected: boolean;
        callbackContext: any;
        onConnectCallback: Function;
        onDisconnectCallback: Function;
        onDownCallback: Function;
        onUpCallback: Function;
        onAxisCallback: Function;
        onFloatCallback: Function;
        deadZone: number;
        private _rawPad;
        private _prevTimestamp;
        private _buttons;
        private _buttonsLen;
        private _axes;
        private _axesLen;
        constructor(game: Game, padParent: any);
        /**
         * Add callbacks to this Gamepad to handle connect / disconnect / button down / button up / axis change / float value buttons.
         *
         * @method SinglePad#addCallbacks
         * @param {object} context - The context under which the callbacks are run.
         * @param {object} callbacks - Object that takes six different callbak methods:
         * onConnectCallback, onDisconnectCallback, onDownCallback, onUpCallback, onAxisCallback, onFloatCallback
         */
        addCallbacks(context: any, callbacks: any): void;
        /**
         * Gets a DeviceButton object from this controller to be stored and referenced locally.
         * The DeviceButton object can then be polled, have events attached to it, etc.
         *
         * @method SinglePad#getButton
         * @param {number} buttonCode - The buttonCode of the button, i.e. Gamepad.BUTTON_0, Gamepad.XBOX360_A, etc.
         * @return {DeviceButton} The DeviceButton object which you can store locally and reference directly.
         */
        getButton(buttonCode: number): DeviceButton;
        /**
         * Main update function called by Gamepad.
         *
         * @method SinglePad#pollStatus
         */
        pollStatus(): void;
        /**
         * Gamepad connect function, should be called by Gamepad.
         *
         * @method SinglePad#connect
         * @param {object} rawPad - The raw gamepad object
         */
        connect(rawPad: IObject): void;
        /**
         * Gamepad disconnect function, should be called by Gamepad.
         *
         * @method SinglePad#disconnect
         */
        disconnect(): void;
        /**
         * Destroys this object and associated callback references.
         *
         * @method SinglePad#destroy
         */
        destroy(): void;
        /**
         * Handles changes in axis.
         *
         * @method SinglePad#processAxisChange
         * @param {object} axisState - State of the relevant axis
         */
        processAxisChange(index: number, value: any): void;
        /**
         * Handles button down press.
         *
         * @method SinglePad#processButtonDown
         * @param {number} buttonCode - Which buttonCode of this button
         * @param {object} value - Button value
         */
        processButtonDown(buttonCode: number, value: any): void;
        /**
         * Handles button release.
         *
         * @method SinglePad#processButtonUp
         * @param {number} buttonCode - Which buttonCode of this button
         * @param {object} value - Button value
         */
        processButtonUp(buttonCode: number, value: any): void;
        /**
         * Handles buttons with floating values (like analog buttons that acts almost like an axis but still registers like a button)
         *
         * @method SinglePad#processButtonFloat
         * @param {number} buttonCode - Which buttonCode of this button
         * @param {object} value - Button value (will range somewhere between 0 and 1, but not specifically 0 or 1.
         */
        processButtonFloat(buttonCode: number, value: any): void;
        /**
         * Returns value of requested axis.
         *
         * @method SinglePad#axis
         * @param {number} axisCode - The index of the axis to check
         * @return {number} Axis value if available otherwise false
         */
        axis(axisCode: number): boolean;
        /**
         * Returns true if the button is pressed down.
         *
         * @method SinglePad#isDown
         * @param {number} buttonCode - The buttonCode of the button to check.
         * @return {boolean} True if the button is pressed down.
         */
        isDown(buttonCode: number): boolean;
        /**
         * Returns true if the button is not currently pressed.
         *
         * @method SinglePad#isUp
         * @param {number} buttonCode - The buttonCode of the button to check.
         * @return {boolean} True if the button is not currently pressed down.
         */
        isUp(buttonCode: number): boolean;
        /**
         * Returns the "just released" state of a button from this gamepad. Just released is considered as being true if the button was released within the duration given (default 250ms).
         *
         * @method SinglePad#justReleased
         * @param {number} buttonCode - The buttonCode of the button to check for.
         * @param {number} [duration=250] - The duration below which the button is considered as being just released.
         * @return {boolean} True if the button is just released otherwise false.
         */
        justReleased(buttonCode: number, duration: number): boolean;
        /**
         * Returns the "just pressed" state of a button from this gamepad. Just pressed is considered true if the button was pressed down within the duration given (default 250ms).
         *
         * @method SinglePad#justPressed
         * @param {number} buttonCode - The buttonCode of the button to check for.
         * @param {number} [duration=250] - The duration below which the button is considered as being just pressed.
         * @return {boolean} True if the button is just pressed otherwise false.
         */
        justPressed(buttonCode: number, duration: number): boolean;
        /**
         * Returns the value of a gamepad button. Intended mainly for cases when you have floating button values, for example
         * analog trigger buttons on the XBOX 360 controller.
         *
         * @method SinglePad#buttonValue
         * @param {number} buttonCode - The buttonCode of the button to check.
         * @return {number} Button value if available otherwise null. Be careful as this can incorrectly evaluate to 0.
         */
        buttonValue(buttonCode: number): number;
        /**
         * Reset all buttons/axes of this gamepad.
         *
         * @method SinglePad#reset
         */
        reset(): void;
    }
}
declare namespace ingenuity.bridge {
    class WheelEventProxy implements IWheelEventProxy {
        static _stubsGenerated: boolean;
        _scaleFactor: number;
        _deltaMode: number;
        private originalEvent;
        type: string;
        deltaZ: number;
        constructor(scaleFactor: number, deltaMode: number);
        readonly deltaMode: number;
        readonly deltaY: number;
        readonly deltaX: number;
        makeBinder(name: string): () => void;
        bindEvent(event: any): WheelEventProxy;
    }
}
/**
 * Declare here all exported variables (at respective namespaces) at the `bridge` layer.
 */
declare namespace ingenuity.bridge {
}
declare namespace ingenuity.bridge {
    class Signal implements ISignal {
        memorize: boolean;
        active: boolean;
        private boundDispatchVar;
        protected shouldPropagate: boolean;
        private bindings;
        private prevParams;
        readonly boundDispatch: boolean | Function;
        validateListener(listener: Function, fnName: string): void;
        has(listener: Function, context?: any): boolean;
        add(listener: Function, listenerContext?: any, priority?: number, data?: IObject): SignalBinding;
        addOnce(listener: Function, listenerContext?: any, priority?: number, data?: IObject): SignalBinding;
        remove(listener: Function, context?: any): Function;
        removeAll(context?: any): void;
        getNumListeners(): number;
        halt(): void;
        dispatch(...params: any[]): void;
        forget(): void;
        dispose(): void;
        toString(): string;
        private registerListener;
        private addBinding;
        private indexOfListener;
    }
}
declare namespace ingenuity.bridge {
    class SignalBinding implements ISignalBinding {
        context: any;
        callCount: number;
        active: boolean;
        params: any;
        listener: Function;
        private isOnceVar;
        private signal;
        priority: number;
        private args;
        constructor(signal: Signal, listener: Function, isOnce: boolean, listenerContext?: any, priority?: number, args?: any);
        execute(paramsArr?: any[]): any;
        detach(): Function;
        isBound(): boolean;
        isOnce(): boolean;
        getListener(): Function;
        getSignal(): ISignal;
        toString(): string;
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    /**
     * This is a base State class which can be extended if you are creating your own game.
     * It provides quick access to common functions such as the camera, cache, input, match, sound and more.
     *
     * #### Callbacks
     *
     * | start | preload     | loaded     | paused       | stop     |
     * |-------|-------------|------------|--------------|----------|
     * | init  |             |            |              |          |
     * |       | preload     | create     | paused       |          |
     * |       | loadUpdate* | update*    | pauseUpdate* |          |
     * |       |             | postUpdate*|              |          |
     * |       |             | preRender* |              |          |
     * |       | loadRender* | render*    | render*      |          |
     * |       |             |            | resumed      |          |
     * |       |             |            |              | shutdown |
     *
     * Update and render calls (*) are repeated.
     *
     * If your State has a constructor, it will be invoked exactly once, during bridge.StateManager#add()
     */
    class StateBase implements IState {
        game: Game;
        key: string;
        add: GameObjectFactory;
        camera: Camera;
        cache: Cache;
        input: Input;
        load: Loader;
        math: Maths;
        sound: SoundManager;
        scale: ScaleManager;
        stage: Stage | Container | PIXI.Container | any;
        state: StateManager;
        time: Time;
        tweens: Tween;
        particles: Particles;
        rnd: RandomDataGenerator;
        enabled: boolean;
        created: boolean;
        constructor(game?: Game);
        create(game?: Game): void;
        init(...args: any[]): void;
        loadRender(game?: Game): void;
        loadUpdate(game?: Game): void;
        paused(game?: Game): void;
        pauseUpdate(game?: Game): void;
        preload(game?: Game): void;
        preRender(game?: Game, elapsedTime?: number): void;
        render(game?: Game): void;
        resize(width?: number, height?: number): void;
        resumed(game?: Game): void;
        shutdown(game?: Game): void;
        update(game?: Game): void;
    }
}
declare namespace ingenuity.bridge {
    class StateManager implements IStateManager {
        current: string;
        states: {
            [key: string]: StateBase;
        };
        onInitCallback: () => void;
        onPreloadCallback: () => void;
        onCreateCallback: () => void;
        onUpdateCallback: () => void;
        onRenderCallback: () => void;
        onResizeCallback: () => void;
        onPreRenderCallback: () => void;
        onLoadUpdateCallback: () => void;
        onLoadRenderCallback: () => void;
        onPausedCallback: () => void;
        onResumedCallback: () => void;
        onPauseUpdateCallback: () => void;
        onShutDownCallback: () => void;
        protected game: Game;
        private pendingState;
        protected clearWorld: boolean;
        protected clearCache: boolean;
        private args;
        private callbackContext;
        private onStateChange;
        private created;
        constructor(game: Game, pendingState: StateBase);
        link(key: string): void;
        unlink(key: string): void;
        getCurrentState(): StateBase | any;
        setCurrentState(key: string): void;
        protected pauseUpdate(): void;
        boot(): void;
        pause(): void;
        add(key: string, state: StateBase | any, autoStart?: boolean): StateBase | any;
        checkState(key: string): boolean;
        clearCurrentState(): void;
        destroy(): void;
        loadComplete(): void;
        preRender(elapsedTime: number): void;
        preUpdate(): void;
        render(): void;
        remove(key: string): void;
        resume(): void;
        restart(clearWorld?: boolean, clearCache?: boolean, ...args: any[]): void;
        resize(width: number, height: number): void;
        start(key: string, clearWorld?: boolean, clearCache?: boolean, ...args: any[]): void;
        update(): void;
        dummy(): void;
        loadUpdate(): void;
    }
}
declare namespace ingenuity.bridge {
    class Time implements ITime {
        advancedTiming: boolean;
        desiredFpsMult: number;
        elapsed: number;
        events: Timer;
        elapsedMS: number;
        fps: number;
        fpsMax: number;
        fpsMin: number;
        frames: number;
        game: Game;
        lastTime: number;
        msMax: number;
        msMin: number;
        now: number;
        pausedTime: number;
        pauseDuration: number;
        physicsElapsed: number;
        physicsElapsedMS: number;
        prevTime: number;
        renders: number;
        rps: number;
        slowMotion: number;
        suggestedFps: number;
        time: number;
        timeExpected: number;
        timeToCall: number;
        updates: number;
        ups: number;
        private frameCount;
        private elapsedAccumulator;
        private started;
        private timeLastSecond;
        private pauseStarted;
        protected justResumed: boolean;
        private timers;
        private desiredFpsObj;
        constructor(game: Game);
        boot(): void;
        add(timer: Timer): Timer;
        create(autoDestroy?: boolean): Timer;
        removeAll(): void;
        refresh(): void;
        update(time: number): void;
        updateTimers(): void;
        updateAdvancedTiming(): void;
        countUpdate(): void;
        countRender(): void;
        gamePaused(): void;
        gameResumed(): void;
        totalElapsedSeconds(): number;
        elapsedSince(since: number): number;
        elapsedSecondsSince(since: number): number;
        reset(): void;
        desiredFps: number;
    }
}
declare namespace ingenuity.bridge {
    class Timer implements ITimer {
        static HALF: number;
        static MINUTE: number;
        static QUARTER: number;
        static SECOND: number;
        autoDestroy: boolean;
        events: TimerEvent[];
        expired: boolean;
        game: Game;
        nextTick: number;
        onComplete: Signal;
        running: boolean;
        paused: boolean;
        protected elapsed: number;
        protected timeCap: number;
        private codePaused;
        private started;
        private pauseStarted;
        private pauseTotal;
        private now;
        private len;
        private marked;
        private i;
        private newTick;
        constructor(game: Game, autoDestroy?: boolean);
        create(delay: number, loop: boolean, repeatCount: number, callback: Function, callbackContext: any, args: any): TimerEvent;
        add(delay: number, callback: Function, callbackContext?: any, ...args: any[]): TimerEvent;
        repeat(delay: number, repeatCount: number, callback: Function, callbackContext?: any, ...args: any[]): TimerEvent;
        loop(delay: number, callback: Function, callbackContext?: any, ...args: any[]): TimerEvent;
        start(delay?: number): void;
        stop(clearEvents: boolean): void;
        remove(event: TimerEvent): boolean;
        order(): void;
        sortHandler(a: any, b: any): number;
        clearPendingEvents(): void;
        update(time: number): boolean;
        pause(): void;
        _pause(): void;
        adjustEvents(baseTime: number): void;
        resume(): void;
        _resume(): void;
        removeAll(): void;
        destroy(): void;
        readonly next: number;
        readonly duration: number;
        readonly length: number;
        readonly ms: number;
        readonly seconds: number;
    }
}
declare namespace ingenuity.bridge {
    class TimerEvent implements ITimerEvent {
        args: any[];
        callback: Function;
        callbackContext: any;
        delay: number;
        loop: boolean;
        pendingDelete: boolean;
        repeatCount: number;
        tick: number;
        timer: Timer;
        constructor(timer: Timer, delay: number, tick: number, repeatCount: number, loop: boolean, callback: Function, callbackContext?: any, ...args: any[]);
    }
}
declare namespace ingenuity.bridge {
    class Tween implements ITween {
        chainedTween: ITween;
        current: number;
        frameBased?: boolean;
        isRunning: boolean;
        isPaused: boolean;
        manager?: ITweenManager;
        onChildComplete: ISignal;
        onComplete: ISignal;
        onLoop: ISignal;
        onRepeat: ISignal;
        onStart: ISignal;
        pendingDelete?: boolean;
        properties?: IObject;
        repeatCounter: number;
        reverse: boolean;
        target: any;
        timeline: Array<ITweenData>;
        timeScale: number;
        game: Game;
        readonly totalDuration: number;
        private _onUpdateCallback;
        private _onUpdateCallbackContext;
        private _pausedTime;
        private _codePaused;
        private _hasStarted;
        /**
         * Creates a tween using an object.
         * Prefer creating a tween through the TweenManager as `game.add.tween()`
         * @param target the target object. Usually a `DisplayObject`, however it can be used on any `Object`.
         * @param game The Game instance
         * @param manager The TweenManager
         */
        constructor(target: any, game: Game, manager: ITweenManager);
        /**
         * Sets this tween to be a `to` tween on the properties given. A `to` tween starts at the current value and tweens to the destination value given.
         * For example a Sprite with an `x` coordinate of 100 could be tweened to `x` 200 by giving a properties object of `{ x: 200 }`.
         * The ease function allows you define the rate of change. You can pass either a function such as Easing.Circular.Out or a string such as "Circ".
         * ".easeIn", ".easeOut" and "easeInOut" variants are all supported for all ease types.
         *
         * @method Tween#to
         * @param {object} properties - An object containing the properties you want to tween, such as `Sprite.x` or `Sound.volume`. Given as a JavaScript object.
         * @param {number} [duration=1000] - Duration of this tween in ms. Or if `Tween.frameBased` is true this represents the number of frames that should elapse.
         * @param {function|string} [ease=null] - Easing function. If not set it will default to Easing.Default, which is Easing.Linear.None by default but can be over-ridden.
         * @param {boolean} [autoStart=false] - Set to `true` to allow this tween to start automatically. Otherwise call Tween.start().
         * @param {number} [delay=0] - Delay before this tween will start in milliseconds. Defaults to 0, no delay.
         * @param {number} [repeat=0] - Should the tween automatically restart once complete? If you want it to run forever set as -1. This only effects this individual tween, not any chained tweens.
         * @param {boolean} [yoyo=false] - A tween that yoyos will reverse itself and play backwards automatically. A yoyo'd tween doesn't fire the Tween.onComplete event, so listen for Tween.onLoop instead.
         * @return {Tween} This Tween object, useful for chaining.
         */
        to(properties: IObject, duration?: number, ease?: any, autoStart?: boolean, delay?: number, repeat?: number, yoyo?: boolean): Tween;
        /**
         * Sets this tween to be a `from` tween on the properties given. A `from` tween sets the target to the destination value and tweens to its current value.
         * For example a Sprite with an `x` coordinate of 100 tweened from `x` 500 would be set to `x` 500 and then tweened to `x` 100 by giving a properties object of `{ x: 500 }`.
         * The ease function allows you define the rate of change. You can pass either a function such as Easing.Circular.Out or a string such as "Circ".
         * ".easeIn", ".easeOut" and "easeInOut" variants are all supported for all ease types.
         *
         * @method Tween#from
         * @param {object} properties - An object containing the properties you want to tween., such as `Sprite.x` or `Sound.volume`. Given as a JavaScript object.
         * @param {number} [duration=1000] - Duration of this tween in ms. Or if `Tween.frameBased` is true this represents the number of frames that should elapse.
         * @param {function|string} [ease=null] - Easing function. If not set it will default to Easing.Default, which is Easing.Linear.None by default but can be over-ridden.
         * @param {boolean} [autoStart=false] - Set to `true` to allow this tween to start automatically. Otherwise call Tween.start().
         * @param {number} [delay=0] - Delay before this tween will start in milliseconds. Defaults to 0, no delay.
         * @param {number} [repeat=0] - Should the tween automatically restart once complete? If you want it to run forever set as -1. This only effects this induvidual tween, not any chained tweens.
         * @param {boolean} [yoyo=false] - A tween that yoyos will reverse itself and play backwards automatically. A yoyo'd tween doesn't fire the Tween.onComplete event, so listen for Tween.onLoop instead.
         * @return {Tween} This Tween object.
         */
        from(properties: IObject, duration?: number, ease?: string | Function, autoStart?: boolean, delay?: number, repeat?: number, yoyo?: boolean): Tween;
        /**
         * Starts the tween running. Can also be called by the autoStart parameter of `Tween.to` or `Tween.from`.
         * This sets the `Tween.isRunning` property to `true` and dispatches a `Tween.onStart` signal.
         * If the Tween has a delay set then nothing will start tweening until the delay has expired.
         *
         * @method Tween#start
         * @param {number} [index=0] - If this Tween contains child tweens you can specify which one to start from. The default is zero, i.e. the first tween created.
         * @return {Tween} This tween. Useful for method chaining.
         */
        start(index?: number): Tween;
        /**
         * Stops the tween if running and flags it for deletion from the TweenManager.
         * If called directly the `Tween.onComplete` signal is not dispatched and no chained tweens are started unless the complete parameter is set to `true`.
         * If you just wish to pause a tween then use Tween.pause instead.
         *
         * @method Tween#stop
         * @param {boolean} [complete=false] - Set to `true` to dispatch the Tween.onComplete signal.
         * @return {Tween} This tween. Useful for method chaining.
         */
        stop(complete?: boolean): Tween;
        /**
         * Updates either a single TweenData or all TweenData objects properties to the given value.
         * Used internally by methods like Tween.delay, Tween.yoyo, etc. but can also be called directly if you know which property you want to tweak.
         * The property is not checked, so if you pass an invalid one you'll generate a run-time error.
         *
         * @method Tween#updateTweenData
         * @param {string} property - The property to update.
         * @param {number|function} value - The value to set the property to.
         * @param {number} [index=0] - If this tween has more than one child this allows you to target a specific child. If set to -1 it will set the delay on all the children.
         * @return {Tween} This tween. Useful for method chaining.
         */
        updateTweenData(property: string, value: number | Function | any, index?: number): Tween;
        /**
         * Sets the delay in milliseconds before this tween will start. If there are child tweens it sets the delay before the first child starts.
         * The delay is invoked as soon as you call `Tween.start`. If the tween is already running this method doesn't do anything for the current active tween.
         * If you have not yet called `Tween.to` or `Tween.from` at least once then this method will do nothing, as there are no tweens to delay.
         * If you have child tweens and pass -1 as the index value it sets the delay across all of them.
         *
         * @method Tween#delay
         * @param {number} duration - The amount of time in ms that the Tween should wait until it begins once started is called. Set to zero to remove any active delay.
         * @param {number} [index=0] - If this tween has more than one child this allows you to target a specific child. If set to -1 it will set the delay on all the children.
         * @return {Tween} This tween. Useful for method chaining.
         */
        delay(duration: number, index: number): Tween;
        /**
         * Sets the number of times this tween will repeat.
         * If you have not yet called `Tween.to` or `Tween.from` at least once then this method will do nothing, as there are no tweens to repeat.
         * If you have child tweens and pass -1 as the index value it sets the number of times they'll repeat across all of them.
         * If you wish to define how many times this Tween and all children will repeat see Tween.repeatAll.
         *
         * @method Tween#repeat
         * @param {number} total - How many times a tween should repeat before completing. Set to zero to remove an active repeat. Set to -1 to repeat forever.
         * @param {number} [repeat=0] - This is the amount of time to pause (in ms) before the repeat will start.
         * @param {number} [index=0] - If this tween has more than one child this allows you to target a specific child. If set to -1 it will set the repeat value on all the children.
         * @return {Tween} This tween. Useful for method chaining.
         */
        repeat(total: number, repeatDelay?: number, index?: number): Tween;
        /**
         * Sets the delay in milliseconds before this tween will repeat itself.
         * The repeatDelay is invoked as soon as you call `Tween.start`. If the tween is already running this method doesn't do anything for the current active tween.
         * If you have not yet called `Tween.to` or `Tween.from` at least once then this method will do nothing, as there are no tweens to set repeatDelay on.
         * If you have child tweens and pass -1 as the index value it sets the repeatDelay across all of them.
         *
         * @method Tween#repeatDelay
         * @param {number} duration - The amount of time in ms that the Tween should wait until it repeats or yoyos once start is called. Set to zero to remove any active repeatDelay.
         * @param {number} [index=0] - If this tween has more than one child this allows you to target a specific child. If set to -1 it will set the repeatDelay on all the children.
         * @return {Tween} This tween. Useful for method chaining.
         */
        repeatDelay(duration: number, index?: number): Tween;
        /**
         * A Tween that has yoyo set to true will run through from its starting values to its end values and then play back in reverse from end to start.
         * Used in combination with repeat you can create endless loops.
         * If you have not yet called `Tween.to` or `Tween.from` at least once then this method will do nothing, as there are no tweens to yoyo.
         * If you have child tweens and pass -1 as the index value it sets the yoyo property across all of them.
         * If you wish to yoyo this Tween and all of its children then see Tween.yoyoAll.
         *
         * @method Tween#yoyo
         * @param {boolean} enable - Set to true to yoyo this tween, or false to disable an already active yoyo.
         * @param {number} [yoyoDelay=0] - This is the amount of time to pause (in ms) before the yoyo will start.
         * @param {number} [index=0] - If this tween has more than one child this allows you to target a specific child. If set to -1 it will set yoyo on all the children.
         * @returns {Tween} This tween. Useful for method chaining.
         *
         */
        yoyo(enable: boolean, yoyoDelay?: number, index?: number): Tween;
        /**
         * Sets the delay in milliseconds before this tween will run a yoyo (only applies if yoyo is enabled).
         * The repeatDelay is invoked as soon as you call `Tween.start`. If the tween is already running this method doesn't do anything for the current active tween.
         * If you have not yet called `Tween.to` or `Tween.from` at least once then this method will do nothing, as there are no tweens to set repeatDelay on.
         * If you have child tweens and pass -1 as the index value it sets the repeatDelay across all of them.
         *
         * @method Tween#yoyoDelay
         * @param {number} duration - The amount of time in ms that the Tween should wait until it repeats or yoyos once start is called. Set to zero to remove any active yoyoDelay.
         * @param {number} [index=0] - If this tween has more than one child this allows you to target a specific child. If set to -1 it will set the yoyoDelay on all the children.
         * @return {Tween} This tween. Useful for method chaining.
         */
        yoyoDelay(duration: number, index?: number): Tween;
        /**
         * Set easing function this tween will use, i.e. Easing.Linear.None.
         * The ease function allows you define the rate of change. You can pass either a function such as Easing.Circular.Out or a string such as "Circ".
         * ".easeIn", ".easeOut" and "easeInOut" variants are all supported for all ease types.
         * If you have child tweens and pass -1 as the index value it sets the easing function defined here across all of them.
         *
         * @method Tween#easing
         * @param {function|string} ease - The easing function this tween will use, i.e. Easing.Linear.None.
         * @param {number} [index=0] - If this tween has more than one child this allows you to target a specific child. If set to -1 it will set the easing function on all children.
         * @return {Tween} This tween. Useful for method chaining.
         */
        easing(ease: Function | string, index?: number): Tween;
        /**
         * Sets the interpolation function the tween will use. By default it uses Math.linearInterpolation.
         * Also available: Math.bezierInterpolation and Math.catmullRomInterpolation.
         * The interpolation function is only used if the target properties is an array.
         * If you have child tweens and pass -1 as the index value and it will set the interpolation function across all of them.
         *
         * @method Tween#interpolation
         * @param {function} interpolation - The interpolation function to use (Math.linearInterpolation by default)
         * @param {object} [context] - The context under which the interpolation function will be run.
         * @param {number} [index=0] - If this tween has more than one child this allows you to target a specific child. If set to -1 it will set the interpolation function on all children.
         * @return {Tween} This tween. Useful for method chaining.
         */
        interpolation(interpolation: Function, context?: Object, index?: number): Tween;
        /**
         * Set how many times this tween and all of its children will repeat.
         * A tween (A) with 3 children (B,C,D) with a `repeatAll` value of 2 would play as: ABCDABCD before completing.
         * When all child tweens have completed Tween.onLoop will be dispatched.
         *
         * @method Tween#repeat
         * @param {number} total - How many times this tween and all children should repeat before completing. Set to zero to remove an active repeat. Set to -1 to repeat forever.
         * @return {Tween} This tween. Useful for method chaining.
         */
        repeatAll(total?: number): Tween;
        /**
         * This method allows you to chain tweens together. Any tween chained to this tween will have its `Tween.start` method called
         * as soon as this tween completes. If this tween never completes (i.e. repeatAll or loop is set) then the chain will never progress.
         * Note that `Tween.onComplete` will fire when *this* tween completes, not when the whole chain completes.
         * For that you should listen to `onComplete` on the final tween in your chain.
         *
         * If you pass multiple tweens to this method they will be joined into a single long chain.
         * For example if this is Tween A and you pass in B, C and D then B will be chained to A, C will be chained to B and D will be chained to C.
         * Any previously chained tweens that may have been set will be overwritten.
         *
         * @method Tween#chain
         * @param {...Tween} tweens - One or more tweens that will be chained to this one.
         * @return {Tween} This tween. Useful for method chaining.
         */
        chain(...args: any[]): Tween;
        /**
         * Enables the looping of this tween and all child tweens. If this tween has no children this setting has no effect.
         * If `value` is `true` then this is the same as setting `Tween.repeatAll(-1)`.
         * If `value` is `false` it is the same as setting `Tween.repeatAll(0)` and will reset the `repeatCounter` to zero.
         *
         * Usage:
         * game.add.tween(p).to({ x: 700 }, 1000, Easing.Linear.None, true)
         * .to({ y: 300 }, 1000, Easing.Linear.None)
         * .to({ x: 0 }, 1000, Easing.Linear.None)
         * .to({ y: 0 }, 1000, Easing.Linear.None)
         * .loop();
         * @method Tween#loop
         * @param {boolean} [value=true] - If `true` this tween and any child tweens will loop once they reach the end. Set to `false` to remove an active loop.
         * @return {Tween} This tween. Useful for method chaining.
         */
        loop(value?: boolean): Tween;
        /**
         * Sets a callback to be fired each time this tween updates.
         *
         * @method Tween#onUpdateCallback
         * @param {function} callback - The callback to invoke each time this tween is updated. Set to `null` to remove an already active callback.
         * @param {object} callbackContext - The context in which to call the onUpdate callback.
         * @return {Tween} This tween. Useful for method chaining.
         */
        onUpdateCallback(callback: Function, callbackContext: any): Tween;
        /**
         * Pauses the tween. Resume playback with Tween.resume.
         *
         * @method Tween#pause
         */
        pause(): void;
        /**
         * This is called by the core Game loop. Do not call it directly, instead use Tween.pause.
         *
         * @private
         * @method Tween#_pause
         */
        protected _pause(): void;
        /**
         * Resumes a paused tween.
         *
         * @method Tween#resume
         */
        resume(): void;
        /**
         * This is called by the core Game loop. Do not call it directly, instead use Tween.pause.
         * @method Tween#_resume
         * @private
         */
        protected _resume(): void;
        /**
         * Core tween update function called by the TweenManager. Does not need to be invoked directly.
         *
         * @method Tween#update
         * @param {number} time - A timestamp passed in by the TweenManager.
         * @return {boolean} false if the tween and all child tweens have completed and should be deleted from the manager, otherwise true (still active).
         */
        update(time: number): boolean;
        /**
         * This will generate an array populated with the tweened object values from start to end.
         * It works by running the tween simulation at the given frame rate based on the values set-up in Tween.to and Tween.from.
         * It ignores delay and repeat counts and any chained tweens, but does include child tweens.
         * Just one play through of the tween data is returned, including yoyo if set.
         *
         * @method Tween#generateData
         * @param {number} [frameRate=60] - The speed in frames per second that the data should be generated at. The higher the value, the larger the array it creates.
         * @param {array} [data] - If given the generated data will be appended to this array, otherwise a new array will be returned.
         * @return {array} An array of tweened values.
         */
        generateData(frameRate?: number, data?: any): any[];
    }
}
declare namespace ingenuity.bridge {
    class TweenData implements ITweenData {
        static PENDING: number;
        static RUNNING: number;
        static LOOPED: number;
        static COMPLETE: number;
        parent: ITween;
        game: Game;
        repeatTotal: number;
        private vStart;
        private vStartCache;
        vEnd: IObject;
        private vEndCache;
        duration: number;
        percent: number;
        value: number;
        repeatCounter: number;
        repeatDelay: number;
        interpolate: boolean;
        yoyo: boolean;
        yoyoDelay: number;
        inReverse: boolean;
        delay: number;
        dt: number;
        startTime: number;
        easingFunction: Function;
        interpolationFunction: Function;
        interpolationContext: Object;
        isRunning: boolean;
        isFrom: boolean;
        yoyoCounter: number;
        constructor(parent: ITween);
        /**
         * Sets this tween to be a `to` tween on the properties given. A `to` tween starts at the current value and tweens to the destination value given.
         * For example a Sprite with an `x` coordinate of 100 could be tweened to `x` 200 by giving a properties object of `{ x: 200 }`.
         *
         * @method TweenData#to
         * @param {object} properties - The properties you want to tween, such as `Sprite.x` or `Sound.volume`. Given as a JavaScript object.
         * @param {number} [duration=1000] - Duration of this tween in ms.
         * @param {function} [ease=null] - Easing function. If not set it will default to Easing.Default, which is Easing.Linear.None by default but can be over-ridden at will.
         * @param {number} [delay=0] - Delay before this tween will start, defaults to 0 (no delay). Value given is in ms.
         * @param {number} [repeat=0] - Should the tween automatically restart once complete? If you want it to run forever set as -1. This ignores any chained tweens.
         * @param {boolean} [yoyo=false] - A tween that yoyos will reverse itself and play backwards automatically. A yoyo'd tween doesn't fire the Tween.onComplete event, so listen for Tween.onLoop instead.
         * @return {TweenData} This Tween object.
         */
        to(properties: IObject, duration: number, ease: Function, delay: number, repeat: number, yoyo: boolean): TweenData;
        /**
         * Sets this tween to be a `from` tween on the properties given. A `from` tween sets the target to the destination value and tweens to its current value.
         * For example a Sprite with an `x` coordinate of 100 tweened from `x` 500 would be set to `x` 500 and then tweened to `x` 100 by giving a properties object of `{ x: 500 }`.
         *
         * @method TweenData#from
         * @param {object} properties - The properties you want to tween, such as `Sprite.x` or `Sound.volume`. Given as a JavaScript object.
         * @param {number} [duration=1000] - Duration of this tween in ms.
         * @param {function} [ease=null] - Easing function. If not set it will default to Easing.Default, which is Easing.Linear.None by default but can be over-ridden at will.
         * @param {number} [delay=0] - Delay before this tween will start, defaults to 0 (no delay). Value given is in ms.
         * @param {number} [repeat=0] - Should the tween automatically restart once complete? If you want it to run forever set as -1. This ignores any chained tweens.
         * @param {boolean} [yoyo=false] - A tween that yoyos will reverse itself and play backwards automatically. A yoyo'd tween doesn't fire the Tween.onComplete event, so listen for Tween.onLoop instead.
         * @return {TweenData} This Tween object.
         */
        from(properties: IObject, duration: number, ease: Function, delay: number, repeat: number, yoyo: boolean): TweenData;
        /**
         * Starts the Tween running.
         *
         * @method TweenData#start
         * @return {TweenData} This Tween object.
         */
        start(): TweenData;
        /**
         * Loads the values from the target object into this Tween.
         * @method TweenData#loadValues
         * @return {TweenData} This Tween object.
         */
        loadValues(): TweenData;
        /**
         * Updates this Tween. This is called automatically by Tween.
         *
         * @protected
         * @method TweenData#update
         * @param {number} time - A timestamp passed in by the Tween parent.
         * @return {number} The current status of this Tween. One of the TweenData constants: PENDING, RUNNING, LOOPED or COMPLETE.
         */
        update(time: number): number;
        /**
         * This will generate an array populated with the tweened object values from start to end.
         * It works by running the tween simulation at the given frame rate based on the values set-up in Tween.to and Tween.from.
         * Just one play through of the tween data is returned, including yoyo if set.
         *
         * @method TweenData#generateData
         * @param {number} [frameRate=60] - The speed in frames per second that the data should be generated at. The higher the value, the larger the array it creates.
         * @return {array} An array of tweened values.
         */
        generateData(frameRate: number): Array<any>;
        /**
         * Checks if this Tween is meant to repeat or yoyo and handles doing so.
         *
         * @private
         * @method TweenData#repeat
         * @return {number} Either TweenData.LOOPED or TweenData.COMPLETE.
         */
        private repeat;
    }
}
declare namespace ingenuity.bridge {
    class TweenManager implements ITweenManager {
        frameBase: boolean;
        game: Game;
        private _tweens;
        private _add;
        easeMap: IObject;
        constructor(game: Game);
        getAll(): Tween[];
        removeAll(): void;
        /**
         * Remove all tweens from a specific object, array of objects or Group.
         *
         * @method TweenManager#removeFrom
         * @param {object|object[]|Group} obj - The object you want to remove the tweens from.
         * @param {boolean} [children=true] - If passing a group, setting this to true will remove the tweens from all of its children instead of the group itself.
         */
        removeFrom(obj: any, children?: boolean): void;
        /**
         * Add a new tween into the TweenManager.
         *
         * @method TweenManager#add
         * @param {Tween} tween - The tween object you want to add.
         * @returns {Tween} The tween object you added to the manager.
         */
        add(tween: Tween): Tween;
        /**
         * Create a tween object for a specific object. The object can be any JavaScript object or bridge object such as Sprite.
         *
         * @method TweenManager#create
         * @param {object} object - Object the tween will be run on.
         * @returns {Tween} The newly created tween object.
         */
        create(object: any): Tween;
        /**
         * Remove a tween from this manager.
         *
         * @method TweenManager#remove
         * @param {Tween} tween - The tween object you want to remove.
         */
        remove(tween: Tween): Tween;
        /**
         * Update all the tween objects you added to this manager.
         *
         * @method bridge.TweenManager#update
         * @returns {boolean} Return false if there's no tween to update, otherwise return true.
         */
        update(): boolean;
        /**
         * Checks to see if a particular Sprite is currently being tweened.
         *
         * @method TweenManager#isTweening
         * @param {object} object - The object to check for tweens against.
         * @returns {boolean} Returns true if the object is currently being tweened, false if not.
         */
        isTweening(object: any): boolean;
        /**
         * Private. Called by game focus loss. Pauses all currently running tweens.
         *
         * @method TweenManager#_pauseAll
         * @private
         */
        private _pauseAll;
        /**
         * Private. Called by game focus loss. Resumes all currently paused tweens.
         *
         * @method TweenManager#_resumeAll
         * @private
         */
        private _resumeAll;
        /**
         * Pauses all currently running tweens.
         *
         * @method TweenManager#pauseAll
         */
        pauseAll(): void;
        /**
         * Resumes all currently paused tweens.
         *
         * @method TweenManager#resumeAll
         */
        resumeAll(): void;
    }
}
declare namespace ingenuity.bridge {
    class Color {
        /**
         * Packs the r, g, b, a components into a single integer, for use with Int32Array.
         * If device is little endian then ABGR order is used. Otherwise RGBA order is used.
         *
         * @method Color.packPixel
         * @static
         * @param {number} r - The red color component, in the range 0 - 255.
         * @param {number} g - The green color component, in the range 0 - 255.
         * @param {number} b - The blue color component, in the range 0 - 255.
         * @param {number} a - The alpha color component, in the range 0 - 255.
         * @return {number} The packed color as uint32
         */
        static packPixel(r: number, g: number, b: number, a: number): number;
        /**
         * Unpacks the r, g, b, a components into the specified color object, or a new
         * object, for use with Int32Array. If little endian, then ABGR order is used when
         * unpacking, otherwise, RGBA order is used. The resulting color object has the
         * `r, g, b, a` properties which are unrelated to endianness.
         *
         * Note that the integer is assumed to be packed in the correct endianness. On little-endian
         * the format is 0xAABBGGRR and on big-endian the format is 0xRRGGBBAA. If you want a
         * endian-independent method, use fromRGBA(rgba) and toRGBA(r, g, b, a).
         *
         * @method Color.unpackPixel
         * @static
         * @param {number} rgba - The integer, packed in endian order by packPixel.
         * @param {object} [out] - An object into which 3 properties will be created: r, g and b. If not provided a new object will be created.
         * @param {boolean} [hsl=false] - Also convert the rgb values into hsl?
         * @param {boolean} [hsv=false] - Also convert the rgb values into hsv?
         * @return {object} An object with the red, green and blue values set in the r, g and b properties.
         */
        static unpackPixel(rgba: number, out?: any, hsl?: boolean, hsv?: boolean): any;
        /**
         * A utility to convert an integer in 0xRRGGBBAA format to a color object.
         * This does not rely on endianness.
         *
         * @method Color.fromRGBA
         * @static
         * @param {number} rgba - An RGBA hex
         * @param {object} [out] - The object to use, optional.
         * @return {object} A color object.
         */
        static fromRGBA(rgba: number, out: any): any;
        /**
         * A utility to convert RGBA components to a 32 bit integer in RRGGBBAA format.
         *
         * @method Color.toRGBA
         * @static
         * @param {number} r - The red color component, in the range 0 - 255.
         * @param {number} g - The green color component, in the range 0 - 255.
         * @param {number} b - The blue color component, in the range 0 - 255.
         * @param {number} a - The alpha color component, in the range 0 - 255.
         * @return {number} A RGBA-packed 32 bit integer
         */
        static toRGBA(r: number, g: number, b: number, a: number): number;
        /**
         * Converts RGBA components to a 32 bit integer in AABBGGRR format.
         *
         * @method Color.toABGR
         * @static
         * @param {number} r - The red color component, in the range 0 - 255.
         * @param {number} g - The green color component, in the range 0 - 255.
         * @param {number} b - The blue color component, in the range 0 - 255.
         * @param {number} a - The alpha color component, in the range 0 - 255.
         * @return {number} A RGBA-packed 32 bit integer
         */
        static toABGR(r: number, g: number, b: number, a: number): number;
        /**
         * Converts an RGB color value to HSL (hue, saturation and lightness).
         * Conversion forumla from http://en.wikipedia.org/wiki/HSL_color_space.
         * Assumes RGB values are contained in the set [0, 255] and returns h, s and l in the set [0, 1].
         * Based on code by Michael Jackson (https://github.com/mjijackson)
         *
         * @method Color.RGBtoHSL
         * @static
         * @param {number} r - The red color component, in the range 0 - 255.
         * @param {number} g - The green color component, in the range 0 - 255.
         * @param {number} b - The blue color component, in the range 0 - 255.
         * @param {object} [out] - An object into which 3 properties will be created, h, s and l. If not provided a new object will be created.
         * @return {object} An object with the hue, saturation and lightness values set in the h, s and l properties.
         */
        static RGBtoHSL(r: number, g: number, b: number, out: any): any;
        /**
         * Converts an HSL (hue, saturation and lightness) color value to RGB.
         * Conversion forumla from http://en.wikipedia.org/wiki/HSL_color_space.
         * Assumes HSL values are contained in the set [0, 1] and returns r, g and b values in the set [0, 255].
         * Based on code by Michael Jackson (https://github.com/mjijackson)
         *
         * @method Color.HSLtoRGB
         * @static
         * @param {number} h - The hue, in the range 0 - 1.
         * @param {number} s - The saturation, in the range 0 - 1.
         * @param {number} l - The lightness, in the range 0 - 1.
         * @param {object} [out] - An object into which 3 properties will be created: r, g and b. If not provided a new object will be created.
         * @return {object} An object with the red, green and blue values set in the r, g and b properties.
         */
        static HSLtoRGB(h: number, s?: number, l?: number, out?: any): any;
        /**
         * Converts an RGB color value to HSV (hue, saturation and value).
         * Conversion forumla from http://en.wikipedia.org/wiki/HSL_color_space.
         * Assumes RGB values are contained in the set [0, 255] and returns h, s and v in the set [0, 1].
         * Based on code by Michael Jackson (https://github.com/mjijackson)
         *
         * @method Color.RGBtoHSV
         * @static
         * @param {number} r - The red color component, in the range 0 - 255.
         * @param {number} g - The green color component, in the range 0 - 255.
         * @param {number} b - The blue color component, in the range 0 - 255.
         * @param {object} [out] - An object into which 3 properties will be created, h, s and v. If not provided a new object will be created.
         * @return {object} An object with the hue, saturation and value set in the h, s and v properties.
         */
        static RGBtoHSV(r: number, g: number, b: number, out: any): any;
        /**
         * Converts an HSV (hue, saturation and value) color value to RGB.
         * Conversion forumla from http://en.wikipedia.org/wiki/HSL_color_space.
         * Assumes HSV values are contained in the set [0, 1] and returns r, g and b values in the set [0, 255].
         * Based on code by Michael Jackson (https://github.com/mjijackson)
         *
         * @method Color.HSVtoRGB
         * @static
         * @param {number} h - The hue, in the range 0 - 1.
         * @param {number} s - The saturation, in the range 0 - 1.
         * @param {number} v - The value, in the range 0 - 1.
         * @param {object} [out] - An object into which 3 properties will be created: r, g and b. If not provided a new object will be created.
         * @return {object} An object with the red, green and blue values set in the r, g and b properties.
         */
        static HSVtoRGB(h: number, s: number, v: number, out?: any): any;
        /**
         * Converts a hue to an RGB color.
         * Based on code by Michael Jackson (https://github.com/mjijackson)
         *
         * @method Color.hueToColor
         * @static
         * @param {number} p
         * @param {number} q
         * @param {number} t
         * @return {number} The color component value.
         */
        static hueToColor(p: number, q: number, t: number): number;
        /**
         * A utility function to create a lightweight "color" object with the default components.
         * Any components that are not specified will default to zero.
         *
         * This is useful when you want to use a shared color object for the getPixel and getPixelAt methods.
         *
         * @method Color.createColor
         * @static
         * @param {number} [r=0] - The red color component, in the range 0 - 255.
         * @param {number} [g=0] - The green color component, in the range 0 - 255.
         * @param {number} [b=0] - The blue color component, in the range 0 - 255.
         * @param {number} [a=1] - The alpha color component, in the range 0 - 1.
         * @param {number} [h=0] - The hue, in the range 0 - 1.
         * @param {number} [s=0] - The saturation, in the range 0 - 1.
         * @param {number} [l=0] - The lightness, in the range 0 - 1.
         * @param {number} [v=0] - The value, in the range 0 - 1.
         * @return {object} The resulting object with r, g, b, a properties and h, s, l and v.
         */
        static createColor(r?: number, g?: number, b?: number, a?: number, h?: number, s?: number, l?: number, v?: number): any;
        /**
         * Takes a color object and updates the rgba, color and color32 properties.
         *
         * @method Color.updateColor
         * @static
         * @param {object} out - The color object to update.
         * @returns {number} A native color value integer (format: 0xAARRGGBB).
         */
        static updateColor(out?: any): number;
        /**
         * Given an alpha and 3 color values this will return an integer representation of it.
         *
         * @method Color.getColor32
         * @static
         * @param {number} a - The alpha color component, in the range 0 - 255.
         * @param {number} r - The red color component, in the range 0 - 255.
         * @param {number} g - The green color component, in the range 0 - 255.
         * @param {number} b - The blue color component, in the range 0 - 255.
         * @returns {number} A native color value integer (format: 0xAARRGGBB).
         */
        static getColor32(a: number, r: number, g: number, b: number): number;
        /**
         * Given 3 color values this will return an integer representation of it.
         *
         * @method Color.getColor
         * @static
         * @param {number} r - The red color component, in the range 0 - 255.
         * @param {number} g - The green color component, in the range 0 - 255.
         * @param {number} b - The blue color component, in the range 0 - 255.
         * @returns {number} A native color value integer (format: 0xRRGGBB).
         */
        static getColor(r: number, g: number, b: number): number;
        /**
         * Converts the given color values into a string.
         * If prefix was "#" it will be in the format `#RRGGBB` otherwise `0xAARRGGBB`.
         *
         * @method Color.RGBtoString
         * @static
         * @param {number} r - The red color component, in the range 0 - 255.
         * @param {number} g - The green color component, in the range 0 - 255.
         * @param {number} b - The blue color component, in the range 0 - 255.
         * @param {number} [a=255] - The alpha color component, in the range 0 - 255.
         * @param {string} [prefix="#"] - The prefix used in the return string. If "#" it will return `#RRGGBB`, else `0xAARRGGBB`.
         * @return {string} A string containing the color values. If prefix was "#" it will be in the format `#RRGGBB` otherwise `0xAARRGGBB`.
         */
        static RGBtoString(r: number, g: number, b: number, a: number, prefix: string): string;
        /**
         * Converts a hex string into an integer color value.
         *
         * @method Color.hexToRGB
         * @static
         * @param {string} hex - The hex string to convert. Can be in the short-hand format `#03f` or `#0033ff`.
         * @return {number} The rgb color value in the format 0xAARRGGBB.
         */
        static hexToRGB(hex: string): number;
        /**
         * Converts a hex string into a bridge Color object.
         *
         * The hex string can supplied as `"#0033ff"` or the short-hand format of `"#03f"`; it can begin with an optional "#" or "0x", or be unprefixed.
         *
         * An alpha channel is _not_ supported.
         *
         * @method Color.hexToColor
         * @static
         * @param {string} hex - The color string in a hex format.
         * @param {object} [out] - An object into which 3 properties will be created or set: r, g and b. If not provided a new object will be created.
         * @return {object} An object with the red, green and blue values set in the r, g and b properties.
         */
        static hexToColor(hex: string, out?: any): any;
        /**
         * Converts a CSS "web" string into a bridge Color object.
         *
         * The web string can be in the format `"rgb(r,g,b)"` or `"rgba(r,g,b,a)"` where r/g/b are in the range [0..255] and a is in the range [0..1].
         *
         * @method Color.webToColor
         * @static
         * @param {string} web - The color string in CSS "web" format.
         * @param {object} [out] - An object into which 4 properties will be created: r, g, b and a. If not provided a new object will be created.
         * @return {object} An object with the red, green, blue and alpha values set in the r, g, b and a properties.
         */
        static webToColor(web: string, out?: any): any;
        /**
         * Converts a value - a "hex" string, a "CSS "web" string", or a number - into red, green, blue, and alpha components.
         *
         * The value can be a string (see `hexToColor` and `webToColor` for the supported formats) or a packed integer (see `getRGB`).
         *
         * An alpha channel is _not_ supported when specifying a hex string.
         *
         * @method Color.valueToColor
         * @static
         * @param {string|number} value - The color expressed as a recognized string format or a packed integer.
         * @param {object} [out] - The object to use for the output. If not provided a new object will be created.
         * @return {object} The (`out`) object with the red, green, blue, and alpha values set as the r/g/b/a properties.
         */
        static valueToColor(value: string | number, out?: any): any;
        /**
         * Return a string containing a hex representation of the given color component.
         *
         * @method Color.componentToHex
         * @static
         * @param {number} color - The color channel to get the hex value for, must be a value between 0 and 255.
         * @returns {string} A string of length 2 characters, i.e. 255 = ff, 100 = 64.
         */
        static componentToHex(color: number): string;
        /**
         * Get HSV color wheel values in an array which will be 360 elements in size.
         *
         * @method Color.HSVColorWheel
         * @static
         * @param {number} [s=1] - The saturation, in the range 0 - 1.
         * @param {number} [v=1] - The value, in the range 0 - 1.
         * @return {array} An array containing 360 elements corresponding to the HSV color wheel.
         */
        static HSVColorWheel(s: number, v: number): number[];
        /**
         * Get HSL color wheel values in an array which will be 360 elements in size.
         *
         * @method Color.HSLColorWheel
         * @static
         * @param {number} [s=0.5] - The saturation, in the range 0 - 1.
         * @param {number} [l=0.5] - The lightness, in the range 0 - 1.
         * @return {array} An array containing 360 elements corresponding to the HSL color wheel.
         */
        static HSLColorWheel(s: number, l: number): number[];
        /**
         * Interpolates the two given colours based on the supplied step and currentStep properties.
         *
         * @method Color.interpolateColor
         * @static
         * @param {number} color1 - The first color value.
         * @param {number} color2 - The second color value.
         * @param {number} steps - The number of steps to run the interpolation over.
         * @param {number} currentStep - The currentStep value. If the interpolation will take 100 steps, a currentStep value of 50 would be half-way between the two.
         * @param {number} alpha - The alpha of the returned color.
         * @returns {number} The interpolated color value.
         */
        static interpolateColor(color1: number, color2: number, steps: number, currentStep: number, alpha: number): number;
        /**
         * Interpolates the two given colours based on the supplied step and currentStep properties.
         *
         * @method Color.interpolateColorWithRGB
         * @static
         * @param {number} color - The first color value.
         * @param {number} r - The red color value, between 0 and 0xFF (255).
         * @param {number} g - The green color value, between 0 and 0xFF (255).
         * @param {number} b - The blue color value, between 0 and 0xFF (255).
         * @param {number} steps - The number of steps to run the interpolation over.
         * @param {number} currentStep - The currentStep value. If the interpolation will take 100 steps, a currentStep value of 50 would be half-way between the two.
         * @returns {number} The interpolated color value.
         */
        static interpolateColorWithRGB(color: number, r: number, g: number, b: number, steps: number, currentStep: number): number;
        /**
         * Interpolates the two given colours based on the supplied step and currentStep properties.
         * @method Color.interpolateRGB
         * @static
         * @param {number} r1 - The red color value, between 0 and 0xFF (255).
         * @param {number} g1 - The green color value, between 0 and 0xFF (255).
         * @param {number} b1 - The blue color value, between 0 and 0xFF (255).
         * @param {number} r2 - The red color value, between 0 and 0xFF (255).
         * @param {number} g2 - The green color value, between 0 and 0xFF (255).
         * @param {number} b2 - The blue color value, between 0 and 0xFF (255).
         * @param {number} steps - The number of steps to run the interpolation over.
         * @param {number} currentStep - The currentStep value. If the interpolation will take 100 steps, a currentStep value of 50 would be half-way between the two.
         * @returns {number} The interpolated color value.
         */
        static interpolateRGB(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number, steps: number, currentStep: number): number;
        /**
         * Returns a random color value between black and white
         * Set the min value to start each channel from the given offset.
         * Set the max value to restrict the maximum color used per channel.
         *
         * @method Color.getRandomColor
         * @static
         * @param {number} [min=0] - The lowest value to use for the color.
         * @param {number} [max=255] - The highest value to use for the color.
         * @param {number} [alpha=255] - The alpha value of the returning color (default 255 = fully opaque).
         * @returns {number} 32-bit color value with alpha.
         */
        static getRandomColor(min: number, max: number, alpha: number): number;
        /**
         * Return the component parts of a color as an Object with the properties alpha, red, green, blue.
         *
         * Alpha will only be set if it exist in the given color (0xAARRGGBB)
         *
         * @method Color.getRGB
         * @static
         * @param {number} color - Color in RGB (0xRRGGBB) or ARGB format (0xAARRGGBB).
         * @returns {object} An Object with properties: alpha, red, green, blue (also r, g, b and a). Alpha will only be present if a color value > 16777215 was given.
         */
        static getRGB(color: number): any;
        /**
         * Returns a CSS friendly string value from the given color.
         *
         * @method Color.getWebRGB
         * @static
         * @param {number|Object} color - Color in RGB (0xRRGGBB), ARGB format (0xAARRGGBB) or an Object with r, g, b, a properties.
         * @returns {string} A string in the format: "rgba(r,g,b,a)"
         */
        static getWebRGB(color: any): string;
        /**
         * Given a native color value (in the format 0xAARRGGBB) this will return the Alpha component, as a value between 0 and 255.
         *
         * @method Color.getAlpha
         * @static
         * @param {number} color - In the format 0xAARRGGBB.
         * @returns {number} The Alpha component of the color, will be between 0 and 1 (0 being no Alpha (opaque), 1 full Alpha (transparent)).
         */
        static getAlpha(color: number): number;
        /**
         * Given a native color value (in the format 0xAARRGGBB) this will return the Alpha component as a value between 0 and 1.
         *
         * @method Color.getAlphaFloat
         * @static
         * @param {number} color - In the format 0xAARRGGBB.
         * @returns {number} The Alpha component of the color, will be between 0 and 1 (0 being no Alpha (opaque), 1 full Alpha (transparent)).
         */
        static getAlphaFloat(color: number): number;
        /**
         * Given a native color value (in the format 0xAARRGGBB) this will return the Red component, as a value between 0 and 255.
         *
         * @method Color.getRed
         * @static
         * @param {number} color In the format 0xAARRGGBB.
         * @returns {number} The Red component of the color, will be between 0 and 255 (0 being no color, 255 full Red).
         */
        static getRed(color: number): number;
        /**
         * Given a native color value (in the format 0xAARRGGBB) this will return the Green component, as a value between 0 and 255.
         *
         * @method Color.getGreen
         * @static
         * @param {number} color - In the format 0xAARRGGBB.
         * @returns {number} The Green component of the color, will be between 0 and 255 (0 being no color, 255 full Green).
         */
        static getGreen(color: number): number;
        /**
         * Given a native color value (in the format 0xAARRGGBB) this will return the Blue component, as a value between 0 and 255.
         *
         * @method Color.getBlue
         * @static
         * @param {number} color - In the format 0xAARRGGBB.
         * @returns {number} The Blue component of the color, will be between 0 and 255 (0 being no color, 255 full Blue).
         */
        static getBlue(color: number): number;
        /**
         * Blends the source color, ignoring the backdrop.
         *
         * @method Color.blendNormal
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendNormal(a: number): number;
        /**
         * Selects the lighter of the backdrop and source colors.
         *
         * @method Color.blendLighten
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendLighten(a: number, b: number): number;
        /**
         * Selects the darker of the backdrop and source colors.
         *
         * @method Color.blendDarken
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendDarken(a: number, b: number): number;
        /**
         * Multiplies the backdrop and source color values.
         * The result color is always at least as dark as either of the two constituent
         * colors. Multiplying any color with black produces black;
         * multiplying with white leaves the original color unchanged.
         *
         * @method Color.blendMultiply
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendMultiply(a: number, b: number): number;
        /**
         * Takes the average of the source and backdrop colors.
         *
         * @method Color.blendAverage
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendAverage(a: number, b: number): number;
        /**
         * Adds the source and backdrop colors together and returns the value, up to a maximum of 255.
         *
         * @method Color.blendAdd
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendAdd(a: number, b: number): number;
        /**
         * Combines the source and backdrop colors and returns their value minus 255.
         *
         * @method Color.blendSubtract
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendSubtract(a: number, b: number): number;
        /**
         * Subtracts the darker of the two constituent colors from the lighter.
         *
         * Painting with white inverts the backdrop color; painting with black produces no change.
         *
         * @method Color.blendDifference
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendDifference(a: number, b: number): number;
        /**
         * Negation blend mode.
         *
         * @method Color.blendNegation
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendNegation(a: number, b: number): number;
        /**
         * Multiplies the complements of the backdrop and source color values, then complements the result.
         * The result color is always at least as light as either of the two constituent colors.
         * Screening any color with white produces white; screening with black leaves the original color unchanged.
         *
         * @method Color.blendScreen
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendScreen(a: number, b: number): number;
        /**
         * Produces an effect similar to that of the Difference mode, but lower in contrast.
         * Painting with white inverts the backdrop color; painting with black produces no change.
         *
         * @method Color.blendExclusion
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendExclusion(a: number, b: number): number;
        /**
         * Multiplies or screens the colors, depending on the backdrop color.
         * Source colors overlay the backdrop while preserving its highlights and shadows.
         * The backdrop color is not replaced, but is mixed with the source color to reflect the lightness or darkness of the backdrop.
         *
         * @method Color.blendOverlay
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendOverlay(a: number, b: number): number;
        /**
         * Darkens or lightens the colors, depending on the source color value.
         *
         * If the source color is lighter than 0.5, the backdrop is lightened, as if it were dodged;
         * this is useful for adding highlights to a scene.
         *
         * If the source color is darker than 0.5, the backdrop is darkened, as if it were burned in.
         * The degree of lightening or darkening is proportional to the difference between the source color and 0.5;
         * if it is equal to 0.5, the backdrop is unchanged.
         *
         * Painting with pure black or white produces a distinctly darker or lighter area, but does not result in pure black or white.
         * The effect is similar to shining a diffused spotlight on the backdrop.
         *
         * @method Color.blendSoftLight
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendSoftLight(a: number, b: number): number;
        /**
         * Multiplies or screens the colors, depending on the source color value.
         *
         * If the source color is lighter than 0.5, the backdrop is lightened, as if it were screened;
         * this is useful for adding highlights to a scene.
         *
         * If the source color is darker than 0.5, the backdrop is darkened, as if it were multiplied;
         * this is useful for adding shadows to a scene.
         *
         * The degree of lightening or darkening is proportional to the difference between the source color and 0.5;
         * if it is equal to 0.5, the backdrop is unchanged.
         *
         * Painting with pure black or white produces pure black or white. The effect is similar to shining a harsh spotlight on the backdrop.
         *
         * @method Color.blendHardLight
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendHardLight(a: number, b: number): number;
        /**
         * Brightens the backdrop color to reflect the source color.
         * Painting with black produces no change.
         *
         * @method Color.blendColorDodge
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendColorDodge(a: number, b: number): number;
        /**
         * Darkens the backdrop color to reflect the source color.
         * Painting with white produces no change.
         *
         * @method Color.blendColorBurn
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendColorBurn(a: number, b: number): number;
        /**
         * An alias for blendAdd, it simply sums the values of the two colors.
         *
         * @method Color.blendLinearDodge
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendLinearDodge(a: number, b: number): number;
        /**
         * An alias for blendSubtract, it simply sums the values of the two colors and subtracts 255.
         *
         * @method Color.blendLinearBurn
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendLinearBurn(a: number, b: number): number;
        /**
         * This blend mode combines Linear Dodge and Linear Burn (rescaled so that neutral colors become middle gray).
         * Dodge applies to values of top layer lighter than middle gray, and burn to darker values.
         * The calculation simplifies to the sum of bottom layer and twice the top layer, subtract 128. The contrast decreases.
         *
         * @method Color.blendLinearLight
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendLinearLight(a: number, b: number): number;
        /**
         * This blend mode combines Color Dodge and Color Burn (rescaled so that neutral colors become middle gray).
         * Dodge applies when values in the top layer are lighter than middle gray, and burn to darker values.
         * The middle gray is the neutral color. When color is lighter than this, this effectively moves the white point of the bottom
         * layer down by twice the difference; when it is darker, the black point is moved up by twice the difference. The perceived contrast increases.
         *
         * @method Color.blendVividLight
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendVividLight(a: number, b: number): number;
        /**
         * If the backdrop color (light source) is lighter than 50%, the blendDarken mode is used, and colors lighter than the backdrop color do not change.
         * If the backdrop color is darker than 50% gray, colors lighter than the blend color are replaced, and colors darker than the blend color do not change.
         *
         * @method Color.blendPinLight
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendPinLight(a: number, b: number): number;
        /**
         * Runs blendVividLight on the source and backdrop colors.
         * If the resulting color is 128 or more, it receives a value of 255; if less than 128, a value of 0.
         * Therefore, all blended pixels have red, green, and blue channel values of either 0 or 255.
         * This changes all pixels to primary additive colors (red, green, or blue), white, or black.
         *
         * @method Color.blendHardMix
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendHardMix(a: number, b: number): number;
        /**
         * Reflect blend mode. This mode is useful when adding shining objects or light zones to images.
         *
         * @method Color.blendReflect
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendReflect(a: number, b: number): number;
        /**
         * Glow blend mode. This mode is a variation of reflect mode with the source and backdrop colors swapped.
         *
         * @method Color.blendGlow
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendGlow(a: number, b: number): number;
        /**
         * Phoenix blend mode. This subtracts the lighter color from the darker color, and adds 255, giving a bright result.
         *
         * @method Color.blendPhoenix
         * @static
         * @param {integer} a - The source color to blend, in the range 1 to 255.
         * @param {integer} b - The backdrop color to blend, in the range 1 to 255.
         * @returns {integer} The blended color value, in the range 1 to 255.
         */
        static blendPhoenix(a: number, b: number): number;
    }
}
declare namespace ingenuity.bridge {
    class Device {
        static LITTLE_ENDIAN: boolean;
        onInitialized: Signal;
        deviceReadyAt: number;
        initialized: boolean;
        desktop: boolean;
        iOS: boolean;
        iOSVersion: number;
        cocoonJS: boolean;
        cordova: boolean;
        ejecta: boolean;
        crosswalk: boolean;
        android: boolean;
        chromeOS: boolean;
        linux: boolean;
        macOS: boolean;
        windows: boolean;
        windowsPhone: boolean;
        canvas: boolean;
        canvasBitBltShift: boolean;
        webGL: boolean;
        file: boolean;
        fileSystem: boolean;
        worker: boolean;
        css3D: boolean;
        pointerLock: boolean;
        typedArray: boolean;
        vibration: boolean;
        getUserMedia: boolean;
        quirksMode: boolean;
        touch: boolean;
        mspointer: boolean;
        wheelEvent: string;
        arora: boolean;
        chrome: boolean;
        chromeVersion: number;
        epiphany: boolean;
        firefox: boolean;
        firefoxVersion: number;
        ie: boolean;
        ieVersion: number;
        trident: boolean;
        tridentVersion: number;
        edge: boolean;
        mobileSafari: boolean;
        midori: boolean;
        opera: boolean;
        safari: boolean;
        safariVersion: number;
        webApp: boolean;
        silk: boolean;
        audioData: boolean;
        webAudio: boolean;
        ogg: boolean;
        opus: boolean;
        mp3: boolean;
        wav: boolean;
        m4a: boolean;
        webm: boolean;
        dolby: boolean;
        oggVideo: boolean;
        h264Video: boolean;
        mp4Video: boolean;
        webmVideo: boolean;
        vp9Video: boolean;
        hlsVideo: boolean;
        iPhone: boolean;
        iPhone4: boolean;
        iPad: boolean;
        pixelRatio: number;
        littleEndian: boolean;
        support32bit: boolean;
        fullscreen: boolean;
        requestFullscreen: string;
        cancelFullscreen: string;
        fullscreenKeyboard: boolean;
        vita: boolean;
        kindle: boolean;
        /**
         * Add a device-ready handler and ensure the device ready sequence is started.
         *
         * Device will _not_ activate or initialize until at least one `whenReady` handler is added,
         * which is normally done automatically be calling `new Game(..)`.
         *
         * The handler is invoked when the device is considered "ready", which may be immediately
         * if the device is already "ready". See {@link Device#deviceReadyAt deviceReadyAt}.
         *
         * @method
         * @param {function} handler - Callback to invoke when the device is ready. It is invoked with the given context the Device object is supplied as the first argument.
         * @param {object} [context] - Context in which to invoke the handler
         * @param {boolean} [nonPrimer=false] - If true the device ready check will not be started.
         */
        whenReady(callback: Function, context: object, nonPrimer: boolean): void;
        /**
         * Internal method used for checking when the device is ready.
         * This function is removed from Device when the device becomes ready.
         *
         * @method
         * @public
         */
        readyCheck(): void;
        /**
         * Check which OS is game running on.
         */
        checkOS(): void;
        /**
         * Check HTML5 features of the host environment.
         */
        checkFeatures(): void;
        /**
         * Checks/configures various input.
         */
        checkInput(): void;
        /**
         * Checks for support of the Full Screen API.
         */
        checkFullScreenSupport(): void;
        /**
         * Check what browser is game running in.
         */
        checkBrowser(): void;
        /**
         * Check video support.
         */
        checkVideo(): void;
        /**
         * Check audio support.
         */
        checkAudio(): void;
        /**
         * Check Little or Big Endian system.
         *
         */
        checkIsLittleEndian(): boolean;
        /**
         * Test to see if ImageData uses CanvasPixelArray or Uint8ClampedArray.
         *
         * @author Matt DesLauriers (@mattdesl)
         */
        checkIsUint8ClampedImageData(): boolean;
        /**
         * Check PixelRatio, iOS device, Vibration API, ArrayBuffers and endianess.
         */
        checkDevice(): void;
        /**
         * Check whether the host environment support 3D CSS.
         */
        checkCSS3D(): void;
        /**
         * Internal method to initialize the capability checks.
         * This function is removed from Device once the device is initialized.
         *
         * @method
         * @public
         */
        initialize(): void;
        /**
         * Check whether the host environment can play audio.
         *
         * @method canPlayAudio
         * @param {string} type - One of 'mp3, 'ogg', 'm4a', 'wav', 'webm' or 'opus'.
         * @return {boolean} True if the given file type is supported by the browser, otherwise false.
         */
        canPlayAudio(type: string): boolean;
        /**
         * Check whether the host environment can play video files.
         *
         * @method canPlayVideo
         * @param {string} type - One of 'mp4, 'ogg', 'webm' or 'mpeg'.
         * @return {boolean} True if the given file type is supported by the browser, otherwise false.
         */
        canPlayVideo(type: string): boolean;
        /**
         * Check whether the console is open.
         * Note that this only works in Firefox with Firebug and earlier versions of Chrome.
         * It used to work in Chrome, but then they removed the ability: {@link http://src.chromium.org/viewvc/blink?view=revision&revision=151136}
         *
         * @method isConsoleOpen
         * @memberof prototype
         */
        isConsoleOpen(): boolean;
        /**
         * Detect if the host is a an Android Stock browser.
         * This is available before the device "ready" event.
         *
         * Authors might want to scale down on effects and switch to the CANVAS rendering method on those devices.
         *
         * @example
         * var defaultRenderingMode = isAndroidStockBrowser() ? CANVAS : AUTO;
         *
         * @method isAndroidStockBrowser
         * @memberof prototype
         */
        isAndroidStockBrowser(): boolean;
        needsTouchUnlock(): boolean;
    }
}
declare namespace ingenuity.bridge {
    class DOM {
        static documentBounds: Rectangle;
        static layoutBounds: Rectangle;
        static visualBounds: Rectangle;
        static scrollX: number;
        static scrollY: number;
        /**
         * Get the [absolute] position of the element relative to the Document.
         *
         * The value may vary slightly as the page is scrolled due to rounding errors.
         *
         * @method DOM.getOffset
         * @param {DOMElement} element - The targeted element that we want to retrieve the offset.
         * @param {Point} [point] - The point we want to take the x/y values of the offset.
         * @return {Point} - A point objet with the offsetX and Y as its properties.
         */
        getOffset(element: HTMLElement, point: Point): Point;
        /**
         * A cross-browser element.getBoundingClientRect method with optional cushion.
         *
         * Returns a plain object containing the properties `top/bottom/left/right/width/height` with respect to the top-left corner of the current viewport.
         * Its properties match the native rectangle.
         * The cushion parameter is an amount of pixels (+/-) to cushion the element.
         * It adjusts the measurements such that it is possible to detect when an element is near the viewport.
         *
         * @method DOM.getBounds
         * @param {DOMElement|Object} element - The element or stack (uses first item) to get the bounds for.
         * @param {number} [cushion] - A +/- pixel adjustment amount.
         * @return {Object|boolean} A plain object containing the properties `top/bottom/left/right/width/height` or `false` if a non-valid element is given.
         */
        getBounds(element: HTMLElement | Object, cushion?: number): ClientRect | boolean;
        /**
         * Calibrates element coordinates for `inLayoutViewport` checks.
         *
         * @method DOM.calibrate
         * @private
         * @param {object} coords - An object containing the following properties: `{top: number, right: number, bottom: number, left: number}`
         * @param {number} [cushion] - A value to adjust the coordinates by.
         * @return {object} The calibrated element coordinates
         */
        private calibrate;
        /**
         * Get the Visual viewport aspect ratio (or the aspect ratio of an object or element)
         *
         * @method DOM.getAspectRatio
         * @param {(DOMElement|Object)} [object=(visualViewport)] - The object to determine the aspect ratio for. Must have public `width` and `height` properties or methods.
         * @return {number} The aspect ratio.
         */
        getAspectRatio(object: HTMLElement | ClientRect): number;
        /**
         * Tests if the given DOM element is within the Layout viewport.
         *
         * The optional cushion parameter allows you to specify a distance.
         *
         * inLayoutViewport(element, 100) is `true` if the element is in the viewport or 100px near it.
         * inLayoutViewport(element, -100) is `true` if the element is in the viewport or at least 100px near it.
         *
         * @method DOM.inLayoutViewport
         * @param {DOMElement|Object} element - The DOM element to check. If no element is given it defaults to the  game canvas.
         * @param {number} [cushion] - The cushion allows you to specify a distance within which the element must be within the viewport.
         * @return {boolean} True if the element is within the viewport, or within `cushion` distance from it.
         */
        inLayoutViewport(element: HTMLElement | ClientRect, cushion?: number): boolean;
        /**
         * Returns the device screen orientation.
         *
         * Orientation values: 'portrait-primary', 'landscape-primary', 'portrait-secondary', 'landscape-secondary'.
         *
         * Order of resolving:
         * - Screen Orientation API, or variation of - Future track. Most desktop and mobile browsers.
         * - Screen size ratio check - If fallback is 'screen', suited for desktops.
         * - Viewport size ratio check - If fallback is 'viewport', suited for mobile.
         * - window.orientation - If fallback is 'window.orientation', works iOS and probably most Android; non-recommended track.
         * - Media query
         * - Viewport size ratio check (probably only IE9 and legacy mobile gets here..)
         *
         * See
         * - https://w3c.github.io/screen-orientation/ (conflicts with mozOrientation/msOrientation)
         * - https://developer.mozilla.org/en-US/docs/Web/API/Screen.orientation (mozOrientation)
         * - http://msdn.microsoft.com/en-us/library/ie/dn342934(v=vs.85).aspx
         * - https://developer.mozilla.org/en-US/docs/Web/Guide/CSS/Testing_media_queries
         * - http://stackoverflow.com/questions/4917664/detect-viewport-orientation
         * - http://www.matthewgifford.com/blog/2011/12/22/a-misconception-about-window-orientation
         *
         * @method DOM.getScreenOrientation
         * @protected
         * @param {string} [primaryFallback=(none)] - Specify 'screen', 'viewport', or 'window.orientation'.
         */
        getScreenOrientation(primaryFallback: string): string;
    }
}
declare namespace ingenuity.bridge {
    /**
     * Filter is a special type of WebGL shader that is applied to the screen.
     * @ref https://pixijs.download/dev/docs/PIXI.Filter.html
     */
    class Filter extends PIXI.Filter implements IFilter {
    }
}
/**
 * This namespace contains WebGL-only display filters that can be applied to DisplayObjects using the filters property.
 * Since PixiJS only had a handful of built-in filters, additional filters can be downloaded here from the PixiJS Filters repository.
 * All filters must extend bridge.Filter that extends PIXI.Filter.
 *
 * NOTE: These are some Built-In filters.
 * @ref https://github.com/pixijs/pixi-filters
 * @ref https://pixijs.io/pixi-filters/docs/
 * @ref https://pixijs.download/dev/docs/PIXI.filters.html
 */
declare namespace ingenuity.bridge.filters {
    class AlphaFilter extends PIXI.filters.AlphaFilter {
    }
    class BlurFilter extends PIXI.filters.BlurFilter {
    }
    class BlurFilterPass extends PIXI.filters.BlurFilterPass {
    }
    class ColorMatrixFilter extends PIXI.filters.ColorMatrixFilter {
    }
    class DisplacementFilter extends PIXI.filters.DisplacementFilter {
    }
    class FXAAFilter extends PIXI.filters.FXAAFilter {
    }
    class NoiseFilter extends PIXI.filters.NoiseFilter {
    }
}
/**
 * Provides some in-house maths utility functions.
 * Example use: ingenuity.bridge.Maths.HALF
 */
declare namespace ingenuity.bridge {
    class Maths {
        static readonly HALF: number;
        static readonly TWO: number;
        static getHalf(value: number): number;
        static getDouble(value: number): number;
        static clamp(v: number, min: number, max: number): number;
        /**
         * A Linear Interpolation Method, mostly used by Tween.
         *
         * @method Math#linearInterpolation
         * @param {Array} v - The input array of values to interpolate between.
         * @param {number} k - The percentage of interpolation, between 0 and 1.
         * @return {number} The interpolated value
         */
        static linearInterpolation(v: Array<number>, k: number): number;
        /**
         * Calculates a linear (interpolation) value over t.
         *
         * @method Math#linear
         * @param {number} p0
         * @param {number} p1
         * @param {number} t - A value between 0 and 1.
         * @return {number}
         */
        static linear(p0: number, p1: number, t: number): number;
        /**
         * Returns the euclidian distance between the two given set of coordinates.
         *
         * @method bridge.Math#distance
         * @param {number} x1
         * @param {number} y1
         * @param {number} x2
         * @param {number} y2
         * @return {number} The distance between the two sets of coordinates.
         */
        static distance(x1: number, y1: number, x2: number, y2: number): number;
        /**
         * Returns an array of numbers within range, both inclusive
         * @param start @default = 0
         * @param finish Keep if null, if using length
         * @param length
         * @param step numbers to step. Keep it non-negative.
         *
         * @example getRange(5, 8) will return [5,6,7,8]
         * @example getRange(5, 2) will return [5,4,3,2]
         * @example getRange(5, null, 3) will return [5,6,7]
         * @example getRange(5, null, -4) will return [5,4,3,2]
         * @example getRange(5, 15, null, 3) will return [5,8,11,13]
         * @example getRange(5, null, 3, 3) will return [5,8,11]
         */
        static getRange(start: number, finish?: number, length?: number, step?: number): Array<number>;
    }
}
declare namespace ingenuity.bridge {
    class Matrix extends EMatrix implements IMatrix {
    }
}
/**
 * An extremely useful repeatable random data generator.
 * Accessing by game.rnd
 */
declare namespace ingenuity.bridge {
    class RandomDataGenerator {
        private c;
        private s0;
        private s1;
        private s2;
        /**
         * @constructor
         * @param {any[]|string} [seeds] - An array of values to use as the seed, or a generator state (from {#state}).
         */
        constructor(seeds: any[] | string);
        /**
         * random helper
         */
        private rnd;
        /**
         * Reset the seed of the random data generator.
         *
         * _Note_: the seed array is only processed up to the first `undefined` (or `null`) value, should such be present.
         *
         * @param {any[]} seeds - The array of seeds: the `toString()` of each value is used.
         */
        sow(seeds: any[]): void;
        /**
         * Internal method that creates a seed hash.
         *
         * @param {any} data
         * @return {number} hashed value.
         */
        private hash;
        /**
         * Returns a random integer between 0 and 2^32.
         *
         * @return {number} A random integer between 0 and 2^32.
         */
        integer(): number;
        /**
         * Returns a random real number between 0 and 1.
         *
         * @return {number} A random real number between 0 and 1.
         */
        frac(): number;
        /**
         * Returns a random real number between 0 and 2^32.
         *
         * @return {number} A random real number between 0 and 2^32.
         */
        real(): number;
        /**
         * Returns a random integer between and including min and max.
         *
         * @param {number} min - The minimum value in the range.
         * @param {number} max - The maximum value in the range.
         * @return {number} A random number between min and max.
         */
        integerInRange(min: number, max: number): number;
        /**
         * Returns a random integer between and including min and max.
         * This method is an alias for RandomDataGenerator.integerInRange.
         *
         * @param {number} min - The minimum value in the range.
         * @param {number} max - The maximum value in the range.
         * @return {number} A random number between min and max.
         */
        between(min: number, max: number): number;
        /**
         * Returns a random real number between min and max.
         *
         * @param {number} min - The minimum value in the range.
         * @param {number} max - The maximum value in the range.
         * @return {number} A random number between min and max.
         */
        realInRange(min: number, max: number): number;
        /**
         * Returns a random real number between -1 and 1.
         *
         * @return {number} A random real number between -1 and 1.
         */
        normal(): number;
        /**
         * Returns a valid RFC4122 version4 ID hex string from https://gist.github.com/1308368
         * Returns a random v4 UUID of the form xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx, where each x is replaced with a random hexadecimal digit from 0 to f,
         * and y is replaced with a random hexadecimal digit from 8 to b.
         *
         * @return {string} A valid RFC4122 version4 ID hex string
         */
        uuid(): string;
        /**
         * Returns a random member of `array`.
         *
         * @param {Array} ary - An Array to pick a random member of.
         * @return {any} A random member of the array.
         */
        pick(ary: Array<any>): any;
        /**
         * Returns a random member of `array`, favoring the earlier entries.
         *
         * @param {Array} ary - An Array to pick a random member of.
         * @return {any} A random member of the array.
         */
        weightedPick(ary: Array<any>): any;
        /**
         * Returns a random timestamp between min and max, or between the beginning of 2000 and the end of 2020 if min and max aren't specified.
         *
         * @param {number} min - The minimum value in the range.
         * @param {number} max - The maximum value in the range.
         * @return {number} A random timestamp between min and max.
         */
        timestamp(min: number, max: number): number;
        /**
         * Returns a random angle between -180 and 180.
         *
         * @return {number} A random number between -180 and 180.
         */
        angle(): number;
        /**
         * Gets or Sets the state of the generator. This allows you to retain the values
         * that the generator is using between games, i.e. in a game save file.
         *
         * To seed this generator with a previously saved state you can pass it as the
         * `seed` value in your game config, or call this method directly after Game has booted.
         *
         * Call this method with no parameters to return the current state.
         *
         * If providing a state it should match the same format that this method
         * returns, which is a string with a header `!rnd` followed by the `c`,
         * `s0`, `s1` and `s2` values respectively, each comma-delimited.
         *
         * @param {string} [state] - Generator state to be set.
         * @return {string} The current state of the generator.
         */
        state(state: string): string;
    }
}
/**
 * Extends an object A with the properties of Object B. You can overwrite the values of already existing properities.
 * @param objA
 * @param objB
 * @param overwrite
 * @returns {Object}
 */
declare namespace ingenuity.bridge {
    function extendObj(objA: IObject, objB: IObject, overwrite?: boolean): IObject;
    function clone(args: any): any;
    /**
      *
      * @param sprite The sprite for which you need to find centerX
      * [BackWards Compatibility] - Bounds returned by bridge includes centerX, which isn't there in pixi
      * Therefore this function can be used to find the centerX of the bounds(sprite) where needed.
      */
    function getCenterX(sprite: BitmapImage | Sprite): number;
    /**
     *
     * @param sprite The sprite for which you need to find centerY
     * [BackWards Compatibility] - Bounds returned by bridge includes centerY, which isn't there in pixi
     * Therefore this function can be used to find the centerY of the bounds(sprite) where needed.
     */
    function getCenterY(sprite: BitmapImage | Sprite): number;
    function mixinPrototype(target: any, mixin: any, replace?: boolean): void;
    /**
     * Converts degree to radian.
     * @param {number} degAngle angle in degrees.
     * @param {int} round How many digits are required after the decimal. Default 4.
     * @returns {Number} Angle in radian
     */
    function degToRad(degAngle: number, roundOpts?: number): number;
    /**
     * Converts radian to degree.
     * @param {number} radAngle angle in radian
     * @param {int} round How many digits are required after the decimal. Default 4.
     * @returns {Number} Angle in Degree
     */
    function radToDeg(radAngle: number, roundOpts?: number): number;
    function distance(x1: number, y1: number, x2: number, y2: number): number;
    function clamp(v: number, min: number, max: number): number;
    function pad(str: string, len: number, pad: string, dir: number): string;
    function wrap(value: number, min: number, max: number): number;
    function getSign(x: number): number;
    /**
     * Throws missing class Error
     * @param className
     */
    function throwMissingClassError(className: string): void;
    /**
     * Utility function to throw missing parameters errors
     * @param cls Class Name which
     * @param func Function Name which got the error
     * @param params {@type string[]} Missing parameters
     */
    function throwMissingParamsError(cls: string, func: string, ...params: string[]): void;
}
