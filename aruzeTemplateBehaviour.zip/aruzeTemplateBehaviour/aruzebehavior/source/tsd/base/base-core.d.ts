/** 
	Base Core v2.0.3 
	©Ingenuity Gaming Pvt. Ltd.
	Published: Tue Sep 24 2019 16:34:03 GMT+0530 (India Standard Time) 
**/
/* tslint:disable */
/* tslint:disable */
/// <reference path="../../../node_modules/typescript/lib/lib.d.ts" />
/// <reference path="../../../node_modules/typescript/lib/lib.es2015.symbol.d.ts" />
/// <reference path="../../../node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts" />
/// <reference path="../adapter-interface/adapter-interface.d.ts" />
/// <reference path="../pixi-bridge/pixi-bridge.d.ts" />
/** These are added to correct the build error for node typing */
declare namespace ingenuity {
    /**
     * custom object works as a superclass for custom interfaces
     */
    interface IObject extends Object {
        [key: string]: any;
        [key: number]: any;
    }
    /** Interface For Event Class. */
    interface IEventDispatcher {
        on(type: string, handler: (e?: IEvent) => void, scope: any, once: boolean, data: any, priority: number): () => void;
        off(type: string, handler?: (e?: IEvent) => void): void;
        hasEvent(type: string): void;
        fireEvent(type: string, data: any): void;
    }
    /** The Event interface to define the data type for event Object.
     */
    interface IEvent {
        /**
         * Type of the event can be one from  the EventConstants
         */
        type: string;
        /**
         * Time at which this event was sent for execution
         */
        timeStamp: number;
        /**
         * Trigger time data, which will be passed to the function
         */
        data: any;
        /**
         * internal property which marks the handler for removal
         */
        removed: boolean;
        /**
         * function which set the removed to true.
         */
        remove(): void;
    }
    interface ISubEventObj {
        [key: string]: IEventObject[];
    }
    interface IHandler {
        [key: string]: IHandlerObject[];
    }
    interface IHandlerObject {
        handler: Function;
        newHandler: Function;
        scope: any;
    }
    /**
     * Interface used inside the on function of the EventDispatcher for the handler object
     */
    interface IEventObject extends IObject {
        /**
         * Handler function
         */
        func: () => void;
        /**
         * Scope of the handler function
         */
        scope: any;
        /**
         * Wherther the binding event should call this handler only once or not
         */
        once: boolean;
        /**
         * Any data which is required by the function to work
         */
        data: any;
        /**
         * Priority of this handler in the execution process
         */
        priority: number;
    }
    /**
     * Big Win FountainOptions
     */
    interface IBigWinFountainOptions {
        w: number;
        h: number;
        fromBottomOut: boolean;
        allAtOnce: boolean;
        offsetHeight: number;
        offsetX: number;
        speed: number;
        numParticles: number;
        deltaX: number;
        deltaY: number;
    }
    /** Interface For Base Meter Class. These properties are a reference for the main_data.json.
     *
     */
    interface IAnimatedMeter {
        startTick(value: number, showCurrency: boolean, showNumOnly: boolean, duration: number, onlyNumber?: boolean, callback?: () => void): number;
        stopTick(showCurrency: boolean, showNumOnly: boolean): void;
    }
    /** Interface of the object passed to ajax function */
    interface IAjaxOptions {
        /** Url to which ajax request is sent */
        url: string;
        /** Send method. "Get" or "Post". Default is 'Get'.*/
        method: string;
        /** Keep the login credentials sent by the server. Keep it true for the in house Demo Server. Default is false. It works only with 'Post' method */
        withCredentials: boolean;
        /** Define the type of data received using ajax function. 'json', 'xml' or 'text'. Default text. */
        receiveType: string;
        /** Define the function to be called on the successfully receiving the data.
         * @param {any} data The data received by the ajax is passed to this function.
         */
        success(data: any): void;
        /** Define the function to be called on receiving the error.
         * @param {any} status The status code of the error is passed.
         */
        error(status: any): void;
        /**
         * Any additional headers needed to be passed to the ajax request
         */
        header?: any;
        /**
         * Data to be sent along the ajax request to the server, mostly when the method is 'Post'.
         */
        data?: any;
        /**
         * Timeout property to cancel an Ajax request after provided milliseconds.
         */
        timeout?: number;
    }
    /**
     * Main sound Json. Should be as per the phaser sound manger requirements
     */
    interface ISoundManifest {
        data: {
            audioSprite: ISoundProperties;
        };
        src: string;
        id: string;
    }
    /**
     * Properites which can be defined in the sound JSON for individual sounds
     */
    interface ISoundProperties {
        id: string;
        loop: number;
        volume: number;
        minVolume: number;
        singleInstance: boolean;
    }
    /**
     * Interface for the game state object which will be passed to the instance of game class.
     */
    interface IGameStates extends IObject {
        load?: loader.Loading;
        intro?: states.State;
        baseGame?: states.BaseGameState;
        freeGame?: states.State;
        bonus?: states.State;
    }
    /** Interface For Base Container Class. These properties are a reference for the main_data.json. */
    interface IContainer extends IObject {
        x?: number;
        y?: number;
        w?: number;
        h?: number;
        id?: string;
        visible?: boolean;
        parent?: string;
        regX?: number;
        regY?: number;
        rotation?: number;
        showBounds?: boolean;
        bounds?: boolean;
    }
    interface ILabelStyles extends bridge.ITextStyleBridge {
        /** The style and size of the font. - Default: 'bold 20pt Arial' */
        font: string;
        /** The size of the font (eg. 32 or '32px'): overrides the value in `style.font`. - Default: (from font) */
        fontSize: number;
        /** The style of the font (eg. 'italic'): overrides the value in `style.font`. - Default: (from font) */
        fontStyle: string;
        /** A canvas fillstyle that will be used on the text eg 'red', '#00FF00'. - Default: 'black' */
        fill?: any;
        /** Horizontal alignment of each line in multiline text. Can be: 'left', 'center' or 'right'. Does not affect single lines of text (see `textBounds` and `boundsAlignH` for that). - Default: 'left' */
        align?: string;
        /** A canvas stroke style that will be used on the text stroke eg 'blue', '#FCFF00'. - Default: 'black' */
        stroke?: string;
        /** A number that represents the thickness of the stroke. Default is 0 (no stroke). */
        strokeThickness?: number;
        /** Indicates if word wrap should be used. Turn this on for multiline text. */
        wordWrap?: boolean;
        /**
         * This defines the max width after which the multiline text will break into new line.
         * The width in pixels at which text will wrap. - Default: 100 in Phaser
         */
        wordWrapWidth?: number;
        /**
         * The maximum number of lines to be shown for wrapped/multiline text.
         */
        maxLines?: number;
        shadowOffsetX?: number;
        shadowOffsetY?: number;
        shadowColor?: string;
        shadowBlur?: number;
        valign?: string;
        tab?: number;
        /** The size (in pixels) of the tabs, for when text includes tab characters. 0 disables. Can be an array of varying tab sizes, one per tab stop. */
        tabs?: number;
        /** The variant of the font (eg. 'small-caps'): overrides the value in `style.font`. - Default: (from font) */
        fontVariant?: string;
        /** The weight of the font (eg. 'bold'): overrides the value in `style.font`. - Default: (from font) */
        fontWeight?: string;
        /** A canvas fillstyle that will be used as the background for the whole Text object. Set to `null` to disable. */
        backgroundColor?: string;
        /** Horizontal alignment of the text within the `textBounds`. Can be: 'left', 'center' or 'right'. - Default: 'left' */
        boundsAlignH?: string;
        /** Vertical alignment of the text within the `textBounds`. Can be: 'top', 'middle' or 'bottom'. - Default: 'top' */
        boundsAlignV?: string;
        lineSpacing: number;
        /**
         * Colour for disabled button
         */
        disableColor?: number;
        /**
         * tinting the label for disabled button. if disable color is specified then tint won't work.
         */
        disableTint?: number;
        opacity?: number;
    }
    interface ILabelShadow extends IObject {
        color: string;
        blurX: number;
        blurY: number;
        quality: number;
    }
    /** Interface For Base Label Class. These properties are a reference for the main_data.json. */
    interface ILabel extends IObject {
        x: number;
        y: number;
        w: number;
        h: number;
        id: string;
        i18nId?: string;
        parent?: string;
        text?: string;
        replaceText?: string | IObject;
        bounds?: boolean;
        showBounds?: boolean;
        boundsColor?: number;
        boundsStroke?: number;
        regX?: number;
        regY?: number;
        rotation?: number;
        visible?: boolean;
        style?: bridge.ITextStyleBridge;
        shadow?: ILabelShadow;
        autoFitHeight?: boolean;
        doInitialFit?: boolean;
    }
    interface IButtonLableStates extends IObject {
        over: ILabel;
        out: ILabel;
        down: ILabel;
        up: ILabel;
        disable: ILabel;
    }
    /** Interface For Base Button Class. These properties are a reference for the main_data.json. */
    interface IButton extends IObject {
        x: number;
        y: number;
        w: number;
        h: number;
        id: string;
        parent?: string;
        enabled?: boolean;
        visible?: boolean;
        showBounds?: boolean;
        anchorX: number;
        anchorY: number;
        angle?: number;
        image: any;
        images: any;
        label: ILabel | IButtonLableStates;
        priorityID?: number;
        frames: {
            up: string;
            over: string;
            down: string;
            out: string;
            disable?: string;
        };
        hitarea?: {
            x: number;
            y: number;
            /**
             * Could be shape or image
             */
            type: string;
            /**
             * Defined in case of a rectangle
             */
            w?: number;
            /**
             * defined in case of a rectangle
             */
            h?: number;
            /**
             * defined in case of a roundcornerrectangle
             */
            radius?: number;
            /**
             * defined in case of circle
             */
            diameter?: number;
            /**
             * Can be circle, rectangle, roundcornerrectangle, custom
             */
            shape?: string;
            /**
             * Provide in case of custom shape
             */
            commandArray?: Array<any>;
            /**
             * For debugging the shape.
             */
            visible?: boolean;
            strokeSize?: number;
            strokeColor?: string;
            strokeAlpha?: number;
            fillColor?: string | number;
            fillAlpha?: number;
            images?: any;
            image?: any;
            frames?: string | number;
            rotation?: number;
        };
    }
    /** Interface For Base Image Class. These properties are a reference for the main_data.json. */
    interface IImage extends IObject {
        x: number;
        y: number;
        id: string;
        parent?: string;
        /**
         * defined in case of a rectangle
         */
        w?: number;
        /**
         * defined in case of a rectangle
         */
        h?: number;
        /**
         * @depricated
         */
        images?: any;
        image?: any;
        frames?: string | number;
        rotation?: number;
        visible?: boolean;
    }
    /** Interface For Base Animation Class. These properties are a reference for the main_data.json. */
    interface IAnimation extends IContainer {
        image?: string;
        images?: string[];
        frame?: string | number;
        frames?: string[] | number[];
        frameRate?: number;
        loop?: boolean;
        scale?: number;
        scaleX?: number;
        scaleY?: number;
        animations: {
            [key: string]: {
                frames: string[] | number[];
                generateNames?: boolean;
                prefix?: string;
                suffix?: string;
                zeroPad?: number;
                frameRate: number;
                loop: boolean;
            };
        };
    }
    /** Interface For Base Shape Class. These properties are a reference for the main_data.json. */
    interface ISlider extends IContainer {
        x: number;
        y: number;
        w: number;
        h: number;
        visible: boolean;
        bounds: boolean;
        min: number;
        max: number;
        sliderMaskFill: boolean;
        orientation: string;
        betArray: any;
        steps: boolean;
        id: string;
        sliderBg: {
            x: number;
            y: number;
            w: number;
            h: number;
            type: any;
            image: any;
        };
        blob: {
            x: number;
            y: number;
            w: number;
            h: number;
            type: any;
            image: any;
        };
        parent: string;
    }
    /** Interface For Base Shape Class. These properties are a reference for the main_data.json. */
    interface IShape extends IObject {
        x: number;
        y: number;
        id: string;
        parent?: string;
        /**
         * defined in case of a rectangle
         */
        w?: number;
        /**
         * defined in case of a rectangle
         */
        h?: number;
        strokeSize: number;
        strokeColor: number;
        strokeAlpha: number;
        fillColor: number;
        fillAlpha: number;
        shape: string;
        radius: number;
        diameter: number;
        commandArray: Array<any>;
        visible: boolean;
        priorityID: number;
    }
    /** Interface For Base Shape Button Class. These properties are a reference for the main_data.json. */
    interface IShapeButton extends IShape {
        label: ILabel;
    }
    /** Interface For Base Shape Toggle Button Class. These properties are a reference for the main_data.json. */
    interface IShapeToggleButton extends IContainer {
        fillColor: number;
        fillColorOff: number;
        circleFillColor: number;
        circleFillAlpha: number;
        isOn: boolean;
        baseStroke: number;
        knobStroke: number;
        baseStrokeColourOn: number;
        baseStrokeColourOff: number;
        knobStrokeColour: number;
        baseStrokeAlpha: number;
        baseCornerRadius: number;
        knobDiameter: number;
        knobOffsetX: number;
        knobOffsetY: number;
    }
    /** Interface For Base Toggle Button Class. These properties are a reference for the main_data.json. */
    interface IToggleButton extends IObject {
        x: number;
        y: number;
        w: number;
        h: number;
        id: string;
        parent?: string;
        enable?: boolean;
        enabled?: boolean;
        visible?: boolean;
        showBounds?: boolean;
        image: any;
        images: any;
        label: ILabel;
        priorityID?: number;
        hitarea?: {
            x: number;
            y: number;
            /**
             * Could be shape or image
             */
            type: string;
            /**
             * defined in case of a rectangle
             */
            w?: number;
            /**
             * defined in case of a rectangle
             */
            h?: number;
            /**
             * defined in case of a roundcornerrectangle
             */
            radius?: number;
            /**
             * defined in case of circle
             */
            diameter?: number;
            /**
             * Can be circle, rectangle, roundcornerrectangle, custom
             */
            shape?: string;
            /**
             * Provide in case of custom shape
             */
            commandArray?: Array<any>;
            /**
             * For debugging the shape.
             */
            strokeSize?: number;
            strokeColor?: string;
            strokeAlpha?: number;
            fillColor?: string | number;
            fillAlpha?: number;
            visible?: boolean;
            images?: any;
            image?: any;
            frames?: string | number;
            rotation?: number;
        };
        alpha: number;
        frames: {
            on: {
                up: string;
                over: string;
                down: string;
                out: string;
                disable?: string;
            };
            off: {
                up: string;
                over: string;
                down: string;
                out: string;
                disable?: string;
            };
        };
    }
    /** Interface For Base Tab Button Class. These properties are a reference for the main_data.json. */
    interface ITabButton extends IButton {
        totalTabs: number;
    }
    /** Interface For Base Bitmap Label Class. These properties are a reference for the main_data.json. */
    interface ILabelBitmap extends ILabel {
        image?: any;
        images?: any;
    }
    interface ITween extends bridge.ITween {
        timeStamp?: number;
    }
    interface IVideo extends bridge.Video {
        key: string;
    }
    interface IGraphics extends bridge.Graphics {
        x: number;
    }
    interface IDisplayObject extends bridge.DisplayObject {
        x: number;
    }
    interface IDeviceConfig {
        [key: string]: {
            width: number;
            height: number;
        };
    }
    interface IText extends bridge.Text {
        name: string;
    }
    interface ISignal extends bridge.Signal {
        dispatch(...params: any[]): void;
    }
    interface IPointer extends bridge.Pointer {
        x: number;
    }
    /** Interface to get the key board key detail */
    interface IKey extends bridge.Key {
        game: bridge.Game;
    }
    interface IAdvancedButton extends IObject {
        x: number;
        y: number;
        w: number;
        h: number;
        id: string;
        parent?: string;
        enabled?: boolean;
        visible?: boolean;
        showBounds?: boolean;
        states: {
            "over": {
                "btnAnimation"?: {};
                "btnSprite"?: {};
                "btnLabelBitmap"?: {};
                "btnLabel"?: {};
            };
            "disable": {};
            "out": {};
            "up": {};
            "down": {};
        };
        hitarea: {
            x: number;
            y: number;
            /**
             * Could be shape or image
             */
            type: string;
            /**
             * Defined in case of a rectangle
             */
            w?: number;
            /**
             * defined in case of a rectangle
             */
            h?: number;
            visible?: boolean;
            images?: any;
            image?: any;
            frames?: string | number;
            rotation?: number;
            alpha?: number;
        };
    }
}
declare namespace ingenuity.events {
    /**
     * Class to make an Event object which can be passed to dispatcher's fireEvent function
     */
    class Event implements IEvent {
        /**
         * Type of the event can be one from the EventConstants
         * @private
         */
        type: string;
        /**
         * Trigger time data, which will be passed to the function
         */
        data: any;
        /**
         * Time at which this event was sent for execution.
         */
        timeStamp: number;
        target: any;
        /** Is event removed */
        removed: boolean;
        /**
         * Event Class.
         * @param type Create a Constant in eventConstants and then pass it as the type of the event.
         * @param data Any data which you want to pass on to the handler. It will be available as event.data.
         */
        constructor(type: string, data?: any);
        /**
         * Marks the event and handler for removal. Can be used as event.remove() inside the handler function
         */
        remove(): void;
        /**
         * Returns the event as string
         */
        toString(): string;
    }
}
declare namespace ingenuity.events {
    class EventDispatcher implements IEventDispatcher {
        /** Contains list of subscribed events */
        private subscribedEvents;
        /**
         * Custom Event handler class. It can be use to listen and fire custom events.
         */
        constructor();
        /**
         * Binds a handler to an Event
         * @param type Event string type. Most of the Events are available @ ingenuity.events.EventConstants
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         * @returns {Function} The handler function which can be saved so that it can be unsubscribe or unbind
         */
        on(type: string, handler: (evt?: IEvent, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): any;
        /**
         * Unbinds the handler from an event
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         */
        off(type: string, handler?: (evt?: IEvent, data?: IObject) => void, scope?: any): void;
        /**
         * Unsubscribe the event for a particular scope
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         * @param scope scope for which event needs to be unsubscribed
         */
        offForScope(type: string, scope: any, handler?: (evt?: IEvent, data?: IObject) => void): void;
        /**
         * Checks whether a handler is bound to specified event
         * @param type event type/name to check
         */
        hasEvent(type: string): boolean;
        /**
         * Fires or triggers an event and runs the handler functions bound or subscribed to the event
         * @param type: string|Event Either pass an event or data. If you are passing Event then data can be passed to its constructor
         * @param data Any which is to be passed along the event. It is available as event.data
         */
        fireEvent(type: string | Event, data?: any): void;
    }
}
/**
 * Quest Sound Controller
 * @extends bridge.SoundManager
 */
declare namespace ingenuity.base {
    class AudioController extends bridge.SoundManager {
        /**
         * Stores Audio instances of the keys passed to constructor
         */
        protected objAudio: bridge.SoundManager;
        /**
         * Stores if an audio is playing
         */
        protected isAudioPlaying: boolean;
        /**
         * Instance of playing sound
         */
        protected sndPlayingInstance: any;
        /**
         * Use this class as the sound manager. pass it the audio sprite and use it play, stop and pause functions to control the sounds in the game
         * @param key - key(s) of the audio sprite(s) which you want the sound manager to control.
         */
        constructor(key?: string | string[]);
        /**
         * Enables or disables the sound manager
         * @param value
         */
        postLoadSound(key: string | string[]): void;
        /**
         * Enables or disables the sound manager
         * @param value
         */
        setEnabled(value: boolean): void;
        /**
         * Tells whether the Sound Manger is enabled or disabled
         * @returns {boolean}
         */
        getEnabled(): boolean;
        /**
         * Plays the part of audio sprite marked with soundId in the sound json. on completion of the sound it fire an event SOUND_PLAY_COMPLETE.
         * if the sound is looping then it fire the event SOUND_PLAY_LOOP.
         * @param soundId - sound marker in the sound json
         * @param vol -  volume of the sound. If not provided then it will take the global volume
         * @param loop -  whether to loop this sound or not
         * @param key - if you have multiple audios sprites then provide the audio sprite key from which you want to play the sound.
         * @returns {bridge.Sound}
         */
        play(soundId: string, vol?: number, loop?: boolean, key?: string): bridge.Sound;
        /**
         * Check wheather a sound is playing or not
         * @param soundId - Sound to check
         * @param key - if you have multiple audios sprites then provide the audio sprite key from which you want to play the sound.
         * @returns {boolean}
         * @depricated
         */
        isSoundPlaying(soundId: string, key?: string): boolean;
        /**
         * Get the Sound instance of playing sound
         * @param soundId - Sound to get
         * @param key - if you have multiple audios sprites then provide the audio sprite key from which you want to play the sound.
         * @returns {boolean}
         */
        getSoundInstance(soundId: string, key?: string): bridge.Sound;
        /**
         * Fade a playing sound's volume
         * @param soundId - Id of the sound to fade
         * @param duration - Duration over which fade should happen
         * @param volume - Volume level at which you want to fade
         * @param key - If you have multiple audio sprites then provide the audio sprite key from which you want to play the sound.
         * @param callback - Callback function which will be called once the fading is over
         */
        fadeVolume(soundId: string, duration: number, volume: number, key?: string, callback?: () => void): void;
        /**
         * Pause a single sound
         * @param soundId - Sound to pause
         * @param key - if you have multiple audios sprites then provide the audio sprite key from which you want to play the sound.
         */
        pause(soundId: string, key?: string): void;
        /**
         * Get the Mute state of a single sound
         * @param soundId - Sound to check for mute state
         * @param key - if you have multiple audios sprites then provide the audio sprite key from which the sound was played.
         * @returns {boolean} The current mute state of the selected sound
         */
        isSoundMuted(soundId: string, key?: string): boolean;
        /**
         * Pauses all playing sounds
         */
        pauseAll(): void;
        /**
         * Resumes all sounds paused by either pause or pauseAll
         */
        resumeAll(): void;
        /**
         * Stops a single sound
         * @param soundId - Sound to stop
         * @param key - if you have multiple audio sprites then provide the audio sprite key from which you want to play the sound.
         */
        stop(soundId: string, key?: string): void;
        /**
         * stops all playing sounds
         */
        stopAll(): void;
        /**
         * mutes or unmutes the sound manager.
         * @param value
         */
        setMute(value: boolean): void;
        /**
         * Returns wheather the sound manager is muted or not
         * @returns {boolean}
         */
        getMute(): boolean;
        destroySound(key: string): void;
    }
}
declare namespace ingenuity.core.base {
    let constants: {
        BASE_CORE_RESIZE_DELAY_STRING: string;
        BASE_CORE_RESIZE_DELAY_TIME: number;
        MILLISECOND_CONVERT_VALUE: number;
        RESIZE_EVENT_STRING: string;
        DEFAULT_FONT_SIZE: number;
        DEFAULT_POSITION: number;
        ANCHOR_LEFT: number;
        ANCHOR_CENTER: number;
        ANCHOR_RIGHT: number;
        MINIMUM_SAFE_FONT: number;
        CANVAS_RENDERER: number;
        AUTO_RENDERER: number;
        WEBGL_RENDERER: number;
        EVENT_MOUSEDOWN: string;
        EVENT_MOUSEUP: string;
        EVENT_MOUSEOVER: string;
        EVENT_MOUSEOUT: string;
        CANVAS_CONTAINER: string;
        EVENT_TAP: string;
        loader: {
            IMAGE: string;
            JSON: string;
            AUDIO_SPRITE: string;
            PACK: string;
            ATLAS: string;
            ATLAS_ARRAY: string;
            BITMAP_FONT: string;
            VIDEO: string;
            SPINE: string;
            VIDEO_EVENT: string;
            VIDEO_AS_BLOB: boolean;
            STAGE_MANIFEST: string;
            STAGE_BASE_GAME: string;
            STAGE_BASE_GAME_POSTLOAD: string;
            STAGE_FREE_GAME: string;
            STAGE_INFO: string;
            STAGE_BONUS: string;
            LANGUAGE_FILE_KEY: string;
            MAIN_DATA_FILE_KEY: string;
            SOUND_LIST_FILE_KEY: string;
            CURRENCY_FILE_KEY: string;
        };
        delayKeys: {
            CHECK_AND_LOAD_NEXT_STAGE: string;
            SPINE_CREATION_DELAY: string;
        };
        meter: {
            TICKUP_ROUNDUP_TO_VALUE: number;
        };
        BUTTON_LABEL_TINT_DISABLE: number;
        BUTTON_LABEL_TINT_ENABLE: number;
        states: {
            PRELOADING_STATE: string;
            BASE_GAME_STATE: string;
            INTRO_STATE: string;
            FREE_GAME_STATE: string;
            BONUS_STATE: string;
        };
    };
}
declare namespace ingenuity.core.base {
    const EventConstants: {
        BASEGAME_ASSETS_LOADED: string;
        PRIORITIZE_LOADING_STAGE: string;
        FREEGAME_ASSETS_LOADED: string;
        INFO_ASSETS_LOADED: string;
        BONUS_ASSETS_LOADED: string;
        ALL_ASSETS_LOADED: string;
        UPDATE_LOADING_PROGRESS: string;
        FILE_LOAD_ERROR: string;
        FILE_LOADED: string;
        UPDATE_LABELS_TEXT: string;
        UPDATE_METER_TEXT: string;
        UPDATE_BUTTON_LABEL_TEXT: string;
    };
}
/**
 * Created by Asharma on 09-02-2017.
 */
declare namespace ingenuity.ui {
    class Container extends bridge.Container {
        json: IContainer;
        scaleX: number;
        scaleY: number;
        /**
         * A custom container to draw bounds if necessary
         *
         * @param json Container json which contains x, y, width, height properties for the container
         * @param game A reference to the currently running game.
         * @param parent The parent Group that this group will be added to.<br>
         *               If undefined/unspecified the Group will be added to the bridge World if null the Group will not be added to any parent. - Default: (game world)
         * @param name A name for this group. Not used internally but useful for debugging. - Default: 'group'
         * @param addToStage If true this group will be added directly to the Game.Stage instead of Game.World.
         * @param enableBody If true all Sprites created will have a physics body created on them.
         * @param physicsBodyType The physics body type to use when physics bodies are automatically added.
         */
        constructor(json: IContainer, game: bridge.Game, parent?: any, name?: string, addToStage?: boolean, enableBody?: boolean, physicsBodyType?: number);
        /**
         * A event binder which in background binds an event to a signal
         * @param type Event string type.
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         */
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): this | any;
        /**
         * Removes the event binding with an event
         * @param type Event type. Must be mentioned in the events.EventConstants
         * @param handler - Binding Function. if not defined then it will remove all handlers from this event
         * @param scope - handler bind to an object.
         */
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): this;
        /**
         * Returns if the event is already subscribed
         * @param type
         */
        hasEvent(type: string): boolean;
        /**
         * Fires a custom event
         * @param type event name/type to be fired
         * @param data data to be sent with event
         */
        fireEvent(type: string, data?: any): void;
        /**
         * Displays the Bounds of the container
         * @param targetCoordinateSpace the transformation matrix of the sprite. Currently, not used
         */
        showBounds(targetCoordinateSpace?: bridge.DisplayObject | bridge.Matrix): void;
        /**
         * Returns the name of container & length of children's in String
         * Example output: ```[Container (name: XYZ, numChildren: 5)]```
         */
        toString(): string;
    }
}
declare namespace ingenuity.ui {
    class Bitmap extends bridge.BitmapImage {
        json: IImage;
        private currentBounds;
        constructor(json: IImage);
    }
}
declare namespace ingenuity.ui {
    class Sprite extends bridge.Sprite {
        private currentBounds;
        constructor(x: number, y: number, key?: string | string[] | bridge.RenderTexture | bridge.Texture, frame?: string | number);
    }
}
declare namespace ingenuity.ui {
    class ButtonBase extends bridge.Button {
        bindedHandlers: any;
        protected currentState: string;
        protected hitarea: any;
        label: Label;
        json: IButton;
        /**
         * Defines the up state of the button. Must be provided in animation of the button json as "up"
         * @type {string}
         */
        static UP: string;
        /**
         * Defines the down state of the button. Must be provided in animation of the button json as "down"
         * @type {string}
         */
        static DOWN: string;
        /**
         * Defines the mouse over state of the button. Must be provided in animation of the button json as "over".
         * This is added to the button to cater to the desktop versions
         * @type {string}
         */
        static OVER: string;
        /**
         * Defines the mouse out state of the button. Must be provided in animation of the button json as "out".
         * This is added to the button to cater to the desktop versions. if this is same as "up" then mention the same
         * frame
         * @type {string}
         */
        static OUT: string;
        /**
         * Defines the mouse out state of the button. Must be provided in animation of the button json as "out".
         * This is added to the button to cater to the desktop versions. if this is same as "up" then mention the same
         * frame
         * @type {string}
         */
        static DISABLED: string;
        constructor(json: IButton, game: bridge.Game, x?: number, y?: number, key?: string, callback?: any, callbackContext?: any, overFrame?: string, outFrame?: string, downFrame?: string, upFrame?: string, disabledFrame?: string);
        /**
         * Sets the label for every button state i.e. over, down, out, up
         */
        protected setLabelForStates(over: ILabel, down: ILabel, out: ILabel, up: ILabel): void;
        /**
         * Changes the label Style and updates the shadow for text
         * @param btn Button whose label state need to be changed
         * @param pointer pointer of type IPointer
         * @param labelState lable state to be changed
         */
        protected changeStateLabel(btn: ButtonBase, pointer: IPointer, labelState: ILabel): void;
        /**
         * toggles the sate of button after a defined delay
         * @param {string} state1 default ButtonBase.OUT
         * @param {string} state2 default ButtonBase.OVER
         * @param {number} toggleTime default 500
         */
        toggleStates(state1?: string, state2?: string, toggleTime?: number): ButtonBase;
        /**
         * resets the current state to ButtonBase.OUT
         */
        clearToggleState(): ButtonBase;
        /**
         * Creates hitarea using the given image
         * @param json json for image which will act as a hitarea
         * @example JSON
         * ```
         * "ImageHitarea": {
                "x": 10,
                "y": 12,
                "image": "sampleImageHitArea",
                "frames": [1,2,3],
                "rotation": "false",
                "visible": true,
                "id": "imgHit"
            } ```
         */
        protected createImageHitarea(json: any): bridge.BitmapImage;
        /**
         * Creates hitarea using shape
         * Possible shapes could be Rectangle, Circle, RoundedRectangle, Polygon
         * @param json shape Example JSON for circle
         * ```
         * "hitarea": {
                "type": "shape",
                "shape": "circle",
                "x": 135,
                "y": 135,
                "visible": false,
                "fillAlpha": 0.4,
                "diameter": 235
            } ```
         */
        protected createShapeHitarea(json: any): bridge.Rectangle | bridge.RoundedRectangle | bridge.Circle | bridge.Polygon;
        /**
         * Returns the name of button in String
         */
        toString(): string;
        /**
         * Sets the inputs true/false. If set to false no input will be listened on the button.
         * @param {boolean} value
         */
        setIsInputEnabled(value: boolean): void;
        /**
         * Returns if the input is enabled on the button or not.
         * @returns {boolean}
         */
        getIsInputEnabled(): boolean;
        /**
         * Get the visibility of the Button.
         * @returns {boolean}
         */
        /**
         * Set the visibility of the Button.
         * @param {boolean} value
         */
        visible: boolean;
        /**
         * Sets the button disable and adds a tint over it rto make it look disabled.
         */
        disableAndTint(): void;
        /**
         * Enables the button from disabled state and removes the tint.
         */
        enableAndTint(): void;
        /**
         * Binds the events with the button. do not use the same handler function to remove the event binding, instead store the returned function and use that to remove the handler.
         * @param type Event string type.
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         */
        on(type: string, handler: Function, scope?: any, once?: boolean, data?: any, priority?: number): this;
        /**
         * Unbinds the events with the button. Use the returned function of on or just leave the handler empty.
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         */
        off(type: string, handler?: Function, scope?: any): this;
        /**
         * sets text in label
         * @param text text to set
         */
        setLabel(text?: string): void;
        /**
         * Displays the bounds of a button
         * bridge worldPosition replaced with Pixi's worldTransform.
         * worldTransform {
         *              tx- x transform of displayObject w.r.t world coords
         *              ty- y transform of displayObject w.r.t world coords
         *              a - scale x (i.e worldScale)
         *              d-  scale y (i.e worldScale)
         * }
         */
        protected showBounds(json?: IButton): void;
    }
}
/**
 * Created by Asharma on 10-02-2017.
 */
declare namespace ingenuity.ui {
    class Label extends bridge.Container {
        protected readonly MIN_FONT_SIZE: number;
        protected label: bridge.Text;
        /** Shape bounds of label */
        private boundsGraphics;
        json: ILabel;
        constructor(json: ILabel);
        /**
        * Retrieves the global bounds of the displayObjectContainer as a rectangle. The bounds calculation takes all visible children into consideration.
        *
        * @param targetCoordinateSpace Returns a rectangle that defines the area of the display object relative to the coordinate system of the targetCoordinateSpace object.
        * @return The rectangular bounding area
        */
        showBounds(targetCoordinateSpace?: bridge.DisplayObject | bridge.Matrix): void;
        /**
         * Scales down the text to fit inside the provided bounds. Works only for single line text.
         * @param targetCoordinateSpace Returns a rectangle that defines the area of the display object relative to the coordinate system of the targetCoordinateSpace object.
         */
        protected fitText(targetCoordinateSpace?: bridge.DisplayObject | bridge.Matrix): Label;
        /**
         * Resets the Label style, text and scale to the provided json property
         */
        reset(): Label;
        /**
         * Resets the Label scale to json scale (if available) else resets to 1
         */
        resetScale(): Label;
        /**
         * Resets the font size, style & shadow of the label
         */
        resetSizing(): Label;
        /**
         * Get the label text
         */
        /**
         * Sets the label text
         * @param {string} value text to set in label
         */
        text: string;
        /**
        * The text to be displayed by this Text object.
        * Use a \n to insert a carriage return and split the text.
        * The text will be rendered with any style currently set.
        *
        * Use the optional `immediate` argument if you need the Text display to update immediately.
        *
        * If not it will re-create the texture of this Text object during the next time the render
        * loop is called.
        *
        * @param value The text to be displayed. Set to an empty string to clear text that is already present.
        * @param immediate Update the texture used by this Text object immediately (true) or automatically during the next render loop (false).
        * @param updateBounds updates the bounds on change in text
        * @return This Text instance.
        */
        setText(value: string, immediate?: boolean, updateBounds?: boolean): Label;
        /**
         * The tint applied to the sprite. This is a hex value. A value of 0xFFFFFF will remove any tint effect.
         * @param {number} value
         */
        tint: number;
        /**
        * Set the style of the text by passing a single style object to it.
        *
        * @param style The style properties to be set on the Text.
        * @param update Immediately update the Text object after setting the new style? Or wait for the next frame.
        * @return This Text instance.
        */
        setStyle(style?: bridge.ITextStyleBridge, update?: boolean): Label;
        /**
        * Sets a drop shadow effect on the Text. You can specify the horizontal and vertical distance of the drop shadow with the `x` and `y` parameters.
        * The color controls the shade of the shadow (default is black) and can be either an `rgba` or `hex` value.
        * The blur is the strength of the shadow. A value of zero means a hard shadow, a value of 10 means a very soft shadow.
        * To remove a shadow already in place you can call this method with no parameters set.
        *
        * @param x The shadowOffsetX value in pixels. This is how far offset horizontally the shadow effect will be.
        * @param y The shadowOffsetY value in pixels. This is how far offset vertically the shadow effect will be.
        * @param color The color of the shadow, as given in CSS rgba or hex format. Set the alpha component to 0 to disable the shadow. - Default: 'rgba(0,0,0,1)'
        * @param blur The shadowBlur value. Make the shadow softer by applying a Gaussian blur to it. A number from 0 (no blur) up to approx. 10 (depending on scene).
        * @param shadowStroke Apply the drop shadow to the Text stroke (if set). - Default: true
        * @param shadowFill Apply the drop shadow to the Text fill (if set). - Default: true
        * @return This Text instance.
        */
        setShadow(x?: number, y?: number, color?: any, blur?: number, shadowStroke?: boolean, shadowFill?: boolean): Label;
        /**
         * Changes the alignment of the text within its bounds. it is only applicable to single line text.
         * @param {string} align Horizontal alignment of the text within the `textBounds`. Can be: 'left', 'center' or 'right'.
         * @param {string} vAlign Vertical alignment of the text within the `textBounds`. Can be: 'top', 'middle' or 'bottom'.
         * @returns {ingenuity.ui.Label}
         */
        setAlignment(align?: string, vAlign?: string): Label;
        /**
        //  * Sets the colour of the outline, you can provide a single value as string and that colour will be applied to entire text.
        //  * other option is that you provide an array containing arrays of two value first being the colour and second being the
        //  * value from where/ which character to start that colour
        //  * @param {any[][] | any} value A canvas fillstyle that will be used on the text stroke eg `red`, `#00FF00`, `rgba()`.
        //  * @returns {ingenuity.ui.Label}
        //  */
        /**
         * @returns text and name of label
         * Example: [Label (text: XYZ, name: ABC)]
         */
        toString(): string;
        destroy(destroyChildren?: boolean): void;
    }
}
/**
 * Utility module.
 * @module ingenuity/utils
 * @alias ingenuity.utils
 */
declare namespace ingenuity.utils {
    /** Gets query parameters from the location of the document.
     * @description: Can be use to get the parameters passed by the operators
     * @param {string} key The key of the param which you want to retreive.
     * @returns {any} The value of the key from the location parameters.
     */
    function getParams(key: string): any;
    /** Checks whether the game is loaded inside an Iframe or not */
    function checkIframe(): boolean;
    /**
     * Checks if local storage is available on current device
     */
    function checkLocalStorage(): boolean;
    /**
     * Stores in local storage of device
     * @param key key to store
     * @param value value of the key
     */
    function store(key: string, value: any): void;
    /**
     * Retrives the value of key from local storage
     */
    function retrieve(key: string): any;
    /**
     * Checks if the key already exists in local storage
     */
    function isStored(key: string): boolean;
    /**
     * Converts XML to Generic JSON
     * @param xml - XML Node Tree
     * @param strRootNode - Root Node
     * @returns {any}
     */
    function xmlToJSON(xml: XMLDocument, strRootNode: string): any;
    /** Checks whether the game is loaded in a touch enabled device */
    let isTouch: boolean;
    /**
     * Function to send aysnc http request to server when there is no wrapper or wrapper doesn't provide option to connect to server. Provide either an object with option or seperate args.
     * @param {ajaxOptions} ..args:
     *      url{string}: url to hit,
     *      success{function}: function to call on successful connection,
     *      error{function}: function to call on unsuccessful connection,
     *      method{string}(optional): connection method 'get'or 'post'. default 'get',
     *      withCredentials{boolean}(optional): whither to connect with or with credentials. default true,
     *      receiveType{string}(optional):data type of the received data. 'json', 'xml' or 'text'.default text,
     *      data{string}(optional): data to be sent along the post method. default null,
     *      header{string:string[]}(optional): additional headers to be sent along the data
     *      timeout{number}(optional): It will close the http request after provided milliseconds
     * @returns {XMLHttpRequest} The xhr object to track or modify the ajax request.
     */
    function ajax(ajaxOpts: IAjaxOptions | string, success?: (response?: any) => void, error?: (response?: any) => void, method?: string, wc?: boolean, receiveType?: string, data?: any, header?: any, timeout?: number): XMLHttpRequest;
    /**
     * Deep clones an array or an object
     * @param {any} args An array or an object to be cloned.
     * @returns {any} The cloned object or array
     */
    function clone(args: any): any;
    /**
     * Clones a Array (of numbers or strings or any unmutable objects)
     * @param array
     * @param target
     * @returns {Array<number>}
     */
    function cloneArray(array: Array<number>, target?: Array<number>): number[];
    /**
     * Shuffles an array of numbers.
     * @param {number[]} array Number array to be cloned
     * @returns {number[]} Cloned and shuffled array of numbers.
     */
    function shuffle(array: Array<number>): Array<number>;
    /**
     * Returns array with unique values
     *
     * @array: array from which you want unique values
     */
    function uniqueArray(array: Array<number | string>, target?: Array<number>): Array<number | string>;
    /**
     * Shuffles an array even a multidimensional array or any type. like shuffle it shuffles the same array.
     * So please clone the array if you do not want to change the original array.
     * @param {any[]} array Number array to be cloned
     * @returns {any[]} Cloned and shuffled array of numbers.
     */
    function hardShuffle(array: Array<any>): Array<any>;
    /**
     * Calculates the distance between to points using pythagoras theorem
     * @param {number} a First point
     * @param {number} b Second point
     * @returns {number} The distance between to points. The hypotenuse of the right tringangle.
     */
    function hypotenuse(a: number, b: number): number;
    /**
     * Converts radian to degree.
     * @param {number} radAngle angle in radian
     * @param {int} round How many digits are required after the decimal. Default 4.
     * @returns {Number} Angle in Degree
     */
    function radToDeg(radAngle: number, roundOpts?: number): number;
    /**
     * Converts degree to radian.
     * @param {number} degAngle angle in degrees.
     * @param {int} round How many digits are required after the decimal. Default 4.
     * @returns {Number} Angle in radian
     */
    function degToRad(degAngle: number, roundOpts?: number): number;
    /**
     * Get the class name of an object.
     * @param object
     * @returns {String} The class name of the object passed
     */
    function getClassString(object: any): string;
    /**
     * Converts an XML string to an XML object
     * @param {string} str XML in string form
     * @returns {XMLDocument} The converted XML.
     */
    function toXML(str: string): any;
    /**
     * Compares two array for equality. Nested arrays can be compared
     * @param arr1
     * @param arr2
     * @returns {boolean}
     */
    function compareArray(arr1: Array<any>, arr2: Array<any>): boolean;
    /**
     * Compares two Objects for equality. Nested arrays and objects can be compared.
     * Please use it only to compare the JSON object otherwise cyclic checks can occur which can cause code to even freeze
     * @param object1
     * @param object2
     * @returns {boolean}
     */
    function compareObject(object1: any, object2: any): boolean;
    /**
     * Converts a String into Integer. This function does its best to extract the digits from a String. Use it carefully.
     * @param {string} str
     * @returns {number}
     */
    function toInt(str: string): number;
    /**
     * Converts a String into Number. This function does its best to extract the digits from a String. Use it carefully.
     * @param {string} str
     * @returns {number}
     */
    function toFloat(str: string): number;
    /**
     * Converts a string into Integer Array.
     * @param {string} str
     * @param {string} separator The character to split the string from
     * @returns {Number[]}
     */
    function strToIntArray(str: string, separator?: string): number[];
    /**
     * Converts a string into Number Array.
     * @param {string} str
     * @param {string} separator The character to split the string from
     * @returns {Number[]}
     */
    function strToNumArray(str: string, separator?: string): Array<number>;
    /**
     * Adds a zero before a string usually a varible. Like adding a '0' before an hour, minute or second.
     * @param num
     * @param size The number of digits finally returned after padding zero. 2 will return '03' or '10', 3 will return '003', '010' or '130'.
     */
    function padZero(num: number, size?: number): string;
    /**
     * Rounds of the provided number to provided decimal places.
     * @param num
     * @param size Decimal places to round off
     */
    function round(num: number, size?: number): number;
    function roundUp(n: number): number;
    /**
     * A faster ceiling function than Math.ceil
     * @param n
     * @returns {number}
     */
    function ceil(n: number): number;
    /**
     * A faster flooring function than Math.floor.
     * @param n
     * @returns {number}
     */
    function floor(n: number): number;
    /**
     * Strips the decimal places from the a number and returns the Integer part. Something similar to floor function
     * @param n
     * @returns {number}
     */
    function floatToInt(n: number): number;
    /**
     * Extends an object A with the properties of Object B. You can overwrite the values of already existing properities.
     * @param objA
     * @param objB
     * @param overwrite
     * @returns {Object}
     */
    function extendObj(objA: IObject, objB: IObject, overwrite?: boolean): IObject;
    /*** DOM based functions **/
    /**
     * Set wender prefix for javascript based css assignments
     * @param element HTML element for which you want to set the css property
     * @param prop The css property whose value you want to change
     * @param value
     */
    function setCSSPrefix(element: HTMLElement, prop: string, value: any): void;
    /**
     * Sets the css styles in the jquery style. Prefer setCSSPrefix function over this.
     * @param element
     * @param style
     */
    function setCSSStyle(element: HTMLElement, style: IObject): void;
    /**
     * Jquery equivelant of $(). Not 100%.
     * @param {string} str Pass a string prefixed with '#' to get the element by id, '.' to get the elements by css class and a simple string to either get the tag by name or tagname. later two returns an array.
     */
    function getElement(str: string | string[]): any;
    /**
     * Add a class to DOM element
     * @param elm
     * @param classList
     */
    function addClass(elm: Element, classList: string | IObject): void;
    /**
     * Remove a class from the element
     * @param elm
     * @param CSSClass
     */
    function removeClass(elm: Element, CSSClass?: string): void;
    /**
     *
     * Creates a delayed call of the specified time(milliseconds) and calls the specified callback function in after the delay.
     * Equivalent to setTimeout.
     * @param key (string)
     * @param time
     * @param callback
     * @param callbackContext
     * @param args Addistion Arguments
     */
    function delayedCall(key: string, time: number, callback: (data?: any) => void, callbackContext?: any, ...args: any[]): void;
    /**
     *
     * Creates a delayed looped call of the specified time(milliseconds) and calls the specified callback function in after the delayed interval.
     * Equivalent to setInterval.
     * @param key (string)
     * @param time
     * @param callback
     * @param callbackContext
     * @param args Addistion Arguments
     */
    function delayedLoopCall(key: string, time: number, callback: (data?: any) => void, callbackContext?: any, ...args: any[]): void;
    /**
     *
     * Creates a delayed repeated call of the specified time(milliseconds) for provided number of counts and calls the specified callback function in after the delayed interval.
     * Equivalent to setInterval.
     * @param key (string)
     * @param time
     * @param repeatCount
     * @param callback
     * @param callbackContext
     * @param args Addistion Arguments
     */
    function delayedRepeatCall(key: string, time: number, repeatCount: number, callback: (data?: any) => void, callbackContext?: any, ...args: any[]): void;
    /**
     *Destroys this Delayed call. The onComplete callbacks won't be called.
     * @param key (string)
     */
    function killDelayedCall(key: string): void;
    /**
     * A small util to load fonts. provide the list of font names to be loaded.
     * The name should be same for the font file and the font face which will be used in the css.
     * It requires a div with "fontTemp" id and it should be below the preloader so that it is not visible to the user.
     * don't forget to remove/ hide the "fontTemp" div before removing the preloader.
     * @param {string[]} fonts
     * @param {string} basePath
     * @constructor
     */
    function LoadFonts(fonts: string[], basePath?: string): void;
}
declare namespace ingenuity.utils.Formatter {
    /**
     * To prefix or to suffix the currency symbol
     * @boolean
     */
    let prefixSymbol: boolean;
    /**
     * Initialize the currency formatter.
     * @param basePath If this parameter is a string, it will load the symbol information from that url string. The symbol information object can directly be passed in this parameter
     * @param curr the currency to pick from symbol information object
     * @param decimalSep the symbol which separate decimal from whole number
     * @param thousandSep the symbol which separate the thousands
     * @param callback This function is called when the loading of symbol information is done.
     */
    function init(basePath: any, curr?: string, decimalSep?: string, thousandSep?: string, callback?: (data?: any) => void): void;
    /**
     * Sets the currency to be used by this module. If the currency is not available at the time of initialization, this function can be used to set currency later.
     * @param curr
     */
    function setCurrency(curr: string, decimalSep?: string, thousandSep?: string): void;
    function setCurrencySeparators(decimalSep: string, thousandSep?: string): void;
    /**
     * Formats number based on the separates provided
     * @param num Number to be formatted
     * @param places Number of decimals to show in the formatting
     * @returns {string} A formatted number as string.
     */
    function toLocaleNum(num: number | string, places?: number): string;
    /**
     * Suffix or Prefix the currency symbol to the formatted number
     * @param num Number to be formatted along with currency symbol
     * @param places Number of decimals to show in the formatting
     * @returns {string} A formatted number with currency.
     */
    function toLocaleMoney(num: number, places?: number): string;
    /**
     * Formats a number and suffix a '%' sign. Useful for formatting RTP values.
     * @param num Number to be formatted along with currency symbol
     * @param places Number of decimals to show in the formatting
     * @returns {string} A formatted number with '%'.
     */
    function toLocalePercent(num: string | number, places?: number): string;
}
declare namespace ingenuity.utils.Localization {
    let initiated: boolean;
    /**
     * Initializes localization handler
     * @param basepath If this parameter is a string, it will load the language information from that url string. The language information object can directly be passed in this parameter
     * @param lang The language to be used
     * @param isFolder Load the language file from a folder. The folder should of the same name as the language code and the file should be saved as text.json.
     * @param callback This function is called when the loading of language information is done.
     */
    function init(basepath: string | string[], lang?: string, isFolder?: boolean, callback?: (data?: any) => void): void;
    /**
     * Set the language to be used by this module. If the language is not available at the time of initialization, this function can be used to set language later.
     * @param lang
     */
    function setLanguage(lang?: string): void;
    /**
     * Get the text using the text key string.
     * @param key Key of the text value
     * @param replaceArray The array object of replaceable values. The replaceable variables should be enclosed in '%%'
     * @returns {string} The localized string matched to the key with replaced variables
     */
    function getText(key: string, replaceArray?: any): string;
}
declare namespace ingenuity.ui {
    class Meter extends Label implements IAnimatedMeter {
        protected value: number;
        protected formatedValue: string;
        protected currencyFormattedValue: string;
        protected ticking: boolean;
        protected endValue: number;
        protected callback: () => void;
        protected tickupAnim: ITween;
        protected duration: number;
        onTickupStart: ISignal;
        /**
         * This signal is fired when the meter updates the value while tick-up. the callback function will have parameter value which will be the updated value.
         */
        onTickup: ISignal;
        onTickupComplete: ISignal;
        /**
         * @param json Label Properties based json structure.
         * @param game bridge game object
         */
        constructor(json: ILabel, game?: bridge.Game);
        /**
         * Set a simple numeric value for the meter. Example number of autoplay left or number of freegames left
         * @param value
         */
        setValue(value: number): void;
        /**
         * @returns {number} The numeric value of the meter. You can even get this value for a meter which is
         *     displaying currency formatted value.
         */
        getValue(): number;
        /**
         * Sets the visibility of the meter.
         * @param value
         */
        setVisible(value: boolean): void;
        /**
         * Returns the visible state in boolean value
         */
        getVisible(): boolean;
        /**
         * Sets meter value and formats it with separators.
         * @param value
         */
        setFormattedValue(value: string): void;
        /**
         * Sets the  meter value with a defined string.
         * @param str String to be displayed in the meter
         * @param value Value to be replaced in the string. The string should contain '%amount%'.
         */
        setFormattedString(str: string, value: string): void;
        /**
         * Gets the formated value.
         * @returns {string} formated value
         */
        getFormattedValue(): string;
        /**
         * Set currency formatted value for the meter
         * @param value value to set
         */
        setCurrencyFormattedValue(value: string): void;
        /**
         * Sets the  meter value with a defined string.
         * @param str String to be displayed in the meter
         * @param value Value to be replaced in the string. The string should contain '%amount%'.
         */
        setCurrencyFormattedString(str: string, value: string): void;
        /**
         * Gets the currency formated value for this meter.
         * @returns currency formated value
         */
        getCurrencyFormattedValue(): string;
        /**
         * Resets the meter's value to zero, also resets any scaling done.
         */
        resetMeter(): void;
        /**
         * Returns whether the meter is ticking or not.
         * @returns {boolean}
         */
        readonly isTicking: boolean;
        /**
         * Starts meter tick up
         * @param value Ticks to this value.
         * @param showCurrency Whether to show the currency or not.
         * @param noFormatting Whether to tick up without any formatting. showCurrency takes precedence over this.
         * @param duration Duration for which meter will tick in seconds
         * @param onlyNumber Whether to tick value or a value in a string
         * @param callback Callback function to be called once tick up finishes.
         * @returns {number}
         */
        startTick(value: number, showCurrency?: boolean, noFormatting?: boolean, duration?: number, onlyNumber?: boolean, callback?: () => void): number;
        /**
         * Stops the running tickup
         * @param showCurrency
         * @param noFormatting
         * @param onlyNumber
         */
        stopTick(showCurrency?: boolean, noFormatting?: boolean, onlyNumber?: boolean): void;
        /**
         * @returns Meter text and name in string format
         * Example: `[Meter (text: ABC, name: XYZ)]`
         */
        toString(): string;
    }
}
/**
 * Created by Mupdhyay on 06/12/2017.
 */
declare namespace ingenuity.ui {
    class Slider extends Container {
        /**
         * A json object for slider which is to be used throughout the class.
         * @type {IContainer}
         */
        json: IContainer;
        /**
         * A blob object of type Image used to change the value of slider. (Since, the events are not defined under type Image bridge.Image or IObject
         * that is why any is used here.)
         * @type {any}
         */
        blob: any;
        /**
         * Background of blob of type Image
         *  @type {bridge.Image}
         */
        protected blobBg: bridge.BitmapImage;
        /**
         * A boolean to trace whether the dragging is true or not.
         *  @type {boolean}
         */
        private dragging;
        /**
         *  Variable to trace the min bets.
         *  @type {number}
         */
        private min;
        /**
         *  Variable to trace the max bets.
         *  @type {number}
         */
        private max;
        /**
         * // todo - Orientation based configuration is still need to be developed, Currently horizontal slider is available.
         *  @type {string}
         */
        private orientation;
        /**
         * A label object to display the max value of bet slider.
         *  @type {IText}
         */
        private maxLabel;
        /**
         * A label object to display min value of bet slider.
         *  @type {IText}
         */
        private minLabel;
        /**
         * A label object to display the current value of slider after dragged or initially.
         *  @type {IText}
         */
        private currentValueLabel;
        /**
         * The variable to store the initial X position of the slider object.(Container).
         *  @type {number}
         */
        private initialX;
        /**
         * The variable to store the initial Y position of the slider object.(Container).
         *  @type {number}
         */
        private initialY;
        /**
         * The variable to store the current X position of the slider object.(Container).
         * @type {number}
         */
        private currentX;
        /**
         * The variable to store the current Y position of the slider object.(Container).
         * @type {number}
         */
        private currentY;
        /**
         * The variable to store the range of the bet eg. - min = 5 max = 100 so range = 95.
         * @type {number}
         */
        private range;
        /**
         * The variable is most important which returns/ carries the current value of slider (Among the bets). Due to multiple type castings it is not
         * accepting String | Number or number or Number that is why any is used.
         * @type {number}
         */
        private currentValue;
        /**
         * A variable to store the max width of the slider object.
         * @type {number}
         */
        private maxWidth;
        /**
         * TODO- Masking / Filling Functionality when slider value changes.
         * @type {IGraphics}
         */
        private maskObj;
        /**
         * A bet array containing all the bets.
         * @type {Array<string>}
         */
        protected betArray: Array<string>;
        /**
         * A variable pointing towards the current bet among all.
         * @type {Number}
         */
        protected currentBet: number;
        /**
         * The ratio is used to calculate the slider movement on the track so as to divide into the areas for each bets.
         * @type {Number}
         */
        protected ratio: number;
        /**
         * Steps boolean is given from json to enable steps in the blobs movement.
         * @type {boolean}
         */
        protected steps: boolean;
        /**
         * This variable is used to store the previous X position of the blob.
         * @type {Number}
         */
        protected previousX: number;
        /**
         * This variable is used to store the previous y position of the blob.
         * @type {Number}
         */
        protected previousY: number;
        /**
         * Defines the up state of the Slider blob. Must be provided in animation of the Slider blob json as "up"
         * @type {string}
         */
        static UP: string;
        /**
         * Defines the down state of the Slider blob. Must be provided in animation of the Slider blob json as "down"
         * @type {string}
         */
        static DOWN: string;
        /**
         * Defines the mouse over state of the Slider blob. Must be provided in animation of the Slider blob json as "over".
         * This is added to the Slider blob to cater to the desktop versions
         * @type {string}
         */
        static OVER: string;
        /**
         * Defines the mouse out state of the Slider blob. Must be provided in animation of the Slider blob json as "out".
         * This is added to the Slider blob to cater to the desktop versions. if this is same as "up" then mention the same
         * frame
         * @type {string}
         */
        static OUT: string;
        /**
         * Defines the mouse out state of the Slider blob. Must be provided in animation of the button json as "out".
         * This is added to the Slider blob to cater to the desktop versions. if this is same as "up" then mention the same
         * frame
         * @type {string}
         */
        static DISABLED: string;
        constructor(json: IContainer, parent?: bridge.DisplayObjectContainer);
        /**
         * @param json
         */
        protected init(json: IContainer): void;
        /**
         * Setting The range, min , max, Bet Array for the slider.
         */
        protected setMinMaxAndCurrentValue(): void;
        /**
         * To create the slider mask According to the JSON entry.
         */
        protected createSliderMask(): void;
        /**
         * Method is to calculate the move of pointer/ Blob
         * @param pointer
         * @param x
         * @param y
         */
        protected move(pointer: IObject, x: number, y: number): void;
        /**
         * Creating the temporary labels for getting Min Max & Current Value of slider.
         */
        protected createSliderParametersLabel(): void;
        /**
         * For creating Sliders Track
         */
        protected createSliderTrack(): void;
        /**
         * For creating Sliders Blob
         */
        protected createBlob(): void;
        /**
         * Binds the events with the slider.
         * @param type Event string type.
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         * @returns {Function} The handler function which can be saved so that it can be unsubscribe or unbind
         */
        on(type: string, handler: (evt?: any) => void, scope?: any, once?: boolean, data?: any, priority?: number): (evt?: any) => void;
        /**
         * Unbinds the events with the slider.
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         */
        off(type: string, handler?: (evt?: any) => void, scope?: any): this;
        /**
         * Internal Tab down handler. Can be override to add more functionality.
         * @param evt
         */
        protected onBlobClicked(evt: IObject): void;
        /**
         * @param evt - An event fires when the dragging of slider ends
         */
        protected onBlobDragEnd(evt: IEvent): void;
        /**
         * The method manipulates current value to be returned to user
         * @returns {any}
         */
        protected calculateBlobsValue(): string | number;
        /**
         * Method is called when drag is moving/Updating
         */
        protected dragStarted(blob: IObject, pointer: IObject, dragX: any): void;
        /**
         * This method is to initialize the value of X & Y.
         */
        protected initializeInitialXY(): void;
        /**
         * Adds internal Input Down handler to change the index on selection.
         * @param tabBtn
         */
        protected addInputEvents(tabBtn: IObject): void;
        /**
         * This method is for setting bet array and the current Bet in the game.
         * @param betArray
         * @param currentBet
         */
        setBetArrayAndCurrentBet(betArray: Array<any>, currentBet: number): void;
        /**
         * The method is to set the blob position according to current Bet.
         */
        protected setBlobsInitialPosition(): void;
    }
}
declare namespace ingenuity.ui {
    class TabButton extends bridge.Container {
        protected selectedTab: number;
        protected tabArray: Array<any>;
        /**
         * Creates and add the no of tabs supplied in JSON in a group.
         * @param json
         * @param game
         */
        constructor(json: ITabButton, game: bridge.Game);
        /**
         * Creates a tabButton and binds input events to them.
         * @param json
         * @param game
         */
        protected createTabGroupAndAddTabButtons(json: any, game: bridge.Game): void;
        /**
         * Internal Tab down handler. Can be overrided to add more functionality.
         * @param evt
         */
        protected onTabDown(evt: any): void;
        /**
         * Adds internal Input Down handler to change the index on selection.
         * @param tabBtn
         */
        protected addInputEvents(tabBtn: ButtonBase): void;
        /**
         * Returns an object of BaseButton.
         * @param json
         * @param game
         */
        protected createTabButtons(json: any, game: any): any;
        /**
         * Returns the no of selected Tab.
         * @returns {Number}
         */
        getSelectedTab(): number;
        /**
         * Binds the events with the button.
         * @param type Event string type.
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         * @returns {Function} The handler function which can be saved so that it can be unsubscribe or unbind
         */
        on(type: string, handler: (e?: any) => void, scope?: any, once?: boolean, data?: any, priority?: number): this;
        /**
         * Unbinds the events with the button.
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         */
        off(type: string, handler?: (e?: any) => void): this;
        /**
          * Checks whether a handler is bound to specified event
          * @param type event type/name to check
          */
        hasEvent(type: string): any;
        /**
         * Sets all the tab buttons enable or disable.
         */
        setEnabled(value: boolean): void;
        /**
         * Enable or disable tab by specified tab number.
         * @param tabNo
         * @param value
         */
        setTabEnabledByNo(tabNo: number, value: boolean): void;
        /**
         * Returns if the supplied tab is enabled or not.
         * @param tabNo
         * @returns {boolean}
         */
        getIsTabEnabled(tabNo: number): any;
    }
}
/**
 * Created by Amathur on 2/3/2017.
 */
declare namespace ingenuity.ui {
    class ShapeToggleButton extends Container {
        private objMyGame;
        private objBtnBGOn;
        private objBtnBGOff;
        private objBtnCircle;
        objBtnHit: bridge.Graphics;
        isOn: boolean;
        constructor(json: IShapeToggleButton, objGame: bridge.Game);
        /**
         * Internal function. Creates the shapes and hit area and add in the container.
         * @param json
         * @returns {ingenuity.ui.ShapeToggleButton}
         */
        private createToggleButtonShape(json);
        /**
         * Sets the button state to the supplied state. If set true it will switch on the button and vice-versa.
         * @param state
         */
        setButtonState(state: boolean): void;
        /**
         * Switches the button to the opposite of the current state. If the button is on it will switch it of and vice-versa.
         */
        switchBtn(): void;
        /**
         * Binds the events with the button.
         * @param type Event string type.
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         * @returns {Function} The handler function which can be saved so that it can be unsubscribe or unbind
         */
        on(type: string, handler: (e?: any) => void, scope?: any, once?: boolean, data?: any, priority?: number): () => void;
        /**
         * Unbinds the events with the button.
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         */
        off(type: string, handler?: (e?: any) => void): this;
    }
}
declare namespace ingenuity.ui {
    class ToggleButton extends Container {
        protected stateOnOff: boolean;
        protected enabled: boolean;
        protected btnOn: ButtonBase;
        protected btnOff: ButtonBase;
        constructor(json: IToggleButton, game: bridge.Game);
        /**
         * Internal function. Creates the 2 buttons and add input events to them.
         * @param json
         * @param game
         */
        private createButtons(json, game);
        /**
         * Binds the events with the button.
         * @param type Event string type. Most of the Events are available @ ingenuity.events.EventConstants
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         * @returns {Function} The handler function which can be saved so that it can be unsubscribe or unbind
         */
        on(type: string, handler: (btn?: ToggleButton, ptr?: IPointer, over?: boolean, ...args: any[]) => void, scope?: any, once?: boolean, data?: any, priority?: number): this;
        /**
         * Switches the button to Off state.
         */
        onBtnOnPressed(btn: ToggleButton, point: IPointer, isOver?: boolean): void;
        /**
         * Switches the button to ON state.
         */
        onBtnOffPressed(btn: ToggleButton, point: IPointer, isOver?: boolean): void;
        /**
         * Unbinds the events with the button.
         * @param type type/name of the event to be unsubscribed
         * @param handler Event handler function
         */
        off(type: string, handler?: (btn?: ToggleButton, ptr?: IPointer, over?: boolean, ...args: any[]) => void, scope?: any): this;
        /**
         * Sets the button enable or disable.
         * @param value
         */
        setEnabled(value: boolean): void;
        /**
         * @param value Sets the button interactive based on value
         */
        setInteractive(value: boolean): void;
        /**
         * @returns button's interactive state
         */
        getInteractive(): boolean;
        /**
         * Changes the state of the Toggle Button. If the parameter is not provided it will toggle the current state.
         * @param isOn
         */
        switchBtn(isOn?: boolean): void;
        /**
         * Gets the state of the Toggle Button.
         * @returns {boolean} The current state of the Toggle button.
         * - `true`: Button is in ON state.
         * - `false`: Button is in OFF state.
         */
        isOn(): boolean;
    }
}
/**
 * Created by Amathur on 2/19/2017.
 */
declare namespace ingenuity.ui {
    import BitmapText = bridge.BitmapText;
    class LabelBitmap extends Container {
        protected label: BitmapText;
        constructor(json: ILabelBitmap);
        /**
         * Resets any sizing done on this label.
         * @returns {ui.LabelBitmap}
         */
        resetSizing(): LabelBitmap;
        /**
         * Gets the text property of the label.
         * @returns {string}
         */
        /**
         * Sets the text property of the label.
         * @param {string} value text to set
         */
        text: string;
        /**
         * Sets the label text immediately.
         * @param value The text to be displayed. Set to an empty string to clear text that is already present.
         * @param immediate Update the texture used by this Text object immediately (true) or automatically during the next render loop (false).
         * @returns {ingenuity.ui.LabelBitmap}
         */
        setText(value: string, immediate?: boolean): LabelBitmap;
        /** Sets alignment of the Label
         * @param {string} align Horizontal alignment of the text within the `textBounds`. Can be: 'left', 'center' or 'right'.
         * @param {string} vAlign Vertical alignment of the text within the `textBounds`. Can be: 'top', 'middle' or 'bottom'.
         * @returns {ui.LabelBitmap}
         */
        setAlignment(align?: string, vAlign?: string): LabelBitmap;
        /**
         * Sets the tint value of the Label
         * @param {number} value
         */
        tint: number;
        /**
         * Creates a rectangle boundary around the label.
         * @param targetCoordinateSpace
         */
        showBounds(targetCoordinateSpace?: bridge.DisplayObject | bridge.Matrix): void;
        /**
         * Called for autoscaling of BitMap LABEL.
         */
        protected fitText(targetCoordinateSpace?: bridge.DisplayObject | bridge.Matrix): LabelBitmap;
        /**
         * @returns text and name of label as string
         * Example output: `[Label (text: ABC, name: XYZ)]`
         */
        toString(): string;
    }
}
declare namespace ingenuity.ui {
    class MeterBitmap extends LabelBitmap {
        protected value: number;
        protected formatedValue: string;
        protected currencyFormattedValue: string;
        protected defaultColor: string;
        protected ticking: boolean;
        protected endValue: number;
        protected callback: () => void;
        protected tickupAnim: ITween;
        protected duration: number;
        onTickupStart: bridge.Signal;
        onTickupComplete: bridge.Signal;
        /**
         * @param json Label Properties based json structure.
         * @param game bridge game object
         */
        constructor(json: ILabelBitmap);
        /**
         * Set a simple numeric value for the meter. Example number of autoplays left or number of freegames left
         * @param value
         */
        setValue(value: number): void;
        /**
         *
         * @returns {number} The numeric value of the meter. You can even get this value for a meter which is
         *     displaying currency formatted value.
         */
        getValue(): number;
        /**
         * Toggle visibility
         * @param value true or false to set the visibility
         */
        setVisible(value: boolean): void;
        /**
         * @returns current visibility of meter bitmap
         */
        getVisible(): boolean;
        /**
         * Sets meter value and formats it with separators.
         * @param value
         */
        setFormattedValue(value: string): void;
        /**
         * Sets the  meter value with a defined string.
         * @param str String to be displayed in the meter
         * @param value Value to be replaced in the string. The string should contain '%amount%'.
         */
        setFormattedString(str: string, value: string): void;
        /**
         * @returns current formated value of meter bitmap
         */
        readonly formattedValue: string;
        /**
         * Set currency formatted value for the meter
         */
        setCurrencyFormattedValue(value: string): void;
        /**
         * Sets the  meter value with a defined string.
         * @param str String to be displayed in the meter
         * @param value Value to be replaced in the string. The string should contain '%amount%'.
         */
        setCurrencyFormattedString(str: string, value: string): void;
        /**
         * @returns Currency formatted value
         */
        getCurrencyFormattedValue(): string;
        /**
         * To reset meter value to Zero
         */
        resetMeter(): void;
        /**
         * Returns whether the meter is ticking or not.
         * @returns {boolean}
         */
        readonly isTicking: boolean;
        /**
         * Starts meter tick up
         * @param value Ticks to this value.
         * @param showCurrency Whether to show the currency or not.
         * @param showNumOnly Whether to tick up without any formatting. showCurrency takes precedence over this.
         * @param duration Duration for which meter will tick in seconds
         * @param onlyNumber Whether to tick value or a value in a string
         * @param callback Callback function to be called once tick up finishes.
         * @returns {number}
         */
        startTick(value: number, showCurrency?: boolean, showNumOnly?: boolean, duration?: number, onlyNumber?: boolean, callback?: () => void): number;
        /**
         * Stops the running tickup
         * @param showCurrency
         * @param showNumOnly
         * @param onlyNumber
         */
        stopTick(showCurrency?: boolean, showNumOnly?: boolean, onlyNumber?: boolean): void;
        /**
         * @returns Meter text and name in string format
         * Example: `[Meter (text: ABC, name: XYZ)]`
         */
        toString(): string;
    }
}
declare namespace ingenuity.ui {
    function AssignProperties(obj: any, json: any): void;
    /**
     * This Class creates the view of your game. It contains all methods to create and get the base components for your
     * game. All the data passed in JSON format.
     */
    class BaseView extends Container {
        /** Contains all buttons created in this view */
        protected buttons: {
            [key: string]: ButtonBase | TabButton | IGraphics;
        };
        /** Contains all images created in this view */
        protected images: {
            [key: string]: Bitmap;
        };
        /** Contains all Label & LabelBitmap created in this view */
        protected labels: {
            [key: string]: Label | LabelBitmap;
        };
        /** Contains all Meter & MeterBitmap created in this view */
        protected meters: {
            [key: string]: Meter | MeterBitmap;
        };
        /** Contains all animations created in this view */
        protected animations: {
            [key: string]: AnimationBase;
        };
        /** Contains all shapes created in this view */
        protected shapes: {
            [key: string]: bridge.Graphics;
        };
        /** Contains all containers created in this view */
        protected containers: {
            [key: string]: Container;
        };
        protected videoContainers: {
            [key: string]: Container;
        };
        protected toggleButtons: {
            [key: string]: ToggleButton;
        };
        /** Contains all Slider created in this view */
        protected slider: {
            [key: string]: Slider;
        };
        /** Contains all spines created in this view */
        protected spines: {
            [key: string]: SpineBase;
        };
        /** Contains all components created in this view */
        protected allComponents: {
            [key: string]: Container | any;
        };
        /** Possible type of components */
        protected compTypes: Array<string>;
        constructor(viewJson: IContainer);
        /**
         * Creates the components specific to their type. If new types has to be added then override this method and
         * call the super first then add switch case for new types.
         * Following types of components can be created by this method.
         * * container - Creates a container in the View.
         * * button
         * * label
         * * meter
         * * image
         * * animation
         * * shape
         * * shapebutton
         * * shapetogglebutton
         * * togglebutton
         * * tabbutton
         * * labelbitmap
         * * meterbitmap
         * * Slider
         * @param json
         * Any can't be removed as several different type of JSON'S are used
         */
        createDisplayTree(json: any): void;
        /**
         *
         * Creates the Spine in the View
         * Following is the example JSON Entry.
         * ```
         *"SpineData": {
            "x": 50,
            "y": 200,
            "id": "exampleSpine",
            "images": ["spine_1", "spine_2"],
            "premultipliedAlpha": false,
            "anchorX": 10,
            "anchorY": 10,
            "regX": 10,
            "regY": 10,
            "scale": 1,
            type: "spine",
            "parent": parent_1,
            "rotation": 5,
            "visible": true,
            "hitArea": {
                "x": 10,
                "y": 12,
                "type": "shape""w": 50,
                "h": 50,
                "d": 30
            }```
         }
         * @param json
         */
        protected createSpine(json: ISpineData): SpineBase;
        /**
         * Creates the video in the view
         * Following is the example JSON
         * "Video1": {
                x: 0,
                y: 0,
                visible: true,
                type: "video",
                id: "dolby",
                scaleX: 0.5,
                scaleY: 0.5
            }
         */
        protected createVideo(json: IContainer): IVideo;
        /**
         *
         * Creates the Bitmap Meter in the View.
         * Following is the example JSON Entry.
         *
         * ```
         *        "BitmapMeter": {
                    "text": "0.00",
                    "x": 50,
                    "y": 200,
                    "w": 100,
                    "h": 43,
                    "type": "meterbitmap",
                    "image": "text",
                    "id": "MeterID",
                    "style": {
                        "align": "center",
                        "fontSize": 70
                    }
                }
         * ```
         * @param json
         */
        createMeterBitmap(json: ILabelBitmap): LabelBitmap;
        /** Creates the Slider in the View
         * Following is the Example of its JSON Entry
         * ```
         * slider :{ "x": 200,
         "y": 200,
         "w": 600,
         "h": 400,
         "type": "slider",
         "visible": true,
         "bounds":false,
         "min": 1,
         "max": 11,
         "sliderMaskFill": true,
         "betArray": ["1","50","100","500","900"],
         "steps": true,
         "orientation": "horizontal",
         "id": "sliderContainer",
         "sliderBg":{
                "x": 0,
                "y": 0,
                "w": 400,
                "h": 30,
                "type": "image",
                "image": "sliderBg"
            },
         "blob": {
                "x": 0,
                "y": 10,
                "w": 30,
                "h": 30,
                "type": "image",
                "image": "blob"
            },
         "parent": "xyz",
         } } ```
         * @param {ingenuity.ISlider} json
         */
        createSlider(json: ISlider): Slider;
        /**
         * Creates the Bitmap Label in the View.
         * Following is the example JSON Entry.
         * ```
         "BitmapLabel": {
                    "text": "This is a sample text.",
                    "x": 50,
                    "y": 200,
                    "w": 100,
                    "h": 43,
                    "type": "labelbitmap",
                    "image": "text",
                    "id": "LabelId",
                    "style": {
                        "font": "Arial",
                        "align": "center",
                        "fontSize": 70
                    }
                }
         * ```
         * @param json
         */
        createLabelBitmap(json: ILabelBitmap): LabelBitmap;
        /**
         * Creates the Tab Buttons in the View. Can create multiple tabs by specifying the no and frames.
         * Following is the example JSON Entry.
         * ```
         *        "tabButtonName" = {
                    "x"        : 100,
                    "y"        : 100,
                    "w"        : 170,
                    "h"        : 47,
                    "totalTabs": 3,
                    "type"     : "tabbutton",
                    "id"       : "tabBtnID",
                    "image"    : "tab",
                    "frames"   : {
                        "up"  : "1.png",
                        "over": "2.png",
                        "down": "3.png",
                        "out" : "1.png"
                    }
         *		},
         * ```
         * @param json
         */
        createTabButton(json: ITabButton): TabButton;
        /**
         * Creates basic shape Toggle button in the View.
         * Following is the example JSON Entry.
         * ```
         *        "toggleBtn" = {
         * 		    "x"      : 0,
                    "y"      : 200,
                    "w"      : 100,
                    "h"      : 43,
                    "type"   : "togglebutton",
                    "id"     : "toggleBtn2",
                    "image"  : "toggle",
                    "enable": false,
                    "frames" : {
                        "on" : {
                            "up"      : "SoundOn_Noraml.png",
                            "over"    : "SoundOn_Touch.png",
                            "down"    : "SoundOn_down.png",
                            "out"     : "SoundOn_Noraml.png",
                            "disable": "SoundOn_disable.png"
                        },
                        "off": {
                            "up"      : "Sound_off_touch.png",
                            "over"    : "Sound-off_normal.png",
                            "down"    : "Sound_off_down.png",
                            "out"     : "Sound_off_touch.png",
                            "disable": "Sound-off_disable.png"
                        }
                    }
                }
         * ```
         * @param json
         */
        createToggleButton(json: IToggleButton): ToggleButton;
        /** creates advanced buttons with layers of label bitmaps, idle animations, labels etc
         * ```
         *  "spinAdvancedButton": {
      "x": 1150,
      "y": 400,
      "h": 209,
      "w": 169,
      "idleTimer": 15000,
      "type": "advancedbutton",
      "id": "spin1",
      "visible": true,
      "states": {
        "over": {
          "x": 0,
          "y": 0,
          "h": 209,
          "w": 169,
          "btnSprite": {
            "type": "image",
            "x": -5,
            "y": 25,
            "w": 180,
            "h": 184,
            "images": "spin_hover"
          },
          "btnLabel": {
            "x": 0,
            "y": 0,
            "w": 100,
            "h": 26,
            "visible": true,
            "type": "label",
            "text": "SPIN",
            "bounds": false,
            "style": {
              "font": "14px 'MyriadPro-Bold'",
              "boundsAlignH": "left",
              "boundsAlignV": "middle",
              "fill": "#941100",
              "stroke": "#000000"
            }
          }
        },
        "disable": {
          "x": 0,
          "y": 0,
          "h": 209,
          "w": 169,
          "btnSprite": {
            "type": "image",
            "x": -5,
            "y": 25,
            "w": 180,
            "h": 184,
            "images": "spin_disable"
          },
          "btnLabel": {
            "x": 0,
            "y": 0,
            "w": 100,
            "h": 26,
            "visible": true,
            "type": "label",
            "text": "SPIN",
            "bounds": false,
            "style": {
              "font": "14px 'MyriadPro-Bold'",
              "boundsAlignH": "left",
              "boundsAlignV": "middle",
              "fill": "#000000",
              "stroke": "#000000"
            }
          }
        },
        "up": {
          "x": 0,
          "y": 0,
          "h": 209,
          "w": 169,
          "btnSprite": {
            "type": "image",
            "x": -5,
            "y": 25,
            "w": 180,
            "h": 184,
            "images": "spin_normal"
          },
          "btnAnimation": {
            "type": "animation",
            "x": 0,
            "y": 0,
            "h": 209,
            "w": 169,
            "alwaysAnimate": true,
            "animations22": {
              "anim": {
                "generateNames": true,
                "prefix": "spin_button_animation_bubble_",
                "suffix": ".png",
                "zeroPad": 1,
                "frames": [
                  0,
                  9
                ],
                "loop": true,
                "frameRate": 30
              }
            },
            "images": "spin_button_bubble_animation",
            "posterFrame": 1,
            "frameRate": 60,
            "loop": false,
            "visible": false
          },
          "btnLabel": {
            "x": 0,
            "y": 0,
            "w": 100,
            "h": 26,
            "visible": true,
            "type": "label",
            "text": "SPIN",
            "id": "SPINC",
            "bounds": false,
            "style": {
              "font": "14px 'MyriadPro-Bold'",
              "boundsAlignH": "left",
              "boundsAlignV": "middle",
              "fill": "#33FFF9",
              "stroke": "#000000"
            }
          }
        },
        "out": {
          "x": 0,
          "y": 0,
          "h": 209,
          "w": 169,
          "btnSprite": {
            "type": "image",
            "x": -5,
            "y": 25,
            "w": 180,
            "h": 184,
            "images": "spin_normal"
          },
          "btnAnimation": {
            "type": "animation",
            "x": 0,
            "y": 0,
            "h": 209,
            "w": 169,
            "alwaysAnimate": true,
            "animType": "idle",
            "images": "spin_button_bubble_animation",
            "posterFrame": 1,
            "frameRate": 60,
            "loop": false,
            "visible": false
          },
          "btnLabel": {
            "x": 90,
            "y": 90,
            "w": 100,
            "h": 26,
            "visible": true,
            "type": "label",
            "text": "SPIN",
            "id": "SPINC",
            "bounds": false,
            "style": {
              "font": "14px 'MyriadPro-Bold'",
              "boundsAlignH": "left",
              "boundsAlignV": "middle",
              "fill": "#33FFF9",
              "stroke": "#000000"
            }
          },
          "BitmapLabel": {
            "text": "012",
            "x": 10,
            "y": 90,
            "w": 100,
            "h": 43,
            "type": "labelbitmap",
            "image": "text",
            "id": "LabelId",
            "style": {
              "font": "50px BigWinFont",
              "align": "center"
            }
          }
        },
        "down": {
          "x": 0,
          "y": 0,
          "h": 209,
          "w": 169,
          "btnSprite": {
            "type": "image",
            "x": -5,
            "y": 25,
            "h": 180,
            "w": 184,
            "images": "spin_press"
          },
          "btnLabel": {
            "x": 0,
            "y": 0,
            "w": 100,
            "h": 26,
            "visible": true,
            "type": "label",
            "text": "SPIN",
            "id": "SPINC",
            "bounds": false,
            "style": {
              "font": "14px 'MyriadPro-Bold'",
              "boundsAlignH": "left",
              "boundsAlignV": "middle",
              "fill": "#062E0B",
              "stroke": "#000000"
            }
          }
        }
      },
      "hitareas": {
        "type": "shape",
        "shape": "circle",
        "x": 0,
        "y": 0,
        "anchorX": -80,
        "anchorY": -102,
        "diameter": 160,
        "visible": false
      },
      "hitarea": {
        "type": "image",
        "x": -5,
        "y": 25,
        "w": 180,
        "h": 184,
        "image": "spin_disable",
        "visible": false,
        "alpha": 0.01
      },
      "parent": "buttonsContainer"
    } ```
        */
        createAdvancedButton(json: IAdvancedButton): AdvancedButton;
        /**
         * Creates basic shape Toggle button in the View.
         * Following is the example JSON Entry.
         * ```
         *      "shapeToggleBtn":{
                    x:200,
                    y:150,
                    w:80,
                    h:45,
                    visible:true,
                    alpha:1,
                    id:"shapeToggleBtnID",
                    fillColor:"0Xff0",
                    fillColorOff:"0Xff0044",
                    circleFillColor:"0XFFFFFF",
                    fillAlpha:1,
                    fillAlphaOff:1,
                    circleFillAlpha:1,
                    isOn:true
                    }
         *      } ```
         * @param json
         */
        createShapeToggleButton(json: IShapeToggleButton): ShapeToggleButton;
        /**
         * Creates the button of the specified shape in the View.
         * Following is the example JSON Entry.
         * ```typescript
         * "shapeButton":{
              "x"          : 400,
              "y"          : 300,
              "w"          : 150,
              "h"          : 150,
              "visible"    : true,
              "alpha"      : 1,
              "type"       : "shapebutton",
              "id"         : "roundcornerrectangle",
              "strokeSize" : 1,
              "strokeColor": "0Xffffff",
              "strokeAlpha": 0,
              "fillColor"  : "0XFF00FF",
              "fillAlpha"  : 0.8,
              "shape"      : "roundcornerrectangle", // can be "rectangle", "roundornerrectangle", "circle", "custom".
              "radius"     : 40,
              "label":{
                   "text":"Sample Text",
                   "x":15,
                   "y":10,
                   "w":90,
                   "h":90,
                   "type":"label",
                   "id":"LabelId",
                   "style":{
                      "font":"Arial",
                      "fill":"#0000FF",
                      "align":"center",
                      "fontStyle": "normal",
                      "fontWeight":"normal",
                      "fontSize":40,
                      "boundsAlignH":"center",
                      "boundsAlignV":"middle",
                      "wordWrap": true
                   },
                   "shadow": {
                      "color"  : "#000000",
                      "blurX"  : 1,
                      "blurY"  : 5,
                      "quality": 10
                   }
               }
         *	}```
         * @param json
         */
        createShapeButton(json: IShapeButton): IGraphics;
        /**
         * Creates the container in the View.
         * Following is the example JSON Entry.
         * ```
         * "Container":{
         *		  "x":0, //mandatory
         *		  "y":0, //mandatory
         *		  "w":1024, //mandatory
         *		  "h":768, //mandatory
         *		  "visible":true, //Optional
         *		  "type":"container", //mandatory
         *		  "id":"ContainerID", //mandatory
         *		  "parent":"ParentName" //Optional
         *		} ```
         * @param json
         */
        createContainer(json: IContainer): Container;
        /**
         * Creates an Image in the view.
         * Following is the example JSON Entry.
         * ```
         * "Image":{
         *	  "x":0,
         *	  "y":0,
         *	  "w":1024,
         *	  "h":768,
         *	  "visible":true,
         *	  "type":"image",
         *	  "image":"ImageName",
         *	  "id":"ImageID",
         *	  "parent":"ParentName"
         *	} ```
         * @param json
         */
        createImage(json: IImage): Bitmap;
        /**
         * Creates the Animation from the sprite sheet in the View.
         * Following is the example JSON Entry.
         * ```
         * "Animation":{
         *	  "x": 200,
                "y": 200,
                "visible": true,
                "type": "animation",
                "id": "animId",
                "image": "animation"
         *	} ```
         * @param json
         */
        createAnimation(json: IAnimation): AnimationBase;
        protected checkAllImagesLoaded(imgArr: string[]): boolean;
        /**
         * Creates basic shapes like "Rectangle", "Circle", "Rounded corner Rectangle", "Polygon" in the View.
         * Following is the example JSON Entry.
         * ```typescript
         * "shape":{
                "x"          : 100,
                "y"          : 175,
                "w"          : 0,
                "h"          : 0,
                "visible"    : true,
                "alpha"      : 1,
                "type"       : "shape",
                "id"         : "circleShape",
                "strokeSize" : 1,
                "strokeColor": "0Xffffff",
                "strokeAlpha": 0,
                "fillColor"  : "0XFF00000",
                "fillAlpha"  : 0.8,
                "shape"      : "circle", // can be "rectangle", "roundornerrectangle", "circle", "custom".
                "diameter"   : 150    // used in Circle. "radius" : 45 for roundCornerRectangle.
         *	} ```
         * @param json
         */
        createShape(json: IShape): bridge.Graphics;
        /**
         * Creates a simple button with the frames provided in the View.
         * Following is the example JSON Entry.
         * ```
         *    "Button":{
                "x": 300,
                "y": 100,
                "w": 100,
                "h": 43,
                "type": "button",
                "id": "Btn2",
                "image": "btn",
                "enable": true,
                "frames": {
                    "up": "Left_Arrow_Active.png",
                    "over": "Left_Arrow_touch.png",
                    "down": "Left_Arrow_down.png",
                    "out": "Left_Arrow_Active.png",
                    "disable": "Left_Arrow_Desible.png"
                }
         *	} ```
         * @param json
         */
        createButton(json: IButton): ButtonBase;
        /**
         * Creates Label for the Button and return the object of the label. It does not add the label in the View.
         * ```
         * "label":{
                     "text":"Sample Text",
                     "x":15,
                     "y":10,
                     "w":90,
                     "h":90,
                     "type":"label",
                     "id":"LabelId",
                     "style":{
                        "font":"Arial",
                        "fill":"#0000FF",
                        "align":"center",
                        "fontStyle": "normal",
                        "fontWeight":"normal",
                        "fontSize":40,
                        "boundsAlignH":"center",
                        "boundsAlignV":"middle",
                        "wordWrap": true
                     },
                     "shadow": {
                        "color"  : "#000000",
                        "blurX"  : 1,
                        "blurY"  : 5,
                        "quality": 10
                     }
                 }
         * ```
         * @param json
         * @param cache
         * @returns {Label}
         */
        createBtnLabel(json: ILabel, cache?: boolean): Label;
        /**
         * Creates a Label in the View.
         * ```
         * "label":{
                    x     : 10,
                    y     : 100,
                    w     : 500,
                    h     : 85,
                    type  : "label",
                    text  : "Sample Text",
                    style : {
                        font : "65px Arial",
                        fill : "#ff0044",
                        align: "center"
                    },
                    shadow: {
                        color  : "#fff",
                        blurX  : 1,
                        blurY  : 5,
                        quality: 10
                    }
                 } ```
         * @param json
         */
        createLabel(json: ILabel): Label;
        /**
         * Creates a tickup Meter in the View. Following is the example JSON Entry.
         * ```
         *        "meterName" = {
         * 		     "text":"0.00",
                     "x":100,
                     "y":10,
                     "w":90,
                     "h":90,
                     "type":"meter",
                     "id":"MeterID",
                     "style":{
                        "font":"Arial",
                        "fill":"#0000FF",
                        "align":"center",
                        "fontStyle": "normal",
                        "fontWeight":"normal",
                        "fontSize":60,
                        "boundsAlignH":"center",
                        "boundsAlignV":"middle",
                        "wordWrap": true
                     },
                     "shadow": {
                        "color"  : "#000000",
                        "blurX"  : 1,
                        "blurY"  : 5,
                        "quality": 10
                     }
         *		} ```
         * @param json
         */
        createMeter(json: ILabel): void;
        /**
         * Returns the button of the specified name created in the View.
         * @param id
         */
        getButtonById(id: string): ButtonBase | TabButton | IGraphics;
        /**
         * Returns the button of the specified name created in the View.
         * @param id
         */
        getToggleButtonById(id: string): ToggleButton;
        /**
         * Returns the array of all the button created in the View.
         */
        getbuttonArray(): {
            [key: string]: ButtonBase | TabButton | IGraphics;
        };
        /**
         * Returns the array of all the toggle button created in the View.
         */
        getToggleButtonArray(): {
            [key: string]: ToggleButton;
        };
        /**
         * Updates labels of Button.
         * @param evt
         * This function accepts the {id: string} or {Button: ButtonBase} as an Array in evt.data
         * In case only one button need to be updated, just send {id: string} or {Button: ButtonBase} in evt.data
         */
        protected updateButtonLabels(evt?: IEvent): void;
        /**
         * Returns the Image of the specified name created in the View.
         * @param id
         */
        getImageById(id: string): Bitmap;
        /**
         * Returns the array containing all the Images creates in the View.
         */
        getImageArray(): {
            [key: string]: Bitmap;
        };
        /**
         * Returns the Shape of the specified name created in the View.
         * @param id
         */
        getShapeById(id: string): IGraphics;
        /**
         * Returns the array of all the Shapes created in the View.
         */
        getShapeArray(): {
            [key: string]: IGraphics;
        };
        /**
         * Returns the Label of the specified name created in the View.
         * @param id id of label
         */
        getLabelById(id: string): Label | LabelBitmap;
        /**
         * Returns the array of all the Labels created in the View.
         */
        getLabelsArray(): {
            [key: string]: Label | LabelBitmap;
        };
        /**
         * Updates text in labels.
         * @param evt
         * This function accepts the {id: string} or {label: Label} as an Array in evt.data
         * In case only one label need to be updated, just send {id: string} or {label: Label} in evt.data
         */
        protected updateLabels(evt?: IEvent): void;
        /**
         * Returns the Meter of the specified name created in the View.
         * @param id
         */
        getMeterById(id: string): Meter | MeterBitmap;
        /**
         * Returns the array of all the Meters created in the View.
         */
        getMetersArray(): {
            [key: string]: Meter | MeterBitmap;
        };
        /**
         * Updates the value in meter
         * @param {IEvent} evt
         */
        protected updateMeters(evt?: IEvent): void;
        /**
         * To get the slider present in the base view
         * @param {string} id id of slider
         */
        getSliderByID(id: string): Slider;
        /**
         * Returns the Container of the specified name created in the View.
         * @param id id of container
         */
        getContainerByID(id: string): Container;
        /**
         * Returns the Array of all the cContainers created in the View.
         */
        getContainersArray(): {
            [key: string]: Container;
        };
        /**
         * Returns the Animation of the specified name created in the View.
         * @param {string} id id of animation
         */
        getAnimationById(id: string): AnimationBase;
        /**
         * Returns the array of all the Animations created in the View.
         */
        getAnimationsArray(): {
            [key: string]: AnimationBase;
        };
        /**
         * Returns JSON of view
         */
        getJson(): IContainer;
        /**
         * Returns Spine by id
         * @param {SpineBase} id id of spine
         */
        getSpineById(id: string): SpineBase;
        /**
         * Returns all the Spines available in current view
         */
        getSpinesArray(): {
            [key: string]: SpineBase;
        };
        /**
         * Returns all the available components of view
         */
        getAllcomponents(): Container | any;
        /**
         * Returns any component of the specified name created in the View.
         * @param id id of component
         */
        getComponentById(id: string): Container | any;
        /**
         * Returns Video Container by id
         * @param {Container} id
         */
        getVideoContainerById(id: string): Container;
        /**
         * Returns the Component of the specified name and type created in the View.
         * @param id
         * @param type
         */
        fetchComponentById(id: string, type?: string): any;
        /**
         * To Fade in the current view
         * @param time fade in time in milliseconds
         * @param callback callback to be executed after fade in is completed
         */
        fadeIn(time?: number, callback?: () => void, callbackScope?: any): void;
        /**
         * To Fade out the current view
         * @param time fade out time in milliseconds
         * @param callback callback to be executed after fade out is completed
         */
        fadeOut(time?: number, callback?: () => void, callbackScope?: any): void;
        /**
         * Checks the overlapping of the 2 specified Display Object.
         * @param spriteA type any as there is a conflict in bridge definitions
         * @param spriteB type any as there is a conflict in bridge definitions
         * @returns {boolean}
         */
        checkOverlap(spriteA: any, spriteB: any): boolean;
        /**
         * Clones the specified animation with the name as provided Id.
         * @param sprite
         * @param id
         */
        cloneAnimation(animationToCloneName: string, clonedAnimationName?: string): void;
        /**
         * Resize function of the view, handel's the scaling of the view
         * @param {IEvent} e
         */
        protected resize(e?: IEvent): void;
        destroy(): void;
    }
}
/**
 * Created by Amathur on 3/27/2017.
 */
declare namespace ingenuity.ui {
    class AnimationBase extends Container {
        json: IAnimation;
        protected animPartArray: Array<Sprite>;
        protected currentAnimPart: number;
        protected callbackFunction: (e?: IEvent) => void;
        constructor(json: IAnimation, game?: bridge.Game, parent?: bridge.DisplayObjectContainer);
        /**
         * Resets the animation to poster frame
         * @param frame
         */
        resetToPoster(frame?: string | number): void;
        /**
         * Creates animation where single sprite sheet contains multiple animations.
         * @param x The x coordinate
         * @param y The y coordinate
         * @param imageKey This is the image id or texture id used by the Sprite during rendering.
         * @param frame If this Sprite is using part of a sprite sheet or texture atlas you can specify the exact frame to use by giving a string or numeric index.
         * @param animationsObj
         * @param regX The RegX coordinate
         * @param regY The RegY coordinate
         * @param alwaysAnimate If the sprite should always animate
         * @param show
         */
        protected createSpriteWithMultiAnimations(x: number, y: number, imageKey: string, animationsObj: any, frame?: number, regX?: number, regY?: number, alwaysAnimate?: boolean, show?: boolean): void;
        /**
         * Creates sprite sheet using frames
         * @param x The x coordinate
         * @param y The y coordinate
         * @param imageKey This is the image id or texture id used by the Sprite during rendering.
         * @param regX The RegX coordinate
         * @param regY The RegY coordinate
         * @param alwaysAnimate If the sprite should always animate
         * @param show
         * @param frames
         * @param frame
         */
        protected createSpriteWithFrames(x: number, y: number, imageKey: string, frames: any, frame?: number, regX?: number, regY?: number, alwaysAnimate?: boolean, show?: boolean): void;
        /**
         * Creates animation Sprites, can create Multi animation or sprite with frames
         * @param json
         */
        protected createAnimationSprites(json: any): void;
        /**
         * Play animation
         * @param animName name of animation to play, defaults to "anim"
         * @param callbackFunction function to be executed once the animation completes
         * @param scope scope for callback
         */
        playAnim(animName?: string, callbackFunction?: () => void, scope?: any): AnimationBase;
        /**
        * Stop playback of an animation.
        *
        * @param resetFrame When the animation is stopped should the currentFrame be set to the first frame of the animation (true) or paused on the last frame displayed (false)
        */
        stopAnim(resetFrame?: boolean): AnimationBase;
        /**
        * Gets and sets the paused state of the current animation.
        */
        pause(): AnimationBase;
        /**
        * Gets and resumes the current animation.
        */
        resume(): AnimationBase;
        /**
         * returns is animation playing
         */
        readonly isPlaying: boolean;
        /**
         * Returns if animation is paused
         */
        readonly isPaused: boolean;
        /**
         * Executes callback once animation is complete
         * @param evt
         */
        protected onAnimPartComplete(evt: IEvent): void;
    }
}
declare namespace ingenuity.ui {
    class SpineBase extends bridge.Spine {
        /**
         * for custom events use signals variable. Store your specific signal with its type as the key for the object
         */
        protected signals: IObject;
        json: ISpineData;
        private pause;
        constructor(json: ISpineData);
        /**
         * Plays the animation
         * @param animName animation id
         * @param loop should loop
         * @param trackIndex index value
         */
        playAnim(animName?: string, loop?: boolean, trackIndex?: number): PIXI.spine.core.TrackEntry;
        /**
         * Create Hitarea
         * @param json Shape JSON to create hitArea
         */
        protected createHitArea(json: any): bridge.Rectangle | bridge.Circle;
        /**
         * Set hit area for Spine
         * @param shape shape to be used as hitarea
         */
        setHitArea(shape: bridge.Rectangle | bridge.Circle | bridge.Polygon): void;
        /**
         * A event binder which in background binds an event to a signal
         * @param type Event string type.
         * @param handler Event handler function
         * @param scope scope for the event handler function
         * @param once defines whether the event handler will be triggered once or more times.
         * @param data Data which will be passed at the time of binding
         * @param priority Priority among the handlers for the same event.
         */
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): this;
        /**
         * Removes the event binding with an event
         * @param type Event type. Must be mentioned in the events.EventConstants
         * @param handler - Binding Function. if not defined then it will remove all handlers from this event
         * @param scope - handler bind to an object.
         */
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): this;
        /**
         * Checks whether a handler is bound to specified event
         * @param type event type/name to check
         */
        hasEvent(type: string): boolean;
        /**
         * Fires or triggers an event and runs the handler functions bound or subscribed to the event
         * @param type: string|Event Either pass an event or data. If you are passing Event then data can be passed to its constructor
         * @param data Any which is to be passed along the event. It is available as event.data
         */
        fireEvent(type: string, data?: any): void;
        update(dt: number): void;
        setPause(val: boolean): void;
    }
}
/** This class creates button with different containers for every state and each state can contain
 * images, animations, label, labelBitmaps.
 */
declare namespace ingenuity.ui {
    class AdvancedButton extends Container {
        protected hitarea: any;
        protected btn: ButtonBase;
        protected isOn: boolean;
        enabled: boolean;
        containers: {
            [key: string]: Container;
        };
        animations: {
            [key: string]: AnimationBase;
        };
        hitArea: any;
        protected idleTimer: number;
        constructor(json: IAdvancedButton);
        /**
         * creates a button hitarea and binds events so that states can be managed from image
         * @param json
         */
        protected createHitArea(json: IAdvancedButton): void;
        /**
         *  Creates a state container and adds elements like image, animation, label, labelbitmap to it.
         * @param json
         */
        protected createAdvButton(json: any, game: bridge.Game): void;
        /**
         * creates missing states if all states are not provided
         */
        protected createMissingStates(): void;
        /**
         *
         * @param json creates the view of each state container
         */
        createButtonDisplay(json: any): void;
        /**
         * Creates a Label in the View.
         * ```
         * "label":{
                            x     : 10,
                            y     : 100,
                            w     : 500,
                            h     : 85,
                            type  : "label",
                            text  : "Sample Text",
                            style : {
                                font : "65px Arial",
                                fill : "#ff0044",
                                align: "center"
                            },
                            shadow: {
                                color  : "#fff",
                                blurX  : 1,
                                blurY  : 5,
                                quality: 10
                            }
                         } ```
                 * @param json
                 */
        createLabel(json: ILabel): Label;
        /**
                * Creates an Image in the view.
                * * Following is the example JSON Entry.
                * ```
                * "Image":{
                *	  "x":0,
                *	  "y":0,
                *	  "w":1024,
                *	  "h":768,
                *	  "visible":true,
                *	  "type":"image",
                *	  "image":"ImageName",
                *	  "id":"ImageID",
                *	  "parent":"ParentName"
                *	} ```
                * @param json
                */
        createImage(json: IImage): Bitmap;
        /**
                * Creates the Animation from the sprite sheet in the View.
                * * Following is the example JSON Entry.
                * ```
                * "Animation":{
                *	 "x": 200,
                *     "y": 200,
                *     "visible": true,
                *     "type": "animation",
                *     "id": "animId",
                *     "image": "animation"
                *	}
                * ```
                * @param json
                */
        createAnimation(json: IAnimation): AnimationBase;
        /**
                * Creates basic shapes like "Rectangle", "Circle", "Rounded corner Rectangle", "Polygon" in the View.
                * * Following is the example JSON Entry.
                * ```
                * "shape":{
                         "x"          : 100,
                       "y"          : 175,
                       "w"          : 0,
                       "h"          : 0,
                       "visible"    : true,
                       "alpha"      : 1,
                       "type"       : "shape",
                       "id"         : "circleShape",
                       "strokeSize" : 1,
                       "strokeColor": "0Xffffff",
                       "strokeAlpha": 0,
                       "fillColor"  : "0XFF00000",
                       "fillAlpha"  : 0.8,
                       "shape"      : "circle", // can be "rectangle", "roundornerrectangle", "circle", "custom".
                       "diameter"   : 150    // used in Circle. "radius" : 45 for roundCornerRectangle.
                *	} ```
                * @param json
                * @returns {Graphics}
                */
        createShape(json: IShape): IGraphics;
        /**
         *
         * Creates the Bitmap Label in the View.
         * Following is the example JSON Entry.
         * ```
         "BitmapLabel": {
                    "text": "This is a sample text.",
                    "x": 50,
                    "y": 200,
                    "w": 100,
                    "h": 43,
                    "type": "labelbitmap",
                    "image": "text",
                    "id": "LabelId",
                    "style": {
                        "font": "Arial",
                        "align": "center",
                        "fontSize": 70
                    }
                }
         * ```
         * @param json
         * @returns {any}
         */
        createLabelBitmap(json: ILabelBitmap): LabelBitmap;
        /**
         * Creates spine
         * @param json
         */
        protected createSpine(json: ISpineData): any;
        /**
         * Binds the events with the button.
         * @param type
         * @param handler
         * @param scope
         * @param once
         * @param data
         * @param priority
         * @returns {Function}
         */
        on(type: string, handler: (e?: any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): (but?: ButtonBase, evt?: bridge.Pointer, isOver?: boolean) => void;
        /**
         * Unbinds the events with the button.
         * @param type
         * @param handler
         */
        off(type: string, handler?: (e?: any, data?: IObject) => void): this;
        /**
         * Mouse over handler
         */
        onInputOverHandler(sprite: bridge.Button, pointer: bridge.Pointer, e: IEvent): void;
        /**
        * Internal function that handles input events.
        *
        * @method bridge.Button#onInputOutHandler
        * @public
        * @param {bridge.Button} sprite - The Button that the event occurred on.
        * @param {bridge.Pointer} pointer - The Pointer that activated the Button.
        */
        onInputOutHandler(sprite: bridge.Button, pointer: bridge.Pointer): void;
        /**
        * Internal function that handles input events.
        *
        * @method bridge.Button#onInputDownHandler
        * @public
        * @param {bridge.Button} sprite - The Button that the event occurred on.
        * @param {bridge.Pointer} pointer - The Pointer that activated the Button.
        */
        onInputDownHandler(sprite: bridge.Button, pointer: bridge.Pointer): void;
        /**
        * Internal function that handles input events.
        *
        * @method bridge.Button#onInputUpHandler
        * @public
        * @param {bridge.Button} sprite - The Button that the event occurred on.
        * @param {bridge.Pointer} pointer - The Pointer that activated the Button.
        */
        onInputUpHandler(sprite: bridge.Button, pointer: bridge.Pointer, isOver: Boolean): void;
        /**
         *set button interactivity
         * @param value
         */
        setInteractive(value: boolean): void;
        /**
         * Returns if button is interactive
         */
        getInteractive(): boolean;
        /**
         * @param value enable or disable button
         */
        setEnabled(value: boolean): void;
        /**
         * Enables the button
         */
        enableAndTint(): void;
        /**
         * Disables the button
         */
        disableAndTint(): void;
        /**
         * Manage state of the button
         * @param state Possible options "up","over", "down", "out", "disable"
         */
        changeStateFrame(state: string): void;
        /**
         * Callback on idle animation complete
         */
        protected onCompleteIdleAnim(event?: IEvent): void;
    }
}
/**
 * Created by arathore on 30-04-2018.
 */
declare namespace ingenuity.ui {
    class Video extends bridge.Video {
        constructor(vJson: IContainer);
    }
}
declare namespace ingenuity.loader {
    class Loader extends bridge.Loader {
        /**
         * @param game Current game instance
         * @param baseURL If you want to append a URL before the path of any asset you can set this here.
         * Useful if allowing the asset base url to be configured outside of the game code. The string _must_ end with a "/".
         * @param crossOrigin The crossOrigin value applied to loaded images. Very often this needs to be set to 'anonymous'.
         * @param enableParallel If true (the default) then parallel downloading will be enabled. To disable all parallel downloads this must be set to false prior to any resource being loaded.
         */
        constructor(game: bridge.Game, baseURL?: string, crossOrigin?: boolean, enableParallel?: boolean);
        processPack(pack: any): void;
        removeItem(json: IObject): void;
        /**
         * Loads files from a list/Array.<br>
         * If any entry is a file which contains list of assets then define its type as "manifest" and that file should have an object with file
         * array assigned to "manifest" property.
         * @example [{id:"gameBG",src:"images/BaseGameBackground.jpg",type:"image"}]. <br>
         * @param json
         */
        loadManifest(json: IObject): void;
    }
}
/**
 * Created by Asharma on 13-02-2017.
 */
declare namespace ingenuity.states {
    abstract class State extends bridge.StateBase {
        /**
         * Will help in implementing state based game development
         */
        constructor();
        /**
         * Function executed when a state is in preload state we can preload/ prioritize the assets for the state.
         */
        preload(): void;
        /**
         * Function executed when a state is initialized.
         */
        init(...args: any[]): void;
        /**
         * Function executed when a state is created.
         */
        create(): void;
        /**
         * Function executed when another state is initialized.
         */
        shutdown(): void;
        /**
         * Function executed when a Game's update cycle is executed.
         */
        update(): void;
        /**
         * Function executed when a Game's update cycle is paused.
         */
        paused(): void;
        /**
         * Function executed when a Game's update cycle is resumed.
         */
        resumed(): void;
        /**
         * Function executed when a Game's render cycle is executed.
         */
        render(): void;
        /**
         * Function executed when a Game's resize cycle is executed.
         */
        resize(width: number, height: number): void;
    }
}
declare namespace ingenuity.events {
    /**
     * Event constants for the Event and Event Dispatcher. It can be extended to be used at other modules.<br>
     * @example
     * ```typescript
     * utils.extendObj(events.EventConstants, {<Your Events Here>}, overwrite); ```
     */
    let EventConstants: {
        PLAY_SOUND: string;
        STOP_SOUND: string;
        RESIZE: string;
        METER_TICKUP_STARTED: string;
        METER_TICKUP_FINISHED: string;
        STOP_METER_TICKUP: string;
        INFO_CLOSED: string;
        SLIDER_VALUE_CHANGE: string;
        BUTTON_PRESSED: string;
        BUTTON_RELESED: string;
        SHOW_PAYTABLE: string;
        INSUFFICIENT_FUNDS: string;
        SOUND_PLAY_COMPLETE: string;
        SOUND_PLAY_FAILED: string;
        SOUND_PLAY_LOOP: string;
        ERROR_LOADING_SOUND: string;
        GAME_STAGE_CLICKED: string;
        SHOW_ERROR: string;
        PRIORITIZE_LOADING_STAGE: string;
        BASEGAME_ASSETS_LOADED: string;
        BASEGAME_POSTLOAD_ASSETS_LOADED: string;
        FREEGAME_ASSETS_LOADED: string;
        INFO_ASSETS_LOADED: string;
        BONUS_ASSETS_LOADED: string;
        ALL_ASSETS_LOADED: string;
        UPDATE_LOADING_PROGRESS: string;
        FILE_LOAD_ERROR: string;
        STATE_LOADED: string;
        COMPONENT_CREATED: string;
        LOAD_STATE: string;
        REMOVE_STATE_CACHE: string;
    };
}
/**
 * This class verifies the current user agent against the provided configurations.
 * @author Ankush Sharma
 */
declare namespace ingenuity.deviceEnvironment {
    class Configrator {
        private config;
        private userAgent;
        /**
         * User Agent string
         */
        ua: {
            [key: string]: string | string[] | boolean;
        };
        /**
         * Tells if the device is black list
         */
        blackListDevice: boolean;
        /** Tells if device is slow */
        slowDevice: boolean;
        /** Tells if device is mid resolution */
        midRes: boolean;
        /** Tells if device is low resolution */
        lowRes: boolean;
        constructor(config: IConfig, userAgent: string);
        /**
         * Validates the current user agent against the device config
         * @param value device name
         */
        private checkValue(value);
        /**
         * Verify if the entries in device config are Array
         * if not will be converted to array
         */
        private getSignatures(key);
        /**
         * Parse User agent from config
         */
        private parseUserAgent();
        /**
         * Match if the current device is in black list
         */
        private matchBlackList();
        /**
         * Verify if the current device is slow
         */
        private matchSlowList();
        /**
         * Verify if the current device is Mid resolution device
         */
        private matchMidResList();
        /**
         * Verify if device is is low resolution device list
         */
        private matchLowResList();
    }
}
declare namespace ingenuity.deviceEnvironment {
    const DeviceConfig: IConfig;
}
declare namespace ingenuity {
    interface IBrowser {
        isUC?: boolean;
        isQQ: boolean;
        isChromeIOS?: boolean;
        isBaidu?: boolean;
        isEdge?: boolean;
        isVivoNative?: boolean;
        isChromeAndroid?: boolean;
        isStockAndroid?: boolean;
        isFirefox?: boolean;
        isFirefoxIOS?: boolean;
    }
    interface IConfig extends IObject {
        noContextMenu: boolean;
        userAgent?: IObject;
        blackListDevice?: IObject;
        osVersion?: IObject;
        browserVersion?: IObject;
        canvas?: IObject;
        ldpi?: IObject;
        simplifiedAnimation?: IObject;
        viewportSettings?: IViewportSettings;
        disableScrolling?: IObject;
        disableFullScreen?: IObject;
        disablePointerEvents?: IObject;
    }
    interface IViewportSettings {
        resizeTimeout: number;
        alternateCheckFullscreen: boolean;
        useWindowSize: boolean;
        margin: IMarginSettings[];
        statusBarHeight: IMobileOrientation | number;
    }
    interface IMobileOrientation {
        "portrait": number;
        "landscape": number;
    }
    interface IMarginSettings {
        mobileType: string;
        fullscreen: boolean;
        height: number[];
        offset: IOffset;
        top?: number;
        bottom?: number;
    }
    interface IOffset {
        top: number;
        bottom: number;
    }
    /**
     * Interface for Detect device update function.
     */
    interface IDeviceEnvironmentUpdate {
        availWidth: number;
        availHeight: number;
        width: number;
        height: number;
        gameWidth: number;
        gameHeight: number;
        scale: number;
        portraitScale?: number;
        maxScale: number;
        portraitMaxScale?: number;
        devicePixelRatio: number;
        orientation: string;
        scaleVariant: number;
    }
    /** Interface For Detect Device Class. */
    interface IDeviceEnvironment {
        update(): IDeviceEnvironmentUpdate;
        scale: number;
        isSlowDevice: () => boolean;
        isDeviceUnsupported: () => boolean;
    }
}
declare namespace ingenuity.deviceEnvironment {
    class DeviceDetector implements IDeviceEnvironment {
        private config;
        static readonly DEVICES: {
            [key: string]: string;
        };
        static readonly DEVICE_NAMES: {
            [key: string]: string | string[];
        };
        static readonly BROWSER_NAMES: {
            [key: string]: string;
        };
        static readonly RESOLUTION: {
            [key: string]: string;
        };
        static readonly SCALE_VARIANT: {
            [key: string]: number;
        };
        /** Tells if local storage is available on device */
        readonly isLocalStorageAvailable: boolean;
        /** Tells if game is in an iFrame */
        readonly isIframe: boolean;
        /** Physical width of the screen */
        readonly width: number;
        /** Physical height of the screen */
        readonly height: number;
        /** Tells whether the game is loaded in a touch enabled device */
        readonly isTouch: boolean;
        /** Screen height available for the game */
        availHeight: number;
        /** Screen width available for the game */
        availWidth: number;
        /** PPI or the pixel per inch ratio of the screen */
        devicePixelRatio: number;
        ppi: number;
        /** Screen Aspect Ratio */
        aspectRatio: number;
        isLockTouchMove: boolean;
        /** Tells which browser game is loaded in */
        browser: string;
        /** Version of the browser in which game is loaded */
        browserVersion: number | string;
        /** OS of the device */
        os: string;
        /** OS version of the device */
        osVersion: string;
        /** Tell which device it is : Mobile, Tablet, iPad, iPhone, desktop etc */
        device: string;
        /** Scale required for the device */
        scale: number;
        standalone: boolean;
        /** Current orientation of the device */
        orientation: string;
        /** Provides user agent string */
        protected readonly UA: string;
        /** Provides browser version string */
        protected readonly AV: string;
        /** Instance of device Configrator */
        protected deviceConfig: Configrator;
        /** Max Scale value */
        protected maxSide: number;
        /** Min Scale value */
        protected minSide: number;
        /** Game height */
        protected gameHeight: number;
        /** Game height in portrait */
        protected gameHeightPortrait: number;
        /** Game width in portrait */
        protected gameWidthPortrait: number;
        /** Game current width */
        protected gameWidth: number;
        /** Scale variant i.e. variation in scaling from original calculated scale value */
        protected scaleVariant: number;
        constructor(config: IDeviceConfig);
        /**
         * Sets the scale variant
         * @param value scale variant
         */
        setScaleVariant(value: number): void;
        /**
         * @returns Current scale variant
         */
        getScaleVariant(): number;
        /**
         * @param width game width
         * @param height game height
         */
        setGameDimensions(width: number, height: number): void;
        setGameDimensions(config: {
            width: number;
            height: number;
        } | {
            [key: string]: {
                [key: string]: number;
            };
        }): void;
        /**
         * Returns the resolutions suitable for current device
         */
        getResolution(): string;
        /**
         * Returns the resolutions suitable for current device
         */
        getDeviceResolution(): string;
        /**
         * Calculates device resolution can be overridden as per client needs
         */
        getDpiResolution(): string;
        /** Updates the available height and available width, scale and orientation. Call this function whenever you want these values.*/
        update(): IDeviceEnvironmentUpdate;
        /** Calculates the scale value on the basis of the assets width or height and available width or available height */
        getPortraitScale(): number;
        /**
         * Returns the scale for the device
         */
        getScale(): number;
        /**
         * Returns max scale for the device
         */
        getMaxScale(): number;
        /**
         * Returns max scale for portrait mode
         */
        getPortraitMaxScale(): number;
        /**
         * Returns device current orientation
         * defaults to Landscape for Desktop on Windows and Mac
         */
        getOrientation(): string;
        /**
         * Returns current device name
         */
        getDeviceName(): string;
        /**
         * Returns current device OS
         */
        getDeviceOS(): string;
        /**
         * Returns browser name
         */
        getBrowser(): string;
        /**
         * Returns current device Aspect Ratio
         */
        protected getAspectRatiio(): number;
        protected detectProperty(list: IObject): string;
        /**
         * Detects device OS
         */
        protected detectOS(): string;
        /**
         * Detects device name
         */
        protected detectName(): string;
        /**
         * Detects browser and returns an object containing boolean values for the following <br>
         * isUC: ua.uc, <br>
         * isQQ: ua.qq,<br>
         * isIE: ua.ie10 || ua.ie11,<br>
         * isIE10: ua.ie10,<br>
         * isBaidu: ua.baidu,<br>
         * isEdge: ua.edge,<br>
         * isChromeIOS: ua.chromeios,<br>
         * isSafariIOS: ua.safariios,<br>
         * isChromeAndroid,<br>
         * isStockAndroid,<br>
         * isVivo: ua["all vivo"],<br>
         * isVivoNative: ua["vivo native"],<br>
         * isFirefox: ua.firefox,<br>
         * isFirefoxIOS: ua.firefoxios
         */
        detectBrowser(): IObject;
        /**
         * Return if the device is slow
         */
        isSlowDevice(): boolean;
        /**
         * Return if the device is low res
         */
        isLowResDevice(): boolean;
        /**
         * Return if the device is mid res
         */
        isMidResDevice(): boolean;
        /**
         * Return if the device is unsupported
         */
        isDeviceUnsupported(): boolean;
        protected static preventDefault(e: Event): void;
        readonly isIPad: boolean;
        readonly isDesktop: boolean;
        readonly isIPhone: boolean;
        /**
         * Locks the context menu (i.e. right mouse click)
         */
        static lockContextMenu(value: boolean): void;
    }
}
/**
 * Main game class, entry point for a game
 * @author Asharma on 13-02-2017
 */
declare namespace ingenuity.core {
    import IDeviceEnvironmentUpdate = ingenuity.IDeviceEnvironmentUpdate;
    class MainGame {
        /**
         * Enables parallel loading of assets
         * Changing to false will load assets one by one
         * @default true
         */
        enableParallelLoading: boolean;
        /**
         * Stores the div containing the canvas
         */
        mainDiv: string;
        /**
         * Saves all the game states
         */
        loadStateObj: IGameStates;
        /**
         * Creates and sets the phaser game object. Requires a Div or main tag in the index page where it can inject
         * the canvas.
         * @param mainDiv - Id of the div or main tag where canvas will be injected by the code.
         * @param deviceConfig - set of resolutions handled by the library example <br>
         * {"hd": {"width": 1136, "height": 640}, "sd":{"width":1024,"height":720}}
         * @param loadStateObj - List of state classes which should have load and createGame
         */
        constructor(mainDiv?: string, deviceConfig?: IDeviceConfig, loadStateObj?: IGameStates);
        /**
         * Initializes the detect device environment class. can be accessed using deviceEnv property. Also sets the
         * resolution string.
         * @param deviceConfig - set of resolutions handled by the library example <br>
         * {"hd": {"width": 1136, "height": 640}, "sd":{"width":1024,"height":720}}
         */
        protected setDetectDevice(deviceConfig?: IDeviceConfig): void;
        /**
         * Create and sets the bridge game stage. <br>
         * Add Spine Plugin <br>
         * Also assignes the following - <br>
         * ScaleMode = bridge.ScaleManager.RESIZE;
         * RenderSession.roundPixels = true;
         * AutoResize = true;
         * @param mainDiv - Id of the div or main tag where canvas will be injected by the code
         * @param callback - Function to be called once the Game object is ready.
         * @param callbackContext - Context fo the callback function.
         */
        protected setGameStage(mainDiv?: string | HTMLCanvasElement, callback?: Function, callbackContext?: IObject): bridge.Game;
        /**
         * Sets the phaser game stage with custom canvas, similer to setGameStage except this function requires a custom canvas
         * @param canvas - Canvas element and not its id where game displayed.
         * @param callback - Function to be called once the Game object is ready.
         * @param callbackContext - Context fo the callback function.
         * @deprecated
         */
        protected setGameStageWithCanvas(canvas: HTMLCanvasElement, callback?: Function, callbackContext?: IObject): void;
        /**
         * Registers game states.
         * The game state should have a create function as starting point.
         * For loading assets for that state use preload function in that state.
         * Rest you can create as many functions as desired
         *
         * @param loadState - List of state classes which should have load and createGame
         */
        protected registerStates(loadState?: IGameStates, initialState?: string): void;
        /**
         * Initiated on change in the game size
         * updates the Game size and orientation
         * @param e Custom event object instance
         */
        protected onSizeChange(e?: IEvent): void;
        /**
         * fires resize event for the game client, so that game client can resize views.
         * @param e - resize event object of the windows
         */
        protected resize(e?: IEvent): void;
        /**
         * Starts the create game state and hands over the control to the game client code
         * @param e - Custom event object instance
         */
        protected onAssetsLoaded(e?: IEvent): void;
        /**
         * Executed on change in device orientation
         * Function is empty and can be overrided on behaviour or game side
         * @param devEnv Accepts detect device JSON
         */
        protected orientationChanged(devEnv: IDeviceEnvironmentUpdate): void;
    }
}
/**
 * Created by sgoswami on 9/7/2016.
 */
declare namespace ingenuity.loader {
    class Loading extends states.State {
        /** Instance of class Loader */
        protected loader: Loader;
        protected loadingStagesArray: IMainManifest[];
        protected currentLoadingStage: IMainManifest;
        /** Contains details of stages loaded till now */
        protected static loadedStages: IManifest;
        protected static prioritize: IManifest;
        static isRemovePack: boolean;
        protected initialStageArray: IMainManifest[];
        private pendingFiles;
        protected allStagesLoaded: boolean;
        /**
         * @param enableParallel defines if assets need to be loaded parallel
         */
        init(enableParallel?: boolean): void;
        /**
         * Adds the loader events and loads the Main Manifest.
         */
        protected addLoadEventsAndLoadMainManifest(): void;
        protected loadState(evt: IEvent): void;
        protected getStateFromArray(loadingStage: string, loadArr: IMainManifest[]): IMainManifest;
        protected removeStateCache(evt: IEvent): void;
        /**
         * This method is called when any loading stage is needed on priority.
         * Checks if the stage is currently loading or not.
         * @param evt
         */
        protected onPrioritizeLoadingStage(evt: IEvent): void;
        /**
         * This function is called when a stage is loaded. It removes the state from the array and load the next stage.
         */
        protected onStageLoadComplete(): void;
        /**
         * This function is called when a stage loading is completed. This function dispatches the event respective to
         * the stage loaded. Override this function if more stages are added except the base stages (basegame, info,
         * freegame, bonus).
         * @param loadingStage
         */
        protected checkForLoadingStagesComplete(loadingStage: string): void;
        /**
         * This method suspends the current loading stage and start the prioritized stage.
         * @param stageName
         */
        protected prioritizeStage(stageName: string): void;
        /**
         * This method checks the URL and updates the url with resolution {%res%} and language {%lang%}.
         * The language will be added to json
         * @param json
         */
        protected checkAndReturnJSON(json: IContainer): IObject;
        /**
         * This method is called when the Main Manifest is loaded. It stores all the stages in an array and calls to
         * load the next stage in the array.
         * @param cacheKey
         */
        protected onMainManifestLoaded(cacheKey: string): void;
        /**
         * This method checks if any stage is available to load.
         * If not than it calls the loading complete else loads the next stage from the loadingStagesArray.
         */
        protected checkAndLoadNextStageInQueue(): void;
        protected getNextStage(): IMainManifest;
        /**
         * This method is called when all the stages are loaded.
         * It removes all the loaded events and fire the Load Complete event.
         */
        protected onAllStagesLoadingComplete(): void;
        /**
         * This method returns the key and path of the Main Manifest.
         * @returns {{mainManifest: {key: string, url: string, type: string}}}
         */
        protected getMainManifestListPath(): IMainManifest;
        /**
         * This method is called when any file/pack is loaded.
         * It dispatches the progress and performs the task respective to their key.
         * @param progress - Number between 1 and 100 (inclusive) representing the percentage of the load.
         * @param cacheKey
         * @param success
         * @param totalLoaded
         * @param totalFiles
         */
        protected onFileLoadCompleted(progress: number, cacheKey: string, success?: any, totalLoaded?: number, totalFiles?: number, fileType?: string, file?: any): void;
        /**
         * This method is called when loading of a stage is started.
         */
        protected onLoadStart(): void;
        /**
         * This method is called when there is an error while loading a file.
         * @param fileKey
         * @param file
         */
        protected onFileLoadError(fileKey: string, file: any): void;
        /**
         * Returns if state (passed as param) is loaded
         * @param key state to confirm if it's loaded
         */
        static isStateLoaded(key: string): boolean;
        /**
         * Returns if video (passed as param) is loaded
         * @param key video id to confirm if it's loaded
         */
        static isVideoLoaded(key: string): boolean;
        /**
         * Returns if image (passed as param) is loaded
         * @param key image id to confirm if it's loaded
         */
        static isImageLoaded(key: string): boolean;
        /**
         * Returns if spine (passed as param) is loaded
         * @param key spine id to confirm if it's loaded
         */
        static isSpineLoaded(key: string): boolean;
        /**
         * Returns if JSON (passed as param) is loaded
         * @param key JSON name to confirm if it's loaded
         */
        static isJSONLoaded(key: string): boolean;
        /**
         * Returns the JSON if loaded
         * @param key JSON name
         */
        getJSONById(key: string): any;
        /**
         * Returns the image if loaded
         * @param key image id
         */
        getImageById(key: string): HTMLImageElement;
        /**
         * Returns asset by ID
         * @param key ID of asset
         * @param type type of asset
         */
        getAssetById(key: string, type?: number): any;
    }
}
/**
 * Created by Asharma on 13-02-2017.
 */
declare namespace ingenuity.core.constructors {
    let base: any;
}
declare namespace ingenuity.deviceEnvironment {
    const constants: IObject;
}
declare namespace ingenuity.Easing {
    class Back extends bridge.Easing.Back {
    }
}
declare namespace ingenuity.Easing {
    class Bounce extends bridge.Easing.Bounce {
    }
}
declare namespace ingenuity.Easing {
    class Circular extends bridge.Easing.Circular {
    }
}
declare namespace ingenuity.Easing {
    class Cubic extends bridge.Easing.Cubic {
    }
}
declare namespace ingenuity.Easing {
    let Default: Function;
    let Power0: Function;
    let Power1: Function;
    let Power2: Function;
    let Power3: Function;
    let Power4: Function;
    /**
     * Following are for compatibility with previous versions.
     * Please don't use them.
     * TODO: remove following.
     * @deprecated
     */
    let power2: Function;
    let power3: Function;
    let power4: Function;
}
declare namespace ingenuity.Easing {
    class Elastic extends bridge.Easing.Elastic {
    }
}
declare namespace ingenuity.Easing {
    class Exponential extends bridge.Easing.Exponential {
    }
}
declare namespace ingenuity.Easing {
    class Linear extends bridge.Easing.Linear {
    }
}
declare namespace ingenuity.Easing {
    class Quadratic extends bridge.Easing.Quadratic {
    }
}
declare namespace ingenuity.Easing {
    class Quartic extends bridge.Easing.Quartic {
    }
}
declare namespace ingenuity.Easing {
    class Quintic extends bridge.Easing.Quintic {
    }
}
declare namespace ingenuity.Easing {
    class Sinusoidal extends bridge.Easing.Sinusoidal {
    }
}
declare namespace ingenuity {
    interface IMainManifest extends IObject {
        mainManifest?: IManifest;
    }
    interface IManifest extends IObject {
        name: string;
        loadData: {
            key: string;
            url: string;
            type: string;
        };
    }
}
/**
 * Defines the namespace ingenuity
 */
declare namespace ingenuity {
    /**
     * Sound Manager variable exposed at the ingenuity namespace
     */
    let soundManager: any;
    /**
     * Phaser game instance exposed at the ingenuity namespace
     */
    let currentGame: bridge.Game;
    /**
     * Custom Global dispatcher. There is no need to pass on dispatcher to classes. It can be used from the ingenuity
     * namespace
     */
    let dispatcher: events.EventDispatcher;
    /**
     * Game stage instance
     */
    let stage: bridge.Stage;
    /**
     * Device Environment utility, can be acccessed directly from Ingenuity namespace
     */
    let deviceEnv: deviceEnvironment.DeviceDetector;
    /**
     * Resolution of the game decided by the device environment
     */
    let resolution: string;
    /**
     * Language of the current game instance
     * @default English
     * @type ISO key for language
     */
    let lang: string;
    /**
     * Currency ISO code to be used in game
     * @default Euro
     */
    let currencyISO: string;
    /**
     * Decimal seprator for curreny
     * @default "."
     */
    let defaultDecimalSeparator: string;
    /**
     * Thousand seprator for curreny
     * @default ","
     */
    let defaultThousandSeparator: string;
    /**
     * Base url of the game where it is hosted, incase of CDN it will be url of the cdn
     */
    /**
     * Base url of the game where it is hosted, incase of CDN it will be url of the cdn
     */
    let mainManifestURL: string;
    /**
     * Wheather or not the Content Delivery network is avilable or not
     */
    let cdn: boolean;
    /**
     * The content of main_data.son will be stored in game data
     */
    let gameData: any;
    /**
     * Contains the data loaded assets.
     * For some client if loading is done by wrapper then plateform should have a class with the methods mentioned below.
     * This object will have following three methords - <br>
     * @method getImageById
     * @method getJSONById
     * @method getAssetById
     */
    let assetsData: any;
    /**
     * Contains configuration based data
     */
    let configData: {
        [key: string]: string | number | boolean | any;
    };
    /**
     * @deprecated Not in use
     */
    let soundData: any;
    /**
     * Generic server model
     */
    let parserModel: any;
    /**
     * Generic base game model
     */
    let baseGameModel: any;
    /**
     * Generic Free game model
     */
    let freeGameModel: any;
    /**
     * If this option is true then the game will not pause on page visibilty change.
     * @default true
     */
    let disableVisibilityChange: boolean;
    /**
     * Rounds pixels while drawing. Faster on slower devices.
     */
    let roundPixels: boolean;
    /**
     * Enables or disables the Phaser WebGL renderer's  multiTexture support
     * @default true
     */
    let multiTexture: boolean;
    let enableDebug: boolean;
    let antialias: boolean;
    /**
     * If this flag is true then it will switch to canvas if webGL performance is not good.
     * This only works in case of bridge.AUTO
     * @default true
     */
    let failIfMajorPerformanceCaveat: boolean;
    /**
     * Default bridge Rendrer, possible options - <br>
     * * bridge.AUTO: will auto-detect
     * * bridge.WEBGL: will force WebGL
     * * bridge.WEBGL_MULTI: will force mutli texture support in webGL
     * * bridge.CANVAS: will force Canvas
     * * bridge.HEADLESS: no rendering at all
     * @default bridge.AUTO
     */
    let defaultRenderer: number;
    /**
     * Defaults for screen resolutions
     */
    let resolutionConfig: IDeviceConfig;
}
/**
 * Created by Amathur on 3/3/2017.
 */
declare namespace ingenuity.states {
    class BaseGameState extends State {
        /**
         * Function executed when a state is initialized.
         */
        init(...args: any[]): void;
    }
}
declare namespace ingenuity.ui {
    class Animation extends bridge.Animation {
        constructor(game: bridge.Game, parent: bridge.Sprite, name: string, frameData: bridge.FrameData, frames: number[], frameRate?: number, loop?: boolean);
    }
}
/**
 * Created by Asharma on 19-05-2017.
 */
/**
 * Extends bridge class so that the lib uses our point class
 */
declare namespace ingenuity.ui {
    class Point extends bridge.Point {
        constructor(x?: number, y?: number);
    }
}
declare namespace ingenuity {
    interface ISpineData {
        x: number;
        y: number;
        id: string;
        image?: string;
        /** @deprecated */
        images?: string[];
        premultipliedAlpha?: boolean;
        anchorX?: number;
        anchorY?: number;
        regX?: number;
        regY?: number;
        scale?: number;
        type: string;
        parent?: string;
        rotation?: number;
        visible?: boolean;
        hitArea?: {
            x: number;
            y: number;
            type: string;
            w?: number;
            h?: number;
            d?: number;
        };
    }
}
