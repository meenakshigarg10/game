/** 
	Slot Core v2.0.3 
	©Ingenuity Gaming Pvt. Ltd.
	Published: Tue Sep 24 2019 17:09:37 GMT+0530 (India Standard Time) 
**/
/* tslint:disable */
/// <reference path="../platform/platform-core.d.ts" />
declare namespace ingenuity.slot.BaseGame {
    class BaseController {
        /** Instance of base game view */
        protected view: BaseGame.View;
        /** Instance of base game Model */
        protected model: BaseGame.Model;
        /** View JSON */
        protected json: IObject;
        /** Instance of assets manager */
        protected assets: any;
        /** Instance of Slot game logic */
        protected slotLogic: Logic.SlotGameLogic;
        /** Instance of Button Controller, holds all button functionality */
        protected buttonController: ButtonController;
        /** Instance of Meter Controller, holds all meter updating activity */
        protected meterController: MetersController;
        /** Instance of Player Message Controller */
        protected playerMsgController: any;
        /** Instance of Reel Panel Controller */
        protected reelPanelController: ReelPanelController;
        /** Win presentation controller instance, holds all win presentation's activity */
        protected winPresentationController: WinPresentationController;
        constructor(view: BaseGame.View, model: Model, json: IObject, assetManager: any);
        /**
         * Subscribes all the events required for Base game
         */
        protected subscribeEvents(): void;
        /**
         * Fire Events When Returning from free spin. Unsubscribe Free Game related Events and Subscribe Base Game related Events.
         */
        protected onFreeGamereturning(evt: IEvent): void;
        /**
         * Hide Base Game View.
         */
        protected onHideBaseGame(evt: IEvent): void;
        /**
         * Show Base Game View.
         */
        protected onShowBaseGame(evt: IEvent): void;
        /**
         * Initialize Slot Logic Class.
         */
        protected onInitializeSlotLogic(evt: IEvent): void;
        /**
         * Initialize instances of all the controllers for the game
         */
        protected onInitializeAllControllers(evt: IEvent): void;
        /**
         * Initialize button controller
         */
        protected initializeButtonController(): void;
        /**
         * Initialize meter controller
         */
        protected initializeMeterController(): void;
        /**
         * Initialize player msg controller
         */
        protected initializePlayerMsgController(): void;
        /**
         * Initialize reel panel controller
         */
        protected initializeReelPanelController(): void;
        /**
         * Initialize win presentation controller
         */
        protected initializeWinPresentationController(): void;
        /**
         * On Five of a kind tween completion
         * Dispatches `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION`
         */
        protected onFokTweenComplete(): void;
    }
}
/**
 * @author Sjoshi
 * on 2/27/2017.
 */
declare namespace ingenuity.slot.slotConstants {
    /** @event */
    let SlotEventConstants: {
        SPIN_CLICKED: string;
        SKIP_CLICKED: string;
        SPIN_CLICKED_IN_FREE_GAME: string;
        UPDATE_AUTOPLAY_BUTTONS: string;
        UPDATE_AUTOPLAY_METERS: string;
        CLEAR_SPIN_TIMER: string;
        REMOVE_ALL_LISTNERS_FROM_STAGE: string;
        DISABLED_ALL_BUTTONS: string;
        ENABLED_ALL_BUTTONS: string;
        ENABLE_BUTTON: string;
        DISABLE_BUTTON: string;
        SUSPEND_WINPRESENTATION: string;
        DO_NEXT_SPIN: string;
        CLEAR_DATA: string;
        SUBSCRIBE_BASEGAME_REELPANEL_EVENTS: string;
        UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS: string;
        SUBSCRIBE_FREEGAME_REELPANEL_EVENTS: string;
        UNSUBSCRIBE_FREEGAME_REELPANEL_EVENTS: string;
        SUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS: string;
        UNSUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS: string;
        SUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS: string;
        UNSUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS: string;
        VALIDATE_BET: string;
        VALIDATE_BET_IN_FREEGAME: string;
        RESET_METERS: string;
        UPDATE_BET_METER: string;
        UPDATE_PAID_METER: string;
        UPDATE_TOTAL_WIN_METER: string;
        UPDATE_FREEGAME_LEFT_METER: string;
        ON_SET_FREEGAME_LEFT: string;
        UPDATE_TOTAL_BET_METER: string;
        UPDATE_BALANCE_METER_AFTER: string;
        UPDATE_BALANCE_METER_AFTER_SPIN_CLICK: string;
        STOP_METER_TICKUP: string;
        UPDATE_BALANCE_METER_BEFORE: string;
        UPDATE_BALANCE_METER: string;
        UPDATE_STAKE_METER: string;
        SUBSCRIBE_EVENTS_ON_REEL_START: string;
        SUBSCRIBE_EVENTS_ON_REEL_START_BG: string;
        SUBSCRIBE_EVENTS_ON_REEL_START_FG: string;
        STOP_REEL_NOW: string;
        CHECK_FOR_ANTICIPATION_ON_REELS: string;
        UPDATE_SYMBOLS_ON_GRID: string;
        NULL_SPIN_BTN: string;
        UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN: string;
        ENABLE_STOP_BTN: string;
        HIDE_CONTAINERS: string;
        NOW_SPIN_REEL: string;
        SHOW_CONTAINERS: string;
        ENABLE_BUTTON_INTERACTION: string;
        DISABLED_BUTTON_INTERACTION: string;
        SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
        SHOW_SKIP_BTN_DISABLED_HIDE_STOP_BTN: string;
        CHECK_FOR_WIN_AFTER_REEL_STOP: string;
        CHECK_FOR_AUTOPLAY_CONDITION: string;
        DISABLED_AUTOPLAY_BTN: string;
        AUTOPLAY_RESET: string;
        AUTOPLAY_RESET_ENABLE_BUTTONS: string;
        AUTOPLAY_COUNT: string;
        ENABLE_AUTOPLAY_STOP_BTN: string;
        RESET_PALYER_MSG_LABELS: string;
        SHOW_NEXT_WIN_PRESENTATION: string;
        SHOW_5OAK: string;
        HIDE_5OAK: string;
        SET_WINLINE_AND_WAYS_DATA: string;
        SHOW_SPAGHTTI: string;
        SHOW_ALL_WIN_FRAMES: string;
        START_WIN_TICK_UP: string;
        STOP_WIN_TICK_UP: string;
        ON_RETURNING_FG_UPDATE_METER: string;
        FORCE_STOP: string;
        START_SCATTER_PRESENTATION: string;
        START_BIG_WIN_PRESENTATION: string;
        START_FIRST_TOGGLE_CYCLE: string;
        START_SECOND_TOGGLE_CYCLE: string;
        START_FIRST_TOGGLE_CYCLE_WAYS: string;
        START_SECOND_TOGGLE_CYCLE_WAYS: string;
        UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER: string;
        STOP_ALL_WIN_ANIMATION_ON_REEL: string;
        SCBSCRIBE_BUTTON_CONTROLLERS_BG: string;
        UNSCBSCRIBE_BUTTON_CONTROLLERS_BG: string;
        SCBSCRIBE_BUTTON_CONTROLLERS_FG: string;
        UNSCBSCRIBE_BUTTON_CONTROLLERS_FG: string;
        SCBSCRIBE_METER_CONTROLLERS_BG: string;
        UNSCBSCRIBE_METER_CONTROLLERS_BG: string;
        SCBSCRIBE_METER_CONTROLLERS_FG: string;
        UNSCBSCRIBE_METER_CONTROLLERS_FG: string;
        ALL_REEL_SPINING: string;
        INITIALIZE_ALL_CONTROLLERS_BG: string;
        INITIALIZE_ALL_CONTROLLERS_FG: string;
        INITIALIZE_SLOT_LOGIC: string;
        WRAPPER_READY: string;
        INITIALIZE_BASE_CLASSES: string;
        INITIALIZE_BASE_CLASSES_COMPLETE: string;
        GAME_RESIZE: string;
        INTRO_HIDE_COMPLETE: string;
        OUTRO_HIDE_COMPLETE: string;
        INTRO_SHOW: string;
        INTRO_HIDE: string;
        OUTRO_SHOW: string;
        OUTRO_HIDE: string;
        INITIALIZE_BG_MODEL: string;
        INITIALIZE_FG_MODEL: string;
        SETUP_FG: string;
        ON_FREEGAME_RETURNING: string;
        SUBSCRIBE_WINPRESENTATION_PANEL_BG: string;
        UNSUBSCRIBE_WINPRESENTATION_PANEL_BG: string;
        SUBSCRIBE_WINPRESENTATION_PANEL_FG: string;
        UNSUBSCRIBE_WINPRESENTATION_PANEL_FG: string;
        HIDE_BASEGAME_VIEW: string;
        SHOW_BASEGAME_VIEW: string;
        HIDE_FREEGAME_VIEW: string;
        SHOW_FREEGAME_VIEW: string;
        SHOW_WIN_PAYLINE: string;
        SHOW_SCATTER_FRAMES: string;
        HIDE_WIN_PAYLINE: string;
        SHOW_ALL_WIN_PAYLINE: string;
        HIDE_ALL_WIN_PAYLINE: string;
        HIDE_ALL_PAYLINE: string;
        HIDE_ALL_SPAGETTI: string;
        FLASH_SPAGETTI: string;
        SHOW_SPAGETTI: string;
        SHOW_ALL_FRAMES: string;
        HIDE_ALL_FRAMES: string;
        SHOW_PAYLINE: string;
        HIDE_PAYLINE: string;
        HIDE_PAYLINE_WINBOX: string;
        HIDE_ALL_PAYLINE_WINBOX: string;
        PLAY_LANDING_ANIMATION_SOUND: string;
        CREATE_WINBOX: string;
        CREATE_PAYLINE_SPAGGITTE: string;
        SUMUP_BIGWIN: string;
        CLEAR_STICKY_WILD_DATA: string;
        PLAY_STICKY_WILD_SYMBOL_ANIM: string;
        START_RETRIGGER_IN_FREEGAME: string;
        SHOW_FREEGAME_RETRIGGER_POPUP: string;
        CLEAR_RANDOM_WILD_DATA: string;
        START_RANDOM_WILD: string;
        RANDOM_WILD_APPEARED: string;
        UNSUBSCRIBE_RANDOM_WILD_EVENTS: string;
        STOP_WILD_ON_EXPWILD: string;
        STOP_SCATTER_ON_EXPWILD: string;
        INIT_EXPANDING_WILD: string;
        ON_ALL_REELS_STOPPED: string;
        CLEAR_EXP_WILD: string;
        SPIN_EXP_WILD_WITH_REEL: string;
        HIDE_EXP_WILD: string;
        HIDE_STICKY_CONTAINER: string;
        PLAY_STICKY_WILD_LANDING_ANIM: string;
        UNSUBSCRIBE_STICKY_EVENTS: string;
        PLAY_STICKY_SYMBOLS_ANIMATIONS: string;
        ADD_ANIM_OVERLAY_LAYER: string;
        ADD_ALL_OVERLAY_SYMBOLS_TO_ANIM_OVERLAY_LAYER: string;
        ADD_SYMBOL_TO_ANIM_OVERLAY_LAYER: string;
        CLEAR_ANIM_LAYER: string;
        PLACE_OVER_PAYLINES: string;
        SHOW_STICKY_VIEW: string;
        STICKY_ANIM_STARTED: string;
        REMOVE_STICKY_ICONS: string;
        FG_DISABLED_ALL_BUTTONS: string;
        FG_ENABLED_ALL_BUTTONS: string;
        FG_ENABLE_BUTTON: string;
        FG_DISABLE_BUTTON: string;
        FG_SUSPEND_WINPRESENTATION: string;
        FG_CLEAR_DATA: string;
        FG_RESET_METERS: string;
        FG_UPDATE_PAID_METER: string;
        FG_UPDATE_TOTAL_WIN_METER: string;
        FG_UPDATE_BALANCE_METER_AFTER: string;
        FG_UPDATE_BALANCE_METER_AFTER_SPIN_CLICK: string;
        FG_UPDATE_BALANCE_METER: string;
        FG_STOP_REEL_NOW: string;
        FG_CHECK_FOR_ANTICIPATION_ON_REELS: string;
        FG_UPDATE_SYMBOLS_ON_GRID: string;
        FG_NULL_SPIN_BTN: string;
        FG_UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN: string;
        FG_ENABLE_STOP_BTN: string;
        FG_HIDE_CONTAINERS: string;
        FG_NOW_SPIN_REEL: string;
        FG_SHOW_CONTAINERS: string;
        FG_ENABLE_BUTTON_INTERACTION: string;
        FG_DISABLED_BUTTON_INTERACTION: string;
        FG_SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
        FG_SHOW_SKIP_BTN_DISABLED_HIDE_STOP_BTN: string;
        FG_CHECK_FOR_WIN_AFTER_REEL_STOP: string;
        FG_SHOW_NEXT_WIN_PRESENTATION: string;
        FG_SHOW_5OAK: string;
        FG_HIDE_5OAK: string;
        FG_SET_WINLINE_AND_WAYS_DATA: string;
        FG_SHOW_SPAGHTTI: string;
        FG_SHOW_ALL_WIN_FRAMES: string;
        FG_START_WIN_TICK_UP: string;
        FG_FORCE_STOP: string;
        FG_START_SCATTER_PRESENTATION: string;
        FG_START_BIG_WIN_PRESENTATION: string;
        FG_START_FIRST_TOGGLE_CYCLE: string;
        FG_START_SECOND_TOGGLE_CYCLE: string;
        FG_START_FIRST_TOGGLE_CYCLE_WAYS: string;
        FG_START_SECOND_TOGGLE_CYCLE_WAYS: string;
        FG_UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER: string;
        FG_STOP_ALL_WIN_ANIMATION_ON_REEL: string;
        FG_ALL_REEL_SPINING: string;
        FG_SHOW_WIN_PAYLINE: string;
        FG_SHOW_SCATTER_FRAMES: string;
        FG_SHOW_ALL_WIN_PAYLINE: string;
        FG_HIDE_ALL_WIN_PAYLINE: string;
        FG_HIDE_ALL_PAYLINE: string;
        FG_HIDE_ALL_SPAGETTI: string;
        FG_FLASH_SPAGETTI: string;
        FG_SHOW_SPAGETTI: string;
        FG_SHOW_ALL_FRAMES: string;
        FG_HIDE_ALL_FRAMES: string;
        FG_SHOW_PAYLINE: string;
        FG_HIDE_PAYLINE: string;
        FG_HIDE_PAYLINE_WINBOX: string;
        FG_HIDE_ALL_PAYLINE_WINBOX: string;
        FG_CREATE_WINBOX: string;
        FG_CREATE_PAYLINE_SPAGGITTE: string;
        INITIATE_REELPANEL: string;
        SPIN: string;
        STOP_SPIN: string;
        SPIN_COMPLETE: string;
        REEL_STOPPED: string;
        REEL_STOPPING: string;
        LINE_ANIMATION_STARTED: string;
        START_SCATTER_WIN_ANIM: string;
        SCATTER_ANIMATION_STARTED: string;
        SCATTER_ANIMATION_ENDED: string;
        LINE_ANIMATION_ENDED: string;
        SYMBOL_ANIM_STARTED: string;
        SYMBOL_ANIM_ENDED: string;
        START_All_WIN_ANIM: string;
        START_WIN_ANIM: string;
        START_WAYS_ANIM: string;
        WIN_CYCLE_COMPLETED: string;
        WAY_ANIMATION_STARTED: string;
        WAY_ANIMATION_ENDED: string;
        START_EXPANDING_WILD: string;
        PLAY_EXPANDING_WILD: string;
        CLEAR_EXPANDING_WILD: string;
        SHOW_STICKY_WILD: string;
        PLAY_STICKY_WILD_ANIMATION: string;
        CLEAR_STICKY_WILD: string;
        RESET_SHIFTING_WILD: string;
        CHANGE_SYMBOL: string;
        PLAY_CHANGE_SYMBOL_SOUND: string;
        SHOW_SHIFTING_WILD: string;
        MOVE_SHIFTING_WILD: string;
        CLEAR_SHIFTING_WILD: string;
        TWEEN_SHIFTING_WILD: string;
        WILD_SHIFTED: string;
        INTRO_OUTRO_HIDDEN: string;
        STOP_ALL_WIN_ANIMATIONS: string;
        SPIN_STARTED: string;
        SHOW_ANTICIPATION: string;
        SHOW_LANDINGANIMATION: string;
        SHOW_BIG_WIN: string;
        BIG_WIN_HIDDEN: string;
        REEL_MASK_ON: string;
        REEL_MASK_OFF: string;
        FG_INITIATE_REELPANEL: string;
        FG_SPIN: string;
        FG_STOP_SPIN: string;
        FG_SPIN_COMPLETE: string;
        FG_REEL_STOPPED: string;
        FG_REEL_STOPPING: string;
        FG_LINE_ANIMATION_STARTED: string;
        FG_START_SCATTER_WIN_ANIM: string;
        FG_SCATTER_ANIMATION_STARTED: string;
        FG_SCATTER_ANIMATION_ENDED: string;
        FG_LINE_ANIMATION_ENDED: string;
        FG_START_All_WIN_ANIM: string;
        FG_START_WIN_ANIM: string;
        FG_START_All_WAYS_ANIM: string;
        FG_START_WAYS_ANIM: string;
        FG_WIN_CYCLE_COMPLETED: string;
        FG_WAY_ANIMATION_STARTED: string;
        FG_WAY_ANIMATION_ENDED: string;
        FG_START_EXPANDING_WILD: string;
        FG_STOP_ALL_WIN_ANIMATIONS: string;
        FG_SHOW_ANTICIPATION: string;
        FG_SHOW_LANDINGANIMATION: string;
        FORCE_HIDE_REEL_SYMBOLS: string;
        ON_FIVE_OF_A_KIND_TWEEN_COMPLETE: string;
        WIN_ON_REELS: string;
        GAME_MSG_SHOW: string;
        GAME_MSG_HIDE: string;
        LOGIC_ONSTAKE_CHANGE: string;
        LOGIC_ONINFO_PRESSED: string;
        LOGIC_SHOW_GAME_MESSAGE: string;
        LOGIC_HIDE_GAME_MESSAGE: string;
        LOGIC_ON_UNSUBSCRIBE_REEL_PANEL_EVENTS: string;
        UPDATE_REEL_CONFIG: string;
        DOMMOUSESCROLL: string;
        MOUSEWHEEL: string;
        KEYDOWN: string;
        DISABLE_SPACEBAR_EVENTS: string;
        ENABLE_SPACEBAR_EVENTS: string;
        KEY_DOWN_FG: string;
    };
}
/**
 * Created by Sjoshi on 2/28/2017.
 */
declare namespace ingenuity.slot.slotConstants {
    class SlotConstants {
        static MainData: string;
        static SpinBtnId: string;
        static SkipBtnId: string;
        static reSpinBtnId: string;
        static SpinStopBtnId: string;
        static BetMinusBtnId: string;
        static BetPlusBtnId: string;
        static AutoPlayBtnId: string;
        static AutoPlayOffBtnId: string;
        static StopAutoPlayBtnId: string;
        static InfoBtnId: string;
        static SettingBtnId: string;
        static ButtonsContainerId: string;
        static AutoPlayOnBtnContainer: string;
        static AutoPlayOffBtnContainer: string;
        static MenuContainerId: string;
        static WinBoxContainerId: string;
        static PayLineContainerId: string;
        static SpaggitteContainerId: string;
        static SettingCloseBtnId: string;
        static FreegameLeftMtrId: string;
        static BetMeterId: string;
        static TotalBetMeterId: string;
        static StakeMeterId: string;
        static BalanceMeterId: string;
        static WinMeterId: string;
        static AutoPlayMeterId: string;
        static BalanceMeterIdFG: string;
        static WinMeterIdFG: string;
        static totalWinMeterIdFG: string;
        static IntroContinueBtn: string;
        static OutroContinueBtn: string;
        static IntroOutroContainer: string;
        static IntroContainer: string;
        static OutroContainer: string;
        static LogicScopeBG: string;
        static LogicScopeFG: string;
        static TimerForDisplayOutro: string;
        static TimerForNextFreeSpin: string;
        static TimerHidePayline: string;
        static TimerForFiveOfKind: string;
        static TimerScatterAnimationEnded: string;
        static TimerAnimateNextWinLine: string;
        static TimerAllAnimateWin: string;
        static TimerDelayInWinBox: string;
        static TimerSendBetWithDelay: string;
        static StopSpinTimer: string;
        static StartSpinTimer: string;
        static StopTimerStopNow: string;
        static AnticipationDelayTimer: string;
        static StopReelId: string;
        static SpaghettiDisplayTimer: string;
        static ButtonDisplayDelayTimer: string;
        static DelayFinalAmount: string;
        static BaseGameReelSetIndex: number;
        static FreeGameReelSetIndex: number;
        static baseGameState: string;
        static freeGameState: string;
        static stopBtnContainer: string;
        static settingAutoPlayContainer: string;
        static settingContainer: string;
        static autoPlayContainer: string;
        static FiveOKContainer: string;
        static KeyCodeSpaceBar: number;
        static KeyCodeEqualPlus: number;
        static KeyCodePlus: number;
        static KeyCodeSubtract: number;
        static KeyCodeNumbSubtract: number;
        static KeyCodeNumbEqualPlus: number;
        static KeyCodeSubtractUnderscore: number;
        static ResetAutoplayCount: number;
        static BetIncrement: number;
        static BetDecrement: number;
        static WinLineAnimTimeOutFirstToggle: number;
        static WinLineAnimTimeOutSecondToggle: number;
        static BigWinMultiplier: number;
        static MegaWinMultiplier: number;
        static SuperWinMultiplier: number;
        static BigWinMultiplierFG: number;
        static MegaWinMultiplierFG: number;
        static SuperWinMultiplierFG: number;
        static soundWinMeterTickup: string;
        static sound5OFKind: string;
        static soundFreeGameBGMusic: string;
        static soundFreeGameWinMeterTickup: string;
        static soundFreeGameWinMeterTickupComplete: string;
        static AnimOverlayReel: string;
        static AnimOverlayLayer: string;
        static AnticipationConatiner: string;
        static AnticipationIdPrefix: string;
        static LandingAnimName: string;
        static WinBoxPrefix: string;
        static WinBoxContainerPrefix: string;
        static WinBoxScatterPrefix: string;
        static WinBoxScatterContainerPrefix: string;
        static LinePrefix: string;
        static SpinePrefix: string;
        static SpaghettiPrefix: string;
        static StaticSymbolPrefix: string;
        static MultiSymbolPrefix: string;
        static AnimationPrefix: string;
        static LayeredPrefix: string;
        static NextAnimation: string;
        static LayerAnimation: string;
        static LayerSpine: string;
        static LayerStatic: string;
        static Frames: string;
        static MIN_SPIN_DELAY: string;
        static ANIM_DELAY: string;
        static SPIN_DONE_DELAY: string;
        static DROP_DELAY: string;
        static FORCE_STOP_DELAY: string;
        static BURST_ANIM_COMPLETE_DELAY: string;
    }
}
declare namespace ingenuity.slot.BaseGame {
    /**
     * Purpose of this class to manage base game view
     */
    class View extends ui.BaseView {
        /** Anticipation animation container */
        protected anticipationContainer: ui.Container;
        /** Five of a kind container */
        protected fiveOfKindContainer: ui.Container;
        /** Big Win presentation container */
        protected bigWinPresent: ui.Container;
        /** Instance of reel panel */
        protected reelView: reelPanel.ReelPanel;
        /** Instance of win presentation panel */
        protected winView: reelPanel.WinPresentationPanel;
        /** Instance of win presentation overlay panel */
        protected winOverlayView: reelPanel.WinPresentationOverlayPanel;
        /** Instance of paylines */
        protected paylineView: reelPanel.Paylines;
        protected fiveOfKindTween: ITween;
        /**
         * Constructor for base game view
         * @param viewJson Base game view JSON
         */
        constructor(viewJson: IContainer);
        /**
         * This function adds reel view in view
         * @param reelView Instance of reel view
         * @param pos child index of reel, if pos available then the container will be added `addChildAt` on the index provided else will be added by default `addChild`
         * @param parentId parent container id, if available reelview will be created in the container else will be added to current base view.
         */
        setReelView(reelView: reelPanel.ReelPanel, pos?: number, parentId?: string): void;
        /**
         * @returns Returns the reelview
         */
        getReelView(): reelPanel.ReelPanel;
        /**
         * This function adds Payline view in view
         * @param value Instance of Payline view
         * @param pos Index at which payline view need to be added
         * @param parentId Parent container id, if not available will be added to base view
         */
        setPaylineView(value: reelPanel.Paylines, pos?: number, parentId?: string): void;
        /**
         * @returns Returns instance of Payline view.
         */
        getPaylineView(): reelPanel.Paylines;
        /**
         * This function adds Win presentation in view
         * @param value Instance of WinPresentationPanel view
         * @param pos Index at which container need to be added
         * @param parentId Parent container id, if not available will be added to base view
         */
        setWinReelView(value: reelPanel.WinPresentationPanel, pos?: number, parentId?: string): void;
        /**
         * @returns Returns Win presentation panel
         */
        getWinReelView(): reelPanel.WinPresentationPanel;
        /**
         * This function adds Win overlay in view
         * @param value Instance of WinPresentationOverlayPanel view
         * @param pos Index at which container need to be added
         * @param parentId Parent container id, if not available will be added to base view
         */
        setWinReelOverlayView(value: reelPanel.WinPresentationOverlayPanel, pos?: number, parentId?: string): void;
        /**
         * @returns Win presentation overlay panel
         */
        getWinOverlayReelView(): reelPanel.WinPresentationOverlayPanel;
        /**
         * Removes anticipation from base game view
         */
        clearAnticipation(): void;
        /**
         * Shows 5OAK animation via tween on base game view.<br>
         * on completion of tween, hides five if a kind and fires event `slotConstants.SlotEventConstants.ON_FIVE_OF_A_KIND_TWEEN_COMPLETE` to initiate next pressentation cycle
         * @param fiveOfkindTimer duration in milliseconds for which fok should be visible
         */
        show5OfKind(fiveOfkindTimer: number): void;
        /**
         * Hides 5OAK from base game view
         */
        hide5OfKind(): void;
        /**
         * Hides the base view
         */
        hide(): void;
        /**
         * Shows the base view by setting `visible` to `true`
         */
        show(): void;
        /**
         * Plays landing animation of a symbol. <br>
         * Name of animation to be played: `slotConstants.SlotConstants.LandingAnimName`
         */
        landingAnimation(data: any, callback?: () => void, callbackScope?: any): void;
        /**
         * Plays anticipation animation of a symbol. <br>
         * Creates a new container named `slotConstants.SlotConstants.AnticipationConatiner` if container doesn't already exists <br>
         * Name of animation to be played: `anticipation_ + reelId`
         */
        showAnticipation(reel: number, callback?: () => void, callbackScope?: any): void;
    }
}
/** Namespace contains only the interfaces for TypeScript. Root of the namespace */
declare namespace ingenuity {
    /**
     * Big Win FountainOptions
     */
    interface IBigWinFountainOptions {
        /** Width of fountain */
        w: number;
        /** Height of fountain */
        h: number;
        /** Should the fountain origin point be screen bottom */
        fromBottomOut: boolean;
        /** If all the big win particles should come at the same time */
        allAtOnce: boolean;
        offsetHeight: number;
        offsetX: number;
        /** Speed of particles */
        speed: number;
        /** Number of particles */
        numParticles: number;
        deltaX: number;
        deltaY: number;
    }
    /**
     * Overlapping symbol data
     */
    interface OverlapSymbolData extends IObject {
        symbolId: {
            scaleX: number;
            scaleY: number;
            regX: number;
            regY: number;
            rotate: number;
            skewX: number;
            skewY: number;
        };
    }
    /**
     * Defines the data type of the win line object
     */
    interface IWinLineObject extends IObject {
        positions: number[][];
        no: number;
        winSymLen: number;
        win: number;
        id: number;
    }
}
/**
 * Created by Asaxena on 3/22/2017.
 */
declare namespace ingenuity.slot.BaseGame {
    /**
     * Generic Base Game Model, stores all the data required in game
     */
    class Model {
        /** Stores time for win box fade out */
        protected fadeOutTimeWinBox: number;
        /** Stores reel sets */
        protected reelsets: number[][][] | string[][][];
        /** Animation sequence array */
        protected animationSequence: string[];
        /** Maintains the current sequence index of Win presentation */
        protected animationSequenceCounter: number;
        /** Server model Instance */
        protected serverModel: platform.baseslot.Model;
        /** Game config JSON */
        protected gameConfig: IObject;
        /** Defines if turbo mode is active */
        protected isTurboMode: boolean;
        /** Total auto spins available */
        protected totalAutoSpins: number;
        /** Current auto spin index */
        protected currentAutoSpinIndex: number;
        /** Stores if reel stop is required */
        protected stopReel: boolean;
        /** Stores how long spaghetti should stay in game */
        protected delayForSpaghttiDisplay: number;
        /** Display duration of five if a kind */
        protected fiveOAKDispalyTimer: number;
        /** Tick-up duration for meters */
        protected tickUpDuration: number;
        protected allReelSpinning: boolean;
        /** Defines if reel are spinning */
        protected reelSpinning: boolean;
        /** Defines if server response is received */
        protected serverResponseReceived: boolean;
        /** Defines if Re-Spin is available */
        protected reSpinIdentifier: boolean;
        /** No of re-spins available */
        protected reSpinCounter: number;
        /**
         * @param serverModel Instance of server model
         */
        constructor(serverModel: platform.baseslot.Model);
        /**
         * Sets if all reels started spinning
         * @param value
         */
        setAllReelSpinning(value: boolean): void;
        /**
         * @returns If all reels are spinning
         */
        getAllReelSpinning(): boolean;
        /**
         * Sets if reels are spinning
         * @param value if reels are spinning
         */
        setReelSpinning(value: boolean): void;
        /**
         * @returns If reels are spinning
         */
        isReelSpinning(): boolean;
        /**
         * Sets if server response is received
         * @param value is server response received
         */
        setServerResponseReceived(value: boolean): void;
        /**
         * @returns If server response is received
         */
        getServerResponseReceived(): boolean;
        /**
         * This function sets fade out timings for Win Boxes.
         * Win Boxes will take this time (`this.fadeOutTimeWinBox`) to fadeout
         * @param value Win box fadeout time in milliseconds
         */
        setFadeOutTimeWinBox(value: number): void;
        /**
         * @returns Timing to fadeout win boxes in games
         */
        getFadeOutTimeWinBox(): number;
        /**
         * Sets Win Presentation Sequences that we want to play at the time of win presentation in game.
         * @example `["5OAK", "Spaghtti", "bigWin","firstToggle","secondToggle","triggeringAnimation","bonus","freeSpin"]`
         * Win presentation will be displayed as per the array index i.e. from 0 to Array length
         * @param value Win presentation sequence
         */
        setAnimationSequence(value: string[]): void;
        /**
         * @returns Win Presentation Sequence that will be displayed at the time of win presentation
         */
        getAnimationSequence(): string[];
        /**
         * Sets Reels sets for game
         * @param value Reel set Array
         */
        setReelSet(value: number[][][] | string[][][]): void;
        /**
         * @returns All Reel sets for game
         */
        getReelSets(): number[][][] | string[][][];
        /**
         * @returns A Reel from multiple reel sets
         * @param id id of the reel set required
         */
        getReelSet(id: number): number[][] | string[][];
        /**
         * Resets animation sequence counter to provided value
         * @param value to set `this.animationSequenceCounter`
         */
        reSetAnimationSequenceCounter(value: number): void;
        /**
         * Increase `this.animationSequenceCounter` as presentation sequence jumps from one to other. <br>
         * If presentation sequence is ["5OAK", "Spaghtti", "bigWin","firstToggle","secondToggle","triggeringAnimation","bonus","freeSpin"]
         * then "5OAK" counter will be 0, "Spaghtti", counter will be 1 and so on.
         */
        updateAnimationSequenceCounter(): void;
        /**
         * @returns Current index of animation sequence
         */
        getAnimationSequenceCounter(): number;
        /**
         * Sets game configuration in Model.
         * @param value game configuration JSON
         */
        setGameConfig(value: IObject): void;
        /**
         * @returns Slot game configurations
         */
        getGameConfig(): IObject;
        /**
         * @returns if Turbo Mode is on or off in game
         */
        getIsTurboModeOn(): boolean;
        /**
         * To activate or deactivate Turbo Mode
         */
        setIsTurboModeOn(value: boolean): void;
        /**
         * @returns Total auto spins selected by user to play Auto Spins
         */
        getTotalAutoSpins(): number;
        /**
         * Updates the total number of selected auto spins
         * @param value Number of auto spins selected
         */
        setTotalAutoSpins(value: number): void;
        /**
         * @returns Duration of Spaghetti to be displayed
         */
        getDelayForSpaghttiDispaly(): number;
        /**
         * Sets the duration for Spaghetti display
         */
        setDelayForSpaghttiDispaly(value: number): void;
        /**
         * @returns Duration to show 5OAK in game
         */
        getFiveOfAKindDisplayTime(): number;
        /**
         * Sets duration to show 5OAK in game
         */
        setFiveOfAKindDisplayTime(value: number): void;
        /**
         * @returns Duration to run Win Meter tickup in game
         */
        getTickUpDuration(): number;
        /**
         * Sets duration for meter tickup in game
         */
        setTickUpDuration(value: number): void;
        /**
         * As Auto Spins progress, this function increases the counter by 1
         */
        setUpdateCurrentAutoSpinIndex(): void;
        /**
         * Resets auto spins counter `this.currentAutoSpinIndex` to `0`
         */
        reSetCurrentAutoSpinIndex(): void;
        /**
         * @returns Current Auto spins counter (`this.currentAutoSpinIndex`)
         */
        getCurrentAutoSpinIndex(): number;
        /**
         * Set value of `this.stopReel`
         */
        setIsStopReel(value: boolean): void;
        /**
         * @returns value of `this.stopReel`
         */
        getIsStopReel(): boolean;
        /**
         * @returns Reel stops position from server, this is required to create Reel Grid using Reel Sets
         */
        getReelStops(): number[];
        /**
         * Sets Reel Stops value in `serverModel.setReelStops`
         * @param value Reel Stop Array
         */
        setReelStops(value: number[]): void;
        /**
         * @returns Reel Grid received from server
         */
        getReelGrid(): Array<Array<number>>;
        /**
         * @returns Feature triggering Reel grid received from serer
         */
        getTriggeringReelGrid(): number[][];
        /**
         * Resets server model `serverModel.resetForBet()`
         */
        resetForSpin(): void;
        /**
         * If current play is in Credits
         * @returns `serverModel.getIsCredit()`
         */
        getIsCredits(): boolean;
        /**
         * Clears free spin data from server model `serverModel.clearFreeSpinData()`
         */
        clearFreeSpinData(): void;
        /**
         * If there is a win
         * @returns `serverModel.getHasWin()`
         */
        getIsWin(): boolean;
        /**
         * @returns if there is any feature triggering win `serverModel.getHasTriggeringWin()`
         */
        getIsTriggeringWin(): boolean;
        /**
         * @returns if there is a line win in game `serverModel.getHasLineWins()`
         */
        getIsLineWins(): boolean;
        /**
         * @returns If Scatter Win is available on current spin `this.serverModel.getHasScatterWins()`
         */
        getIsScatterWins(): boolean;
        /**
         * @returns `this.serverModel.getHasFreeGamesWin()` If free spins are awarded on current spin
         */
        getIsWonFreeSpin(): boolean;
        /**
         * @returns If free spins are available
         */
        getTotalFreeSpin(): boolean;
        /**
         * @returns If triggering grid is available
         */
        getIsTriggeringGrid(): boolean;
        /**
         * @returns If feature is won on current spin,
         * feature can be anything:- freepins, pick bonus etc. feature is determined based on the length of Scatter win data `serverModel.getScatterWinData().length`
         */
        getIsWonBonus(): boolean;
        /**
         * If Five if a kind is available on current spin
         * @returns `serverModel.get5OfKind()`
         */
        getIs5OfKindAvailable(): boolean;
        /**
         * @returns Data for Win Line received from server e.g. Line number, Line Win amount etc.
         */
        getWinLinesData(): IWinLineObject[];
        /**
         * Sets ways win data from server like win amount, winning symbol id, its positions
         */
        setWinLinesData(value: IWinLineObject[]): void;
        /**
         * @returns Current way win data `serverModel.getWaysWinData()`
         */
        getWaysWinData(): IWinLineObject[];
        /**
         * Ways win data from server model having all unique win positions to show win summary
         * @returns `serverModel.getWaysWinAllUniquePositions()`
         */
        getWaysWinAllUniquePositions(): number[][];
        /**
        * @returns if there is a way win in game `serverModel.getHasWaysWins()`
        */
        getIsWaysWins(): boolean;
        /**
         * @returns triggering Win Line data `serverModel.getTriggerWinLinesData()`
         */
        getTriggeringWinLinesData(): IWinLineObject[];
        /**
         * @returns Scatter win information for current spin i.e. Number of scatter win, scatter win amount etc.
         * @borrows `serverModel.getScatterWinData()`
         */
        readonly scatterWinData: IWinLineObject[];
        /**
         * @returns Triggering Scatter win data
         * @borrows `serverModel.getTriggerScatterWinData()`
         */
        getTriggerScatterWinData(): IWinLineObject[];
        /**
         * Sets the following in `serverModel`-  <br>
         * * Current bet Index `serverModel.setCurrentBetIndex`
         * * Current bet `serverModel.setCurrentBet`
         * * Current total bet `serverModel.setCurrentTotalBet`
         * @returns Next available bet for game `serverModel.getCurrentBet`
         */
        getNextAvailableBet(): number;
        /**
        * Sets the following in `serverModel`-  <br>
        * * Current bet Index `serverModel.setCurrentBetIndex`
        * * Current bet `serverModel.setCurrentBet`
        * * Current total bet `serverModel.setCurrentTotalBet`
        * @returns Previous available bet for game `serverModel.getCurrentBet`
        */
        getPrevAvailableBet(): number;
        /**
         * @returns If big win is available returns the following - <br>
         ** 0 means no BIG WIN
         ** 1 means BIG WIN, calculated based on multiplier mentioned in `slotConstants.SlotConstants.BigWinMultiplier`
         ** 2 means MEGA BIG WIN calculated based on multiplier mentioned in `slotConstants.SlotConstants.MegaWinMultiplier`
         ** 3 means SUPER BIG WIN calculated based on multiplier mentioned in `slotConstants.SlotConstants.SuperWinMultiplier`
         */
        getIsBigWin(): number;
        /**
         * @returns If a broken free game is pending
         */
        getIsBrokenFreeGame(): boolean;
        /**
         * @returns If a broken base game is pending
         */
        getIsBrokenBaseGame(): boolean;
        /**
         * @returns Total available balance for Game received from server
         */
        getBalance(): number;
        /**
         * @returns Current bet amount for game
         */
        getCurrentBet(): number;
        /**
         * @returns Current total bet
         */
        getTotalBet(): number;
        /**
         * @returns Current spin win amount, e.g. current free spin win amount
         */
        getCurrentWinAmt(): number;
        /**
         * @returns Total win amount for game
         */
        getTotalWinAmt(): number;
        /**
         * @returns If enough balance is available or not to place a bet
         */
        getHasEnoughBalance(): boolean;
        /**
         * Updates balance after placing bet. <br>
         * e.g. if balance is 100 & bet amount is 10 updated balance would be this (100-10 = 90)
         */
        setUpdatedBalanceForSpin(): void;
        /**
         * Update balance after win in game, it will add win amount in balance
         */
        setUpdatedBalanceAfterWin(): void;
        /**
         * @returns Free spin win amount
         */
        getFreeSpinWin(): number;
        /**
         * Resets all auto play properties. i.e. sets `this.totalAutoSpins` to `-1` & `this.currentAutoSpinIndex` to `0`
         */
        resetAutoPlay(): void;
        /**
         * @returns Returns if autoplay spins are still pending.
         */
        getIsAutoPlayLeft(): boolean;
        /**
         * @returns Game state, received from server
         */
        getGameState(): number;
        /**
         * This method sets the normal re-spin data won in Base Game or Free Game.
         * @param reSpin if re-spin is available
         * @param reSpinCounter Number of re-spins available
         */
        setReSpinData(reSpin: boolean, reSpinCounter: number): void;
        /**
         * @returns IS re-spin available in game
         */
        getReSpinIdentifier(): boolean;
        /**
         * @returns Number of Re-Spin available in game.
         */
        getReSpinCounter(): number;
    }
}
/**
 * Created by Sjoshi on 2/20/2017.
 */
declare namespace ingenuity.slot.BaseGame {
    /**
     * Purpose of this class is to control all buttons functionalities in game
     * like, if user click "SPIN" button, it will be first listened here and required action will be taken
     */
    class ButtonController {
        /** Spin button to handle spin functionality */
        protected spinBtn: ui.ButtonBase;
        /** Stop button, to handel stop button functionality */
        protected spinStopBtn: ui.ButtonBase;
        /** Bet minus button, decrease Bet in bet Meter */
        protected betMinusBtn: ui.ButtonBase;
        /** Bet plus button, increase Bet in bet Meter */
        protected betPlusBtn: ui.ButtonBase;
        /** Autoplay button, which activates AutoPlay */
        protected autoPlayBtn: ui.ButtonBase;
        /** Autoplay Off button */
        protected autoPlayOffBtn: ui.ButtonBase;
        /** Info Screen Button */
        protected infoBtn: ui.ButtonBase;
        /** Settings button to change settings in the game */
        protected settingBtn: ui.ButtonBase;
        /** Settings Close button */
        protected settingCloseBtn: ui.ButtonBase;
        /** Instance of Base Game view */
        protected view: View;
        /** Instance of reel view */
        protected reelView: slot.reelPanel.ReelPanel;
        /** Instance of Model */
        protected model: Model;
        protected isRemoveKeyListeners: boolean;
        /**
         * Button panel constructor, which initializes all buttons , binds events on them and subscribes events
         * handles by buttons
         * @param view
         * @param model
         * @param dispatcher
         */
        constructor(view: BaseGame.View, model: BaseGame.Model);
        /**
         * Initialize all game buttons by taking their reference from Base Game View
         * @param view Base game view
         */
        protected initializeButtons(view: BaseGame.View): void;
        /**
         * Binds events on all buttons
         * like when user clicks on SPIN button in game, it will trigger onSpinPressUp event
         */
        protected bindHandlers(): void;
        /**
         * Unsubscribes button events
         */
        protected unBindHandlers(): void;
        /**
         * Keyboard event handler
         * On Spacebar - Stars Spin else force stops the reels (if reels are already spinning)
         * Prevents mouse wheel + Ctrl Key zoom
         */
        protected spaceKeyBoardEvent(): void;
        /**handler used to remove keyboard keydown event */
        protected removeSpaceBarEvent(e: IEvent): void;
        /**handler used to add keyboard keydown event */
        protected addSpaceBarEvent(e: IEvent): void;
        /**handler for keyboard keydown event */
        protected keyboardKeyDown(event: KeyboardEvent): void;
        /**
         * When user clicks SPIN button in game, this function will be executed and will dispatch event "slotConstants.SlotEventConstants.SPIN_CLICKED" to handle spin functionality
         * and "ingenuity.events.EventConstants.BUTTON_RELESED" to show released button animation in game
         */
        protected onSpinPressUp(button?: ui.ButtonBase): void;
        /**
         *Set Auto Play Counting
         */
        protected setAutoPlayCounting(evt: IEvent): void;
        /**
         * When user clicks AUTOPLAY button in game, this function will be called
         */
        protected onAutoPlayPressUp(): void;
        /**
         * Reset Auto play When auto Play Finished.
         */
        protected resetAutoPlay(evt: IEvent): void;
        /**
         * Callback function for click of Autoplay Off button
         */
        protected onAutoPlayOffPressUp(): void;
        /**
         * Updates AUTOPLAY buttons state after every spin
         * if Autoplay available, it will update autoplay index in meter
         * and if Autoplay not available, it will hide autoplaystop Button and visible autoPlayBtn
         */
        protected onUpdateAutoPlayBtns(evt: IEvent): void;
        /**
         * Callback function for Stop button
         * Executes FORCE_STOP event to force stop the reels and updates the Spin & Stop button state
         */
        protected onSpinStopPressUp(): void;
        /**
         * Callback function for Bet increase button
         * increases bet amount in betMeter
         */
        protected onBetPlusPressUp(): void;
        /**
         * Sets next or previous bet in model based on param value,
         * Dispatches the following events - <br>
         * * slotConstants.SlotEventConstants.CLEAR_DATA
         * * slotConstants.SlotEventConstants.RESET_METERS
         * * slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATION_ON_REEL
         * * slotConstants.SlotEventConstants.RESET_PALYER_MSG_LABELS
         * @param value If value is greater than 0, next available bet will be set in model else previous available bet will be set in Model
         */
        protected onChangeStake(value: number): void;
        /**
         * Callback function for Decrease bet Button
         */
        protected onBetMinusPressUp(): void;
        /**
         * Callback function for Info screen Button.
         * On execution, dispatches event for GAME_MSG_HIDE & SHOW_PAYTABLE
         */
        protected onInfoPressUp(): void;
        /**
         * Callback function for Settings press up.
         * Executes this.onSettings
         */
        protected onSettingPressUp(): void;
        /**
         * Following things happen in game
         * enabled setting button, and opens setting panel in game for user to change settings and hides setting Autoplay container, if reel is spinning
         * otherwise, if AutoplaySettingsContainer is on, unsubscribes all events on Reel Panel,hides game message, disabled button interactions
         */
        protected onSettings(): void;
        /**
         * Closes settings panel
         */
        protected onSettingClose(): void;
        /**
         * Callback function for Settings Close button
         */
        protected onSettingClosePressUp(): void;
        /**
         * Hides STOP button and show SPIN button to the player
         */
        protected onShowSpinBtnHideStopBtn(evt: IEvent): void;
        /**
         * Subscribes events for buttons.
         */
        protected subscribeEvents(): void;
        /**
         * Unsubscribes events for buttons.
         */
        protected unsubscribeEvents(): void;
        /**
         * Enabled AUTOPLAY stop button in game
         */
        protected onEnableAutoStopBtn(evt: IEvent): void;
        /**
         * Disables AUTOPLAY button in game
         */
        protected onDisabledAutoPlayBtn(evt: IEvent): void;
        /**
         * Nullifies SPIN button in game
         */
        protected nullSpinButton(evt: IEvent): void;
        /**
         * Enables Stop button in game <br>
         * disables & hide Spin button
         */
        protected onEnableStopBtn(evt: IEvent): void;
        /**
         * Clears some button related data and property that is required to clear at the
         * time of reel spinning start
         */
        protected onClearData(evt: IEvent): void;
        /**
         * Toggles visibility of containers to invisible, by default sets all available containers to invisible.
         * If the containerId or container is passed in event.data then only passed containers will be set to invisible
         */
        protected onHideContainers(evt: IEvent): void;
        /**
         * Toggles visibility of containers to visible, by default sets all available containers to visible.
         * If the containerId or container is passed in event.data then only passed containers will be set to visible
         */
        protected showContainers(evt: IEvent): void;
        /**
         * Disable all buttons available in game
         * if `configData.MenuBtnEnableAllTime` is set to `true`, Enables menu button and fires event to set the container visible
         */
        protected onDisabledAllButtons(evt: IEvent): void;
        /**
         * Enable all buttons available in game
         * if Autoplay is left then disables setting button
         */
        protected onEnableAllButtons(evt: IEvent): void;
        /**
         * Enables Menu button in game
         */
        protected enableMenuBtn(): void;
        /**
         * Enables the button passed in evt.data,
         * if Autoplay is left then disables setting button
         */
        protected onEnabledButton(evt: IEvent): void;
        /**
         * Disables the button passed in evt.data
         */
        protected onDisabledButton(evt: IEvent): void;
        /**
         * Toggles visibility of containers to visible, by default sets all available containers to visible.
         * If the containerId or container is passed in event.data then only passed containers will be set to visible
         */
        protected onShowContainers(evt: IEvent): void;
        /**
         * To remove all events from stage, left blank in slot core
         */
        protected onRemoveAllListnersFromStage(evt: IEvent): void;
        /**
         * Disables button interaction.
         * If data (evt.data) is passed at the time of event fire, it disabled interaction for that passed button only
         * else disables interaction for all the button available
         */
        protected onDisableButtonInteraction(evt: IEvent): void;
        /**
         * Enables button interaction.
         * if data (evt.data) is passed at the time of event fire, it enabled interaction for that passed button only
         * if not then it enabled interaction for all the button available
         */
        protected onEnableButtonInteraction(evt: IEvent): void;
    }
}
/**
 * Created by Sjoshi on 2/21/2017.
 */
declare namespace ingenuity.slot.BaseGame {
    /**
     * This class controls all the base game meters in game
     */
    class MetersController {
        /** Holds bet meter */
        protected betMeter: ui.Meter;
        /** Holds total bet meter */
        protected totalBetMeter: ui.Meter;
        /** Holds stake meter */
        protected stakeMeter: ui.Meter;
        /** Holds balance meter */
        protected balanceMeter: ui.Meter;
        /** Holds win meter */
        protected winMeter: ui.Meter;
        /** Holds autoplay meter */
        protected autoPlayMeter: ui.Meter;
        /** Instance of base game view */
        protected view: View;
        /** Instance of Base game Model */
        protected model: Model;
        constructor(view: View, model: Model);
        /**
         * Binds class level events for meters
         */
        protected bindHandlers(): void;
        /**
         * To subscribe meter events, subscribeEvents is called When `SCBSCRIBE_METER_CONTROLLERS_BG` fired.
         */
        protected subscribeEvents(): void;
        /**
         * To unsubscribe meter events, unsubscribeEvents is called When UNSCBSCRIBE_METER_CONTROLLERS_BG fired.
         */
        protected unsubscribeEvents(): void;
        /**
         * Starts Tick-up in win meter
         */
        protected onStartWinTickUp(evt: IEvent): void;
        /**
         * Stops win Tickup in win meter
         */
        protected onStopWinTickUp(evt: IEvent): void;
        /**
         * Updates basegame win meter after free games finishes
         */
        protected onReturningFreegameUpdateMeter(evt: IEvent): void;
        /**
         * Update balance meter if there is no scatter wins
         */
        protected updateBalance(): void;
        /**
         * Updates balance after free games finishes
         */
        protected updateBalanceafterFG(): void;
        /**
         * Updates balance in win meter after win
         */
        protected onUpdateBalanceMeterAfter(evt: IEvent): void;
        /**
         * Updates balance meter after placing the bet
         */
        protected onUpdateBalanceMeterAfterSpinClick(evt: IEvent): void;
        /**
         * updates meter with currency or normal value
         * @param meter meter which needs to be updated with value
         * @param value value to be updated
         */
        protected updateMeterForCreditCoin(meter: ui.Meter, value: string): void;
        /**
         * Updates balance (`model.getBalance()`) in balance meter.
         * Sets currency formated value if playing in credits else sets formatted value
         */
        protected onUpdateBalanceMeter(evt: IEvent): void;
        /**
         * Update current bet amount (`model.getCurrentBet()`) in stake meter.
         * Sets currency formated value if playing in credits else sets formatted value
         */
        protected onUpdateStakeMeter(evt: IEvent): void;
        /**
         * Resets all meters available in games & updates autoplayMeter
         */
        protected onResetMeters(evt: IEvent): void;
        /**
         * Updates current bet amount in Bet Meter
         * Sets currency formated value if playing in credits else sets formated value
         */
        protected onUpdateBetMeter(evt: IEvent): void;
        /**
         * Sets currency formated value in win meter
         */
        protected updateValueForCreditCoin(evt: IEvent): void;
        /**
         * Updates Win amount in Win Meter. <br>
         * If tickup is in progress: This function will stop tickup & show the amount after delay mentioned in configData `ingenuity.configData.timeToDisplayFinalTickValue` or defaults to 50 if no value provided in config data.<br>
         * If tickup is already stopped - Sets currency formated value if playing in credits else sets formated value
         * @param evt sets the value from evt.data is type is number else sets value from `model.getCurrentWinAmt()`
         */
        protected onUpdatePaidMeter(evt: IEvent): void;
        /**
         * Updates Total Bet amount in Total Bet Meter
         * Sets currency formated value if playing in credits else sets formated value
         */
        protected onUpdateTotalBetMeter(evt: IEvent): void;
        /**
         * Toggles visibility of autoplay meter based on `model.getIsAutoPlayLeft()` and sets value in meter
         */
        protected onUpdateAutoPlayMeter(evt: IEvent): void;
        /**
         * Stops meter tickup for the meterId/meter passed in evt.data else stops tickup in all meters
         * @param evt pass the meter id or meter in evt.data to stop the tickup in meter
         */
        protected onStopMeterTickup(evt: IEvent): void;
    }
}
/**
 * Created by Sjoshi on 2/23/2017.
 */
declare namespace ingenuity.slot.BaseGame {
    /**
     * Purpose of this is class to control Player Messages in Game
     * @abstract
     */
    abstract class PlayerMsgController {
        /** Instance of view */
        protected view: View;
        /** Instance of model */
        protected model: Model;
        /** HTML Div element  */
        protected messageDiv: HTMLDivElement;
        /** View JSON */
        protected json: IObject;
        protected assets: IObject;
        /** Instance of localization */
        protected locale: IObject;
        /** HTML base container */
        protected baseContainer: HTMLElement;
        constructor(view: View, model: Model, json: IObject, assets: IObject);
        /**
         * Bind handlers to bind event on Player Message
         */
        protected bindHandlers(): void;
        /**
         * Subscribes listeners to controls Player messages
         * show player message, hide player message, show WinLine message, showGood Luck message etc..
         */
        protected abstract subscribeEvents: void;
        /**
         * If dispatched an event to show message in base game
         * handled and listened here and update view to show message in game
         */
        protected abstract showMessages(evt: IEvent): void;
        /**
         * if dispatched an event to show Promo message in game, listened here
         * and update view that show promo message in base game view
         */
        protected abstract showPromoMessages(evt: IEvent): void;
        /**
         * when event dispatched to show Line win message in game listened here and update view to show Line Win Message in game
         */
        protected abstract showWinLineMessage(evt: IEvent): void;
        /**
         * when an event dispatched to show Good Luck message in game
         * listened here and update view to show Good Luck message in base game
         */
        protected abstract showGoodLuckMessage(evt: IEvent): void;
        /**
         * To clear player message in game
         */
        protected abstract clearMessage(evt: IEvent): void;
    }
}
/**
 * Created by Sjoshi on 2/21/2017.
 */
declare namespace ingenuity.slot.BaseGame {
    /**
     * Purpose of this controller is to control activities on base game Reel Panel
     * Like Reel Spins, Reel Stops, All Reels Stop, Call to check Win
     * Anticipation, Landing Animation etc..
     */
    class ReelPanelController {
        /** Instance of view */
        protected view: View;
        /** Instance of model */
        protected model: Model;
        /** Instance of reel view */
        protected reelView: reelPanel.ReelPanel;
        /** Instance of Win presentation panel */
        protected winReelView: reelPanel.WinPresentationPanel;
        /** Instance of payline view */
        protected paylineView: reelPanel.Paylines;
        /** Array to store anticipation data */
        protected anticipationList: Array<Array<number>>;
        constructor(view: View, model: Model);
        /**
         * Init is called when ReelPanelController initialized.In this func we set reel set and reel grid to reelpanel.
         */
        protected init(): void;
        /**
         * Unsubscribe all reel events
         * @listens `slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS`
         */
        protected unsubscribeEvents(): void;
        /**
         * Binds class level events in this
         */
        protected bindHandlers(): void;
        /**
         * Subscribes all Reel level events to handle Reel Panel Functionality
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_BASEGAME_REELPANEL_EVENTS`
         */
        protected subscribeEvents(): void;
        /**
         * Adds Animation over paylines
         * @param layer animation layer that is to be placed over the payline view and will carry the overlay symbols while animate
         * @listens `slotConstants.SlotEventConstants.ADD_ANIM_OVERLAY_LAYER`
         */
        addAnimOverlayLayer(layer: any): void;
        /**
         * Unsubscribes all Reel level events to handle Reel Panel Functionality
         * @listens `slotConstants.SlotEventConstants.UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER`
         */
        protected onUnScribeAllReelPanelEvents(evt: IEvent): void;
        /**
         * To force stop the reel spin
         * @listens `slotConstants.SlotEventConstants.FORCE_STOP`
         */
        protected onReelsForceStop(): void;
        /**
         * When Response came from server, now we are ready to stop reels one by one
         * @listens `ingenuity.events.EventConstants.STOP_REEL_NOW`
         */
        protected onStopReelNow(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.NOW_SPIN_REEL`
         * @fires `slotConstants.SlotEventConstants.SPIN` immediately.
         * @fires `platform.EventConstants.PLACE_BET` with a delay of 10 milliseconds
         */
        protected onSpinReel(evt: IEvent): void;
        /**
         * To update symbols on grid.
         * Updates the reel grid as per the data in `model.getReelStops()`
         * @listens `slotConstants.SlotEventConstants.UPDATE_SYMBOLS_ON_GRID`
         */
        protected onUpdateSymbolsOnGrid(): void;
        /**
         * Checks if anticipation is available on applicable reels
         * @listens `slotConstants.SlotEventConstants.CHECK_FOR_ANTICIPATION_ON_REELS`
         */
        protected onCheckingAnticipationOnReels(): void;
        /**
         * Sets Quick spin/Turbo mode to true in Model
         * @listens `slotConstants.SlotEventConstants.UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN`
         */
        protected updateModelForQuickSpin(): void;
        /**
         * Show anticipation on reel
         * @param e e.data to show the anticipation
         * @listens `slotConstants.SlotEventConstants.SHOW_ANTICIPATION`
         */
        protected showAnticipation(e?: IEvent): void;
        /**
         * Show landing animation
         * @param e e.data to show the landing animation
         * @listens `slotConstants.SlotEventConstants.SHOW_LANDINGANIMATION`
         */
        protected showLanding(e?: IEvent): void;
        /**
         * Unsubscribes and then subscribes reel start events
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START_BG`
         */
        protected onReelStartSubscribeEvents(evt: IEvent): void;
        /**
         * This function will be executed for every reel stop i.e. for 5 reels this function will be executed five times
         * @listens `ingenuity.events.EventConstants.REEL_STOPPED`
         */
        protected onReelStopped(evt?: IEvent): void;
        /**
         * Executed once spin is complete
         * @listens `slotConstants.SlotEventConstants.SPIN_COMPLETE`
         */
        protected onSpinComplete(evt?: IEvent): void;
        /**
         * When all Reels started to stop and about to bounce but not stopped completely
         * @listens `slotConstants.SlotEventConstants.REEL_STOPPING`
         */
        protected onReelStoping(evt?: IEvent): void;
        /**
         * Check whether to play anticipation on Reels or not
         * @param symbolObj
         * @param listLength
         */
        protected checkForAnticipation(symbolObj: any, listLength: number): void;
        /**
         * Check for landing animation in game, for all reels
         * @param symbolObj
         * @param listLength
         */
        protected checkForlandingAnim(symbolObj: any, listLength: number): void;
        /**
         * Clears anticipationList, landingOnReel and calls `model.resetForSpin()`
         * @listens `slotConstants.SlotEventConstants.CLEAR_DATA`
         */
        protected onClearData(evt: IEvent): void;
        /**
         * Adds All overlay symbols in Animation overlay layer.
         * @listens `slotConstants.SlotEventConstants.ADD_ALL_OVERLAY_SYMBOLS_TO_ANIM_OVERLAY_LAYER`
         */
        addAllOverlaySymobolsToAnimOverlayLayer(): void;
        /**
         * Adds symbols in Animation overlay layer
         * @param reelNum Reel Number
         * @param rowNum Row Number
         * @listens `slotConstants.SlotEventConstants.ADD_SYMBOL_TO_ANIM_OVERLAY_LAYER`
         */
        addSymobolToAnimOverlayLayer(reelNum: number, rowNum: number): void;
        /**
         * Removes all children's from anim over layer
         * @listens `slot.slotConstants.SlotEventConstants.CLEAR_ANIM_LAYER`
         */
        clearSymbAnimLayer(): void;
        /**
         * Updates the children index highr than payline view
         * @listens `slot.slotConstants.SlotEventConstants.PLACE_OVER_PAYLINES`
         */
        protected placeOverPayline(data: any): void;
    }
}
/**
 * Created by Sjoshi on 2/21/2017. <br>
 */
declare namespace ingenuity.slot.BaseGame {
    /**
     * Purpose of this class is to Control All Win Presentation activities running in game
     */
    class WinPresentationController {
        /** Instance of Payline View */
        protected paylineView: slot.reelPanel.Paylines;
        /** Instance of Reel View */
        protected reelView: slot.reelPanel.WinPresentationPanel;
        /** Instance of View */
        protected view: View;
        /** Instance of Model */
        protected model: Model;
        /** Stores duration of five of a kind */
        protected fiveOfKindDuration: number;
        /** Stores current toggle cycle */
        protected togglingCycle: number;
        constructor(view: View, model: Model);
        /**
         * Subscribes events required for Payline View and Win presentation controller.
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS`
         */
        protected subscribeEvents(): void;
        /**
         * Unsubscribes events required for Payline View and Win presentation controller.
         * @listens `slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS`
         */
        protected unsubscribeEvents(): void;
        /**
         * Executed on Symbol animation start if subscribed
         * @listens `slotConstants.SlotEventConstants.SYMBOL_ANIM_STARTED`
         */
        protected onSymbolAnimStarted(evt: IEvent): void;
        /**
         * Executed on Symbol animation end if subscribed
         * @listens `slotConstants.SlotEventConstants.SYMBOL_ANIM_ENDED`
         */
        protected onSymbolAnimEnded(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.WIN_CYCLE_COMPLETED`
         * @fires `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION`
         */
        protected onWinCycleCompleted(evt: IEvent): void;
        /**
         * Executed on line animation started if subscribed
         * @listens `slotConstants.SlotEventConstants.LINE_ANIMATION_STARTED`
         */
        protected onLineAnimStarted(evt: IEvent): void;
        /**
         * Executed on way animation started if subscribed
         * @listens `slotConstants.SlotEventConstants.WAY_ANIMATION_STARTED`
         */
        protected onWayAnimStarted(evt: IEvent): void;
        /**
         * Executed on line animation ended if subscribed
         * @listens `slotConstants.SlotEventConstants.LINE_ANIMATION_ENDED`
         */
        protected onLineAnimEnded(evt: IEvent): void;
        /**
         * Executed on way animation ended if subscribed
         * @listens `slotConstants.SlotEventConstants.Way_ANIMATION_ENDED`
         */
        protected onWayAnimEnded(evt: IEvent): void;
        /**
         * On start of Big win presentation, this functions configures Event on Big win presentation.
         * @fires `slotConstants.SlotEventConstants.SHOW_BIG_WIN`
         * @listens `slotConstants.SlotEventConstants.START_BIG_WIN_PRESENTATION`
         */
        protected onStartBigWinPresentation(evt: IEvent): void;
        /**
         * * Sets animation symbol `true`
         * * Sets toggling continue `false`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutFirstToggle`
         */
        protected updateReelViewForFirstToggle(): void;
        /**
         * On start of first line toggle cycle -
         * * Sets animation symbol `true`
         * * Sets toggling continue `false`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutFirstToggle`
         * @fires `slotConstants.SlotEventConstants.START_WIN_ANIM`
         * @listens `slotConstants.SlotEventConstants.START_FIRST_TOGGLE_CYCLE`
         */
        protected onStartFirstToggleCycle(evt: IEvent): void;
        /**
         * On start of first ways toggle cycle -
         * * Sets animation symbol `true`
         * * Sets toggling continue `false`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutFirstToggle`
         * @fires `slotConstants.SlotEventConstants.START_WAYS_ANIM`
         * @listens `slotConstants.SlotEventConstants.START_FIRST_TOGGLE_CYCLE_WAYS`
         */
        protected onStartFirstToggleCycleWays(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.SCATTER_ANIMATION_ENDED`
         * @fires `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION`
         */
        protected onScatterAnimationEnd(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.START_SCATTER_PRESENTATION`
         * @fires `slotConstants.SlotEventConstants.START_SCATTER_WIN_ANIM`
         */
        protected onStartScatterPresentation(evt: IEvent): void;
        /**
         * * Sets animation symbol `false`
         * * Sets toggling continue to value of `evt.data`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutSecondToggle`
         */
        protected updateReelViewForSecondToggle(evt: IEvent): void;
        /**
         * On start of second line toggle cycle -
         * * Sets animation symbol `false`
         * * Sets toggling continue to value of `evt.data`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutSecondToggle`
         * @fires `slotConstants.SlotEventConstants.START_WIN_ANIM`
         * @listens `slotConstants.SlotEventConstants.START_SECOND_TOGGLE_CYCLE`
         */
        protected onStartSecondToggleCycle(evt: IEvent): void;
        /**
         * On start of second line toggle cycle -
         * * Sets animation symbol `false`
         * * Sets toggling continue to value of `evt.data`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutSecondToggle`
         * @fires `slotConstants.SlotEventConstants.START_WIN_ANIM`
         * @listens `slotConstants.SlotEventConstants.START_SECOND_TOGGLE_CYCLE_WAYS`
         */
        protected onStartSecondToggleCycleWays(evt: IEvent): void;
        /**
         * Dispatches the following events
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_FRAMES`
         * @fires `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION`
         * @listens `slotConstants.SlotEventConstants.BIG_WIN_HIDDEN`
         */
        protected cofigureEventOnBigWinHide(): void;
        /**
         * @listens `slotConstants.SlotEventConstants.SHOW_SPAGHTTI` in game During Win presentation
         * @fires `slotConstants.SlotEventConstants.SHOW_SPAGETTI`
         * @callback dispatches `slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI` & `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION` <br>
         * Once shown:
         * @fires `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION`
         */
        protected onShowSpaghtti(evt: IEvent): void;
        /**
         * Shows win summary in ways game by showing all win frames together
         * @listens `slotConstants.SlotEventConstants.SHOW_ALL_WIN_FRAMES` in game During Win presentation
         * @fires `slotConstants.SlotEventConstants.SHOW_ALL_FRAMES`
         * @callback dispatches `slotConstants.SlotEventConstants.HIDE_ALL_FRAMES` & `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION` <br>
         * Once all frames are shown:
         * @fires `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION`
         */
        protected onShowAllFrames(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.SHOW_5OAK`
         * Sets display time from `model.getFiveOfAKindDisplayTime()` to `this.fiveOfKindDuration`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_FRAMES` <br>
         * Executes `view.show5OfKind`
         */
        protected onShow5OAK(evt: IEvent): void;
        /**
         * On hide Five of a kind.
         * @listens `slotConstants.SlotEventConstants.HIDE_5OAK`
         */
        protected onHide5OAK(evt: IEvent): void;
        /**
         * Set WinLines And Ways data for Win Presentation.
         * @listens slotConstants.SlotEventConstants.SET_WINLINE_AND_WAYS_DATA
         */
        protected onSetWinLineAndWaysUniqueData(evt: IEvent): void;
        /**
         * When Reel Spinning Starts this function subscribes events for Win Presentation.
         */
        protected onReelStartSubscribeEvents(evt: IEvent): void;
        /**
         * Clears free spin data.
         */
        protected onClearData(): void;
        /**
         * Stops all running Win Animation in game.
         * @fires `slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATIONS` <br>
         * After delay defined in `slotConstants.SlotConstants.TimerHidePayline`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_FRAMES`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_WIN_PAYLINE` <br>
         * Unsubscribes: `slotConstants.SlotEventConstants.WIN_CYCLE_COMPLETED`
         */
        protected onStopAllWinAnimation(): void;
        /**
         * Suspends the win presentation.
         * @listens `slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_FRAMES`
         * @fires `slotConstants.SlotEventConstants.HIDE_ALL_WIN_PAYLINE`
         * @fires `slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATION_ON_REEL`
         */
        protected onSuspendWinPresentation(): void;
    }
}
declare namespace ingenuity.slot.symbol {
    interface ISymbolData {
        /** X Coordinate */
        x?: number;
        /** Y Coordinate */
        y?: number;
        /** Width of Symbol */
        width?: number;
        /** Height of Symbol */
        height?: number;
        /** Symbol ID */
        symNum: number;
        /** Symbol name */
        symName?: string;
        /** Symbol Type*/
        symType?: string | string[];
        /**
         *  Defines the ordering of the symbol a higher number means symbols will be placed higher.
         */
        zIndex?: number;
        /**
         * To enable touch/ mouse events on an icon
         */
        enableEvents?: boolean;
        /**
         * Possible entries for Animate are :
         * * sprite - Atlas/SpriteSheet based animations
         * * spine - Spine based animations
         * * layered - a mix of different animations
         * * scale - Scale an Icon while animating
         * * blink - Changes visible on and off
         * * flash - changes the alpha of an Icon
         * * none - symbol will not have any kind of animation
         */
        animation?: string;
        /**
         * Possible entries for Animate are :
         * * scale - Scale an Icon while animating
         * * blink - Changes visible on and off
         * * flash -  changes the alpha of an Icon
         * * none - symbol will not have any kind of animation
         */
        defaultAnimType: string;
        /**
         * Spacing between two icons
         */
        iconSpacingX?: number;
        /**
         * Spacing between two icons vertically
         */
        iconSpacingY?: number;
        /**
         * Config for Overlay symbols
         */
        overlay?: OverlapSymbolData;
        /** Blur Y value for Symbol */
        blurYValue?: number;
        /** If symbol is an always animating type symbol */
        alwaysAnimate?: boolean;
        /** Config for Static Symbol */
        staticSym: IStaticSymbolData;
        /**
         * Config for Blur symbol, if set to `true` `staticSym` config will be used.
         */
        blurSym: IStaticSymbolData | boolean;
        animSym: string | IAnimationSymbolData | ISpineSymbolData | ILayeredSymbolData;
        /** Parent container for symbol */
        container: string;
    }
    interface IStaticSymbolData extends IStaticAnimation {
        /** Width of Symbol */
        width?: number;
        /** Height of Symbol */
        height?: number;
        /**
         * Possible entries for Animate are :
         * * scale - Scale an Icon while animating
         * * blink - Changes visible on and off
         * * flash -  changes the alpha of an Icon
         * * none - symbol will not have any kind of animation
         */
        animType: string;
        /** Symbol image to be used */
        image?: string;
        /** Poster frame for symbol */
        posterFrame?: string;
        /**
         * An array of numbers or strings indicating which frames to play in which order.
         */
        frame?: number;
        /**
         * Set the x anchor point of the Symbol. A value between 0 and 1, where 0 is the top-left and 1 is bottom-right.
         */
        anchorX?: number;
        /**
         * Set the y anchor point of the Symbol. A value between 0 and 1, where 0 is the top-left and 1 is bottom-right.
         */
        anchorY?: number;
        regX?: number;
        regY?: number;
        /**
         * The horizontal scale factor of the Image. A value of 1 means no scaling. 2 would be twice the size, and so on.
         */
        scaleX?: number;
        /** The vertical scale factor of the Image. A value of 1 means no scaling. 2 would be twice the size, and so on. */
        scaleY?: number;
        scale?: number;
        /** To enable touch/ mouse events on an icon */
        enableEvents?: boolean;
    }
    interface IStaticAnimation extends IObject {
        /** Tween delay time for the Symbol */
        wait?: number;
        /** Duration of Tween */
        time?: number;
        /** Scale to value */
        scaleto?: number;
        /**
         * Whether or not the animation is looped or just plays once.
         */
        loop?: number | boolean;
        override?: boolean;
        /** Callback to be executed once anim is completed */
        callback?: () => void;
        sym2Flash?: number;
        sym2Wait?: number;
        brightness?: number;
        contrast?: number;
    }
    interface IAnimationSymbolData extends IStaticSymbolData {
        /**
         * Possible entries for Animate are :
         * * sprite - Atlas/SpriteSheet based animations
         * * spine - Spine based animations
         * * layered - A mix of different animations
         */
        animType: string;
        /**
         * To animate a sprite based symbol all times
         * In case alwaysAnimate is true, then poster in the animation should have the animation to be played
         **/
        alwaysAnimate?: boolean;
        animations: {
            [key: string]: IAnimationProperties | string;
        };
    }
    interface IAnimationProperties extends IObject {
        /**
         * When you are creating arrays of animation data but it's using frame names and not numbers.
         * For example imagine you've got 30 frames named: 'explosion_0001-large' to 'explosion_0030-large'
         * You could use this property to generate those.
         * For more information refer to Phaser documentation for function `generateFrameNames` in `bridge.Animation`
         */
        generateNames?: boolean;
        /**
         * Prefix to be used while generating frame names.
         * The start of the filename. If the filename was 'explosion_0001-large' the prefix would be 'explosion_'.
         */
        prefix?: string;
        /**
         * Suffix to be used while generating frame names.
         * The end of the filename. If the filename was 'explosion_0001-large' the prefix would be '-large'. - Default: ''
         */
        suffix?: string;
        /**
         * The number of zeros to pad the min and max values with. If your frames are named 'explosion_0001' to 'explosion_0034' then the zeroPad is 4.
         */
        zeroPad?: number;
        /**
         * An array of numbers or strings indicating which frames to play in which order.
         */
        frames: number[] | string[];
        /**
         * The speed at which the animation should play. The speed is given in frames per second.
         */
        frameRate: number;
        /**
         * Whether or not the animation is looped or just plays once.
         */
        loop: boolean;
    }
    interface ISymbol {
        /** Symbol ID */
        num: number;
        /** Symbol Grid position */
        gridPosition: number;
        /** Animation Type */
        animType: string | string[];
        /** Play Symbol animation */
        playAnim(opts?: any): any;
        /** Stop Symbol animation */
        stopAnim(): void;
        /** Add event listener */
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): void;
        /** Remove event listener */
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): void;
        /** @returns if an even tis subscribed */
        hasEvent(type: string): boolean;
        /** Dispatches and event */
        fireEvent(type: string, data?: any): void;
        toString(): string;
    }
    interface ISpineSymbolData extends ISpineData, IAnimationSymbolData {
        animations: {
            [key: string]: string;
        };
    }
    interface ILayeredSymbolData extends IContainer, IAnimationSymbolData {
        layers: IStaticSymbolData[] | IAnimationSymbolData[] | ISpineSymbolData[];
    }
}
/**
 * Created by Asharma on 06-01-2017.
 */
declare namespace ingenuity.slot.symbol {
    /**
     * @abstract Class for all icon types
     */
    abstract class AbstractSymbol extends ui.Sprite implements ISymbol {
        /**
         * Defines the type of animation, possible options:
         * * ANIMATION_SPRITE: "sprite"
         * * ANIMATION_SPINE: "spine"
         * * ANIMATION_LAYERED: "layered"
         * * ANIMATION_SCALE: "scale"
         * * ANIMATION_BLINK: "blink"
         * * ANIMATION_FLASH: "flash"
         * * ANIMATION_NONE: "none"
         */
        skew: ui.Point;
        animType: string | string[];
        /** Symbol data JSON */
        protected json: IStaticSymbolData;
        /** Previous X position of Symbol */
        protected oldX: number;
        /** Previous Y position of Symbol */
        protected oldY: number;
        /** ID of Symbol */
        num: number;
        /** Defines if Symbol is animating */
        protected animating: boolean;
        protected animObj: {
            [key: string]: ui.Animation;
        } | ui.Animation | ITween;
        /** Grid position of Symbol */
        gridPosition: number;
        /** Z-Index of symbol */
        zIndex: number;
        /** Instance of Phaser Signal */
        private signals;
        constructor(id: number, json: IStaticSymbolData, frame?: number | string, name?: string, zIndex?: number);
        /**
         * Sets the Poster frame for JSON.
         * If `json.posterFrame` is give the the value will be use for poster frame else `json.frame`
         * @param json JSON for Symbol
         */
        protected setPosterFrame(json: IStaticSymbolData): void;
        /** Initialize function for Symbol class */
        protected abstract init(json: IStaticSymbolData, name?: string): void;
        /**
         * Play's the symbol animation
         * @param opts
         */
        abstract playAnim(opts: any): void;
        /**
         * Stop the current playing animation
         */
        abstract stopAnim(): void;
        /**
         * Stops all the animations of current symbol
         */
        abstract stopSymbolAllAnim(): void;
        /**
         * To add event listener on a Symbol.
         */
        on(type: string, handler: (evt?: IEvent | any, data?: IObject) => void, scope?: any, once?: boolean, data?: any, priority?: number): this;
        /**
         * Removes the event binding with an event
         * @param type Event type. Must be mentioned in the events.EventConstants
         * @param handler - Binding Function. if not defined then it will remove all handlers from this event
         * @param scope - handler binned to an object.
         */
        off(type: string, handler?: (evt: IEvent | any, data?: IObject) => void, scope?: any): this;
        /**
         * @returns Returns if the event exists
         */
        hasEvent(type: string): boolean;
        /**
         * Fires a custom event.
         * @param type type of event
         * @param data data to be transported with event
         */
        fireEvent(type: string, data?: any): void;
        /**
         * Use this to print the symbol data for Debugging purpose
         */
        toString(): string;
    }
}
declare namespace ingenuity.slot.symbol {
    /**
     * A symbol which don't use graphical animations but animates via code e.g. scale in/out effect etc.
     */
    class StaticSymbol extends AbstractSymbol {
        protected animObj: ITween;
        /**
         * Defaults for the symbol animation.
         */
        protected animDefaults: IStaticAnimation;
        /**
         * Creates a game symbol which can be animated using the script like scale, blink etc.
         * @param id - Symbol number provided by the game server api
         * @param json - Json for this particular symbol
         */
        constructor(id: number, json: IStaticSymbolData, name: string, zIndex: number);
        /**
         * Internal function initiates the symbol properties.
         * Sets the name of the symbol as per param name else sets the name `slotConstants.SlotConstants.StaticSymbolPrefix + this.num` <br>
         * If `json.animType` is available then sets the anim type accordingly else will be set to `SymbolBase.ANIMATION_NONE` <br>
         * Sets Symbol scale as per `json.scale` <br>
         * Sets Symbol scaleX & scaleY as per `json.scaleX` & `json.scaleY` <br>
         * Sets Symbol anchor as per `json.anchorX` & `json.anchorY` <br>
         * Sets Symbol pivot as per `json.regX` & `json.regY` <br>
         */
        protected init(json: IStaticSymbolData, name?: string): void;
        updateData(json: ISymbolData): void;
        /**
         * Plays the animation for the symbol through code. Following animation are currently supported through code:
         * * blink
         * * scale
         * * flash
         */
        playAnim(animName?: any): void;
        /**
         * Resets the changes made to the symbol after scale animation is completed
         */
        resetScaleAnim(): void;
        /**
         * Stops the symbols animation
         */
        stopAnim(): void;
        /**
         * Same as `stopAnim` function
         */
        stopSymbolAllAnim(): void;
    }
}
declare namespace ingenuity.slot.symbol {
    /**
     * Creates symbol which can be animated using atlas.
     */
    class AnimationSymbol extends AbstractSymbol {
        protected animObj: {
            [key: string]: ui.Animation;
        };
        /** Symbol JSON */
        protected json: IAnimationSymbolData;
        multiTextureArray: IObject;
        protected isMultiTexture: boolean;
        /**
         * Create a game symbol which can be animated using the texture atlas
         * @param id - Symbol number provided by the game server api
         * @param json - Json for this particular symbol
         */
        constructor(id: number, json: IAnimationSymbolData, name?: string, zIndex?: number);
        /**
         * Internal function initiates the symbol properties.
         * Sets the name of the symbol as per param name else sets the name `slotConstants.SlotConstants.AnimationPrefix + this.num` <br>
         * Sets the anim type if `json.animType` is available <br>
         * Sets Symbol scale as per `json.scale` <br>
         * Sets Symbol scaleX & scaleY as per `json.scaleX` & `json.scaleY` <br>
         * Sets Symbol anchor as per `json.anchorX` & `json.anchorY` <br>
         * Sets Symbol pivot as per `json.regX` & `json.regY` <br>
         */
        protected init(json: IAnimationSymbolData, name?: string): void;
        /**
         * @returns Confirms if the animation is present in `animObj`
         */
        hasAnimation(key: string): boolean;
        /**
         * Plays the animation from the texture atlas.
         * @param animName The name of the animation to be played.
         * @param stopFrame Define this if the icon should stop at a different frame than the poster or 0 frame.
         * @param callback Callback function to be executed once animation is completed.
         * @param cbScope Scope for Callback function
         */
        playAnim(animName?: any, stopFrame?: string, callback?: () => void, cbScope?: any): void;
        /**
         * Stops the symbols animation and sets the poster frame.
         * @param opts Animation ID to stop.
         */
        stopAnim(opts?: string): void;
        /**
         * Stops the symbols all animations and sets the poster frame.
         */
        stopSymbolAllAnim(): AnimationSymbol;
        /**
         * Resets the triggering animation to default by setting the poster frame.
         */
        resetTriggeringIcon(): AnimationSymbol;
        /**
         * Sets poster frame of a symbol.
         * @param json Symbol JSON
         */
        protected setPosterFrame(json: IAnimationSymbolData): void;
    }
}
declare namespace ingenuity.slot.symbol {
    /**
     * Symbol based on spine animations, these can not be stopped so need a separate animation for poster Frame.
     * Also if the game shows blur symbols while spinning then a blurring should also be part of the spine.
     */
    class SpineSymbol extends ui.SpineBase implements ISymbol {
        /** Symbol ID */
        num: number;
        /** Defines the grid position for symbol */
        gridPosition: number;
        /** Defines the type of animation */
        animType: string | string[];
        /** Defines z-Index for the Symbol */
        zIndex: number;
        skew: ui.Point;
        /** Symbol JSON */
        json: ISpineSymbolData;
        constructor(id: number, json: ISpineSymbolData, name?: string, zIndex?: number);
        /**
         * Initiates the symbol properties. <br>
         * e.g. Sets Symbol name from param `name` else sets to `slotConstants.SlotConstants.SpinePrefix + this.num` <br>
         * Sets animation type from `json.animType`. <br>
         * Sets Scale from `json.scale` or Sets Scale X & Scale Y from `json.scaleX` & `json.scaleY` <br>
         * Sets anchor from `json.anchorX` & `json.anchorY`
         * Sets Pivot points from `this.json.regX || 0, this.json.regY || 0`
         */
        protected init(json: ISpineSymbolData, name?: string): void;
        /**
         * Stops symbol animation by switching the animation to poster animation or always animation state.
         * @param offset Animation name to play
         */
        stopAnim(offset?: string): SpineSymbol;
        /**
         * Plays the spine animation.
         * @param animName The name of the animation to be played.
         * @param loop If animation  need to run in loop.
         * @param trackIndex Index name of the spine.
         */
        playAnim(animName?: any, loop?: boolean, trackIndex?: number): PIXI.spine.core.TrackEntry;
        /**
         * Stops symbol animations
         */
        stopSymbolAllAnim(opts?: string): SpineSymbol;
        /**
         * Resets the symbol back to poster animation.
         * @param {string} offset Animation name to play
         * @returns {SpineSymbol}
         */
        resetTriggeringIcon(offset?: string): SpineSymbol;
        /**
         * Sets the X of Spine symbol.
         */
        x: number;
        /**
         * Sets the Y of Spine symbol.
         */
        y: number;
    }
}
/**
 * Created by Asharma on 02-01-2017.
 */
declare namespace ingenuity.slot.symbol {
    /**
     * Creates a symbol in which multiple animations can be layered to create one single symbol.
     */
    class LayeredAnimationSymbol extends ui.Container implements ISymbol {
        /** Maintains the list of Symbols */
        protected symbolList: Array<AnimationSymbol | StaticSymbol | SpineSymbol>;
        /** Symbol JSON */
        json: IStaticSymbolData;
        /** Symbol ID */
        num: number;
        /** Symbol position in grid */
        gridPosition: number;
        /** Animation type */
        animType: string;
        /** Z-Index of Symbol */
        zIndex: number;
        skew: ui.Point;
        anchor: ui.Point;
        /**
         * @param id Symbol ID
         * @param json The symbol data should be in the form of an array which can have objects for each layer of animation.
         * @param name Name of symbol.
         * @param zIndex Z-Index for the symbol.
         */
        constructor(id: number, json: ILayeredSymbolData, name?: string, zIndex?: number);
        /**
         * Initializes the Symbol properties <br>
         * Sets the name of the symbol as per param name else sets the name `slotConstants.SlotConstants.LayeredPrefix + this.num` <br>
         * Sets the anim type if `json.animType` is available <br>
         * Sets Symbol scale as per `json.scale` <br>
         * Sets Symbol scaleX & scaleY as per `json.scaleX` & `json.scaleY` <br>
         * Sets Symbol anchor as per `json.anchorX` & `json.anchorY` <br>
         * Sets Symbol pivot as per `json.regX` & `json.regY` <br>
         * @param json Symbol JSON
         * @param name Symbol Name
         */
        protected init(json: ILayeredSymbolData, name?: string): void;
        /**
         * Reverts the icon to normal state from triggering animation.
         * @param offset Offset of the icon to reset.
         */
        resetTriggeringIcon(offset?: number): void;
        /**
         * Play's all the layers of symbol animation.
         */
        playAnim(opts?: any): void;
        /**
         * Stops the symbols animation, stops all the layers
         */
        stopAnim(): void;
        /**
         * Stops the symbols' all animations
         */
        stopSymbolAllAnim(): void;
        /**
         * Sets Poster frame for symbol.
         * @param json Symbol JSON
         */
        protected setPosterFrame(json: IAnimationSymbolData): void;
    }
}
declare namespace ingenuity.slot.symbol {
    /**
     * Base class for Symbols
     */
    class SymbolBase {
        /** Symbol JSON */
        json: ISymbolData;
        /** Defines the type of Symbol */
        symType: string | Array<string>;
        /** Symbol ID */
        symNum: number;
        /** Symbol position in Grid */
        gridPosition: number;
        /** Z-Index of symbol */
        zIndex: number;
        /** X Coordinate of symbol */
        x: number;
        /** Y Coordinate of symbol */
        y: number;
        /** Symbol width */
        width: number;
        /** Symbol height */
        height: number;
        /** Symbol Name */
        name: string;
        /** Symbol parent */
        parent: IDisplayObject;
        animation: string;
        /** Static Symbol for the Symbol */
        protected staticSym: StaticSymbol;
        /** Blur Static Symbol for the Symbol */
        protected blurSym: StaticSymbol;
        forceHide: boolean;
        /** Animation Symbol for the Symbol */
        protected animationSym: AnimationSymbol | SpineSymbol | LayeredAnimationSymbol;
        constructor(json: ISymbolData, id?: number);
        /**
         * Initializes the following Symbol properties -
         * * Z-Index: `json.zIndex` or defaults to 0
         * * X Coordinate: `json.x` or defaults to 0
         * * Y Coordinate: `json.y` or defaults to 0
         * * Symbol Type: `json.symType` or defaults to `SymbolConstants.TYPE_NORMAL`
         * * Symbol Name: `json.symName` or defaults to `Symbol_<symNum>`
         * * Grid position to -1
         * * parent to `null`
         * * Animation to `json.animation || json.defaultAnimType || SymbolConstants.ANIMATION_NONE`
         * Also Creates the following symbol type: <br>
         * * Static Symbol using method `this.createStatic(json)`
         * * Blur Symbol using method `this.createBlur(json)`
         * * Symbol Animation using method `this.createAnimation(json)`
         * @param json Symbol JSON
         */
        protected init(json: ISymbolData): void;
        /**
         * Creates new Static Symbol using `core.constructors.reelPanel.StaticSymbol`
         * @param json Symbol JSON
         */
        protected createStatic(json: ISymbolData): void;
        /**
         * If `json.blurSym` is available then creates new Static Symbol using `core.constructors.reelPanel.StaticSymbol`
         * else does nothing.
         *
         * You can set `json.blurSym` to true and it will use `json.staticSym` or you can provide data in `json.blurSym` and blur symbols will be created accordingly
         * @param json Symbol JSON
         */
        protected createBlur(json: ISymbolData): void;
        /**
         * Creates animation Symbol of following types - <br>
         * * Layered Animation symbol using `core.constructors.reelPanel.LayeredAnimationSymbol` if image is loaded.
         * * Spine Animation symbol using `core.constructors.reelPanel.SpineSymbol` if spine is loaded.
         * * Animation symbol using `core.constructors.reelPanel.AnimationSymbol` if image is loaded.
         * @param json Symbol JSON
         */
        protected createAnimation(json: ISymbolData): void;
        /**
         * Use this to print the symbol data for Debugging purpose
         */
        toString(): string;
        /**
         * Sets X & Y coordinates of Symbol.
         * @param x X coordinate of Symbol
         * @param y Y coordinate of Symbol
         */
        setPosition(x: number, y: number): void;
        /**
         * Sets the X coordinate of Static Symbol, blur symbol and animation
         * @param x X coordinate
         */
        setXPosition(x: number): void;
        /**
         * Sets the Y coordinate of Static Symbol, blur symbol and animation
         * @param y Y coordinate
         */
        setYPosition(y: number): void;
        /**
         * Removes the Symbol (including static, blur & animation) from parent.
         */
        returnToPool(): void;
        /**
         * @returns Returns the Animation symbol if `json.animSym` is `true` else returns the static symbol.
         */
        getStatic(): StaticSymbol | AnimationSymbol;
        /**
         * @returns Returns the Blur symbol if exists else returns `null`.
         */
        getBlur(): StaticSymbol;
        /**
         * @returns Returns the Symbol based on the type i.e. if spine then returns the Spin Symbol.
         * including the icon x, y and grid position.
         */
        getAnimation(): AnimationSymbol | SpineSymbol | StaticSymbol | LayeredAnimationSymbol;
        protected checkAllImagesLoaded(img: string[] | string): boolean;
    }
}
declare namespace ingenuity.slot.symbol {
    /**
     * This class creates a Icon pool for the individual reel.
     * The instance of this class can be used to get the Icons based on their id.
     */
    class SymbolFactory {
        private iconPos;
        private iconArray;
        private model;
        /**
         * Creates Icon
         * @param model Reel Panel Model
         */
        constructor(model: reelPanel.Model);
        /**
         * Create the Icon Pool based on their type using `core.constructors.reelPanel.SymbolBase`
         * @param model
         */
        private createIcons(model);
        /**
         * @returns Returns the SymbolBase instance of the symbol.
         * @param id id of the symbol
         */
        getSymbol(id: number): SymbolBase;
        /**
         * @returns Returns the icon from pool by Symbol Type.
         * @param type Type of symbol which is required.
         */
        getIconBySymType(type: String): SymbolBase[][];
    }
}
declare namespace ingenuity.slot.symbol {
    /**
     * Base class for Symbols
     */
    class SymbolBase2 extends SymbolBase {
        /** Symbol JSON */
        json: ISymbolData;
        /** Defines the type of Symbol */
        symType: string | Array<string>;
        /** Symbol ID */
        symNum: number;
        /** Symbol position in Grid */
        gridPosition: number;
        /** Z-Index of symbol */
        zIndex: number;
        /** X Coordinate of symbol */
        x: number;
        /** Y Coordinate of symbol */
        y: number;
        /** Symbol width */
        width: number;
        /** Symbol height */
        height: number;
        /** Symbol Name */
        name: string;
        /** Symbol parent */
        parent: IDisplayObject;
        animation: string;
        /** Static Symbol for the Symbol */
        protected staticSym: StaticSymbol;
        /** Blur Static Symbol for the Symbol */
        protected blurSym: StaticSymbol;
        forceHide: boolean;
        /** Animation Symbol for the Symbol */
        protected animationSym: AnimationSymbol | SpineSymbol | LayeredAnimationSymbol;
        protected isInit: boolean;
        constructor(json: ISymbolData, id?: number);
        /**
         * Initializes the following Symbol properties -
         * * Z-Index: `json.zIndex` or defaults to 0
         * * X Coordinate: `json.x` or defaults to 0
         * * Y Coordinate: `json.y` or defaults to 0
         * * Symbol Type: `json.symType` or defaults to `SymbolConstants.TYPE_NORMAL`
         * * Symbol Name: `json.symName` or defaults to `Symbol_<symNum>`
         * * Grid position to -1
         * * parent to `null`
         * * Animation to `json.animation || json.defaultAnimType || SymbolConstants.ANIMATION_NONE`
         * Also Creates the following symbol type: <br>
         * * Static Symbol using method `this.createStatic(json)`
         * * Blur Symbol using method `this.createBlur(json)`
         * * Symbol Animation using method `this.createAnimation(json)`
         * @param json Symbol JSON
         */
        protected init(json: ISymbolData): void;
        /**
         * If `json.blurSym` is available then creates new Static Symbol using `core.constructors.reelPanel.StaticSymbol`
         * else does nothing.
         *
         * You can set `json.blurSym` to true and it will use `json.staticSym` or you can provide data in `json.blurSym` and blur symbols will be created accordingly
         * @param json Symbol JSON
         */
        protected createBlur(json: ISymbolData): void;
        updateData(json: ISymbolData, id?: number): void;
        /**
         * Creates animation Symbol of following types - <br>
         * * Layered Animation symbol using `core.constructors.reelPanel.LayeredAnimationSymbol` if image is loaded.
         * * Spine Animation symbol using `core.constructors.reelPanel.SpineSymbol` if spine is loaded.
         * * Animation symbol using `core.constructors.reelPanel.AnimationSymbol` if image is loaded.
         * @param json Symbol JSON
         */
        protected createAnimation(json: ISymbolData): void;
        /**
         * @returns Returns the Animation symbol if `json.animSym` is `true` else returns the static symbol.
         */
        getStatic(frameName?: string): StaticSymbol | AnimationSymbol;
        /**
         * @returns Returns the Blur symbol if exists else returns `null`.
         */
        getBlur(): StaticSymbol;
        /**
         * @returns Returns the Symbol based on the type i.e. if spine then returns the Spin Symbol.
         * including the icon x, y and grid position.
         */
        getAnimation(): AnimationSymbol | SpineSymbol | StaticSymbol | LayeredAnimationSymbol;
    }
}
declare namespace ingenuity.slot.symbol {
    /**
     * This class creates a Icon pool for the individual reel.
     * The instance of this class can be used to get the Icons based on their id.
     */
    class SymbolFactory2 {
        private iconPos;
        private iconArray;
        private model;
        /**
         * Creates Icon
         * @param model Reel Panel Model
         */
        constructor(model: reelPanel.Model);
        /**
         * @returns Returns the SymbolBase2 instance of the symbol.
         * @param id id of the symbol
         */
        getSymbol(id: number): SymbolBase2;
        /**
         * @returns Returns the icon from pool by Symbol Type.
         * @param type Type of symbol which is required.
         */
        getIconBySymType(type: String): SymbolBase2[][];
    }
}
/**
 * Purpose of this class to set the response data, as per server parser class,
 * by set()/get() method.
 */
declare namespace ingenuity.slot.reelPanel {
    class Model {
        reelJson: IReel[];
        protected reelset: number[][];
        protected reelsets: number[][][];
        protected JSON: IReelPanel;
        totalSymbols: number;
        protected lockdReelArray: Array<boolean>;
        protected winLinData: Array<any>;
        protected currWinAnimationIndex: number;
        protected reelIndx: number[];
        winAnimCycleCount: number;
        playLineWinAnim: boolean;
        playWayWinAnim: boolean;
        protected reelGrd: Array<Array<number>>;
        protected stopPosition: Array<any>;
        protected paylinData: any;
        protected winboxData: any;
        protected mxPaylines: number;
        winningLines: any;
        protected paylinePositionData: Array<any>;
        defaultConfig: any;
        anticipationSpin: Array<number>;
        landingOnReel: Array<number>;
        spagettiVisible: boolean;
        winWayData: Array<any>;
        winWaySymbolData: any;
        wayUniqueWinData: Array<number[]>;
        protected isQuickSpin: boolean;
        stopHidden: boolean;
        fadeOutTimeWinBox: number;
        animOverlaySymOnToggle: boolean;
        constructor();
        /**
         * get noStopDelay(), inside this method set the noStopDelay boolean
         * by 'this.defaultConfig.noStopDelay' this method,
         * we can use this method in the game by this data 'boolean'
         */
        /**
         * set noStopDelay(), inside this method set the noStopDelay boolean,
         * by 'this.defaultConfig.noStopDelay' this method,
         */
        noStopDelay: boolean;
        /**
         * get noStartDelay(), inside this method set the noStartDelay boolean,
         * we can get this method as per set model data, at the time of spin start with delay or not,
         * by 'this.defaultConfig.noStartDelay' this method.
         */
        /**
         * set noStartDelay(), inside this method set the noStartDelay boolean,
         * we check at the time of spin start with delay or not,
         * by 'this.defaultConfig.noStartDelay' this method.
         */
        noStartDelay: boolean;
        /**
         * get spinDirection(), Inside this method reel spinDirection (1,0) up/down reel spins,
         * as per reel config data, which is set spinDirection(), method.
         *
         */
        /**
         * set spinDirection(), Inside this method set reel spinDirection (1,0) up/down reel spins,
         * as per reel config data, which is set by this method.
         *
         */
        spinDirection: number | number[];
        /**
         * get noStopBounce(),
         * method for noStopBounce, it will return boolean value true/false, we can used at the time of reel stop.
         */
        /**
         * set noStopBounce(),
         * this method for reel stop bounce boolean true/false, which is used at the time of reel stop.
         */
        noStopBounce: boolean;
        /**
         * get noStartBounce(),
         * method for get the noStartBounce boolean, which is set by set method noStartBounce.
         */
        /**
         * set noStartBounce(),
         * method for noStartBounce, set boolean true/false.
         */
        noStartBounce: boolean;
        /**
         * get quickSpinSpeed(),
         * method for get the quickSpinSpeed value, which is set by set method.
         */
        /**
         * set quickSpinSpeed(),
         * method for set the quickSpinSpeed value.
         */
        quickSpinSpeed: number;
        /**
         * get spinSpeed(),
         * method for get the spinSpeed value, which is set by  spinSpeed set method.
         */
        /**
         * set spinSpeed(),
         * method for set the spinSpeed value.
         */
        spinSpeed: number;
        /**
         * get stopDelay(),
         * method for get the stopDelay value, which is set by set stopDelay method.
         */
        /**
         * set stopDelay(),
         * method for set the stopDelay value.
         */
        stopDelay: number[];
        /**
         * get startDelay(),
         * we can get the start delay value by this method,
         * which is set by set startDelay method.
         */
        /**
         * set startDelay(),
         * we can set the start delay at the time of reel start by this method.
         */
        startDelay: number[];
        /**
         * get stopBounceTimeout(),
         * this method for get the stopbonuceTimeout value, which is set by set stopBounceTimeout.
         */
        /**
         * set stopBounceTimeout(),
         * this method for set the stopbonuceTimeout value.
         */
        stopBounceTimeout: number[];
        /**
         * get stopBounceTime(),
         * this method for get the stopBounceTime value, which is set by set stopBounceTime().
         */
        /**
         * set stopBounceTime(),
         * this method for set the stopBounceTime value,
         * we can set this value as per game requirement.
         */
        stopBounceTime: number[];
        /**
         * get startBounceAmt(),
         * by this method get the startBounceAmt value, which is set by set startBounceAmt().
         */
        /**
         * set startBounceAmt(),
         * this method for set the startBounceAmt value,
         * we can set as per the game requirement.
         */
        startBounceAmt: number[];
        /**
         * get startBounceTime(),
         * by this method get the startBounceTime value, which is set by the set startBounceTime() method.
         */
        /**
         * set startBounceTime(),
         * by this method set the startBounceTime value as per game.
         */
        startBounceTime: number[];
        /**
        * get startBounceTimeout(),
        * by this method get the startBounceTimeout value, which is set by set method of this.
        */
        /**
         * set startBounceTimeout(),
         * by this method set the startBounceTimeout value.
         */
        startBounceTimeout: number[];
        /**
         * get stopBounceAmt(),
         * by this method get the stopBounceAmt value, which is set by set method of this.
         */
        /**
         * set stopBounceAmt(),
         * by this method set the stopBounceAmt value.
         */
        stopBounceAmt: number[];
        /**
         * updateReelConfig(),
         * To update reel defaultConfig values from reel JSON.
         */
        protected updateReelConfig(): void;
        /**
         * get json(),
         * for get json data.
         */
        /**
         * set json(),
         * here set the reel json, total symbols in the game and excute updateReelConfig().
         */
        json: IReelPanel;
        /**
         * get reelsJson().
         * this method for get the reel json.
         */
        readonly reelsJson: IReel[];
        /**
         * set paylineJson(),
         * this method for the set payline data, winbox data etc.
         */
        paylineJson: any;
        /**
         * get paylineData(),
         * this method for the get payline data, which is set by set paylineJson() method.
         */
        readonly paylineData: any;
        /**
        * get winBoxData(),
        * this method for the get winBoxData data, which is set by set paylineJson() method.
        */
        readonly winBoxData: any;
        /**
         * getReelJson(),
         * in this method get reeljson with reel Id.
         */
        getReelJson(id: number): IReel;
        /**
         * setReelsets(),
         * In this method set the reelsets as per game/response data.
         *
         */
        setReelsets(value: number[][][], startSet?: number): void;
        /**
         * setReelset(),
         * In this method set the reelset data.
         *
         */
        setReelset(set: number): void;
        /**
         * getReelsets(),
         * In this method get the reelsets data which is set by  setReelset() method.
         *
         */
        getReelsets(): number[][][];
        /**
         * getReelset(),
         * In this method get the reelsets/currentReelset as per the setReelset() method.
         *
         */
        getReelset(set: number): number[][];
        /**
         * getCurrentReelset(),
         * In this method get the currentReelset data.
         *
         */
        getCurrentReelset(): number[][];
        /**
         * get symbolData(),
         * in this method get symbolsData form json file.
         */
        readonly symbolData: symbol.ISymbolData[];
        getSymbolBlurFrame(id: number): string;
        getSymbolStaticFrame(id: number): string;
        /**
         * getSymbolData(),
         * In this class get the symbol data as per there ID.
         */
        getSymbolData(id?: number): symbol.ISymbolData;
        /**
         * getSymbolHeight(),
         * In this class get the symbol height, as per the 'json.symHeight' file.
         */
        getSymbolHeight(id?: number): number;
        /**
         * getSymbolWidth(),
         * In this class get the symbol width, as per there json file.
         */
        getSymbolWidth(id?: number): number;
        /**
         * getSymbolSpacingY(),
         * In this method get the symbols spacing between the two symbol from the symbol data json.
         */
        getSymbolSpacingY(id?: number): number;
        /**
         * get numReels(),
         * In this method get the number of reel from the reel json.
         */
        readonly numReels: number;
        /**
         * get reelLayering(),
         * gets the reels layering from the 'json.reelLayering', which is the highest index reel will be on top.
         */
        readonly reelLayering: number[];
        /**
         * symbolLayeringType(),
         * symbol layering within a reel, canbe "pyramid", "standard", "default'"
         */
        symbolLayeringType(): string;
        /**
         * get anticipationSymbolCount(),
         * here we get the anticipation reel data count.
         */
        readonly anticipationSymbolCount: number;
        /**
         * get getAnticipationSymbolCount(),
         * here we get the anticipation reel data count with reelId.
         */
        getAnticipationSymbolCount(reelId: number): number;
        /**
         * get getAniticipationLoops(),
         * here we get the anticipationLoops count from the 'this.JSON.anticipationLoops'.
         */
        getAniticipationLoops(id: number): number;
        /**
         * getReelConfig(),
         * set the reelConfigData as per reel json.
         */
        getReelConfig(id: number): any;
        /**
         * getAnticipationDelay(),
         * set the anticipationDelay from reelJson.
         */
        getAnticipationDelay(id: number): number;
        /**
         * getAnticipationSpeed(),
         * set the anticipationSpeed from reelJson.
         */
        getAnticipationSpeed(id: number): number;
        /**
         * getAnticipationRunAfterDelay(),
         * set the getAnticipationRunAfterDelay from reelJson.
         */
        getAnticipationRunAfterDelay(id: number): number;
        /**
         * numDisplaySymbols(),
         * set the symbol Per Reel as per game from json.
         */
        numDisplaySymbols(id: number): number;
        /**
         * @ignore  unused.
         */
        isReelLocked(id: number): boolean;
        /**
         *  @ignore unused.
         */
        lockReel: number | boolean[];
        /**
         * get reelStopIndex(),
         * in this method get reelStop index value, which is set by set reelStopIndex() method.
         */
        /**
         * set reelStopIndex(),
         * in this method set reelStop index value.
         */
        reelStopIndex: number[];
        /**
         * get getReelStopIndex(),
         * in this method get reelIndx with Id.
         */
        getReelStopIndex(id: number): number;
        /**
         *  get lockedReels(), method for reel lock features.
         */
        readonly lockedReels: boolean[];
        /**
         *  get numReelsLocked(), here we get reellockArray data.
         */
        readonly numReelsLocked: number;
        /**
         * resetLockedReels(), here reset the lockdReelArray length.
         */
        resetLockedReels(): void;
        /**
         * get reelStops(),
         * inside this method get the reelStops positons, which is set on set reelStops().
         */
        /**
         * set reelStops(),
         * Inside this method set reel stopPosition as per server response.
         */
        reelStops: Array<any>;
        /**
         * getReelGridElement(),
         * in this method get reelGrid data as per [reel][row] index.

         */
        getReelGridElement(reel: number, row: number): number;
        /**
         * get reelGrid(),
         * in this method get reel grid, which is set by set method of reelGrid().
         */
        /**
         * set reelGrid(),
         * in this method set the reelGrid value as per server response data.
         */
        reelGrid: Array<Array<number>>;
        /**
         * set setReelGrid(),
         * in this method set reelGrid value with there Id.
         */
        setReelGrid(id: number, value: Array<number>): void;
        /**
         * get winLineData(),
         * in this method get the winLineData, which set by set winLineData().
         */
        /**
         * set winLineData(),
         * in this method set the winline data as per response data.
         */
        winLineData: Array<any>;
        /**
         * get winLineDataLength(),
         * inside this method get the winLineData length count.
         */
        readonly winLineDataLength: number;
        /**
         * get waysWinData(),
         * in this method get the waysWinData, as per set method of waysWinData.
         */
        /**
         * set waysWinData(),
         * in this method set the waysWinData data as per response data.
         */
        waysWinData: Array<any>;
        /**
         * get waysWinDataLength(),
         * inside this method get the winWayData length.
         */
        readonly waysWinDataLength: number;
        /**
         * resetCurrentWinAnimIndex(),
         * clear the win anim index.
         */
        resetCurrentWinAnimIndex(): void;
        /**
         * get nextWinAnimIndex(),
         * in this method get currWinAnimationIndex count as per game flow.
         */
        readonly nextWinAnimIndex: number;
        /**
         * get currentWinAnimIndex(),
         * in this method get currWinAnimationIndex.
         */
        /**
        * set currentWinAnimIndex(),
        * in this method set currWinAnimationIndex value.
        */
        currentWinAnimIndex: number;
        /**
         * get paylinesPosData(),
         * in this method get the paylinePositionData values.
         */
        /**
         * set paylinesPosData(),
         * in this method set the paylinePositionData values.
         */
        paylinesPosData: Array<any>;
        /**
         * get maxPaylines(),
         * In this method get total number of paylines in the game.
         */
        readonly maxPaylines: number;
        /**
        * get quickSpin(),
        * In this method get isQuickSpin boolean true/false.
        */
        /**
        * set quickSpin(),
        * In this method set isQuickSpin true/false.
        */
        quickSpin: boolean;
        reelsDirection(): string;
    }
}
declare namespace ingenuity.slot.reelPanel {
    import SymbolBase = symbol.SymbolBase;
    import StaticSymbol = symbol.StaticSymbol;
    import AnimationSymbol = symbol.AnimationSymbol;
    import LayeredAnimIcon = symbol.LayeredAnimationSymbol;
    import SpineSymbol = symbol.SpineSymbol;
    class Reel extends ui.Container {
        /** for reel set data  */
        protected reelSet: Array<number>;
        /** for reel Id and row*/
        reelId: number;
        rows: number;
        protected indx: number;
        /** for scroll data set */
        protected initScroll: number;
        /** count the loop counter value */
        protected intLoopCounter: number;
        /** for spin stop boolean true/false */
        protected stopSpinNow: boolean;
        protected stopIndex: number;
        /** for set the blurSpin is on or not */
        protected blurSpin: boolean;
        /** for set reel spin is start or not */
        spinNow: boolean;
        /** for set the max loop counter
         * reel ancicipation speed,
         * @intSpinSpeed for spin speed data.
         */
        protected intMaxLoops: number;
        protected anticipationSpeed: number;
        protected initSpinSpeed: number;
        /**for stop positions set data */
        protected stops: Array<number | number[]>;
        /** for get the model data */
        protected model: Model;
        /** for set the boolean value isSpining or not */
        protected isSpinning: boolean;
        /** for set the symbols is animated or not */
        protected isSymAim: boolean;
        protected animatingIcons: Array<any>;
        protected AllIcons: Array<any>;
        protected hiddenIcons: Array<any>;
        protected scatterIcons: Array<any>;
        /** for get all icons data form the symbols pool */
        protected iconsPool: slot.symbol.SymbolFactory;
        /** for get the spin direction value (0,1) up/down */
        protected spinDirection: number;
        /** for quick spin speed value set */
        protected quickSpinSpeed: number;
        /** for anticipation isAvailable or not */
        anticipationAvailable: boolean;
        protected symCollection: SymbolBase[];
        protected desiredFPSTime: number;
        /**
         * Creates a individual reel for the reel panel
         * @param pool
         * @param reelId
         * @param rows display rows of the reels
         * @param model
         */
        constructor(reelId: number, rows: number, model: Model, pool?: slot.symbol.SymbolFactory);
        /**
         * creates a reel mask to hide the extra top and bottom symbols.
         *
         */
        reelMaskOn(): void;
        /**
         * Inside this function,
         * Removes the reel mask so that animations can play outside the reel area.
         */
        reelMaskOff(): void;
        /**
         * Internal function which creates a reelSubset and stores it in the model's reelgrid.s
         * @param stopPos
         * @returns {Array<number>}
         */
        protected reelSubset(stopPos: number): Array<number>;
        /**
         * Here get an icon from the pool.
         * @param id
         * @returns {StaticSymbol|AnimationSymbol|LayeredAnimIcon}
         */
        getSymbol(id: number): SymbolBase;
        /**
         * it's return the static symbols data.
         */
        getSymbolStatic(id: number): StaticSymbol | AnimationSymbol;
        /**
         * Return the blur symbol data.
         */
        getSymbolBlur(id: number): StaticSymbol;
        /**
         * Return the animtion symbol data.
         */
        getSymbolAnimation(id: number): StaticSymbol | AnimationSymbol | SpineSymbol | LayeredAnimIcon;
        /**
         * Get Icons by their symbol type.
         * @param type
         */
        getIconBySymType(type: string): SymbolBase[][];
        /**
         * Inside this function,
         * fetches the icons from the pool and place then in the grid as the reelgrid.
         * @param reelGrid
         */
        protected setStaticReel(reelGrid: Array<number>): void;
        /**
         * Here hide symbols on force stop.
         */
        forceHideSyms(num: number): void;
        /**
         * Here fire the symbols animation evt.
         * @param evt
         */
        protected onSymbolAnimationEvent(evt?: any): void;
        /**
         * Fetches the next symbol stop index from the reelset based on the stop position.
         * @param symbolId
         * @returns {number}
         */
        protected getStopIndex(symbolId: number): number;
        /**
         * In side this function,
         * Initializes the reels and sets the symbols to display on the grid when game starts.
         * based on reel set data.
         * @param stopPos
         */
        init(stopPos: number | number[]): void;
        /**
         * Returns the index of the reelstop for fetching the symbol for reel spin.
         * @returns {number}
         */
        protected readonly index: number;
        /**
         * Here get the next index form the reel based on there direction.
         * We need next index to get symbol from reel.
         */
        protected readonly upindex: number;
        /**
         * Initializes the variables for spinning and starts the bounce tween
         * inside this fuction reel spining start based on there direction, which we set on model/json file.
         * @param isBlur
         */
        spin(isBlur: boolean): void;
        /**
         * Internal function called once the bounce has finished
         * and sets a variable which starts the movement of the reels,
         * based on current game state.
         * @fires 'slot.slotConstants.SlotEventConstants.ALL_REEL_SPINING'
         * @fires 'slot.slotConstants.SlotEventConstants.FG_ALL_REEL_SPINING'
         * @private
         */
        protected _startLoop(): void;
        /**
         * Inside this function sorts symbols in the reel in the following order:
         * Scatter
         * Wild
         * High
         * Overlap
         * Normal
         * Underlap
         */
        sortIconsOnType(): void;
        /**
         * Inside this function handling spin reel logic as per the reel set data/response data.
         * Handling following things inside this function:
         * * It first moves the position of the reel when it crosses a particular length.
         * * It's 'y' position is resetted and each symbol is moved one position down and a new symbol is added at the top.
         * * Checking whether the reel has moved beyond the symbol height, if yes then its y is reset to 0 and loop is incremented.
         * * Shifting each symbol one position down and removing symbol which go two positions down the visible area.
         * * Check for gridPosition based on spinDirection. If symbol is offscreen, remove it.
         * * Checking if the stops have been set then pick symbols from stop positions otherwise pick from the reelset.
         * * Based on direction, we need to pick index to get next symbol from reel etc..
         */
        updateSpin(deltaTime: number): void;
        /**
         * Inside this functin fire the reel stopping events based on the current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPING'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPING'
         */
        protected handleReelStop(): void;
        /**
         * * This function is called once the stopping bounce has finished.
         * * It resets all the variables used for spinning.
         * * Also calls the reel_Stopped event based on current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPED'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPED'
         * @private
         */
        protected spinDone(): void;
        /**
         * This function is called to set the stop reel grid and eventually stop the reel.
         * @param stopsArray
         */
        setStops(stopsArray: number | number[] | IObject): void;
        /**
         * This function for fore stop the reels,after response received from server.
         * @param stopsArray
         */
        forceStopReel(stopsArray: number | number[]): void;
        /**
         * Inside this function play the symbol animtion for line and ways game as per there positions.
         * @param pos
         * @param symReel
         * @param animationOnCurrentWinLine
         */
        playAnimByPos(pos: number, symReel?: ui.Container, opts?: SymAnimReel): void;
        /**
         * Inside this function play the animation with fetch Id of the symbols.
         */
        playAnimByID(id: number, pos: number, symReel?: ui.Container, opts?: any): SymbolBase;
        /**
         * Inside this function,
         * Plays animation for scatter symbols for triggering a feature.
         * @param id
         * @param pos
         * @param opts
         * @param symReel
         * @returns {StaticSymbol|AnimationSymbol}
         */
        playTriggerAnimByID(id: number, pos: number, symReel?: ui.Container, opts?: any): SymbolBase;
        /**
         * Inside this function stop the animatons as per there Id,
         * show the static frame of the symbols.
         */
        stopAnimByPos(pos: number): void;
        /**
         * Here stops all symbols animation.
         */
        stopAllAnim(): void;
        /**
         * Returns a symbol at the provided grid position.
         * If that symbol is animating then this will return null.
         * @param pos
         * @returns {any}
         */
        getStaticByPos(pos: number): StaticSymbol | AnimationSymbol;
        /**
         * Returns a symbol at the provided grid position.
         * If that symbol is animating then this will return null.
         * @param pos
         * @returns {any}
         */
        getAnimationByPos(pos: number): AnimationSymbol | SpineSymbol | StaticSymbol | LayeredAnimIcon;
        /**
         * Returns a symbol at the provided grid position.
         * If that symbol is animating then this will return null.
         * @param pos
         * @returns {any}
         */
        getSymbolByPos(pos: number): SymbolBase;
        /**
         * Returns number of visible rows for this reel.
         */
        getNumSymbols(): number;
        /**
        * Returns symbols on reel.
        */
        getSymbolsOnReel(): SymbolBase[];
        /**
         * Returns total number of symbols in the reel.
         * This should be number of rows + 2.
         * @returns {number}
         */
        getTotalNumSymbols(): number;
        /**
         * Returns the stops positons.
         */
        getStops(): (number | number[])[];
        /**
         * Returns boolean value,
         * true if this reel is spinning, this includes the bounces.
         * @returns {boolean}
         */
        getIsSpining(): boolean;
        /**
         * Returns boolean value,
         * true if reel is spinning but this excludes the initial bounce.
         */
        readonly isSpinNow: boolean;
        /**
         * Change the loops or the number of icons,
         * which should be placed before placing the actual symbols.
         * This changed generally before anticipation.
         * @param value
         */
        setMaxLoops(value: number): void;
        /**
         * Sets the anticipation speed. This will be added into the current speed.
         * @param value
         */
        setAnticipationSpeed(value: number): void;
        toString(): string;
    }
}
declare namespace ingenuity.slot.reelPanel {
    import SymbolBase2 = symbol.SymbolBase2;
    import StaticSymbol = symbol.StaticSymbol;
    import AnimationSymbol = symbol.AnimationSymbol;
    import LayeredAnimIcon = symbol.LayeredAnimationSymbol;
    import SpineSymbol = symbol.SpineSymbol;
    class Reel2 extends ui.Container {
        /** for reel set data  */
        protected reelSet: Array<number>;
        /** for reel Id and row*/
        reelId: number;
        rows: number;
        protected indx: number;
        /** for scroll data set */
        protected initScroll: number;
        /** count the loop counter value */
        protected intLoopCounter: number;
        /** for spin stop boolean true/false */
        protected stopSpinNow: boolean;
        protected stopIndex: number;
        /** for set the blurSpin is on or not */
        protected blurSpin: boolean;
        /** for set reel spin is start or not */
        spinNow: boolean;
        /** for set the max loop counter
         * reel ancicipation speed,
         * @intSpinSpeed for spin speed data.
         */
        protected intMaxLoops: number;
        protected anticipationSpeed: number;
        protected initSpinSpeed: number;
        /**for stop positions set data */
        protected stops: Array<number | number[]>;
        /** for get the model data */
        protected model: Model;
        /** for set the boolean value isSpining or not */
        protected isSpinning: boolean;
        /** for set the symbols is animated or not */
        protected isSymAim: boolean;
        protected animatingIcons: Array<any>;
        protected AllIcons: Array<any>;
        protected hiddenIcons: Array<any>;
        protected scatterIcons: Array<any>;
        /** for get all icons data form the symbols pool */
        protected iconsPool: slot.symbol.SymbolFactory2;
        /** for get the spin direction value (0,1) up/down */
        protected spinDirection: number;
        /** for quick spin speed value set */
        protected quickSpinSpeed: number;
        /** for anticipation isAvailable or not */
        anticipationAvailable: boolean;
        protected symCollection: SymbolBase2[];
        protected desiredFPSTime: number;
        protected removedSymbol: any;
        protected strip1: ui.Container;
        protected strip2: ui.Container;
        protected visibleReel: ui.Container;
        protected hiddenReel: ui.Container;
        protected speed: number;
        protected maxSpeed: number;
        protected acceleration: number;
        protected deceleration: number;
        protected minSpeed: number;
        protected jerkDistance: number;
        protected symCollection2: SymbolBase2[];
        protected stopUpdateReel: boolean;
        protected counter: number;
        static isStoppingReel: boolean;
        static isForcedStop: boolean;
        protected bounced: boolean;
        /**
         * Creates a individual reel for the reel panel
         * @param pool
         * @param reelId
         * @param rows display rows of the reels
         * @param model
         */
        constructor(reelId: number, rows: number, model: Model, pool?: slot.symbol.SymbolFactory2);
        /**
         * creates a reel mask to hide the extra top and bottom symbols.
         *
         */
        reelMaskOn(): void;
        /**
         * Inside this function,
         * Removes the reel mask so that animations can play outside the reel area.
         */
        reelMaskOff(): void;
        /**
         * Internal function which creates a reelSubset and stores it in the model's reelgrid.s
         * @param stopPos
         * @returns {Array<number>}
         */
        protected reelSubset(stopPos: number): Array<number>;
        /**
         * Here get an icon from the pool.
         * @param id
         * @returns {StaticSymbol|AnimationSymbol|LayeredAnimIcon}
         */
        getSymbol(id: number): SymbolBase2;
        /**
         * it's return the static symbols data.
         */
        getSymbolStatic(id: number): StaticSymbol | AnimationSymbol;
        /**
         * Return the blur symbol data.
         */
        getSymbolBlur(id: number): StaticSymbol;
        /**
         * Return the animtion symbol data.
         */
        getSymbolAnimation(id: number): StaticSymbol | AnimationSymbol | SpineSymbol | LayeredAnimIcon;
        /**
         * Get Icons by their symbol type.
         * @param type
         */
        getIconBySymType(type: string): SymbolBase2[][];
        protected setStaticReel(reelGrid: Array<number>, reelObj?: ui.Container): void;
        protected setStaticReelTexture(reelGrid: Array<number>, reelObj?: ui.Container): void;
        /**
         * Here hide symbols on force stop.
         */
        forceHideSyms(num: number): void;
        /**
         * Here fire the symbols animation evt.
         * @param evt
         */
        protected onSymbolAnimationEvent(evt?: any): void;
        /**
         * Fetches the next symbol stop index from the reelset based on the stop position.
         * @param symbolId
         * @returns {number}
         */
        protected getStopIndex(symbolId: number): number;
        init(stopPos: number | number[]): void;
        /**
         * Returns the index of the reelstop for fetching the symbol for reel spin.
         * @returns {number}
         */
        protected readonly index: number;
        /**
         * Here get the next index form the reel based on there direction.
         * We need next index to get symbol from reel.
         */
        protected readonly upindex: number;
        /**
         * Initializes the letiables for spinning and starts the bounce tween
         * inside this fuction reel spining start based on there direction, which we set on model/json file.
         * @param isBlur
         */
        spin(isBlur: boolean): void;
        /**
         * Internal function called once the bounce has finished
         * and sets a letiable which starts the movement of the reels,
         * based on current game state.
         * @fires 'slot.slotConstants.SlotEventConstants.ALL_REEL_SPINING'
         * @fires 'slot.slotConstants.SlotEventConstants.FG_ALL_REEL_SPINING'
         * @private
         */
        protected _startLoop(): void;
        /**
         * Inside this function sorts symbols in the reel in the following order:
         * Scatter
         * Wild
         * High
         * Overlap
         * Normal
         * Underlap
         */
        sortIconsOnType(): void;
        /**
         * Inside this function handling spin reel logic as per the reel set data/response data.
         * Handling following things inside this function:
         * * It first moves the position of the reel when it crosses a particular length.
         * * It's 'y' position is resetted and each symbol is moved one position down and a new symbol is added at the top.
         * * Checking whether the reel has moved beyond the symbol height, if yes then its y is reset to 0 and loop is incremented.
         * * Shifting each symbol one position down and removing symbol which go two positions down the visible area.
         * * Check for gridPosition based on spinDirection. If symbol is offscreen, remove it.
         * * Checking if the stops have been set then pick symbols from stop positions otherwise pick from the reelset.
         * * Based on direction, we need to pick index to get next symbol from reel etc..
         */
        updateSpin(deltaTime: number): void;
        protected updateSpinTopDown(deltaTime: number): void;
        protected updateSpinBottomUp(deltaTime: number): void;
        protected updateStopReelTopDown(deltaTime: number): void;
        protected updateStopReelBottomUp(deltaTime: number): void;
        protected stopReelsFinally(): void;
        protected checkToStopTopDown(reelStripId: number): void;
        protected checkToStopBottomUp(reelStripId: number): void;
        /**
         * Inside this functin fire the reel stopping events based on the current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPING'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPING'
         */
        private handleReelStop();
        /**
         * * This function is called once the stopping bounce has finished.
         * * It resets all the letiables used for spinning.
         * * Also calls the reel_Stopped event based on current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPED'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPED'
         * @private
         */
        protected spinDone(): void;
        /**
         * This function is called to set the stop reel grid and eventually stop the reel.
         * @param stopsArray
         */
        setStops(stopsArray: number | number[] | IObject): void;
        /**
         * This function for fore stop the reels,after response received from server.
         * @param stopsArray
         */
        forceStopReel(stopsArray: number | number[]): void;
        /**
         * Inside this function play the symbol animtion for line and ways game as per there positions.
         * @param pos
         * @param symReel
         * @param animationOnCurrentWinLine
         */
        playAnimByPos(pos: number, symReel?: ui.Container, opts?: SymAnimReel): void;
        /**
         * Inside this function play the animation with fetch Id of the symbols.
         */
        playAnimByID(id: number, pos: number, symReel?: ui.Container, opts?: any): symbol.SymbolBase;
        /**
         * Inside this function,
         * Plays animation for scatter symbols for triggering a feature.
         * @param id
         * @param pos
         * @param opts
         * @param symReel
         * @returns {StaticSymbol|AnimationSymbol}
         */
        playTriggerAnimByID(id: number, pos: number, symReel?: ui.Container, opts?: any): SymbolBase2;
        /**
         * Inside this function stop the animatons as per there Id,
         * show the static frame of the symbols.
         */
        stopAnimByPos(pos: number): void;
        /**
         * Here stops all symbols animation.
         */
        stopAllAnim(): void;
        /**
         * Returns a symbol at the provided grid position.
         * If that symbol is animating then this will return null.
         * @param pos
         * @returns {any}
         */
        getStaticByPos(pos: number): StaticSymbol | AnimationSymbol;
        /**
         * Returns a symbol at the provided grid position.
         * If that symbol is animating then this will return null.
         * @param pos
         * @returns {any}
         */
        getAnimationByPos(pos: number): AnimationSymbol | SpineSymbol | StaticSymbol | LayeredAnimIcon;
        /**
         * Returns a symbol at the provided grid position.
         * If that symbol is animating then this will return null.
         * @param pos
         * @returns {any}
         */
        getSymbolByPos(pos: number): SymbolBase2;
        /**
         * Returns number of visible rows for this reel.
         */
        getNumSymbols(): number;
        /**
        * Returns symbols on reel.
        */
        getSymbolsOnReel(): SymbolBase2[];
        /**
         * Returns total number of symbols in the reel.
         * This should be number of rows + 2.
         * @returns {number}
         */
        getTotalNumSymbols(): number;
        /**
         * Returns the stops positons.
         */
        getStops(): (number | number[])[];
        /**
         * Returns boolean value,
         * true if this reel is spinning, this includes the bounces.
         * @returns {boolean}
         */
        getIsSpining(): boolean;
        /**
         * Returns boolean value,
         * true if reel is spinning but this excludes the initial bounce.
         */
        readonly isSpinNow: boolean;
        symbolCollectionArray(): SymbolBase2[];
        /**
         * Change the loops or the number of icons,
         * which should be placed before placing the actual symbols.
         * This changed generally before anticipation.
         * @param value
         */
        setMaxLoops(value: number): void;
        /**
         * Sets the anticipation speed. This will be added into the current speed.
         * @param value
         */
        setAnticipationSpeed(value: number): void;
        toString(): string;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class SymAnimReel extends ui.Container {
        protected reelId: number;
        protected rows: number;
        model: Model;
        protected isSymAim: boolean;
        /**
         * These reels contains the symbols while they are animating. only the sprite animation symbols are placed in these reels.
         * @param game
         * @param reelId
         * @param rows
         * @param model
         */
        constructor(game: bridge.Game, reelId: number, rows: number, model: Model);
        /**
         * sortIconsOnType(),
         * inside this function, sorts the symbols while they are animating.
         */
        sortIconsOnType(): void;
        /**
         * This function has been modified to so that it only adds some specific type of objects only.
         * @param child
         * @returns {ingenuity.slot.reelPanel.SymAnimReel}
         */
        addChild(child: PIXI.DisplayObject): ui.Container;
        /**
         * This function stop for all symbols animations.
         */
        stopSymbolAnimation(): void;
    }
}
/**
 * Created by Asharma on 28-02-2017.
 */
declare namespace ingenuity.slot.reelPanel {
    /**
    * Purpose of this class to handle the Win presentation of game flow,
    * how to game win presentation flow/will play as per game.
    */
    class WinPresentationPanel extends ui.Container {
        protected animMode: number;
        protected isStopSymAnim: boolean;
        protected toggleingContinue: boolean;
        protected animateSymbol: boolean;
        SHORT_ANIM_MODE: number;
        LONG_ANIM_MODE: number;
        FREE_SPIN_ANIM_MODE: number;
        WIN_LINE_ANIM_TIMEOUT: number;
        WIN_LINE_ANIM_START_AFTER: number;
        ALL_WIN_ANIM_TIMEOUT: number;
        WIN_SCATTER_ANIM_TIMEOUT: number;
        WAY_ANIM_COUNT: number;
        BLINK_ANIM_CYCLES: number;
        LINE_ANIM_CYCLES: number;
        FS_LINE_ANIM_CYCLES: number;
        protected animModeArray: string[];
        protected numCycleCount: number;
        protected reelPanel: ReelPanel;
        protected model: Model;
        constructor(game: bridge.Game, reelPanel: ReelPanel);
        /**
         * reelLayering(),
         * reel layering according to entry in json,
         * default is [0,1,2,3,4] as per indexing.
         */
        protected reelLayering(game: bridge.Game, reelPanel: ReelPanel): void;
        /**
         * subscribeEvents(),
         * here subscribe win presentation function
         * based on current game state.
         */
        subscribeEvents(): void;
        /**
         * unsubscribeEvents(),
         * here unsubscribe win presentation function events for base and free game.
         */
        unsubscribeEvents(): void;
        /**
         * playSymbolAnimation(),
         * here play the symbol animation as per reel grid position/pays data positions.
         */
        protected playSymbolAnimation(reel: number, row: number, animationOnCurrentWinLine?: boolean): void;
        /**
         * playSymbolAnimationByID(),
         * inside this funtion, symbols animation plays by symbol Id.
         */
        protected playSymbolAnimationByID(symbolID: number, reel: number, row: number, opts?: any): ui.Container | symbol.SymbolBase;
        /**
         * playSymbolTriggerAnimationByID(),
         * here play the trigger animation as per there Id,
         * when symbol animation plays as a triggering animation.
         */
        protected playSymbolTriggerAnimationByID(symbolID: number, reel: number, row: number, opts?: any): ui.Container | symbol.SymbolBase;
        /**
         * playScatterWinAnimations(),
         * here play scatter animations as per reel data, when scatter symbol animation in win data.
         */
        protected playScatterWinAnimations(evt: any): void;
        /**
         * startWinLineAnimation(),
         * inside this funtion, start the paylines toggling as per there data,
         * excute 'playLineWinAnimations()'.
         */
        startWinLineAnimation(evt: any): void;
        /**
         * playLineWinAnimations(),
         * function excute when paylines toggling starts, also inside this function set animateSymbol
         * true to animate Icons on win lines.
         */
        protected playLineWinAnimations(numCycles: number): void;
        /**
         * animateWinLineSymbol(),
         * here play the animate Icons on win lines.
         */
        protected animateWinLineSymbol(winLineData: IWinLineObject): void;
        /**
         * animateNextWinLine(),
         * here fire the events for next win presentation based on current game state for next action.
         * @fires 'slotConstants.SlotEventConstants.LINE_ANIMATION_ENDED'
         * @fires 'slotConstants.SlotEventConstants.FG_LINE_ANIMATION_ENDED'
         */
        protected animateNextWinLine(): void;
        /**
         * winCycleCompleted(),
         * here fire the event for winCycleComplete based on current game state.
         * @fires 'slotConstants.SlotEventConstants.WIN_CYCLE_COMPLETED'
         * @fires 'slotConstants.SlotEventConstants.FG_WIN_CYCLE_COMPLETED'
         */
        protected winCycleCompleted(): void;
        /**
         * showWinLine(),
         * here fire the events for line anim start based on current game state.
         * @fires 'slotConstants.SlotEventConstants.LINE_ANIMATION_STARTED'
         * @fires 'slotConstants.SlotEventConstants.FG_LINE_ANIMATION_STARTED'
         * also call event for animatenextWinLine with a delay by
         * @fires 'slotConstants.SlotConstants.TimerAnimateNextWinLine'
         */
        protected showWinLine(winLineData: any, currentWinLine: any): void;
        /**
         * animateAllWin(),
         * here play the all winning symbols animates together.
         */
        protected animateAllWin(winLineData: any): void;
        /**
         * startWayWinAnimation(),
         * here call the playWaysWinAnimations, for ways win animation starts.
         */
        startWayWinAnimation(evt: any): void;
        /**
         * playWaysWinAnimations(),
         * It's excute when ways animstart, also set animateSymbol
         * true to animate Icons on ways win data.
         */
        protected playWaysWinAnimations(numCycles: number): void;
        /**
         * animateWayWin(),
         * here start the symbol ways win animation by fire event based on current game state.
         * @fires 'slotConstants.SlotEventConstants.WAY_ANIMATION_STARTED'
         * @fires 'slotConstants.SlotEventConstants.FG_WAY_ANIMATION_STARTED'
         */
        protected animateWayWin(winWayData: IWinLineObject, uniquePosition?: Array<any>): void;
        /**
         * animateNextWayWin(),
         * call the nexWaysWin as per model data/sequence and fire events based on current game state.
         * @fires 'slotConstants.SlotEventConstants.WAY_ANIMATION_ENDED'
         * @fires 'slotConstants.SlotEventConstants.FG_WAY_ANIMATION_ENDED'
         */
        protected animateNextWayWin(): void;
        /** showWayWin(),
         * here call ways win animation start events based on current game state.
         * @fires 'slotConstants.SlotEventConstants.WAY_ANIMATION_STARTED'
         * @fires 'slotConstants.SlotEventConstants.FG_WAY_ANIMATION_STARTED'
         *
         */
        protected showWayWin(wayWinData: any, currentWinLine: any): void;
        /**
         * stopAllWinAnimations(),
         * here stop the all symbols animation, kill all delay timer
         * and call the showAllSymbols() for static symbols.
         */
        protected stopAllWinAnimations(): void;
        /**
         * clearSymReels(),
         * for stop the all symbols animation as per reel data.
         */
        protected clearSymReels(): void;
        /**
         * setAnimMode(),
         * here set the animMode value
         */
        setAnimMode(value: number): void;
        /**
         * getAnimMode(),
         * here get the animMode value, which is set by setAnimMode() method.
         */
        getAnimMode(): number;
        /**
         * getAnimModeLongName(),
         * here get the animMode array value.
         */
        getAnimModeLongName(): string;
        /**
         * setStopSymAnimOnWinCycle(),
         * here set the animation stop boolean true/false as per there data.
         */
        setStopSymAnimOnWinCycle(value: boolean): void;
        /**
         * getModel(),
         * for get the model data.
         */
        getModel(): Model;
        /**
         * setAnimateSymbol(),
         * in this method set the animation symbols true/false.
         */
        setAnimateSymbol(value: boolean): void;
        /**
         * getAnimateSymbol(),
         * in this method get the animateSymbol boolean is it true/false.
         */
        getAnimateSymbol(): boolean;
        /**
         * setToggleingContinue(),
         * here set the boolean value of toggle continue as per game flow.
         */
        setToggleingContinue(value: boolean): void;
        /**
         * getToggleingContinue(),
         * here get the toggle continue boolean value for continue toggle or not after one cycles etc.
         */
        getToggleingContinue(): boolean;
    }
}
/**
 * Created by bjindal on 10-04-18.
 * This class is created of creating reel container within the containers,
 * which contain animations to be layered above other animating symbols.
 */
declare namespace ingenuity.slot.reelPanel {
    class SymAnimOverlayReel extends ui.Container {
        protected reelId: number;
        protected rows: number;
        model: Model;
        protected isSymAim: boolean;
        /**
         * These reels contains the symbols while they are animating. only the sprite animation symbols are placed in these reels.
         * @param game
         * @param reelId
         * @param rows
         * @param model
         */
        constructor(game: bridge.Game, reelId: number, rows: number, model: Model, contName: string);
        /**
         * sortIconsOnType(),
         * inside this function, sorts the symbols while they are animating according to json entry.
         */
        sortIconsOnType(): void;
        /**
         * This function has been modified to so that it only adds some specific type of objects only.
         * @param child
         * @returns {ingenuity.slot.reelPanel.SymAnimOverlayReel}
         */
        addChild(child: PIXI.DisplayObject): ui.Container;
        /**
         * stopSymbolAnimation(),
         * This function stop for all symbols animations.
         */
        stopSymbolAnimation(): void;
    }
}
/**
 * Created by bjindal on 10-04-18.
 * In this class handled the reelLayering of the reels, any number of reel panel containers can be created by configuring it in json.
 * e.g. "animContainers": ["scatterContainer", "wildContainer"], is entry we can give in json to create 2 containers
 * above the normal anim reel containers.
 * in the symbolData the scatter should have an entry "parent" : "scatterContainer" (i.e)
 * the name of the parent container on which it is to be added when animating.
 */
declare namespace ingenuity.slot.reelPanel {
    class WinPresentationOverlayPanel extends ui.Container {
        protected toggleingContinue: boolean;
        protected animateSymbol: boolean;
        protected reelPanel: ReelPanel;
        protected model: Model;
        protected symOverlayReels: Array<SymAnimOverlayReel>;
        constructor(game: bridge.Game, reelPanel: ReelPanel, contName: string);
        /**
         * reelLayering(),
         * here we add the symbols Overlay Reels as per there json data.
         * @param game
         * @param reelPanel
         */
        protected reelLayering(game: bridge.Game, reelPanel: ReelPanel): void;
        /**
         * getModel(),
         * for get the model data.
         */
        getModel(): Model;
        /**
         * setAnimateSymbol(),
         * here we set the animated symbols is it true/false.
         */
        setAnimateSymbol(value: boolean): void;
        /**
         * getAnimateSymbol(),
         * here we get the animation symbols data true/false, which is set by setAnimateSymbol()
         * method.
         */
        getAnimateSymbol(): boolean;
        /**
         * setToggleingContinue(),
         * here set the toggleing animation boolean value as per game flow.
         */
        setToggleingContinue(value: boolean): void;
        /**
         * getToggleingContinue(),
         * here get the toggleing animation boolean value true/false,
         * which is set by set setToggleingContinue() method.
         */
        getToggleingContinue(): boolean;
        /**
         * getAnimReels(),
         * get the symbols overlay reels.
         */
        getAnimReels(): Array<SymAnimOverlayReel>;
        /**
         * removeChildren(),
         * remove the all symbols overlay reels.
         * @param beginIndex
         * @param endIndex
         */
        removeChildren(beginIndex?: number, endIndex?: number): PIXI.DisplayObject[];
        /**
         * stopSymbolAnimation(),
         * stop the all symbols overlay symbols animations as per there data.
         */
        stopSymbolAnimation(): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class ReelPanel extends ui.Container {
        /**  for model data  */
        protected model: Model;
        /**  for reel json data  */
        json: IReelPanel;
        /**  for reels arrays  */
        protected reels: Array<Reel>;
        /**  for symbols anim reels  */
        protected symAnimReels: Array<SymAnimReel>;
        /**  for symbols AnimOverlay Containers */
        protected symAnimOverlayContainers: Array<WinPresentationOverlayPanel>;
        /** for reel stop Id */
        protected stopIds: Array<number>;
        /** for boolean value set stop all spins */
        protected stopSpinAll: boolean;
        /** for reels stopped*/
        protected reelsStopped: boolean[];
        /** for set paused boolean value */
        protected paused: boolean;
        /** for set boolean value reel is spining or not  */
        isSpining: boolean;
        /** for set anim Mode */
        protected animMode: number;
        /** for set initiated boolean */
        protected initiated: boolean;
        /** for reel stop boolean value */
        protected stopNow: boolean;
        /** for set the  anticipation Delay time */
        protected anticipationDelayAmt: number;
        /**
         * Constructs the reel panel for the slot game. it controls the reel spin
         * @param game
         * @param model
         */
        constructor(game: bridge.Game, model: Model);
        /**
         * reelLayering(),
         * reel layering according to entry in json, default is [0,1,2,3,4].
        */
        protected reelLayering(): void;
        /**
         * Show a reel grid based on the provided values/server response data.
         * @param grid
         */
        showStaticGrid(grid: any): void;
        /**
         * Intializes the reelpanel, bind the events related to reelpanel and reels,
         * subuscribe the events based on current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPED'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPED'
         * @param stopPos
         */
        init(stopPos: any): void;
        /**
         * updateReelConfig(),
         * inside this function get the all reel configuration data
         * as per the game requirement
         * update reel config data from reel config panel, on click of save button.
         */
        private updateReelConfig(evt);
        /**
         * Stops all symbol animations and Shows all the symbols which are hidden or moved for animation purposes
         */
        showAllSymbols(): void;
        /**
        * This method is made to hide the specified symbols on reels
        */
        protected forceHideReelSymbols(evt: IEvent): void;
        /**
         *  here create the mask of the reel,
         *  Truns on the reel mask before reel spin starts,
         */
        protected reelpanelMaskOn(): void;
        /**
         * here clear the mask/remove,
         * the reel mask will remove as soon as the spin complete is called.
         */
        reelpanelMaskOff(): void;
        /**
         * Symbol animation start or stop events are fired
         * @param evt
         */
        protected onSymAnimEventFired(evt: any): void;
        /**
         * This function is called,
         * when the reel's stop bounce starts and this is triggered from the reel and is fired from the reelpanel,
         * in the game this event is listened at the reelpanel, event fire based on current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPING'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPING'
         * @param evt
         */
        protected onReelStopping(evt: any): void;
        /**
         * This is event is fired when the reel has stopped spinning and its stop bounce tween as finished,
         * Events are fired based on current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPED'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPED'
         * @param evt
         */
        protected reelStopped(evt: any): void;
        /**
         * Sets the aniticipation for reels.
         */
        setAnticipation(id: number): void;
        /**
         * internal variable used for starting the reel spin
         */
        protected spinAll: boolean;
        /**
         * This function,
         * for the reels spinning, it fire the reel spin after the delays provided in the main data json file as per the game requirement.
         * @param isBlur pass it true if the symbols need to be blurred for spinning.
         * fire the reel mask on event.
         * @fires 'slotConstants.SlotEventConstants.REEL_MASK_ON'
         * */
        spin(isBlur?: any): void;
        /**
         * This function is internal function
         * and this is called after the defined delays to spin the individual reels.
         * This function will recurcively call itself till all reels are ready for spin.
         * @param id Reel number to spin.
         * @param isBlur
         * */
        protected spinReel(id: number, isBlur: boolean): void;
        /**
         * Over ridden function of the Phaser this will call the updateSpin on indiviual reels.
         * */
        update(): void;
        /**
         * This function is set reelGrid as per there stop positions.
         */
        setReelStopGrid(value: any): void;
        /**
         * Use this function to pass on the win line object from base game model to reelpanel model.
         */
        setWinningLines(value: any): void;
        /**
         * Calling this function starts the prodedure to stop the reels.
         * @param stops The stop positions for the reel or the stopping reelgrid.
         * */
        stop(stops: any): void;
        /**
         * This function calls itself recursively till all the reels are set to stop.
         * Also sets the anticipation values for the reel if anticipation has to be shown for that reel.
         * */
        protected stopReel(id: number, allReelSpining: boolean): void;
        /**
         * This function call when all reel stops.
         * @param stops
         */
        stopReelsNow(stops: any): void;
        /**
         * This function stops the reels at a interval predefined in the config part of the main data.
         * This is generally less than the general stop delays.
         * @param value
         * */
        setStopNow(value: boolean): void;
        /**
         * In this function force the reels to stop.
         * It will stop the spinning and then shows the stop reel grid base on the stop values passed.
         * this should be called only after receiving the stop positions or stop reel grid.
         * @param stops
         * */
        forceStopReels(stops: any): void;
        /**
         * here set the paused boolean true/false.
         * @param value
         */
        setPause(value: boolean): void;
        /**
         * Can be use to check if the reels are spinning.
         * @returns {boolean}
         */
        getIsSpining(): boolean;
        /**
         * Returns whether this component is in paused true/false.
         * @returns {boolean}
         */
        getPause(): boolean;
        /**
         * return the model data form this method.
         */
        getModel(): Model;
        /**
         * Returns the reels data.
         * @returns {Array<Reel>}
         */
        getReels(): Array<Reel>;
        /**
         * Returns the animation reels data.
         * @returns {Array<SymAnimReel>}
         */
        getAnimReels(): Array<SymAnimReel>;
        /**
         * Return the symbols anim overlay container.
         */
        getAnimationContainers(): Array<WinPresentationOverlayPanel>;
        /**
         * It will return the animation container.
         */
        getAnimationContainerByName(name: string): WinPresentationOverlayPanel;
        /**
         * Returns a symbol from a reel at particular position.
         * @param reel
         * @param pos
         * @returns {StaticSymbol}
         */
        getSymbolByPos(reel: number, pos: number): symbol.SymbolBase;
        /**
         * In this function stop symbols animation by there positions.
         */
        stopSymbolAnim(reel: number, row: number): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class ReelPanel2 extends ui.Container {
        /**  for model data  */
        protected model: Model;
        /**  for reel json data  */
        json: IReelPanel;
        /**  for reels arrays  */
        protected reels: Array<Reel2>;
        /**  for symbols anim reels  */
        protected symAnimReels: Array<SymAnimReel>;
        /**  for symbols AnimOverlay Containers */
        protected symAnimOverlayContainers: Array<WinPresentationOverlayPanel>;
        /** for reel stop Id */
        protected stopIds: Array<number>;
        /** for boolean value set stop all spins */
        protected stopSpinAll: boolean;
        /** for reels stopped*/
        protected reelsStopped: boolean[];
        /** for set paused boolean value */
        protected paused: boolean;
        /** for set boolean value reel is spining or not  */
        isSpining: boolean;
        /** for set anim Mode */
        protected animMode: number;
        /** for set initiated boolean */
        protected initiated: boolean;
        /** for reel stop boolean value */
        protected stopNow: boolean;
        /** for set the  anticipation Delay time */
        protected anticipationDelayAmt: number;
        protected resetElapsedMS: boolean;
        /**
         * Constructs the reel panel for the slot game. it controls the reel spin
         * @param game
         * @param model
         */
        constructor(game: bridge.Game, model: Model);
        /**
         * reelLayering(),
         * reel layering according to entry in json, default is [0,1,2,3,4].
        */
        protected reelLayering(): void;
        /**
         * Show a reel grid based on the provided values/server response data.
         * @param grid
         */
        showStaticGrid(grid: any): void;
        /**
         * Intializes the reelpanel, bind the events related to reelpanel and reels,
         * subuscribe the events based on current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPED'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPED'
         * @param stopPos
         */
        init(stopPos: any): void;
        /**
         * updateReelConfig(),
         * inside this function get the all reel configuration data
         * as per the game requirement
         * update reel config data from reel config panel, on click of save button.
         */
        private updateReelConfig(evt);
        /**
         * Stops all symbol animations and Shows all the symbols which are hidden or moved for animation purposes
         */
        showAllSymbols(): void;
        /**
        * This method is made to hide the specified symbols on reels
        */
        protected forceHideReelSymbols(evt: IEvent): void;
        /**
         *  here create the mask of the reel,
         *  Truns on the reel mask before reel spin starts,
         */
        protected reelpanelMaskOn(): void;
        /**
         * here clear the mask/remove,
         * the reel mask will remove as soon as the spin complete is called.
         */
        reelpanelMaskOff(): void;
        /**
         * Symbol animation start or stop events are fired
         * @param evt
         */
        protected onSymAnimEventFired(evt: any): void;
        /**
         * This function is called,
         * when the reel's stop bounce starts and this is triggered from the reel and is fired from the reelpanel,
         * in the game this event is listened at the reelpanel, event fire based on current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPING'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPING'
         * @param evt
         */
        protected onReelStopping(evt: any): void;
        /**
         * This is event is fired when the reel has stopped spinning and its stop bounce tween as finished,
         * Events are fired based on current game state.
         * @fires 'slotConstants.SlotEventConstants.REEL_STOPPED'
         * @fires 'slotConstants.SlotEventConstants.FG_REEL_STOPPED'
         * @param evt
         */
        protected reelStopped(evt: any): void;
        /**
         * Sets the aniticipation for reels.
         */
        setAnticipation(id: number): void;
        /**
         * internal variable used for starting the reel spin
         */
        protected spinAll: boolean;
        /**
         * This function,
         * for the reels spinning, it fire the reel spin after the delays provided in the main data json file as per the game requirement.
         * @param isBlur pass it true if the symbols need to be blurred for spinning.
         * fire the reel mask on event.
         * @fires 'slotConstants.SlotEventConstants.REEL_MASK_ON'
         * */
        spin(isBlur?: any): void;
        /**
         * This function is internal function
         * and this is called after the defined delays to spin the individual reels.
         * This function will recurcively call itself till all reels are ready for spin.
         * @param id Reel number to spin.
         * @param isBlur
         * */
        protected spinReel(id: number, isBlur: boolean): void;
        /**
         * Over ridden function of the Phaser this will call the updateSpin on indiviual reels.
         * */
        update(): void;
        /**
         * This function is set reelGrid as per there stop positions.
         */
        setReelStopGrid(value: any): void;
        /**
         * Use this function to pass on the win line object from base game model to reelpanel model.
         */
        setWinningLines(value: any): void;
        /**
         * Calling this function starts the prodedure to stop the reels.
         * @param stops The stop positions for the reel or the stopping reelgrid.
         * */
        stop(stops: any): void;
        /**
         * This function calls itself recursively till all the reels are set to stop.
         * Also sets the anticipation values for the reel if anticipation has to be shown for that reel.
         * */
        protected stopReel(id: number, allReelSpining: boolean): void;
        /**
         * This function call when all reel stops.
         * @param stops
         */
        stopReelsNow(stops: any): void;
        /**
         * This function stops the reels at a interval predefined in the config part of the main data.
         * This is generally less than the general stop delays.
         * @param value
         * */
        setStopNow(value: boolean): void;
        /**
         * In this function force the reels to stop.
         * It will stop the spinning and then shows the stop reel grid base on the stop values passed.
         * this should be called only after receiving the stop positions or stop reel grid.
         * @param stops
         * */
        forceStopReels(stops: any): void;
        /**
         * here set the paused boolean true/false.
         * @param value
         */
        setPause(value: boolean): void;
        /**
         * Can be use to check if the reels are spinning.
         * @returns {boolean}
         */
        getIsSpining(): boolean;
        /**
         * Returns whether this component is in paused true/false.
         * @returns {boolean}
         */
        getPause(): boolean;
        /**
         * return the model data form this method.
         */
        getModel(): Model;
        /**
         * Returns the reels data.
         * @returns {Array<Reel2>}
         */
        getReels(): Array<Reel2>;
        /**
         * Returns the animation reels data.
         * @returns {Array<SymAnimReel>}
         */
        getAnimReels(): Array<SymAnimReel>;
        /**
         * Return the symbols anim overlay container.
         */
        getAnimationContainers(): Array<WinPresentationOverlayPanel>;
        /**
         * It will return the animation container.
         */
        getAnimationContainerByName(name: string): WinPresentationOverlayPanel;
        /**
         * Returns a symbol from a reel at particular position.
         * @param reel
         * @param pos
         * @returns {StaticSymbol}
         */
        getSymbolByPos(reel: number, pos: number): symbol.SymbolBase2;
        /**
         * In this function stop symbols animation by there positions.
         */
        stopSymbolAnim(reel: number, row: number): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    /**
     * Creates and displays Paylines, Example JSON Format: <br>
     * ```typescript
     *{
     *  paylineData: [{
     *      x: number,
     *      y: number,
     *      w: number,
     *      h: number,
     *      scale?: number,
     *      regX: number,
     *      regY: number,
     *      offsetX?: number,
     *      offsetY?: number,
     *      startIndex: number,
     *      animType?: string,
     *      startLineId? : number,
     *      endLineId?: number,
     *      images: string[],
     *      frames: string[]
     * }],
     * spaggitte:{},
     * winBoxData:{
     *      x: number,
     *      y: number,
     *      w: number,
     *      h: number,
     *      offsetX?: number,
     *      offsetY?: number,
     *      scale?: number,
     *      regX: number,
     *      regY: number,
     *      startLineId? : number,
     *      endLineId?: number,
     *      images: string[],
     *      frames: string[]
     * }
     * } ```
     */
    class Paylines extends ui.Container {
        /** Spaghetti container */
        protected spaghettiContainer: ui.Container;
        /** Winbox container */
        protected winboxContainer: ui.Container;
        /** Payline container */
        protected paylineContainer: ui.Container;
        /** Paylines Mask Bitmap */
        /** Instance of Model */
        protected model: Model;
        /** Start Index for Paylines */
        protected startIndex: number;
        /** Holds payline sprites */
        protected lines: Array<ui.Sprite | IGraphics>;
        /** Winbox containers */
        protected winboxes: Array<ui.Container>;
        /** Spaghetti Line Sprites */
        protected spaghettiLines: Array<ui.Sprite | IGraphics>;
        /** Is win cycle completed */
        static winCycleComplete: number;
        /** Defines if win frames are required in the game */
        protected isWinbox: boolean;
        /** Defines if spaghetti are required in the game */
        protected isSpaghetti: boolean;
        /** Defines if paylines are required in the game */
        protected isPayline: boolean;
        /** Defines the type of payline animation */
        protected animType: string;
        /** Defines if Second toggle cycle is started */
        protected secondToggleStart: boolean;
        /** The mask of paylines, cut at the places of winboxes. */
        public boxCut: IGraphics;
        protected numCol: number;
        protected numRows: number;
        /**
         * @param json JSON for payline view
         * @param model Model for payline view
         * @param parent if a parent is provided then all the containers of the payline will be created inside that container
         */
        constructor(json: IContainer, model: Model, parent?: ui.Container);
        /**
         * Subscribes events based on the current game state.
         * i.e. if `currentGame.state.getCurrentState().key` is `freeGame` then only free game events will be subscribed
         */
        subscribeEvents(): void;
        /**
         * Unsubscribes base game and free game events
         */
        unsubscribeEvents(): void;
        /**
        * To avoid playing payline and win frame animations during second toggle.
        */
        protected secodToggleEanble(): void;
        /**
         * Creates winboxes for game.
         * if `configData.drawWinFrames` is true, draws the win frames manually through method `drawWinBoxes` <br>
         * if `configData.winboxAnimate` is true, executes `createAnimatedWinBox` to create animated win frames. <br>
         * if `json.winBoxData` is available, creates container (named: winBoxContainer_<count>) for every win box and adds the win box image in the container. <br>
         * else if no `json.winBoxData` is available and `ingenuity.configData.waysGame` is `true` then creates only one win box <br>
         * else creates container and win frame same as the number of paylines (`json.maxPaylines`) <br>
         *
         * Creates Win box for scatter as well if `json.winBoxData.showScatterWinFrame` is `true`
         */
        protected createWinBox(): void;
        /** Creates animated win box instance from provided parameters.
         * @param winBoxData Win box data for one payline.
         * @param i Index of the winbox instance created from the `createAnimatedWinBox` function.
         * @param pickFrameCount Frames that need to be picked from the winbox json animation.
        */
        protected createAnimatedWinBoxInstance(winBoxData: IContainer, i: number, pickFrameCount: number): void;
        /**
         * Creates animated win box data.
         * if `json.winBoxData.animatedWinBoxData` is available win frames will be created based on the data.
         * Else win boxes will be created based on the max number of paylines.
         *
         * If it's a ways game then only one will frame will be created.
         */
        protected createAnimatedWinBox(): void;
        /**
         * Creates win boxes via code if no images are available.
         * Creates a bitmap win box with following parameters for each line pattern:
         * @param i: index of line
         * @param lineColor: color for win box
         * @param shadowColor: color of shadow of win box
         */
        protected drawWinBoxInstance(i: number, lineColor: string, shadowColor?: string): void;
        /**
         * Draw win boxes base on the max number of paylines.
         * And passes the controls to `drawWinBoxInstance` to create the instances.
         */
        protected drawWinBoxes(): void;
        /**
         * Creates Paylines and Spaggitte.
         * Draws Payline and Spaggitte instance and returns the bitmap payline data.
         * @param pyArr: position y Array calculated on the basis of the pattern of payline given in lineValues array in json
         * @param i: payline instance index
         */
        protected drawLine(pyArr: Array<number>, i: number): IGraphics;
        /**
         * Draws the paylines & Spaghetti. <br>
         * Creates the paylines based on the number provided in `json.maxPaylines` <br>
         * Also, sets the scale, and adds the paylines in payline container.
         */
        protected drawPaylines(): void;
        protected animatedPaylines(): void;
        protected createAnimatedPaylineInstance(paylineData: IObject, pickFrameCount: number, i: number): void;
        /**
         * Creates Paylines and Spaggitte with animated paylines. <br>
         * Example JSON:
         * ```typescript
         * "animatedPaylines": [{
         *      "x": 100,
         *      "y": 260,
         *      "w": 952,
         *      "h": 472,
         *      "no":1,
         *      "offsetX": 0,
         *      "offsetY": 0,
         *      "scale": 1,
         *      "startLineId": 1,
         *      "endLineId":20,
         *      "posterFrame":15,
         *      "animations":{
         *      "anim": {
         *          "generateNames": true,
         *          "suffix": ".png",
         *          "prefix": "WinLine_07_",
         *          "zeroPad": 5,
         *          "frames": [0, 27],
         *          "loop": true,
         *          "frameRate": 12
         *      }
         *  },
         *  "images":"payline_1"
         * }]```
         */
        protected createPaylinesAndSpaggitte(): void;
        /**
         * Hides a single payline at a time.
         * @param evt accepts line id as part of `evt.data` which need to be hidden.
         */
        protected hidePayline(evt: number | IEvent): void;
        /**
         * Shows a single payline at a time.
         * @param evt accepts line id as part of `evt.data` which need to be shown.
         */
        protected showPayline(evt: number | IEvent): void;
        /**
         * Hides all displayed paylines.
         */
        protected hideAllPaylines(): void;
        /**
         * Resets the mask which hides the paylines between the winboxes
         */
        /**
         * Creates a safe area for the payline mask.
         */
        protected createMaskSafeArea(): void;
        /**
         * Returns the collection of winboxes for a particular payline.
         * @param id id of the winbox
         */
        protected getWinbox(id: number): ui.Container;
        /**
        * stop win box animation if animation is present.
        * @param winBox win box instance
        */
        protected stopWinBoxAnimation(winBox: ui.Sprite): void;
        /**
         * Hides the win boxes for a particular payline.
         * @param evt ID of win box to be hidden
         */
        protected hidePaylineWinbox(evt: number | IEvent): void;
        /**
         * Hides all payline winboxes.
         */
        protected hideAllPaylineWinboxes(): void;
        /**
         * Hide the Spagetti.
         */
        protected hideAllSpagetti(): void;
        /**
         * Draw the mask over the payline where a winbox is going to be displayed.
         */
        /**
         * Shows winboxes for a particular payline
         * @param id payline for which winboxes are to be shown
         * @param numSymWin number of symbols from left to right for which winboxes has to be shown. an array can also be passed, then it will show the win boxes on the passed positions as an array of array
         */
        protected showPaylineWinbox(id: number, numSymWin: number | Array<Array<number>>): void;
        /**
        * Shows winboxes for a particular payline with no mask as this is used at the time of win summary
        * @param id payline for which winboxes are to be shown
        * @param numSymWin number of symbols from left to right for which winboxes has to be shown. an array can also be passed, then it will show the win boxes on the passed positions as an array of array
        */
        protected showSpecificPaylineWinbox(id: number, numSymWin: number[]): void;
        /**
         * Displays win frame for Scatter if `configData.showScatterWinFrame` is set to `true`.
         * @param evt `evt.data` should have position and id to show the win frame.
         */
        protected showScatterFrames(evt: IEvent): void;
        /**
         * To show only win boxes without paylines (Useful for ways game)
         * @param line
         * @param numSymWin
         */
        protected showWinBoxOnly(line: number, numSymWin: number[][]): void;
        /**
         * Shows the win line in game i.e. payline with win frames.
         * @param evt it can be either the number of the payline to be shown or the event whose data should contain the payline id
         * @param numSymWin
         */
        protected showWinPayline(evt: IEvent, numSymWin?: IObject | number): void;
        /**
         * Shows the win line in game i.e. payline with win frames.
         * Executes `this.showWinPayline` to show lines and frames
         */
        protected showAllPaylineWins(evt: IEvent): void;
        protected showAllPaylineWinframes(evt: IEvent): void;
        /**
         * Show the Spagetti for the winning lines.
         * After delay as per `SlotConstants.SpaghettiDisplayTimer` it will call the callback function from where you can hide the Spagetti
         * @param evt
         * @param delayTimer
         * @param display
         */
        protected showSpagetti(evt: IEvent): void;
        /**
         * This function can be used to show Spagetti for a certain amount of time. This function can use to show Spagetti on changing the number of bet lines.
         * @param evt it can be either the number of Spagetti to be shown (from starting to this number) or an event whose data should contain the number.
         */
        protected flashSpagetti(evt: IEvent): void;
        /**
         * This function can be used to show all frames for a certain amount of time in ways game to show a summary of all wins
         * @param evt contain the ways win data, delay timer, scope in evt.data
         */
        protected showAllFrames(evt: IEvent): void;
        /**
         * Hide all frames when the win summary is shown for a certain duration of time in the ways game
         */
        protected hideAllFrames(evt: IEvent): void;
        /**
         * Hides a particular win line and resets the mask too.
         * @param line
         */
        protected hideWinPayline(evt: IEvent): void;
        /**
         * @returns Returns if Spagetti is visible or not.
         */
        readonly isSpagettiVisible: boolean;
        /**
         * Hide all winning paylines
         */
        protected hideAllWinPaylines(): void;
        /**
         * @returns Returns the spaghetti container.
         */
        getSpagettiContainer(): ui.Container;
        /**
         * @returns Returns the payline container.
         */
        getPaylineContainer(): ui.Container;
        /**
         * @returns Returns the win box container.
         */
        getWinboxContainer(): ui.Container;
        /**
         * To set the spaghetti container.
         */
        setSpagettiContainer(value: ui.Container): void;
        /**
         * To set the payline container.
         */
        setPaylineContainer(value: ui.Container): void;
        /**
         * To set the win box container.
         */
        setWinboxContainer(value: ui.Container): void;
    }
}
/**
 * Created by Asharma on 13-02-2017.
 */
/**
 * This is a namespace where we exposed our API for other modules.
 * We can easily overwrite modules using this and adding a reference to this file will add reference to whole module.
 */
declare namespace ingenuity.core.constructors {
    let reelPanel: {
        SymbolBase: typeof ingenuity.slot.symbol.SymbolBase;
        SymbolBase2: typeof ingenuity.slot.symbol.SymbolBase2;
        StaticSymbol: typeof ingenuity.slot.symbol.StaticSymbol;
        AnimationSymbol: typeof ingenuity.slot.symbol.AnimationSymbol;
        SpineSymbol: typeof ingenuity.slot.symbol.SpineSymbol;
        LayeredAnimationSymbol: typeof ingenuity.slot.symbol.LayeredAnimationSymbol;
        SymbolFactory: typeof ingenuity.slot.symbol.SymbolFactory;
        SymbolFactory2: typeof ingenuity.slot.symbol.SymbolFactory2;
        ReelModel: typeof ingenuity.slot.reelPanel.Model;
        Reel: typeof ingenuity.slot.reelPanel.Reel;
        Reel2: typeof ingenuity.slot.reelPanel.Reel2;
        SymAnimReel: typeof ingenuity.slot.reelPanel.SymAnimReel;
        SymAnimOverlayReel: typeof ingenuity.slot.reelPanel.SymAnimOverlayReel;
        WinReelPanel: typeof ingenuity.slot.reelPanel.WinPresentationPanel;
        WinReelOverlayPanel: typeof ingenuity.slot.reelPanel.WinPresentationOverlayPanel;
        ReelPanel: typeof ingenuity.slot.reelPanel.ReelPanel;
        ReelPanel2: typeof ingenuity.slot.reelPanel.ReelPanel2;
        PaylineView: typeof ingenuity.slot.reelPanel.Paylines;
    };
}
/**
 * Created by Asaxena on 3/23/2017.
 */
declare namespace ingenuity.slot.IntroOutro {
    class View extends ui.BaseView {
        constructor(viewJson: IContainer);
    }
}
/**
 * Created by Asaxena on 3/23/2017.
 */
declare namespace ingenuity.slot.IntroOutro {
    class Model {
    }
}
/**
 * Created by Asaxena on 3/23/2017.
 */
declare namespace ingenuity.slot.IntroOutro {
    class Controller {
        /** Instance of View */
        protected view: slot.IntroOutro.View;
        /** Intro container */
        protected IntroContainer: ui.Container;
        /** Intro Outro container */
        protected IntroOutroContainer: ui.Container;
        /** Outro container */
        protected OutroContainer: ui.Container;
        /** Intro continue button */
        protected IntroContinueBtn: ui.ButtonBase;
        /** Outro continue button */
        protected OutroContinueBtn: ui.ButtonBase;
        constructor(view: View);
        /**
         * Initializes all class level variables e.g.this.IntroOutroContainer etc.
         */
        protected onInitializeIntroOutro(): void;
        /**
         * Subscribe events required for Intro & Outro.
         */
        protected subscribeEvents(): void;
        /**
         * Binds handler for intro & outro continue button.
         */
        protected bindHandlers(): void;
        /**
         * Unsubscribe events for Intro and outro
         */
        protected unSubscribeEvents(): void;
        /**
         * Removes handler for intro & outro continue button.
         */
        protected unBindHandlers(): void;
        /**
         * Sets visibility of `this.IntroOutroContainer` & `this.IntroContainer` to `true`, hides `this.OutroContainer`.
         * And adds the view on stage.
         * @listens `slotConstants.SlotEventConstants.INTRO_SHOW`
         */
        protected onIntroShow(): void;
        /**
         * Hides Intro container.
         * @fires `slotConstants.SlotEventConstants.INTRO_HIDE_COMPLETE`
         * @listens `slotConstants.SlotEventConstants.INTRO_HIDE`
         */
        protected onIntroHide(): void;
        /**
         * Shows outro containers (`this.IntroOutroContainer` & `this.OutroContainer`).
         * Hides Intro Container (`this.IntroContainer`)
         * Adds the current view on stage.
         * @listens `slotConstants.SlotEventConstants.OUTRO_SHOW`
         */
        protected onOutroShow(): void;
        /**
         * Hides Outro container (`this.IntroOutroContainer` & `this.OutroContainer`)
         * @fires `slotConstants.SlotEventConstants.OUTRO_HIDE_COMPLETE`
         * @listens `slotConstants.SlotEventConstants.OUTRO_HIDE`
         */
        protected onOutroHide(): void;
        /**
         * Callback function for Intro continue button click
         * @fires `slotConstants.SlotEventConstants.INTRO_HIDE`
         */
        protected onIntroContinuePressUp(): void;
        /**
         * Callback function for Outro continue button click
         * @fires `slotConstants.SlotEventConstants.OUTRO_HIDE`
         */
        protected onOutroContinuePressUp(): void;
    }
}
/**
 * Created by Asaxena on 3/22/2017.
 */
declare namespace ingenuity.slot.FreeGame {
    /**
     * Generic Free Game Model, stores all the data required in game
     */
    class Model extends BaseGame.Model {
        /** Animation sequence array */
        protected animationSequence: string[];
        /** Stores if free games are initiated */
        freeGameInitiated: boolean;
        /** Stores re-trigger spins count */
        protected reTriggerSpins: number;
        /**
         * @param serverModel Instance of server model
         */
        constructor(serverModel: platform.baseslot.Model);
        /**
         * @returns If big win is available returns the following - <br>
         ** 0 means no BIG WIN
         ** 1 means BIG WIN, calculated based on multiplier mentioned in `slotConstants.SlotConstants.BigWinMultiplierFG`
         ** 2 means MEGA BIG WIN calculated based on multiplier mentioned in `slotConstants.SlotConstants.MegaWinMultiplierFG`
         ** 3 means SUPER BIG WIN calculated based on multiplier mentioned in `slotConstants.SlotConstants.SuperWinMultiplierFG`
         */
        getIsBigWin(): number;
        /**
         * @returns Returns remaining free spin counts `serverModel.getFreeSpinsRemaining()`
         */
        getFreeSpinsRemaining(): number;
        /**
         * If there is a win
         * @returns `serverModel.getHasWin()`
         */
        getIsWin(): boolean;
        /**
         * @returns If Scatter Win is available on current spin `this.serverModel.getHasScatterWins()`
         */
        getIsScatterWins(): boolean;
        /**
         * @returns If free spins are awarded on current spin.
         */
        getIsWonFreeSpin(): boolean;
        /**
         * @returns Returns Player balance
         */
        getUserBalance(): number;
        /**
         * @override Overridden to return true as in free games we don't need to check balance.
         */
        getHasEnoughBalance(): boolean;
        /**
         * Updates balance after placing bet. <br>
         * e.g. if balance is 100 & bet amount is 10 updated balance would be this (100-10 = 90)
         */
        setUpdatedBalanceForSpin(): void;
        /**
         * @override Overridden to return false always as autoplay not required in free spins
         */
        getIsAutoPlayLeft(): boolean;
        /**
         * @returns Re-trigger count of free spins.
         */
        getReTriggerSpins(): number;
        /**
         * Sets the count of re-triggered spins
         * @param retriggerSpinCount count of re-trigger spins
         */
        setRetriggerSpins(retriggerSpinCount: number): void;
    }
}
declare namespace ingenuity.slot.FreeGame {
    /**
     * Purpose of this class to manage free game view
     */
    class View extends BaseGame.View {
        constructor(viewJson: IContainer);
    }
}
/**
 * Created by Sjoshi on 2/20/2017.
 */
declare namespace ingenuity.slot.FreeGame {
    /**
     * This class control's all the button functionalities in the game
     * like, if user click "SPIN" button, it will be first listened here and required action will be taken
     */
    class ButtonController {
        /** Skip button to skip win presentation in free game */
        protected skipBtn: ingenuity.ui.ButtonBase;
        /** Free game Reel stop button */
        protected spinStopBtn: ingenuity.ui.ButtonBase;
        /** Instance of Free Game view */
        protected view: View;
        /** Reference to Stage */
        /** Instance of reel view */
        protected reelView: slot.reelPanel.ReelPanel;
        /** Instance of Free game Model */
        protected model: FreeGame.Model;
        /**
         * Button panel constructor, which initializes all buttons, binds events on them and subscribes events
         * handles by buttons
         * @param view Free game view
         * @param model Free game model
         */
        constructor(view: FreeGame.View, model: FreeGame.Model);
        /**
         * Initialize all game buttons by taking their reference from Base Game View
         * @param view Free game view
         */
        protected initializeButtons(view: FreeGame.View): void;
        /**
         * Binds events on all buttons
         * like when user clicks on SPIN button in game, it will trigger onSpinPressUp event
         */
        protected bindHandlers(): void;
        /**
         * Unsubscribes button events
         */
        protected unBindHandlers(): void;
        /**
         * Callback function for Skip button click.
         * @fires `slotConstants.SlotEventConstants.SKIP_CLICKED`
         */
        protected onSkipPressUp(btn?: ui.ButtonBase): void;
        /**
         * Callback function for Stop button.
         * Executes `FG_FORCE_STOP` event to force stop the reels and updates the Spin, skip & Stop button state
         */
        protected onSpinStopPressUp(): void;
        /**
         * Makes the skip button visible and hides the stop button.
         */
        protected onShowSkipBtnHideStopBtn(evt: IEvent): void;
        /**
         * Enables the skip button.
         */
        protected onShowSkipDisabledBtnHideStopBtn(evt: IEvent): void;
        /**
         * Subscribes events for buttons.
         */
        protected subscribeEvents(): void;
        /**
         * Unsubscribes events for buttons.
         */
        protected unsubscribeEvents(): void;
        /**
         * Nullifies SPIN button in game
         */
        protected nullSpinButton(evt: IEvent): void;
        /**
         * Enables Stop button in game <br>
         * Disables & hide Spin button.
         */
        protected onEnableStopBtn(evt: IEvent): void;
        /**
         * Clears some button related data and property that is required to clear at the
         * time of reel spinning start
         */
        protected onClearData(evt: IEvent): void;
        /**
         * Toggles visibility of containers to invisible, by default sets all available containers to invisible.
         * If the containerId or container is passed in event.data then only passed containers will be set to invisible
         */
        protected onHideContainers(evt: IEvent): void;
        /**
         * Toggles visibility of containers to visible, by default sets all available containers to visible.
         * If the containerId or container is passed in event.data then only passed containers will be set to visible
         */
        protected showContainers(evt: IEvent): void;
        /**
         * Disable all buttons available in game.
         * If `configData.MenuBtnEnableAllTime` is set to `true`, Enables menu button and fires event to set the container visible
         */
        protected onDisabledAllButtons(evt: IEvent): void;
        /**
         * Enable all buttons available in game
         * if Autoplay is left then disables setting button
         */
        protected onEnableAllButtons(evt: IEvent): void;
        /**
         * Enables Menu button in game
         */
        protected enableMenuBtn(): void;
        /**
         * Enables the button passed in `evt.data`,
         * if Autoplay is left then disables setting button
         */
        protected onEnabledButton(evt: IEvent): void;
        /**
         * Disables the button passed in `evt.data`
         */
        protected onDisabledButton(evt: IEvent): void;
        /**
         * Toggles visibility of containers to visible, by default sets all available containers to visible.
         * If the containerId or container is passed in event.data then only passed containers will be set to visible
         */
        protected onShowContainers(evt: IEvent): void;
        /**
         * To remove all events from stage, left blank in slot core
         */
        protected onRemoveAllListnersFromStage(evt: IEvent): void;
        /**
         * Disables button interaction.
         * If data (`evt.data`) is passed at the time of event fire, it disabled interaction for that passed button only
         * else disables interaction for all the button available
         */
        protected onDisableButtonInteraction(evt: IEvent): void;
        /**
         * Enables button interaction.
         * if data (`evt.data`) is passed at the time of event fire, it enabled interaction for that passed button only
         * if not then it enabled interaction for all the button available
         */
        protected onEnableButtonInteraction(evt: IEvent): void;
    }
}
/**
 * Created by Sjoshi on 2/21/2017.
 */
declare namespace ingenuity.slot.FreeGame {
    /**
     * Purpose of below controller to control all Meters in game.
     */
    class MetersController {
        /** Holds balance meter */
        protected balanceMeter: ui.Meter;
        /** Holds win meter */
        protected winMeter: ui.Meter;
        /** Holds total bet meter */
        protected totalWinMeter: ui.Meter;
        /** Holds free game left meter */
        protected freegameLeftMeter: ui.Meter;
        /** Instance of free game view */
        protected view: View;
        /** Instance of free game Model */
        protected model: Model;
        /**
         * @fires `slotConstants.SlotEventConstants.UNSCBSCRIBE_METER_CONTROLLERS_BG`
         * @fires `slotConstants.SlotEventConstants.SCBSCRIBE_METER_CONTROLLERS_FG`
         * @fires `slotConstants.SlotEventConstants.FG_UPDATE_BALANCE_METER_AFTER`
         * @param view Free game view
         * @param model Free game model
         */
        constructor(view: View, model: Model);
        /**
         * Binds class level events for meters
         */
        protected bindHandlers(): void;
        /**
         * To subscribe meter events, subscribeEvents is called When `slotConstants.SlotEventConstants.SCBSCRIBE_METER_CONTROLLERS_FG` fired.
         */
        protected subscribeEvents(): void;
        /**
         * To unsubscribe meter events, unsubscribeEvents is called When `slotConstants.SlotEventConstants.UNSCBSCRIBE_METER_CONTROLLERS_FG` fired.
         */
        protected unsubscribeEvents(): void;
        /**
         * Starts Tick-up in win meter.
         */
        protected onStartWinTickUp(evt: IEvent): void;
        /**
         * Callback function for tickup complete.
         * @fires `slotConstants.SlotEventConstants.DO_NEXT_SPIN`
         */
        protected tickUpComplete(): void;
        /**
         * Updates balance in balance meter.
         * @fires `slotConstants.SlotEventConstants.FG_UPDATE_BALANCE_METER`
         */
        protected updateBalance(): void;
        /**
         * Updates balance in meter after win.
         * @fires `slotConstants.SlotEventConstants.FG_UPDATE_BALANCE_METER`
         */
        protected onUpdateBalanceMeterAfter(evt: IEvent): void;
        /**
         * Updates balance in meter after Spin button click.
         * @fires `slotConstants.SlotEventConstants.FG_UPDATE_BALANCE_METER`
         */
        protected onUpdateBalanceMeterAfterSpinClick(evt: IEvent): void;
        /**
         * updates meter with currency or normal value
         * @param meter meter which needs to be updated with value
         * @param value value to be updated
         */
        protected updateMeterForCreditCoin(meter: ui.Meter, value: string): void;
        /**
         * Updates balance in balance meter.
         */
        protected onUpdateBalanceMeter(evt: IEvent): void;
        /**
         * Updates count of remaining free game in meter.
         */
        protected onUpdateFreegameLeftMeter(evt: IEvent): void;
        /**
         * Updates count of remaining free game in meter.
         */
        protected onSetFreeGameLeftMeter(evt: IEvent): void;
        /**
         * Updates Total Win amount in Total Win Meter
         */
        protected onUpdateTotalWinMeter(evt: IEvent): void;
        /**
         * Resets all meters available in games.
         * @fires `slotConstants.SlotEventConstants.FG_UPDATE_PAID_METER`
         * @fires `slotConstants.SlotEventConstants.UPDATE_FREEGAME_LEFT_METER`
         * @fires `slotConstants.SlotEventConstants.FG_UPDATE_TOTAL_WIN_METER`
         */
        protected onResetMeters(evt: IEvent): void;
        /**
         * Updates Win amount in Win Meter.
         */
        protected onUpdatePaidMeter(evt: IEvent): void;
        /**
         * Stops meter tickup for the meterId/meter passed in `evt.data` else stops tickup in all meters
         * @param evt pass the meter id or meter in `evt.data` to stop the tickup in meter
         */
        protected onStopMeterTickup(evt: IEvent): void;
    }
}
/**
 * Created by Sjoshi on 2/23/2017.
 */
declare namespace ingenuity.slot.FreeGame {
    /**
     * Purpose of this is class to control Player Messages in Game.
     * @abstract
     */
    abstract class PlayerMsgController extends BaseGame.PlayerMsgController {
    }
}
/**
 * Created by Sjoshi on 2/21/2017.
 */
declare namespace ingenuity.slot.FreeGame {
    /**
     * Purpose of this controller is to control activities on free game Reel Panel
     * Like Reel Spins, Reel Stops, All Reels Stop, Call to check Win
     * Anticipation, Landing Animation etc..
     */
    class ReelPanelController {
        /** Instance of view */
        protected view: View;
        /** Instance of model */
        protected model: Model;
        /** Instance of reel view */
        protected reelView: reelPanel.ReelPanel;
        /** Instance of Win presentation panel */
        protected winReelView: reelPanel.WinPresentationPanel;
        /** Instance of payline view */
        protected paylineView: reelPanel.Paylines;
        /** Array to store anticipation data */
        protected anticipationList: Array<Array<number>>;
        constructor(view: View, model: Model);
        /**
         * Init is called when ReelPanelController initialized. In this func we set reel set and reel grid to reelpanel.
         */
        protected init(): void;
        /**
         * Binds class level events in this
         */
        protected bindHandlers(): void;
        /**
         * Subscribes all Reel level events to handle Reel Panel Functionality
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_FREEGAME_REELPANEL_EVENTS`
         */
        protected subscribeEvents(): void;
        /**
         * Unsubscribe all reel events
         * @listens `slotConstants.SlotEventConstants.UNSUBSCRIBE_FREEGAME_REELPANEL_EVENTS`
         */
        protected unsubscribeEvents(): void;
        /**
         * Unsubscribes all Reel level events to handle Reel Panel Functionality
         * @listens `slotConstants.SlotEventConstants.FG_UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER`
         */
        protected onUnScribeAllReelPanelEvents(evt: IEvent): void;
        /**
         * To force stop the reel spin
         * @listens `ingenuity.slotConstants.SlotEventConstants.FG_FORCE_STOP`
         */
        protected onReelsForceStop(): void;
        /**
         * When Response came from server, now we are ready to stop reels one by one
         * @listens `slotConstants.SlotEventConstants.FG_STOP_REEL_NOW`
         */
        protected onStopReelNow(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.FG_NOW_SPIN_REEL`
         * @fires `platform.EventConstants.FREE_BET`
         */
        protected onSpinReel(evt: IEvent): void;
        /**
         * To update symbols on grid.
         * Updates the reel grid as per the data in `model.getReelStops()`
         * @listens `slotConstants.SlotEventConstants.FG_UPDATE_SYMBOLS_ON_GRID`
         */
        protected onUpdateSymbolsOnGrid(): void;
        /**
         * Checks if anticipation is available on applicable reels
         * @listens `slotConstants.SlotEventConstants.FG_CHECK_FOR_ANTICIPATION_ON_REELS`
         */
        protected onCheckingAnticipationOnReels(evt: IEvent): void;
        /**
         * Sets Quick spin/Turbo mode to true in Model
         * @listens `slotConstants.SlotEventConstants.FG_UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN`
         */
        protected updateModelForQuickSpin(evt: IEvent): void;
        /**
         * Show anticipation on reel.
         * @param e `e.data` to show the anticipation
         * @listens `slotConstants.SlotEventConstants.FG_SHOW_ANTICIPATION`
         */
        protected showAnticipation(e?: IEvent): void;
        /**
         * Show landing animation.
         * @param e `e.data` to show the landing animation
         * @listens `slotConstants.SlotEventConstants.FG_SHOW_LANDINGANIMATION`
         */
        protected showLanding(e?: IEvent): void;
        /**
         * Unsubscribes and then subscribes reel start events
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START_FG`
         */
        protected onReelStartSubscribeEvents(evt: IEvent): void;
        /**
         * This function will be executed for every reel stop i.e. for 5 reels this function will be executed five times
         * @listens `slotConstants.SlotEventConstants.FG_REEL_STOPPED`
         */
        protected onReelStopped(evt: IEvent): void;
        /**
         * Executed once spin is complete
         * @listens `slotConstants.SlotEventConstants.FG_SPIN_COMPLETE`
         * @fires `slotConstants.SlotEventConstants.FG_CHECK_FOR_WIN_AFTER_REEL_STOP`
         */
        protected onSpinComplete(evt: ingenuity.events.EventDispatcher): void;
        /**
         * When all Reels started to stop and about to bounce but not stopped completely
         * @listens `slotConstants.SlotEventConstants.FG_REEL_STOPPING`
         */
        protected onReelStopping(evt: IEvent): void;
        /**
         * Check whether to play anticipation on Reels or not
         */
        protected checkForAnticipation(symbolObj: any, listLength: number): void;
        /**
         * Check for landing animation in game, for all reels.
         */
        protected checkForlandingAnim(symbolObj: any, listLength: number): void;
        /**
         * Clears anticipationList, landingOnReel and calls `model.resetForSpin()`
         * @listens `slotConstants.SlotEventConstants.FG_CLEAR_DATA`
         */
        protected onClearData(evt: IEvent): void;
    }
}
/**
 * Created by Sjoshi on 2/21/2017.
 */
declare namespace ingenuity.slot.FreeGame {
    /**
     * Purpose of this class is to Control All Win Presentation activities running in free game
     */
    class WinPresentationController {
        /** Instance of Payline View */
        protected paylineView: slot.reelPanel.Paylines;
        /** Instance of Reel View */
        protected reelView: slot.reelPanel.WinPresentationPanel;
        /** Instance of View */
        protected view: View;
        /** Instance of Model */
        protected model: Model;
        /** Stores duration of five of a kind */
        protected fiveOfKindDuration: number;
        /** Stores current toggle cycle */
        protected togglingCycle: number;
        constructor(view: View, model: Model);
        /**
         * On start of Big win presentation, this functions configures Event on Big win presentation.
         * @fires `slotConstants.SlotEventConstants.SHOW_BIG_WIN`
         * @listens `slotConstants.SlotEventConstants.FG_START_BIG_WIN_PRESENTATION`
         */
        protected onStartBigWinPresentation(evt: IEvent): void;
        /**
         * Subscribes events required for Payline View and Win presentation controller.
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS`
         */
        protected subscribeEvents(): void;
        /**
         * Clears free spin data.
         */
        protected onClearData(): void;
        /**
         * Suspends the win presentation.
         * @listens `slotConstants.SlotEventConstants.FG_SUSPEND_WINPRESENTATION`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_SPAGETTI`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_FRAMES`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_WIN_PAYLINE`
         * @fires `slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATION_ON_REEL`
         */
        protected onSuspendWinPresentation(): void;
        /**
         * Unsubscribes events required for Payline View and Win presentation controller.
         * @listens `slotConstants.SlotEventConstants.UNSUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS`
         */
        protected unsubscribeEvents(): void;
        /**
         * @listens `slotConstants.SlotEventConstants.FG_WIN_CYCLE_COMPLETED`
         * @fires `slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION`
         */
        protected onWinCycleCompleted(evt: IEvent): void;
        /**
         * On start of first line toggle cycle -
         * * Sets animation symbol `true`
         * * Sets toggling continue `false`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutFirstToggle`
         * @fires `slotConstants.SlotEventConstants.FG_START_WIN_ANIM`
         * @listens `slotConstants.SlotEventConstants.FG_START_FIRST_TOGGLE_CYCLE_WAYS`
         */
        protected onStartFirstToggleCycle(evt: IEvent): void;
        /**
         * On start of first ways toggle cycle -
         * * Sets animation symbol `true`
         * * Sets toggling continue `false`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutFirstToggle`
         * @fires `slotConstants.SlotEventConstants.FG_START_WAYS_ANIM`
         * @listens `slotConstants.SlotEventConstants.FG_START_FIRST_TOGGLE_CYCLE_WAYS`
         */
        protected onStartFirstToggleCycleWays(evt: IEvent): void;
        /**
        * @listens `slotConstants.SlotEventConstants.SCATTER_ANIMATION_ENDED`
        * @fires `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION`
        */
        protected onScatterAnimationEnd(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.START_SCATTER_PRESENTATION`
         * @fires `slotConstants.SlotEventConstants.START_SCATTER_WIN_ANIM`
         */
        protected onStartScatterPresentation(evt: IEvent): void;
        /**
         * On start of second line toggle cycle -
         * * Sets animation symbol `false`
         * * Sets toggling continue to value of `evt.data`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutSecondToggle`
         * @fires `slotConstants.SlotEventConstants.FG_START_All_WIN_ANIM`
         * @listens `slotConstants.SlotEventConstants.FG_START_SECOND_TOGGLE_CYCLE`
         */
        protected onStartSecondToggleCycle(evt: IEvent): void;
        /**
         * On start of second line toggle cycle -
         * * Sets animation symbol `false`
         * * Sets toggling continue to value of `evt.data`
         * * updates value of `reelView.WIN_LINE_ANIM_TIMEOUT` with `slotConstants.SlotConstants.WinLineAnimTimeOutSecondToggle`
         * @fires `slotConstants.SlotEventConstants.FG_START_All_WIN_ANIM`
         * @listens `slotConstants.SlotEventConstants.FG_START_SECOND_TOGGLE_CYCLE_WAYS`
         */
        protected onStartSecondToggleCycleWays(evt: IEvent): void;
        /**
         * Dispatches the following events -
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_SPAGETTI`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_FRAMES`
         * @fires `slotConstants.SlotEventConstants.FG_ENABLED_ALL_BUTTONS`
         * @fires `slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION`
         * @listens `slotConstants.SlotEventConstants.BIG_WIN_HIDDEN`
         */
        protected cofigureEventOnBigWinHide(): void;
        /**
         * @listens `slotConstants.SlotEventConstants.FG_SHOW_SPAGHTTI` in game During Win presentation
         * @fires `slotConstants.SlotEventConstants.FG_SHOW_SPAGETTI`
         * @callback dispatches `slotConstants.SlotEventConstants.FG_HIDE_ALL_SPAGETTI` & `slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION` <br>
         * Once shown:
         * @fires `slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION`
         */
        protected onShowSpaghtti(evt: IEvent): void;
        /**
         * Shows win summary in ways game by showing all win frames together
         * @listens `slotConstants.SlotEventConstants.FG_SHOW_ALL_WIN_FRAMES` in game During Win presentation
         * @fires `slotConstants.SlotEventConstants.FG_SHOW_ALL_FRAMES`
         * @callback dispatches `slotConstants.SlotEventConstants.FG_HIDE_ALL_FRAMES` & `slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION` <br>
         * Once all frames are shown:
         * @fires `slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION`
         */
        protected onShowAllFrames(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.FG_SHOW_5OAK`
         * Sets display time from `model.getFiveOfAKindDisplayTime()` to `this.fiveOfKindDuration`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_SPAGETTI`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_FRAMES` <br>
         * Executes `view.show5OfKind`
         */
        protected onShow5OAK(evt: IEvent): void;
        /**
         * On hide Five of a kind.
         * @listens `slotConstants.SlotEventConstants.FG_HIDE_5OAK`
         */
        protected onHide5OAK(evt: IEvent): void;
        /**
         * Set WinLines And Ways data for Win Presentation.
         * @listens slotConstants.SlotEventConstants.FG_SET_WINLINE_AND_WAYS_DATA
         */
        protected onSetWinLineAndWaysUniqueData(evt: IEvent): void;
        /**
         * When Reel Spinning Starts this function subscribes events for Win Presentation.
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START_FG`
         */
        protected onReelStartSubscribeEvents(evt: IEvent): void;
        /**
         * @listens `slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATION_ON_REEL`
         * Stops all running Win Animation in game.
         * @fires `slotConstants.SlotEventConstants.FG_STOP_ALL_WIN_ANIMATIONS` <br>
         * After delay defined in `slotConstants.SlotConstants.TimerHidePayline`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_SPAGETTI`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_FRAMES`
         * @fires `slotConstants.SlotEventConstants.FG_HIDE_ALL_WIN_PAYLINE` <br>
         * Unsubscribes: `slotConstants.SlotEventConstants.FG_WIN_CYCLE_COMPLETED`
         */
        protected onStopAllWinAnimation(): void;
    }
}
/**
 * Created by Asaxena on 3/22/2017.
 */
declare namespace ingenuity.slot.FreeGame {
    /**
     * Controller class for free game
     */
    class FreeGameController {
        /** Instance of free game view */
        protected view: View;
        /** Instance of free game Model */
        protected model: FreeGame.Model;
        /** View JSON */
        protected json: IObject;
        protected assets: any;
        /** Instance of Button Controller, holds all button functionality */
        protected buttonController: ButtonController;
        /** Instance of Meter Controller, holds all meter updating activity */
        protected meterController: MetersController;
        /** Instance of Player Message Controller */
        protected playerMsgController: any;
        /** Instance of Reel Panel Controller */
        protected reelPanelController: ReelPanelController;
        /** Win presentation controller instance, holds all win presentation's activity */
        protected winPresentationController: WinPresentationController;
        constructor(view: FreeGame.View, model: Model, json: IObject, assetManager: any);
        /**
         * Subscribes all the events required for free game.
         */
        protected subscribeEvents(): void;
        /**
         * Hide Free Game View.
         */
        protected onHideFreeGame(evt: IEvent): void;
        /**
         * Show Free Game View.
         */
        protected onShowFreeGame(evt: IEvent): void;
        /**
         * Initialize Slot Logic Class.
         */
        protected onInitializeSlotLogic(evt: IEvent): void;
        /**
         * Initialize instances of all the controllers for the game
         */
        protected onInitializeAllControllers(evt: IEvent): void;
        /**
         * Initialize button controller.
         */
        protected initializeButtonController(): void;
        /**
         * Initialize meter controller.
         */
        protected initializeMeterController(): void;
        /**
         * Initialize player msg controller
         */
        protected initializePlayerMsgController(): void;
        /**
         * Initialize reel panel controller
         */
        protected initializeReelPanelController(): void;
        /**
         * Initialize win presentation controller
         */
        protected initializeWinPresentationController(): void;
    }
}
/**
 * Created by Sjoshi on 2/20/2017.
 */
declare namespace ingenuity.slot.Logic {
    /**
     * Purpose of this class is to handle complete logic of the game.
     * We can change the behavior of the game, by changing the flow inside this class
     * All controllers fire events to this class to perform next expected actions
     */
    class SlotGameLogic {
        /** Instance of Model */
        protected model: any;
        /** Holds the current state for logic e.g. Basegame or freegame */
        protected logicRunningFor: string;
        private isSpinStopped;
        constructor();
        /**
         * Assigns Base game model to `this.model`
         * @fires `slotConstants.SlotConstants.LogicScopeBG`
         */
        protected initializeBaseGameModel(): void;
        /**
         * Assigns Free game model to `this.model`
         * Set logic running for to `slotConstants.SlotConstants.LogicScopeFG`
         */
        protected initializeFreeGameModel(): void;
        /**
         * Subscribes the essential base game and free game events.
         */
        protected subscribeEvents(): void;
        /**
         * Unsubscribe the base game and free game events.
         */
        protected unsubscribeEvents(): void;
        /***
         * when Reels stop, following events fire for next action to be taken inside the onCheckForWinAfterReelStop funtion,
         * if game has win, it starts win presentation execution as per winData,
         * if no win and game has autoplay activated it checks for next AutoPlay call to execute,
         * if no win and no Autoplay activated, then it enables all buttons,show containers(buttonContainer),and resets player msg in game
         * @param evt
         */
        protected onCheckForWinAfterReelStop(evt: IEvent): void;
        /**
         * Here check ways game win data and fire event as per game state baseGameState/freeGameState
         * fire event as per current game state
         * @fires `slotConstants.SlotEventConstants.SET_WINLINE_AND_WAYS_DATA` for free game.
         * @fires 'slotConstants.SlotEventConstants.FG_SET_WINLINE_AND_WAYS_DATA' for base game
         */
        protected setWinlineAndWaysData(): void;
        /**
         * Inside the 'checkForAutoPlay()' fire the events to perform next expected actions.
         * @fires 'slotConstants.SlotEventConstants.SPIN_CLICKED' for next action on spinClicked Button.
         */
        protected checkForAutoPlay(): void;
        /**
         * Inside the 'autoplayReset()' here reset the button state as per game flow.
         * If 'this.model.getIsScatterWins()' will false && 'this.model.isReelSpinning()' will false
         * then button will reset by
         * @fires 'slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS'.
         */
        protected autoplayReset(): void;
        /**
         * Inside the 'checkForAutoPlayCondition()' check the 'this.model.getIsAutoPlayLeft()' true/false.
         * If true call 'checkForAutoPlay()' for perform thennext expected actions.
         * @fires 'slotConstants.SlotEventConstants.UPDATE_AUTOPLAY_METERS' for Autoplay meter update.
         */
        protected checkForAutoPlayCondition(): void;
        /**
         * onShowNextWinPresentation, it execute win presentation one by one in sequence defind in model as per game behaviour.
         * It will depend on game to game sequence like ["5OAK", "Spaghtti", "bigWin","firstToggle","secondToggle","triggeringAnimation","bonus","freeSpin"].
         * As per current model data first "5OAK" executes, when it will complete call back to this method again and exdecute to next step defined in sequence.
         * that is Spaghtti dispaly and on it's copletion it's again call to this method and it will pick next sequnce from this.model.getAnimationSequence()
         * and it will continue till last win sequence to play.
         *
         * @param evt
         */
        protected onShowNextWinPresentation(evt: IEvent): void;
        /**
         * UpdateAnimationSequenceCounter, it's update animation sequence number
         * till animation sequence array length, and number increases than length it reset its value back to 1
         *
         */
        protected updateAnimationSequenceCounter(): void;
        /**
         * Inside the startWinMeterTickUP, start win tickup in win meter in game
         * by firing event.
         * @fires 'slotConstants.SlotEventConstants.START_WIN_TICK_UP' for base game.
         * @fires  'slotConstants.SlotEventConstants.FG_START_WIN_TICK_UP' for free game.
         * here it starts tickup at the time of spaghetti show
         *
         */
        protected startWinMeterTickUP(): void;
        /**
         * onShow5OAK(), throws an event to execute 5OAK presentation in game.
         * if 5OAK available in current game, it will play fiveOk then call back and perform next action as per model data.
         * if 5OAK not available it calls for next presentation to perform the next action of the game.
         */
        protected onShow5OAK(): void;
        /**
         * Inside the showFiveOfAkind, Play fiveOfkind as per fire events
         * @fires 'slotConstants.SlotEventConstants.SHOW_5OAK' for base game
         * @fires 'slotConstants.SlotEventConstants.FG_SHOW_5OAK' for free game
         */
        protected showFiveOfAkind(): void;
        /**
         * Inside the showNextWinPresentation fire event for next game flow.
         * @fires 'slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION' for base game.
         * @fires 'slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION' for free game.
         */
        protected showNextWinPresentation(): void;
        /**
         * Inside onShowSpaghtti,
         * fire spaghetti event as per current game state.
         * @fires 'slotConstants.SlotEventConstants.SHOW_SPAGHTTI' for base game.
         * @fires 'slotConstants.SlotEventConstants.FG_SHOW_SPAGHTTI' for free game.
         */
        protected onShowSpaghtti(): void;
        /**
         * Inside the onShowAllFrames,
         * show all win boxs as per win data by fire events.
         * @fires 'slot.slotConstants.SlotEventConstants.SHOW_ALL_WIN_FRAMES' for base game.
         * @fires 'slot.slotConstants.SlotEventConstants.FG_SHOW_ALL_WIN_FRAMES' for free game.
         */
        protected onShowAllFrames(): void;
        /**
         * onShowBigWin, if BigWin is available in current game, it shows big win presentation in game.
         * If BigWin is not present in game, it will update win meter and enabled all buttons,
         * and call to next win presentation to execute.
         */
        protected onShowBigWin(): void;
        /**
         * On startTheBigWinPresentation,
         * Start the bigwin presentation based on current game states.
         * @fires 'slotConstants.SlotEventConstants.START_BIG_WIN_PRESENTATION' for base game.
         * @fires 'slotConstants.SlotEventConstants.FG_START_BIG_WIN_PRESENTATION' for free game.
         */
        protected startTheBigWinPresentation(): void;
        /**
         * onFirstToggle, if line win presentation in game,
         * it will call first toggle event based on current game state.
         * @fires 'slotConstants.SlotEventConstants.START_FIRST_TOGGLE_CYCLE' for base game.
         * @fires 'slotConstants.SlotEventConstants.FG_START_FIRST_TOGGLE_CYCLE' for free game.
         * e.g. if wins on 3 Lines(Line 1, Line2 and Line 3),
         * it first shows presentation on Line1 for 2 seconds then move to presentation on Line2 for 2 seconds,
         * it's completion move on Line 3 presentation and after 2 seconds of it will call to "FIRST_TOGGLE_CYCLE_COMPLETED" then
         * excute next action.
         * If no line win present, call to next presentation as per game flow.
         */
        protected onFirstToggle(): void;
        /**
       * onFirstToggleWays, if Ways win presentation in game,
       * it will call first toggle event based on current game state.
       * @fires 'slotConstants.SlotEventConstants.START_FIRST_TOGGLE_CYCLE' for base game.
       * @fires 'slotConstants.SlotEventConstants.FG_START_FIRST_TOGGLE_CYCLE' for free game.
       * If no line win present, call to next presentation as per game flow.
       */
        protected onFirstToggleWays(): void;
        /**
         * onSecondToggle, It will call after First Toggle complete,
         * if we win on 3 Lines (Line1, Line2 and Line3)
         * Line 1 toggles and after .8 seconds call to next line (Line2) for .8 seconds
         * and then to Line3 for .8 seconds  on its completion call to "SECOND_TOGGLE_CYCLE_COMPLTED"
         * and call to next presentation to execute.
         */
        protected onSecondToggle(): void;
        /**
         * onSecondToggleWays, It will call after first ways win perform,
         * excute the next steps of game behaviour.
         */
        protected onSecondToggleWays(): void;
        /**
         * In line games, On startSecondToggleOnState, call secod toggle star event based on current game state.
         * @fires 'slotConstants.SlotEventConstants.START_SECOND_TOGGLE_CYCLE' for base game.
         * @fires 'slotConstants.SlotEventConstants.FG_START_SECOND_TOGGLE_CYCLE' for free game.
         */
        protected startSecondToggleOnState(breakToggleing: boolean): void;
        /**
         * In ways games, On startSecondToggleOnStateWays, call secod toggle star event based on current game state.
         * @fires 'slotConstants.SlotEventConstants.START_SECOND_TOGGLE_CYCLE_WAYS' for base game.
         * @fires 'slotConstants.SlotEventConstants.FG_START_SECOND_TOGGLE_CYCLE_WAYS' for free game.
         */
        protected startSecondToggleOnStateWays(breakToggleing: boolean): void;
        /**
         * IntroHideComplete calls,
         * when free game intro banner hide,
         * initializing the free game state for enter into free game screen.
         */
        protected IntroHideComplete(): void;
        /**
         * OutroHideComplete excute,
         * clear the free game state, hide Outro banner and fire following events clear all free game data.
         * @fires 'slotConstants.SlotEventConstants.ON_FREEGAME_RETURNING' for return from free to base game.
         * @fires 'slotConstants.SlotEventConstants.SUBSCRIBE_WINPRESENTATION_PANEL_BG' subscribe event base game.
         * @fires 'slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS' base game buttons enable.
         */
        protected OutroHideComplete(): void;
        /**
         * doNextSpin is called in free spin,
         * when free spin remaining.
         * Also check free spin count is zero and fire following events.
         * @fires 'slotConstants.SlotEventConstants.OUTRO_SHOW'.
         * @fires 'slotConstants.SlotEventConstants.RESET_METERS' etc.
         */
        protected doNextSpin(evt: IEvent): void;
        /**
         * unSubscribeReelPanelControllerEvents, for unsubscribe event based on current game state.
         * @fires 'slotConstants.SlotEventConstants.UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER' for base game.
         * @fires 'slotConstants.SlotEventConstants.FG_UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER' for free game.
         */
        protected unSubscribeReelPanelControllerEvents(): void;
        /**
         * onTriggeringAnimation,
         * shows triggering animation on triggered symbols as per games.
         *
         */
        protected onTriggeringAnimation(): void;
        /**
         * startScatterPresentation, fire event for play scatter win animations,
         * based on current game state.
         * @fires 'slotConstants.SlotEventConstants.START_SCATTER_PRESENTATION' for base game.
         * @fires 'slotConstants.SlotEventConstants.FG_START_SCATTER_PRESENTATION' for free game.
         */
        protected startScatterPresentation(): void;
        /**
         * onBonusPresentation,
         * shows presentation for Bonus as per game flow.
         */
        protected onBonusPresentation(): void;
        /**
         * onFreeSpinPresentation,
         * shows presentation for FreeSpin, unsubscribe base game events and fire free game intro event.
         * @fires 'slotConstants.SlotEventConstants.INTRO_SHOW'
         *
         */
        protected onFreeSpinPresentation(): void;
        /**
         * onCheckForAutoPlay,
         * Checks for next autoplay fire event.
         * @fires 'slotConstants.SlotEventConstants.CHECK_FOR_AUTOPLAY_CONDITION'
         */
        protected onCheckForAutoPlay(): void;
        /**
         * check inside the free game onValidateBetInFreeGame, it validates bet on free game re-spin,
         * if bet validated it proceeds for Reel Spin by performing following events
         * @fires 'slotConstants.SlotEventConstants.FG_RESET_METERS'
         * @fires 'slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START'
         * @fires 'slotConstants.SlotEventConstants.PLACE_BET'
         * @fires 'slotConstants.SlotEventConstants.SPIN_STARTED'
         * check for Turbo Mode this.model.getIsTurboModeOn,
         * if yes Turbo Mode then fire events
         * @fires 'slotConstants.SlotEventConstants.FG_NULL_SPIN_BTN'
         * @fires 'slotConstants.SlotEventConstants.FG_UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN'
         * @fires 'slotConstants.SlotEventConstants.FG_NOW_SPIN_REEL'
         * if bet not found/insufficent fund validated, it fires
         * @fires 'ingenuity.events.EventConstants.INSUFFICIENT_FUNDS' to show insufficnet popup.

         *
         * @param evt
         */
        protected onValidateBetInFreeGame(evt: IEvent): void;
        /**
         * check inside the base game, onValidateBet, it validates bet on spin clicked,
         * if bet validated it proceeds for Reel Spin by performing following events
         * @fires 'slotConstants.SlotEventConstants.RESET_METERS'
         * @fires 'slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START'
         * @fires 'slotConstants.SlotEventConstants.PLACE_BET'
         * @fires 'slotConstants.SlotEventConstants.SPIN_STARTED'
         * @fires 'slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS'
         * @fires 'slotConstants.SlotEventConstants.NOW_SPIN_REEL' etc. as per game flow.
         * if bet not found validated, it will show insufficent popup by fire event,
         * @fires 'ingenuity.events.EventConstants.INSUFFICIENT_FUNDS'
         * if Autoplay Activated, then it resets Autoplay and stop Autoplay and it enable all buttons for game
         *
         * @param evt
         */
        protected onValidateBet(evt: IEvent): void;
        /**
         * onSpinClickedInFreeGame, when free game spinning start, fire below events to
         * performs next action on Spinbuttons clicked.
         * @fires 'slotConstants.SlotEventConstants.UPDATE_AUTOPLAY_BUTTONS'
         * @fires 'slotConstants.SlotEventConstants.UPDATE_AUTOPLAY_METERS'
         * @fires 'slotConstants.SlotEventConstants.CLEAR_SPIN_TIMER'
         * @fires 'slotConstants.SlotEventConstants.REMOVE_ALL_LISTNERS_FROM_STAGE'
         * @fires 'slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS'
         * @fires 'slotConstants.SlotEventConstants.FG_SUSPEND_WINPRESENTATION'
         * @fires 'slotConstants.SlotEventConstants.FG_CLEAR_DATA'
         * @fires 'slotConstants.SlotEventConstants.VALIDATE_BET_IN_FREEGAME'
         *
         * @param evt
         */
        protected onSpinClickedInFreeGame(evt: IEvent): void;
        /**
         * In base game onSpinClicked, when spin button clicked fire below events to
         * performs next action on Spinbutton clicked.
         * @fires 'slotConstants.SlotEventConstants.UPDATE_AUTOPLAY_BUTTONS'
         * @fires 'slotConstants.SlotEventConstants.UPDATE_AUTOPLAY_METERS'
         * @fires 'slotConstants.SlotEventConstants.CLEAR_SPIN_TIMER'
         * @fires 'slotConstants.SlotEventConstants.REMOVE_ALL_LISTENERS_FROM_STAGE'
         * @fires 'slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS'
         * @fires 'slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION'
         * @fires 'slotConstants.SlotEventConstants.CLEAR_DATA'
         * @fires 'slotConstants.SlotEventConstants.VALIDATE_BET'
         *
         * @param evt
         */
        protected onSpinClicked(evt: IEvent): void;
        /**
         * onSkipClicked,
         * when skip button clicked fire events to
         * performs following tasks on Spinbtn click
         * @fires 'slotConstants.SlotEventConstants.CLEAR_SPIN_TIMER'
         * @fires 'slotConstants.SlotEventConstants.REMOVE_ALL_LISTNERS_FROM_STAGE'
         * @fires 'slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS'
         * @fires 'slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION'
         * @fires 'slotConstants.SlotEventConstants.CLEAR_DATA'
         * @fires 'slotConstants.SlotEventConstants.DO_NEXT_SPIN'
         *
         * @param evt
         */
        protected onSkipClicked(evt: IEvent): void;
        /**
         * onReelStartSubscribeEvents,
         * when bet found validated and Reel spinning start then subscribe event.
         * "ingenuity.events.EventConstants.SPIN_RESPONSE_PROCESSED"
         * "slot.slotConstants.SlotEventConstants.ALL_REEL_SPINING"
         * when response received,
         * all reels are ready to stop and STOP btn will enable for force stoped
         *
         */
        protected onReelStartSubscribeEvents(): void;
        /**
         * onSpinResponseReceived, call
         * OnreelSpiningAndServerResponseReceived() based on 'this.model.getAllReelSpinning' && 'this.model.getServerResponseReceived' true,
         * for next action of the game flow.
         * @param evt
         */
        protected onSpinResponseReceived(evt: IEvent): void;
        /**
         * onAllReelSpinning is called, when all reels spinning started.
         */
        protected onAllReelSpinning(evt: IEvent): void;
        /**
         * OnreelSpiningAndServerResponseReceived(),
         * when All Reel Spinning start and Response Received from server.
         * Inside this function fire events as per the conditions/current game state,
         * and fire the events as per flow.
         */
        protected OnreelSpiningAndServerResponseReceived(): void;
        /**
         * onClearSpinTimer, clears spin timer
         *
         * @param evt
         */
        protected onClearSpinTimer(evt: ingenuity.events.EventDispatcher): void;
        /**
         * onStakeChange, fire the the following events for clear win data,
         * reset the meters, reset player message etc..
         * @fires 'slotConstants.SlotEventConstants.CLEAR_DATA'
         * @fires 'slotConstants.SlotEventConstants.RESET_METERS'
         * @fires 'slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATION_ON_REEL'
         * @fires 'slotConstants.SlotEventConstants.RESET_PALYER_MSG_LABELS'
         */
        protected onStakeChange(): void;
        /**
         * onInfoPressed, On Info button Clicked fire the following events.
         * @fires 'slotConstants.SlotEventConstants.GAME_MSG_HIDE'
         * @fires 'ingenuity.events.EventConstants.SHOW_PAYTABLE'
         */
        protected onInfoPressed(): void;
        /**
         * Hides Game message by fire event.
         * @fires 'slotConstants.SlotEventConstants.GAME_MSG_HIDE'
         */
        protected hideGameMessage(): void;
        /**
         * Show Game message by fire event.
         * @fires 'slotConstants.SlotEventConstants.GAME_MSG_SHOW'
         */
        protected showGameMessage(): void;
        /**
         * onUnScribeAllReelPanelEvents, fire following events.
         * @fires 'slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION'
         * @fires 'slotConstants.SlotEventConstants.CLEAR_SPIN_TIMER' etc..
         */
        protected onUnScribeAllReelPanelEvents(): void;
    }
}
declare namespace ingenuity.slot {
    /**
     * @abstract
     * State class for Base game.
     * This class initializes all the required modules for base game.
     */
    abstract class BasegameState extends states.State {
        /** Instance of base game view */
        protected view: BaseGame.View;
        /** Instance of base game Model */
        protected model: BaseGame.Model;
        /** Instance of reel Model */
        protected reelModel: reelPanel.Model;
        /** Instance of base Reel panel */
        protected reelPanel: reelPanel.ReelPanel;
        /** Instance of Win reel panel */
        protected winReelpanel: reelPanel.WinPresentationPanel;
        /** Instance of Reel Overlay panel */
        protected winReelOverlaypanel: Array<any>;
        /** Instance of payline view */
        protected paylineView: reelPanel.Paylines;
        /** Instance of base game controller */
        protected basecontroller: BaseGame.BaseController;
        /**
         * To initialize base game state.
         * Initialize all the modules required for base game.
         */
        init(): void;
        /**
         * To shut down (clean) base game state
         */
        shutdown(): void;
        /**.
         * To initialize base game model
         */
        protected initializeModel(): void;
        /**
         * To initialize base game view.
         */
        protected initializeView(): void;
        /**
         * To initialize base game controller.
         */
        protected initializeController(): void;
        /**
         * To initialize base game reel panel.
         * Creates a new instance of reel Model and reel panel.
         * Assign's reel View JSON to model.
         * Sets reel view in base game view.
         */
        protected initializeReelPanel(): void;
        /**
         * To initialize Win reel panel.
         * Creates a new instance of Win Reel Panel.
         * Sets win reel view in base game view.
         * Adds event listener for `slotConstants.SlotEventConstants.SUBSCRIBE_WINPRESENTATION_PANEL_BG` & `slotConstants.SlotEventConstants.UNSUBSCRIBE_WINPRESENTATION_PANEL_BG`
         * @fires `slotConstants.SlotEventConstants.SUBSCRIBE_WINPRESENTATION_PANEL_BG`
         */
        protected initializeWinReelPresentation(): void;
        /**
        * To initialize Overlay win reel presentation panel.
        * Creates containers for special animation symbols based on the data provided in `this.reelModel.json.animContainers`
        */
        protected initializeOverlayWinReelPresentation(): void;
        /**
         * To subscribe win reel panel events.
         * This function first unsubscribes Win presentation panel FG and then executes `winReelpanel.subscribeEvents()`
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_WINPRESENTATION_PANEL_BG`
         */
        protected subscribeEvents(): void;
        /**
         * To unsubscribe win reel panel events.
         * @listens `slotConstants.SlotEventConstants.UNSUBSCRIBE_WINPRESENTATION_PANEL_BG`
         */
        protected unsubscribeEvents(): void;
        /**
        * To initialize Paylines view.
        * Creates a new instance of PaylineView using the JSON main_data.paylineInfo
        * @fires `slotConstants.SlotEventConstants.CREATE_WINBOX`
        * @fires `slotConstants.SlotEventConstants.CREATE_PAYLINE_SPAGGITTE`
        *
        * Sets payline view in base game view.
        */
        protected initializePayline(): void;
        /**
         * Layering the components according to json entry - <br>
         * ```typescript
         * "indexing": [
         * "paylineContainer",
         * "winboxContainer",
         * "spaggitteContainer",
         * "scatterContainer"
         * ] ```
         * In above example `scatterContainer` will be placed on top.
         * Each container should have name and those names should be given in the json.
         */
        protected setReelPanelLayering(): void;
        /**
         * To initialize big win presentation.
         */
        protected initializeBigWinPresentation(): void;
        /**
         * To initialize Paytable view.
         */
        protected initializePaytable(): void;
        /**
         * To initialize Intro and Outro.
         */
        protected initializeIntroOutro(): void;
        /**
         * To initialize sound manager.
         */
        protected initializeSound(): void;
    }
}
/**
 * Created by Asaxena on 3/24/2017.
 */
declare namespace ingenuity.slot {
    abstract class FreegameState extends states.State {
        /** Instance of free game view */
        protected view: FreeGame.View;
        /** Instance of free game Model */
        protected model: FreeGame.Model;
        /** Instance of reel Model */
        protected reelModel: reelPanel.Model;
        /** Instance of free Reel panel */
        protected reelPanel: reelPanel.ReelPanel;
        /** Instance of Win reel panel */
        protected winReelpanel: reelPanel.WinPresentationPanel;
        /** Instance of Reel Overlay panel */
        protected winReelOverlaypanel: Array<any>;
        /** Instance of payline view */
        protected paylineView: reelPanel.Paylines;
        /** Instance of free game controller */
        protected freeGameController: FreeGame.FreeGameController;
        /**
         * To initialize free game state.
         * Initialize all the modules required for free game.
         * @fires `slotConstants.SlotEventConstants.INITIALIZE_FG_MODEL`
         * @fires `slotConstants.SlotEventConstants.SETUP_FG`
         * @fires `slotConstants.SlotEventConstants.HIDE_BASEGAME_VIEW`
         * @fires `slotConstants.SlotEventConstants.SHOW_FREEGAME_VIEW`
         */
        init(): void;
        /**
         * To shut down (clean) free game state.
         * Unsubscribes free game events, removes freegame view from stage & nullifies this class variables.
         */
        shutdown(): void;
        /**.
         * To initialize free game model
         */
        protected initializeModel(): void;
        /**
         * To initialize free game view.
         */
        protected initializeView(): void;
        /**
         * To initialize free game controller.
         */
        protected initializeController(): void;
        /**
         * To initialize free game reel panel.
         * Creates a new instance of reel Model and reel panel.
         * Assign's reel View JSON to model.
         * Sets reel view in base game view.
         */
        protected initializeReelPanel(): void;
        /**
         * To initialize Win presentation panel.
         * Creates a new instance of Win reel Panel and sets it in free game view.
         * @fires `slotConstants.SlotEventConstants.SUBSCRIBE_WINPRESENTATION_PANEL_FG` to subscribe win presentation events.
         */
        protected initializeWinReelPresentation(): void;
        /**
        * To initialize Overlay win reel presentation panel.
        * Creates containers for special animation symbols based on the data provided in `this.reelModel.json.animContainers`
        */
        protected initializeOverlayWinReelPresentation(): void;
        /**
         * To subscribe win reel panel events.
         * This function first unsubscribes `slotConstants.SlotEventConstants.UNSUBSCRIBE_WINPRESENTATION_PANEL_BG` and then executes `winReelpanel.subscribeEvents()`
         * @listens `slotConstants.SlotEventConstants.SUBSCRIBE_WINPRESENTATION_PANEL_FG`
         */
        protected subscribeEvents(): void;
        /**
         * To unsubscribe win reel panel events of free games.
         * @listens `slotConstants.SlotEventConstants.UNSUBSCRIBE_WINPRESENTATION_PANEL_FG`
         */
        protected unsubscribeEvents(): void;
        /**
        * To initialize Paylines view.
        * Creates a new instance of PaylineView using the JSON main_data.paylineInfo
        * @fires `slotConstants.SlotEventConstants.FG_CREATE_WINBOX`
        * @fires `slotConstants.SlotEventConstants.FG_CREATE_PAYLINE_SPAGGITTE`
        *
        * Sets payline view in base game view.
        */
        protected initializePayline(): void;
        /**
         * Layering the components according to json entry - <br>
         * ```typescript
         * "indexing": [
         * "paylineContainer",
         * "winboxContainer",
         * "spaggitteContainer",
         * "scatterContainer"
         * ] ```
         * In above example `scatterContainer` will be placed on top.
         * Each container should have name and those names should be given in the json.
         */
        protected setReelPanelLayering(): void;
        /**
         * To initialize big win presentation.
         */
        protected initializeBigWinPresentation(): void;
        /**
         * To initialize Paytable view.
         */
        protected initializePaytable(): void;
        /**
         * To initialize Intro and Outro.
         */
        protected initializeIntroOutro(): void;
        /**
         * To initialize sound manager.
         */
        protected initializeSound(): void;
    }
}
/**
 * Created by Asharma on 13-02-2017.
 */
/**
 * The is a namespace where we expose our API for other modules.
 * We can easily overwrite modules using this and adding a reference to this file will add reference to whole module.
 */
declare namespace ingenuity.core.constructors {
    let slot: {
        IntroView: typeof ingenuity.slot.IntroOutro.View;
        IntroModel: typeof ingenuity.slot.IntroOutro.Model;
        IntroController: typeof ingenuity.slot.IntroOutro.Controller;
        BaseButtonController: typeof ingenuity.slot.BaseGame.ButtonController;
        BaseMetersController: typeof ingenuity.slot.BaseGame.MetersController;
        BasePlayerMsgController: typeof ingenuity.slot.BaseGame.PlayerMsgController;
        BaseReelPanelController: typeof ingenuity.slot.BaseGame.ReelPanelController;
        BaseWinPresentationController: typeof ingenuity.slot.BaseGame.WinPresentationController;
        BaseController: typeof ingenuity.slot.BaseGame.BaseController;
        BaseModel: typeof ingenuity.slot.BaseGame.Model;
        BaseView: typeof ingenuity.slot.BaseGame.View;
        FreeButtonController: typeof ingenuity.slot.FreeGame.ButtonController;
        FreeMetersController: typeof ingenuity.slot.FreeGame.MetersController;
        FreePlayerMsgController: typeof ingenuity.slot.FreeGame.PlayerMsgController;
        FreeReelPanelController: typeof ingenuity.slot.FreeGame.ReelPanelController;
        FreeWinPresentationController: typeof ingenuity.slot.FreeGame.WinPresentationController;
        FreeController: typeof ingenuity.slot.FreeGame.FreeGameController;
        FreeModel: typeof ingenuity.slot.FreeGame.Model;
        FreeView: typeof ingenuity.slot.FreeGame.View;
        SlotLogic: typeof ingenuity.slot.Logic.SlotGameLogic;
        SlotConstants: typeof ingenuity.slot.slotConstants.SlotConstants;
        SlotEventConstants: {
            SPIN_CLICKED: string;
            SKIP_CLICKED: string;
            SPIN_CLICKED_IN_FREE_GAME: string;
            UPDATE_AUTOPLAY_BUTTONS: string;
            UPDATE_AUTOPLAY_METERS: string;
            CLEAR_SPIN_TIMER: string;
            REMOVE_ALL_LISTNERS_FROM_STAGE: string;
            DISABLED_ALL_BUTTONS: string;
            ENABLED_ALL_BUTTONS: string;
            ENABLE_BUTTON: string;
            DISABLE_BUTTON: string;
            SUSPEND_WINPRESENTATION: string;
            DO_NEXT_SPIN: string;
            CLEAR_DATA: string;
            SUBSCRIBE_BASEGAME_REELPANEL_EVENTS: string;
            UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS: string;
            SUBSCRIBE_FREEGAME_REELPANEL_EVENTS: string;
            UNSUBSCRIBE_FREEGAME_REELPANEL_EVENTS: string;
            SUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS: string;
            UNSUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS: string;
            SUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS: string;
            UNSUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS: string;
            VALIDATE_BET: string;
            VALIDATE_BET_IN_FREEGAME: string;
            RESET_METERS: string;
            UPDATE_BET_METER: string;
            UPDATE_PAID_METER: string;
            UPDATE_TOTAL_WIN_METER: string;
            UPDATE_FREEGAME_LEFT_METER: string;
            ON_SET_FREEGAME_LEFT: string;
            UPDATE_TOTAL_BET_METER: string;
            UPDATE_BALANCE_METER_AFTER: string;
            UPDATE_BALANCE_METER_AFTER_SPIN_CLICK: string;
            STOP_METER_TICKUP: string;
            UPDATE_BALANCE_METER_BEFORE: string;
            UPDATE_BALANCE_METER: string;
            UPDATE_STAKE_METER: string;
            SUBSCRIBE_EVENTS_ON_REEL_START: string;
            SUBSCRIBE_EVENTS_ON_REEL_START_BG: string;
            SUBSCRIBE_EVENTS_ON_REEL_START_FG: string;
            STOP_REEL_NOW: string;
            CHECK_FOR_ANTICIPATION_ON_REELS: string;
            UPDATE_SYMBOLS_ON_GRID: string;
            NULL_SPIN_BTN: string;
            UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN: string;
            ENABLE_STOP_BTN: string;
            HIDE_CONTAINERS: string;
            NOW_SPIN_REEL: string;
            SHOW_CONTAINERS: string;
            ENABLE_BUTTON_INTERACTION: string;
            DISABLED_BUTTON_INTERACTION: string;
            SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
            SHOW_SKIP_BTN_DISABLED_HIDE_STOP_BTN: string;
            CHECK_FOR_WIN_AFTER_REEL_STOP: string;
            CHECK_FOR_AUTOPLAY_CONDITION: string;
            DISABLED_AUTOPLAY_BTN: string;
            AUTOPLAY_RESET: string;
            AUTOPLAY_RESET_ENABLE_BUTTONS: string;
            AUTOPLAY_COUNT: string;
            ENABLE_AUTOPLAY_STOP_BTN: string;
            RESET_PALYER_MSG_LABELS: string;
            SHOW_NEXT_WIN_PRESENTATION: string;
            SHOW_5OAK: string;
            HIDE_5OAK: string;
            SET_WINLINE_AND_WAYS_DATA: string;
            SHOW_SPAGHTTI: string;
            SHOW_ALL_WIN_FRAMES: string;
            START_WIN_TICK_UP: string;
            STOP_WIN_TICK_UP: string;
            ON_RETURNING_FG_UPDATE_METER: string;
            FORCE_STOP: string;
            START_SCATTER_PRESENTATION: string;
            START_BIG_WIN_PRESENTATION: string;
            START_FIRST_TOGGLE_CYCLE: string;
            START_SECOND_TOGGLE_CYCLE: string;
            START_FIRST_TOGGLE_CYCLE_WAYS: string;
            START_SECOND_TOGGLE_CYCLE_WAYS: string;
            UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER: string;
            STOP_ALL_WIN_ANIMATION_ON_REEL: string;
            SCBSCRIBE_BUTTON_CONTROLLERS_BG: string;
            UNSCBSCRIBE_BUTTON_CONTROLLERS_BG: string;
            SCBSCRIBE_BUTTON_CONTROLLERS_FG: string;
            UNSCBSCRIBE_BUTTON_CONTROLLERS_FG: string;
            SCBSCRIBE_METER_CONTROLLERS_BG: string;
            UNSCBSCRIBE_METER_CONTROLLERS_BG: string;
            SCBSCRIBE_METER_CONTROLLERS_FG: string;
            UNSCBSCRIBE_METER_CONTROLLERS_FG: string;
            ALL_REEL_SPINING: string;
            INITIALIZE_ALL_CONTROLLERS_BG: string;
            INITIALIZE_ALL_CONTROLLERS_FG: string;
            INITIALIZE_SLOT_LOGIC: string;
            WRAPPER_READY: string;
            INITIALIZE_BASE_CLASSES: string;
            INITIALIZE_BASE_CLASSES_COMPLETE: string;
            GAME_RESIZE: string;
            INTRO_HIDE_COMPLETE: string;
            OUTRO_HIDE_COMPLETE: string;
            INTRO_SHOW: string;
            INTRO_HIDE: string;
            OUTRO_SHOW: string;
            OUTRO_HIDE: string;
            INITIALIZE_BG_MODEL: string;
            INITIALIZE_FG_MODEL: string;
            SETUP_FG: string;
            ON_FREEGAME_RETURNING: string;
            SUBSCRIBE_WINPRESENTATION_PANEL_BG: string;
            UNSUBSCRIBE_WINPRESENTATION_PANEL_BG: string;
            SUBSCRIBE_WINPRESENTATION_PANEL_FG: string;
            UNSUBSCRIBE_WINPRESENTATION_PANEL_FG: string;
            HIDE_BASEGAME_VIEW: string;
            SHOW_BASEGAME_VIEW: string;
            HIDE_FREEGAME_VIEW: string;
            SHOW_FREEGAME_VIEW: string;
            SHOW_WIN_PAYLINE: string;
            SHOW_SCATTER_FRAMES: string;
            HIDE_WIN_PAYLINE: string;
            SHOW_ALL_WIN_PAYLINE: string;
            HIDE_ALL_WIN_PAYLINE: string;
            HIDE_ALL_PAYLINE: string;
            HIDE_ALL_SPAGETTI: string;
            FLASH_SPAGETTI: string;
            SHOW_SPAGETTI: string;
            SHOW_ALL_FRAMES: string;
            HIDE_ALL_FRAMES: string;
            SHOW_PAYLINE: string;
            HIDE_PAYLINE: string;
            HIDE_PAYLINE_WINBOX: string;
            HIDE_ALL_PAYLINE_WINBOX: string;
            PLAY_LANDING_ANIMATION_SOUND: string;
            CREATE_WINBOX: string;
            CREATE_PAYLINE_SPAGGITTE: string;
            SUMUP_BIGWIN: string;
            CLEAR_STICKY_WILD_DATA: string;
            PLAY_STICKY_WILD_SYMBOL_ANIM: string;
            START_RETRIGGER_IN_FREEGAME: string;
            SHOW_FREEGAME_RETRIGGER_POPUP: string;
            CLEAR_RANDOM_WILD_DATA: string;
            START_RANDOM_WILD: string;
            RANDOM_WILD_APPEARED: string;
            UNSUBSCRIBE_RANDOM_WILD_EVENTS: string;
            STOP_WILD_ON_EXPWILD: string;
            STOP_SCATTER_ON_EXPWILD: string;
            INIT_EXPANDING_WILD: string;
            ON_ALL_REELS_STOPPED: string;
            CLEAR_EXP_WILD: string;
            SPIN_EXP_WILD_WITH_REEL: string;
            HIDE_EXP_WILD: string;
            HIDE_STICKY_CONTAINER: string;
            PLAY_STICKY_WILD_LANDING_ANIM: string;
            UNSUBSCRIBE_STICKY_EVENTS: string;
            PLAY_STICKY_SYMBOLS_ANIMATIONS: string;
            ADD_ANIM_OVERLAY_LAYER: string;
            ADD_ALL_OVERLAY_SYMBOLS_TO_ANIM_OVERLAY_LAYER: string;
            ADD_SYMBOL_TO_ANIM_OVERLAY_LAYER: string;
            CLEAR_ANIM_LAYER: string;
            PLACE_OVER_PAYLINES: string;
            SHOW_STICKY_VIEW: string;
            STICKY_ANIM_STARTED: string;
            REMOVE_STICKY_ICONS: string;
            FG_DISABLED_ALL_BUTTONS: string;
            FG_ENABLED_ALL_BUTTONS: string;
            FG_ENABLE_BUTTON: string;
            FG_DISABLE_BUTTON: string;
            FG_SUSPEND_WINPRESENTATION: string;
            FG_CLEAR_DATA: string;
            FG_RESET_METERS: string;
            FG_UPDATE_PAID_METER: string;
            FG_UPDATE_TOTAL_WIN_METER: string;
            FG_UPDATE_BALANCE_METER_AFTER: string;
            FG_UPDATE_BALANCE_METER_AFTER_SPIN_CLICK: string;
            FG_UPDATE_BALANCE_METER: string;
            FG_STOP_REEL_NOW: string;
            FG_CHECK_FOR_ANTICIPATION_ON_REELS: string;
            FG_UPDATE_SYMBOLS_ON_GRID: string;
            FG_NULL_SPIN_BTN: string;
            FG_UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN: string;
            FG_ENABLE_STOP_BTN: string;
            FG_HIDE_CONTAINERS: string;
            FG_NOW_SPIN_REEL: string;
            FG_SHOW_CONTAINERS: string;
            FG_ENABLE_BUTTON_INTERACTION: string;
            FG_DISABLED_BUTTON_INTERACTION: string;
            FG_SHOW_SPIN_BTN_HIDE_STOP_BTN: string;
            FG_SHOW_SKIP_BTN_DISABLED_HIDE_STOP_BTN: string;
            FG_CHECK_FOR_WIN_AFTER_REEL_STOP: string;
            FG_SHOW_NEXT_WIN_PRESENTATION: string;
            FG_SHOW_5OAK: string;
            FG_HIDE_5OAK: string;
            FG_SET_WINLINE_AND_WAYS_DATA: string;
            FG_SHOW_SPAGHTTI: string;
            FG_SHOW_ALL_WIN_FRAMES: string;
            FG_START_WIN_TICK_UP: string;
            FG_FORCE_STOP: string;
            FG_START_SCATTER_PRESENTATION: string;
            FG_START_BIG_WIN_PRESENTATION: string;
            FG_START_FIRST_TOGGLE_CYCLE: string;
            FG_START_SECOND_TOGGLE_CYCLE: string;
            FG_START_FIRST_TOGGLE_CYCLE_WAYS: string;
            FG_START_SECOND_TOGGLE_CYCLE_WAYS: string;
            FG_UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER: string;
            FG_STOP_ALL_WIN_ANIMATION_ON_REEL: string;
            FG_ALL_REEL_SPINING: string;
            FG_SHOW_WIN_PAYLINE: string;
            FG_SHOW_SCATTER_FRAMES: string;
            FG_SHOW_ALL_WIN_PAYLINE: string;
            FG_HIDE_ALL_WIN_PAYLINE: string;
            FG_HIDE_ALL_PAYLINE: string;
            FG_HIDE_ALL_SPAGETTI: string;
            FG_FLASH_SPAGETTI: string;
            FG_SHOW_SPAGETTI: string;
            FG_SHOW_ALL_FRAMES: string;
            FG_HIDE_ALL_FRAMES: string;
            FG_SHOW_PAYLINE: string;
            FG_HIDE_PAYLINE: string;
            FG_HIDE_PAYLINE_WINBOX: string;
            FG_HIDE_ALL_PAYLINE_WINBOX: string;
            FG_CREATE_WINBOX: string;
            FG_CREATE_PAYLINE_SPAGGITTE: string;
            INITIATE_REELPANEL: string;
            SPIN: string;
            STOP_SPIN: string;
            SPIN_COMPLETE: string;
            REEL_STOPPED: string;
            REEL_STOPPING: string;
            LINE_ANIMATION_STARTED: string;
            START_SCATTER_WIN_ANIM: string;
            SCATTER_ANIMATION_STARTED: string;
            SCATTER_ANIMATION_ENDED: string;
            LINE_ANIMATION_ENDED: string;
            SYMBOL_ANIM_STARTED: string;
            SYMBOL_ANIM_ENDED: string;
            START_All_WIN_ANIM: string;
            START_WIN_ANIM: string;
            START_WAYS_ANIM: string;
            WIN_CYCLE_COMPLETED: string;
            WAY_ANIMATION_STARTED: string;
            WAY_ANIMATION_ENDED: string;
            START_EXPANDING_WILD: string;
            PLAY_EXPANDING_WILD: string;
            CLEAR_EXPANDING_WILD: string;
            SHOW_STICKY_WILD: string;
            PLAY_STICKY_WILD_ANIMATION: string;
            CLEAR_STICKY_WILD: string;
            RESET_SHIFTING_WILD: string;
            CHANGE_SYMBOL: string;
            PLAY_CHANGE_SYMBOL_SOUND: string;
            SHOW_SHIFTING_WILD: string;
            MOVE_SHIFTING_WILD: string;
            CLEAR_SHIFTING_WILD: string;
            TWEEN_SHIFTING_WILD: string;
            WILD_SHIFTED: string;
            INTRO_OUTRO_HIDDEN: string;
            STOP_ALL_WIN_ANIMATIONS: string;
            SPIN_STARTED: string;
            SHOW_ANTICIPATION: string;
            SHOW_LANDINGANIMATION: string;
            SHOW_BIG_WIN: string;
            BIG_WIN_HIDDEN: string;
            REEL_MASK_ON: string;
            REEL_MASK_OFF: string;
            FG_INITIATE_REELPANEL: string;
            FG_SPIN: string;
            FG_STOP_SPIN: string;
            FG_SPIN_COMPLETE: string;
            FG_REEL_STOPPED: string;
            FG_REEL_STOPPING: string;
            FG_LINE_ANIMATION_STARTED: string;
            FG_START_SCATTER_WIN_ANIM: string;
            FG_SCATTER_ANIMATION_STARTED: string;
            FG_SCATTER_ANIMATION_ENDED: string;
            FG_LINE_ANIMATION_ENDED: string;
            FG_START_All_WIN_ANIM: string;
            FG_START_WIN_ANIM: string;
            FG_START_All_WAYS_ANIM: string;
            FG_START_WAYS_ANIM: string;
            FG_WIN_CYCLE_COMPLETED: string;
            FG_WAY_ANIMATION_STARTED: string;
            FG_WAY_ANIMATION_ENDED: string;
            FG_START_EXPANDING_WILD: string;
            FG_STOP_ALL_WIN_ANIMATIONS: string;
            FG_SHOW_ANTICIPATION: string;
            FG_SHOW_LANDINGANIMATION: string;
            FORCE_HIDE_REEL_SYMBOLS: string;
            ON_FIVE_OF_A_KIND_TWEEN_COMPLETE: string;
            WIN_ON_REELS: string;
            GAME_MSG_SHOW: string;
            GAME_MSG_HIDE: string;
            LOGIC_ONSTAKE_CHANGE: string;
            LOGIC_ONINFO_PRESSED: string;
            LOGIC_SHOW_GAME_MESSAGE: string;
            LOGIC_HIDE_GAME_MESSAGE: string;
            LOGIC_ON_UNSUBSCRIBE_REEL_PANEL_EVENTS: string;
            UPDATE_REEL_CONFIG: string;
            DOMMOUSESCROLL: string;
            MOUSEWHEEL: string;
            KEYDOWN: string;
            DISABLE_SPACEBAR_EVENTS: string;
            ENABLE_SPACEBAR_EVENTS: string;
            KEY_DOWN_FG: string;
        };
        GameStateBG: typeof ingenuity.slot.BasegameState;
        GameStateFG: typeof ingenuity.slot.FreegameState;
    };
}
declare namespace ingenuity.slot.Logic {
    class SlotGameLogic2 extends SlotGameLogic {
        protected minSpinTimeDone: boolean;
        protected minSpinDuration: any;
        protected onValidateBet(evt: IEvent): void;
        protected onValidateBetInFreeGame(evt: IEvent): void;
        protected minSpinDone(): void;
        protected onSpinResponseReceived(evt: IEvent): void;
        protected onAllReelSpinning(evt: IEvent): void;
        protected OnreelSpiningAndServerResponseReceived(): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class CascadingReel extends Reel {
        private dropIndex;
        private symbIndex;
        private isInit;
        private isAnimating;
        protected reelBurstData: any;
        protected slideAnimateArr: any;
        protected model: CascadingReelPanelModel;
        init(stopPos: number | number[]): void;
        protected setStaticReel(reelGrid: Array<number>): void;
        private animateSymbols();
        updateSpin(deltaTime: number): void;
        setStops(stopsArray: number | number[] | IObject): void;
        protected reelSubset(stopPos: number): Array<number>;
        spin(isBlur: boolean): void;
        private dropSymbols();
        protected spinDone(): void;
        forceStopReel(stopsArray: number | number[]): void;
        dissolveSymbolPositions(pos: number[], currentSlideStepGrid: any): void;
        protected createNewSymbols(currentSlideStepGrid: any): void;
        protected slideNewSymbols(): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class CascadingReelPanel extends ReelPanel {
        protected reels: CascadingReel[];
        constructor(game: bridge.Game, model: CascadingReelPanelModel);
        getReels(): CascadingReel[];
    }
}
declare namespace ingenuity.slot.reelPanel {
    class CascadingReelPanelModel extends Model {
        getSymbolTweenDuration(): number;
        getNewSymbolSlideDuration(): number;
        getNextDropDelay(): number;
        getForceStopDelay(): number;
        getBurstAnimCompleteDelay(): number;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class HorizontalReel extends Reel {
        protected setStaticReel(reelGrid: Array<number>): void;
        spin(isBlur: boolean): void;
        updateSpin(deltaTime: number): void;
        setStops(stopsArray: number | number[] | IObject): void;
        forceStopReel(stopsArray: number | number[]): void;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class HorizontalReelPanel extends ReelPanel {
        protected reels: HorizontalReel[];
        constructor(game: bridge.Game, model: reelPanel.Model);
        getReels(): HorizontalReel[];
    }
}
declare namespace ingenuity.slot.reelPanel {
    interface IReelPanel extends IContainer {
        /**
         * x position of the reelpanel generally used to set the reelpanel image
         */
        x: number;
        /**
         * y position of the reelpanel generally used to set the reelpanel image
         */
        y: number;
        /**
         * width of the reelpanel generally used to set the reelpanel image and used in other calculations too.
         */
        w: number;
        /**
         * height of the reelpanel generally used to set the reelpanel image and used in other calculations too.
         */
        h: number;
        /**
         * total symbol in the game. this used for various calculations internally.
         */
        symbolCount: number;
        /**
         * Id of the starting Symbol. Can be either 0 or 1.
         */
        startId: number;
        /**
         * Number of symbols to be displayed in each reel. a single number means all the reels have same number of symbols.
         * For any asymertic reels use an array [2,3,5,3,2]
         */
        symPerReel: number | number[];
        /**
         * Create a mask for the reelPanel depending upon the string passed. Reelpanel will create a single mask for entire reelpanel.
         * Reel will create mask for individual reels. noMask will not create any mask so that a custom mask can be provided.
         */
        mask: string | string[];
        /**
         * Speed at which the reels will spin
         */
        spinSpeed: number | number[];
        minSpeed: number;
        decSpinSpeed: number;
        /**
         * Speed at which the reels will spin in turbo mode.
         */
        quickSpinSpeed: number | number[];
        /**
         * Will always be reel
         */
        type: string;
        /**
         * Reelpanel image/border image.
         */
        image: Array<string>;
        /**
         * Pass this as true if you do not want each reel to start individually after a delay.
         */
        noStartDelay: boolean;
        noStartBounce?: boolean;
        /**
         * Pass this as true if you do not want each reel to stop individually after a delay.
         */
        noStopDelay: boolean;
        noStopBounce?: boolean;
        /**
         * This property is a boolean property which indicates that the layering of StickyWild Symbol is available or not.
         */
        stickyWildLayering: boolean;
        /**
         * This property is a boolean property which indicates that the layering of RandomWild Symbol is available or not.
         */
        RandomWildlayering: boolean;
        anticipationLoops: number;
        anticipationSpeed: number;
        anticipationDelay: number;
        anticipation: IAnticipationConfig | IAnticipationConfig[];
        /**
         * Configration for individual reels. this should be an array as the reel panel class check its length and create the reels accordingly
         */
        reels: IReel[];
        symbolData: slot.symbol.ISymbolData[];
        isBlur: boolean;
    }
    /** Interface For Base Reel Class. These properties are a reference for the main_data.json. */
    interface IReel extends IContainer {
        /**
         * To show debug border of the reel.
         */
        border: boolean;
        /**
         * Pass this as true if you donot want this reel to use delays.
         */
        noDelay: boolean;
        /**
         * This is make reel spin stop more consistent. Always give the highest row count here.
         */
        maxLoops: number;
        config: IReelConfig;
    }
    interface IAnticipationConfig extends IObject {
        symbolId: number;
        symbolCount: number;
        aniticipationRunOnReel: number[];
    }
    interface IReelConfig extends IObject {
        startBounceAmt: number;
        startBounceTime: number;
        startBounceTimeout: number;
        stopBounceAmt: number;
        stopBounceTime: number;
        stopBounceTimeout: number;
        startDelay: number;
        stopDelay: number;
    }
}
declare namespace ingenuity.slot.reelPanel {
    class MultiAnimIcon extends ui.Container {
        /** Defines the type of Symbol */
        symType: string | Array<string>;
        /** Holds the Symbol ID */
        iconNum: number;
        /** Defines the grid position for symbol */
        gridPosition: number;
        /** Defines if symbol is blur */
        blurred: boolean;
        /** Defines the type of animation */
        animType: string | string[];
        /** Is animation already playing */
        protected allreadyAnimating: boolean;
        protected animObj: any;
        /**
         * Create a game symbol which can be animated using the texture atlas.
         * @param symbolId - Symbol number provided by the game server api
         * @param json - JSON for this particular symbol
         */
        constructor(symbolId: number, json: IContainer);
        /**
         * Initiates the symbol properties. <br>
         * e.g. Sets Symbol Type from `json.symType` else sets to "Normal" <br>
         * Sets animation type from `json.animType`. <br>
         * Sets Scale from `json.scale` <br>
         * Sets Scale X & Scale Y from `json.scaleX` & `json.scaleY` <br>
         * Sets Pivot points from `this.json.regX || 0, this.json.regY || 0`
         */
        protected init(): void;
        /**
         * Plays the animation from the texture atlas
         * @param animName Animation to run default is "Anim"
         * @param stopFrame On completion, animation will stop on this frame
         * @param callback Callback function to be executed once animation is completed
         * @param cbScope Callback function scope
         */
        playAnim(animName?: string, stopFrame?: string, callback?: () => void, cbScope?: any): void;
        /**
         * Stops the symbols animation.
         */
        stopAnim(): void;
        /**
         * Changes the Symbol sprite to blur.
         */
        blurIcons(): this;
        /**
         * Resets the blur symbol to Normal
         */
        resetBlurIcon(): MultiAnimIcon;
        /**
         * Resets the triggering animation to default.
         */
        resetTriggeringIcon(): MultiAnimIcon;
    }
}
declare namespace ingenuity.slot.symbol {
    class SymbolConstants {
        static readonly ANIMATION_SPRITE: string;
        static readonly ANIMATION_SPINE: string;
        static readonly ANIMATION_LAYERED: string;
        static readonly ANIMATION_SCALE: string;
        static readonly ANIMATION_BLINK: string;
        static readonly ANIMATION_FLASH: string;
        static readonly ANIMATION_NONE: string;
        static readonly TYPE_NORMAL: string;
        static readonly TYPE_OVERLAY: string;
        static readonly TYPE_UNDERLAY: string;
        static readonly TYPE_HIGH: string;
        static readonly TYPE_MID: string;
        static readonly TYPE_LOW: string;
        static readonly TYPE_WILD: string;
        static readonly TYPE_SCATTER: string;
        static readonly DEFAULT_ANIMATION_KEY: string;
        static readonly DEFAULT_ALWAYS_ANIMATION_KEY: string;
    }
}
