/** 
	Adapter Interface v1.0.3 
	©Ingenuity Gaming Pvt. Ltd.
	Published: Tue Sep 24 2019 16:14:22 GMT+0530 (India Standard Time) 
**/
/* tslint:disable */
/* tslint:disable */
/// <reference path="../../../node_modules/typescript/lib/lib.d.ts" />
/// <reference path="../../../node_modules/typescript/lib/lib.es2015.symbol.d.ts" />
/// <reference path="../../../node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts" />
/// <reference path="../pixi/pixi.d.ts" />
/** These are added to correct the build error for node typing */
declare namespace ingenuity.bridge {
    interface IObject extends Object {
        [key: string]: number | string | boolean | any;
        [key: number]: number | string | boolean | any;
    }
}
declare namespace ingenuity.bridge {
    interface IBack {
    }
    interface IBounce {
    }
    interface ICircular {
    }
    interface ICubic {
    }
    interface IElastic {
    }
    interface IExponential {
    }
    interface ILinear {
    }
    interface IQuadratic {
    }
    interface IQuartic {
    }
    interface IQuintic {
    }
    interface ISinusoidal {
    }
    interface ISine {
    }
}
declare namespace ingenuity.bridge {
    interface IAnimation {
        currentFrame: IFrame;
        delay: number;
        frame: number;
        frameTotal: number;
        game: IGame;
        isFinished: boolean;
        isPaused: boolean;
        isPlaying: boolean;
        killOnComplete: boolean;
        loop: boolean;
        loopCount: number;
        name: string;
        onComplete: ISignal;
        onLoop: ISignal;
        onStart: ISignal;
        onUpdate: ISignal;
        isReversed: boolean;
        speed: number;
        animationSpeed: number;
        currFrame: number;
        enableUpdate: boolean;
        reversed: boolean;
        paused: boolean;
        complete(): void;
        destroy(): void;
        next(quantity?: number): void;
        previous(quantity?: number): void;
        onPause(): void;
        onResume(): void;
        play(frameRate?: number, loop?: boolean, killOnComplete?: boolean): this;
        stop(resetFrame?: boolean, dispatchComplete?: boolean): this;
        update(): boolean;
        gotoAndStop(frameNumber: number): void;
        updateFrameData(frameData: IFrameData): void;
    }
}
declare namespace ingenuity.bridge {
    interface IAnimationManager {
        currentAnim: IAnimation;
        currentFrame: IFrame;
        frameDataObj: IFrameData;
        game: IGame;
        isLoaded: boolean;
        sprite: ISprite;
        updateIfVisible: boolean;
        texture: Array<ITexture>;
        frameData: IFrameData;
        frameTotal: number;
        paused: boolean;
        frame: number;
        name: string;
        frameName: string;
        loadFrameData(frameData: IFrameData, frame: string | number): boolean;
        add(name: string, frames?: number[] | string[], frameRate?: number, loop?: boolean, useNumericIndex?: boolean): IAnimation;
        play(name: string, frameRate?: number, loop?: boolean, killOnComplete?: boolean): IAnimation;
        stop(name?: string, resetFrame?: boolean): void;
        update(): boolean;
        next(quantity?: number): IAnimation;
        previous(quantity?: number): IAnimation;
        getAnimation(name: string): IAnimation;
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IBitmapText {
        game?: IGame;
        anchor?: IPoint;
        fontSize?: number;
        setText(text: string): this;
    }
}
declare namespace ingenuity.bridge {
    interface IButton {
        type?: number;
        physicsType?: number;
        onOverSound?: any;
        onOutSound?: any;
        onDownSound?: any;
        onUpSound?: any;
        onOverSoundMarker?: string;
        onOutSoundMarker?: string;
        onDownSoundMarker?: string;
        onUpSoundMarker?: string;
        onInputOver: ISignal;
        onInputOut: ISignal;
        onInputDown: ISignal;
        onInputUp: ISignal;
        onOverMouseOnly: boolean;
        freezeFrames: boolean;
        forceOut: boolean;
        clearFrames(): void;
        setFrames(overFrame: number | string, outFrame: number | string, downFrame: number | string, upFrame: number | string): void;
        setSounds(overSound: any, overMarker: string, downSound: any, downMarker: string, outSound: any, outMarker: string, upSound: any, upMarker: string): void;
        setOverSound(sound: any, marker: string): void;
        setOutSound(sound: any, marker: string): void;
        setDownSound(sound: any, marker: string): void;
        setUpSound(sound: any, marker: string): void;
    }
}
/**
 * This class handles with many raw data. It is tedius to write that many interfaces, and is not so useful for a game developer,
 * therefore many variables are left as type `any`.
 */
declare namespace ingenuity.bridge {
    interface ICache {
        addSpine: (key: string, data: any) => void;
        getSpine: (key: string) => any;
        addBinary(key: string, binaryData: any): void;
        addBitmapFont(key: string, url: string, data: any, atlasData: any, atlasType: string, xSpacing?: number, ySpacing?: number): void;
        addBitmapFontFromAtlas(key: string, atlasKey: string, atlasFrame: string, dataKey: string, dataType?: string, xSpacing?: number, ySpacing?: number): void;
        addCanvas(key: string, canvas: HTMLCanvasElement, context?: CanvasRenderingContext2D): void;
        addImage(key: string, url: string, data: any): HTMLImageElement;
        addJSON(key: string, urL: string, data: any): void;
        addMissingImage(): void;
        addRenderTexture(key: string, texture: IRenderTexture): void;
        addShader(key: string, url: string, data: any): void;
        addSound(key: string, url: string, data: any, webAudio: boolean, audioTag: boolean): void;
        addSpriteSheet(key: string, url: string, data: any, frameWidth: number, frameHeight: number, frameMax?: number, margin?: number, spacing?: number, skipFrames?: number): void;
        addText(key: string, url: string, data: any): void;
        addTextureAtlas(key: string, url: string, data: any, atlasData: any, format: number): void;
        addTilemap(key: string, url: string, mapData: any, format: number): void;
        addVideo(key: string, url: string, data: any, isBlob?: boolean): void;
        addXML(key: string, url: string, data: any): void;
        checkBinaryKey(key: string): boolean;
        checkBitmapDataKey(key: string): boolean;
        checkBitmapFontKey(key: string): boolean;
        checkCanvasKey(key: string): boolean;
        checkImageKey(key: string): boolean;
        checkJSONKey(key: string): boolean;
        checkKey(cache: number, key: string): boolean;
        checkRenderTextureKey?(key: string): boolean;
        checkShaderKey?(key: string): boolean;
        checkSoundKey(key: string): boolean;
        checkTextKey(key: string): boolean;
        checkTextureKey(key: string): boolean;
        checkTilemapKey(key: string): boolean;
        checkURL?(url: string): any;
        checkUrl?(url: string): any;
        checkXMLKey(key: string): boolean;
        checkVideoKey(key: string): boolean;
        checkSpine(key: string): boolean;
        getBinary(key: string): any;
        getBitmapFont(key: string): any;
        getCanvas(key: string): HTMLCanvasElement;
        getFrame(key: string, cache?: number): IFrame;
        getFrameByIndex(key: string, index: number, cache?: number): IFrame;
        getFrameByName(key: string, name: string, cache?: number): IFrame;
        getFrameCount(key: string, cache?: number): number;
        getFrameData(key: string, cache?: number): IFrameData;
        getImage(key: string, full?: boolean): HTMLImageElement;
        getItem(key: string, cache: number, method?: string, property?: string): any;
        getJSON(key: string, clone?: boolean): any;
        getKeys(cache: number): string[];
        getRenderTexture?(key: string): any;
        getShader(key: string): string;
        getSound(key: string): any;
        getSoundData(key: string): any;
        getSpriteSheetKey(key: string): boolean;
        getText(key: string): string;
        getTextKeys(): string[];
        getTexture?(key: string): IRenderTexture;
        getTextureAtlasKey(key: string): boolean;
        getTextureFrame(key: string): IFrame;
        getTilemap(key: string): any;
        getTilemapData(key: string): any;
        getURL(url: string): any;
        getXML(key: string): any;
        getVideo(key: string): any;
        removeBinary(key: string): void;
        removeBitmapData(key: string): void;
        removeBitmapFont(key: string): void;
        removeCanvas(key: string): void;
        removeImage(key: string, destroyBaseTexture?: boolean): void;
        removeJSON(key: string): void;
        removeRenderTexture(key: string): void;
        removeShader(key: string): void;
        removeSound(key: string): void;
        removeSpriteSheet(key: string): void;
        removeText(key: string): void;
        removeTextureAtlas(key: string): void;
        removeTilemap(key: string): void;
        removeXML(key: string): void;
        removeVideo(key: string): void;
        removeSpine(key: string): void;
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    interface ICamera {
        x: number;
        y: number;
        game: IGame;
        view: IRectangle;
        width: number;
        height: number;
        setSize(width: number, height: number): void;
    }
}
declare namespace ingenuity.bridge {
    interface ICircle {
        diameter: number;
        left: number;
        right: number;
        top: number;
        bottom: number;
        clone(): ICircle;
        contains(x: number, y: number): boolean;
        getBounds(): IRectangle;
        setTo(x: number, y: number, radius: number): ICircle;
        circumferencePoint(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IContainer {
        json: IContainerJSON;
        onChildInputUp?: ISignal;
        game: IGame;
        anchor?: IPoint;
        signals?: {
            [key: string]: ISignal;
        };
        children?: any[];
        name?: string;
        alive?: boolean;
        bottom?: number;
        centerX?: number;
        angle?: number;
        centerY?: number;
        cursor?: any;
        cursorIndex?: number;
        exists?: any;
        inputEnableChildren?: boolean;
        left?: number;
        length?: number;
        pendingDestroy?: boolean;
        right?: number;
        top?: number;
        total?: number;
        z?: number;
        add?(child: any, silent?: boolean, index?: number): any;
        addAll?(property: string, amount: number, checkAlive?: boolean, checkVisible?: boolean): void;
        addAt?(child: any, index: number, silent?: boolean): any;
        addMultiple?(children: any[], silent?: boolean): any[];
        addToHash?(child: IDisplayObject): boolean;
        align?(width: number, height: number, cellWidth: number, cellHeight: number, position?: number, offset?: number): boolean;
        alignIn?(container: IRectangle | ISprite | IImage | IText | IBitmapText | IButton | IGraphics, position?: number, offsetX?: number, offsetY?: number): IContainer;
        alignTo?(container: IRectangle | ISprite | IImage | IText | IBitmapText | IButton | IGraphics, position?: number, offsetX?: number, offsetY?: number): IContainer;
        bringToTop?(child: any): any;
        callAll?(method: string, context: any, ...parameters: any[]): void;
        callAllExists?(callback: string, existsValue: boolean, ...parameters: any[]): void;
        callbackFromArray?(child: any, callback: Function, length: number): void;
        checkAll?(key: string, value: any, checkAlive?: boolean, checkVisible?: boolean, force?: boolean): boolean;
        checkAny?(key: string, value: any, checkAlive?: boolean, checkVisible?: boolean): boolean;
        checkProperty?(child: any, key: string, value: any, force?: boolean): boolean;
        count?(key: string, value: any): number;
        countDead?(): number;
        countLiving?(): number;
        create?(x: number, y: number, key?: string | IRenderTexture | IVideo | ITexture, frame?: string | number, exists?: boolean, index?: number): any;
        createMultiple?(quantity: number, key: string | string[], frame?: any | any[], exists?: boolean, callback?: Function, callbackContext?: any): any[];
        customSort?(sortHandler: Function, context?: any): void;
        destroy?(options?: Object | boolean | {
            children?: boolean;
            texture?: boolean;
            baseTexture?: boolean;
        }): void;
        divideAll?(property: string, amount: number, checkAlive?: boolean, checkVisible?: boolean): void;
        forEach?(callback: Function, callbackContext?: any, checkExists?: boolean, ...args: any[]): void;
        forEachAlive?(callback: Function, callbackContext?: any, ...args: any[]): void;
        forEachDead?(callback: Function, callbackContext?: any, ...args: any[]): void;
        forEachExists?(callback: Function, callbackContext?: any): void;
        getAll?(property?: string, value?: any, startIndex?: number, endIndex?: number): any[];
        getAt?(index: number): IDisplayObject | number;
        getBottom?(): any;
        getByName?(name: string): any;
        getClosestTo?(object: any, callback?: Function, callbackContext?: any): any;
        getFirst?(key: string, value: any): any;
        getFirstAlive?(createIfNull?: boolean, x?: number, y?: number, key?: string | IRenderTexture | IVideo | ITexture, frame?: string | number): any;
        getFirstDead?(createIfNull?: boolean, x?: number, y?: number, key?: string | IRenderTexture | IVideo | ITexture, frame?: string | number): any;
        getFirstExists?(exists: boolean, createIfNull?: boolean, x?: number, y?: number, key?: string | IRenderTexture | IVideo | ITexture, frame?: string | number): any;
        getFurthestFrom?(object: any, callback?: Function, callbackContext?: any): any;
        getIndex?(child: IDisplayObject): number;
        getRandom?(startIndex?: number, length?: number): any;
        getTop?(): any;
        hasProperty?(child: any, key: string[]): boolean;
        iterate?(key: string, value: any, returnType: number, callback?: Function, callbackContext?: any, ...args: any[]): any;
        kill?(): void;
        killAll?(): void;
        moveAll?(group: IContainer, silent?: boolean): IContainer;
        moveDown?(child: any): any;
        moveUp?(child: any): any;
        multiplyAll?(property: string, amount: number, checkAlive: boolean, checkVisible: boolean): void;
        next?(): any;
        postUpdate?(): void;
        preUpdate?(): void;
        previous?(): any;
        remove?(child: any, destroy?: boolean, silent?: boolean): boolean;
        removeAll?(destroy?: boolean, silent?: boolean, destroyTexture?: boolean): void;
        removeBetween?(startIndex: number, endIndex?: number, destroy?: boolean, silent?: boolean): void;
        removeFromHash?(child: IDisplayObject): boolean;
        replace?(oldChild: any, newChild: any): any;
        resetAll?(x?: number, y?: number, key?: string | IRenderTexture | IVideo | ITexture, frame?: string | number, checkExists?: boolean): void;
        resetChild?(child: any, x?: number, y?: number, key?: string | IRenderTexture | IVideo | ITexture, frame?: string | number): any;
        resetCursor?(index?: number): any;
        reverse?(): void;
        revive?(): void;
        reviveAll?(): void;
        scatter?(rect?: IRectangle, checkExists?: boolean): void;
        sendToBack?(child: any): any;
        set?(child: any, key: string[], value: any, operation?: number, force?: boolean): boolean;
        setAll?(key: string, value: any, checkAlive?: boolean, checkVisible?: boolean, operation?: number, force?: boolean): void;
        setAllChildren?(key: string, value: any, checkAlive?: boolean, checkVisible?: boolean, operation?: number, force?: boolean): void;
        setProperty?(child: any, key: string[], value: any, operation?: number, force?: boolean): boolean;
        shuffle?(): void;
        sort?(key?: string, order?: number): void;
        subAll?(property: string, amount: number, checkAlive: boolean, checkVisible: boolean): void;
        swap?(child1: any, child2: any): boolean;
        update(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IContainerJSON {
        x?: number;
        y?: number;
        w?: number;
        h?: number;
        /** An alias of json.w */
        width?: number;
        /** An alias of json.h */
        height?: number;
        id?: string;
        visible?: boolean;
        parent?: string;
        regX?: number;
        regY?: number;
        rotation?: number;
        showBounds?: boolean;
        bounds?: boolean;
        boundsStroke?: number;
        boundsColor?: number;
    }
}
declare namespace ingenuity.bridge {
    interface ICoords {
        top: number;
        right: number;
        bottom: number;
        left: number;
    }
}
declare namespace ingenuity.bridge {
    interface IDisplayObject extends PIXI.DisplayObject {
    }
}
declare namespace ingenuity.bridge {
    interface IDisplayObjectContainer {
        children: IDisplayObject[];
        height: number;
        width: number;
        ignoreChildInput: boolean;
        addChild(child: IDisplayObject): IDisplayObject;
        addChildAt(child: IDisplayObject, index: number): IDisplayObject;
        getBounds(skipUpdate?: boolean, rect?: IRectangle): IRectangle;
        getChildAt(index: number): IDisplayObject;
        getChildIndex(child: IDisplayObject): number;
        getLocalBounds?(): IRectangle;
        removeChild?(child: IDisplayObject): IDisplayObject;
        removeChildAt?(index: number): IDisplayObject;
        removeChildren?(beginIndex?: number, endIndex?: number): IDisplayObject[];
        removeStageReference?(): void;
        setChildIndex?(child: IDisplayObject, index: number): void;
        swapChildren?(child: IDisplayObject, child2: IDisplayObject): void;
        contains?(child: IDisplayObject): boolean;
    }
}
declare namespace ingenuity.bridge {
    interface IEllipse {
        clone(): IEllipse;
        contains(x: number, y: number): boolean;
        getBounds(): IRectangle;
        setTo(x: number, y: number, width: number, height: number): IEllipse;
    }
}
declare namespace ingenuity.bridge {
    interface IEvent {
        type: string;
        data: any;
        timeStamp: number;
        target: any;
        removed: boolean;
        remove(): void;
        toString(): string;
    }
}
declare namespace ingenuity.bridge {
    interface IEventDispatcher {
        on(type: string, handler: (e?: IEvent) => void, scope: any, once: boolean, data: any, priority: number): () => void;
        off(type: string, handler?: (e?: IEvent) => void): void;
        offForScope(type: string, scope: any, handler?: (evt?: IEvent, data?: IObject) => void): void;
        hasEvent(type: string): boolean;
        fireEvent(type: string | Event, data?: any): void;
    }
}
declare namespace ingenuity.bridge {
    interface IEventObject extends IObject {
        func: () => void;
        scope: any;
        once: boolean;
        data: any;
        priority: number;
    }
}
declare namespace ingenuity.bridge {
    interface IEvents {
        onAddedToGroup: ISignal;
        onRemovedFromGroup: ISignal;
        onDestroy: ISignal;
        onKilled: ISignal;
        onRevived: ISignal;
        onOutOfBounds: ISignal;
        onEnterBounds: ISignal;
        onInputOver: ISignal;
        onInputOut: ISignal;
        onInputDown: ISignal;
        onInputUp: ISignal;
        onDragStart: ISignal;
        onDragUpdate: ISignal;
        onDragStop: ISignal;
        onAnimationStart: ISignal;
        onAnimationComplete: ISignal;
        onAnimationLoop: ISignal;
        onRemovedFromWorld: ISignal;
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IFilter extends PIXI.Filter {
    }
}
declare namespace ingenuity.bridge {
    interface IFrame {
        index: number;
        x: number;
        y: number;
        bottom: number;
        centerX: number;
        centerY: number;
        distance: number;
        height: number;
        name: string;
        right: number;
        rotated: boolean;
        sourceSizeH: number;
        sourceSizeW: number;
        spriteSourceSizeH: number;
        spriteSourceSizeW: number;
        spriteSourceSizeX: number;
        spriteSourceSizeY: number;
        trimmed: boolean;
        uuid: string;
        width: number;
        resize(width: number, height: number): void;
        setTrim(trimmed: boolean, actualWidth: number, actualHeight: number, destX: number, destY: number, destWidth: number, destHeight: number): void;
        clone(): IFrame;
        getRect(out?: IRectangle): IRectangle;
    }
}
declare namespace ingenuity.bridge {
    interface IFrameData {
        frames: IFrame[];
        total: number;
        addFrame(frame: IFrame): IFrame;
        getFrame(index: number): IFrame;
        getFrameByName(name: string): IFrame;
        checkFrameName(name: string): boolean;
        clone(): IFrameData;
        getFrameRange(start: number, end: number, output: IFrame[]): IFrame[];
        getFrames(frames?: number[], useNumericIndex?: boolean, output?: IFrame[]): IFrame[];
        getFrameIndexes(frames?: number[], useNumericIndex?: boolean, output?: number[]): number[];
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IFullScreen {
        targetWidth: string;
        targetHeight: string;
    }
}
declare namespace ingenuity.bridge {
    interface IGame {
        stage: IContainer | PIXI.Container | any;
        state: IStateManager;
        cache: ICache;
        tweens: ITweenManager;
        camera?: ICamera;
        add?: IObjectFactory;
        time?: ITime;
        scale?: IScaleManager;
        plugins?: IPluginManager;
        device?: any;
        renderer: ICanvasRenderer | IRenderer;
        sound: ISoundManager;
        canvas: HTMLCanvasElement;
        height: number;
        id: number;
        width: number;
        parent: HTMLElement;
        renderType: number;
        resolution: number;
        isBooted: boolean;
        config: IDefaultConfig;
        load: ILoader;
        antialias?: boolean;
        clearBeforeRender: boolean;
        onPause: ISignal;
        onResume: ISignal;
        onBlur: ISignal;
        onFocus: ISignal;
        input: IInput;
        ticker: PIXI.Ticker;
        deltaTime: number;
        particles: any;
        rnd?: any;
        math?: any;
        /** Please use `game.add()` for now. `game.make()` will be added when needed */
        make?: IObjectCreator;
        context?: CanvasRenderingContext2D;
        transparent?: boolean;
        paused: boolean;
        inputSigToContainer(): void;
        boot(event?: IEvent): void;
        gamePaused(event: IEvent): void;
        gameResumed(event: IEvent): void;
        destroy(): void;
        focusLoss(event: IEvent): void;
        focusGain(event: IEvent): void;
    }
}
declare namespace ingenuity.bridge {
    interface IGameConfig extends IObject {
        alignH?: boolean;
        alignV?: boolean;
        antialias?: boolean;
        backgroundColor?: number | string;
        canvas?: HTMLCanvasElement;
        canvasId?: string;
        canvasStyle?: string;
        crisp?: boolean;
        disableVisibilityChange?: boolean;
        disableStart?: boolean;
        enableDebug?: boolean;
        failIfMajorPerformanceCaveat?: boolean;
        forceSetTimeOut?: boolean;
        fullScreenScaleMode?: number;
        fullScreenTarget?: HTMLElement;
        height?: number | string;
        multiTexture?: boolean;
        parent?: HTMLElement | string;
        physicsConfig?: any;
        preserveDrawingBuffer?: boolean;
        renderer?: number;
        resolution?: number;
        roundPixels?: boolean;
        scaleH?: number;
        scaleMode?: number;
        scaleV?: number;
        seed?: number;
        state?: any;
        transparent?: boolean;
        trimH?: number;
        trimV?: number;
        width?: number | string;
        clearBeforeRender?: boolean;
    }
    /**
     * It stores the default bridge.Game configuration options.
     */
    interface IDefaultConfig extends IGameConfig {
        view?: HTMLCanvasElement;
        forceCanvas?: boolean;
        resizeTo?: boolean;
    }
}
declare namespace ingenuity.bridge {
    interface IGraphics extends IContainer {
        name: string;
        position: IPoint;
        json: any;
        pivot: IPoint;
        parent: any;
        renderable: boolean;
        rotation: number;
        visible: boolean;
        scale: IPoint;
        input: IInputHandler;
        onInputOver: ISignal;
        onInputOut: ISignal;
        onInputDown: ISignal;
        onInputUp: ISignal;
        events: IEvents;
        game: IGame;
        inputEnabled: boolean;
        update(): void;
        generateCanvasTexture?(scaleMode?: number, resolution?: number): PIXI.Texture;
    }
}
declare namespace ingenuity.bridge {
    interface IGraphicsData {
        lineWidth: number;
        lineColor: number;
        lineAlpha: number;
        fillColor: number;
        fillAlpha: number;
        fill: boolean;
        nativeLines?: boolean;
        shape: ICircle | IRectangle | IEllipse | IPolygon | IRoundedRectangle | any;
        lineAlignment: number;
        clone(): IGraphicsData;
    }
}
declare namespace ingenuity.bridge {
    interface IImage {
        alive: boolean;
        angle: number;
        bottom?: number;
        cameraOffset: IPoint;
        fixedToCamera: boolean;
        centerX: number;
        centerY: number;
        cropRect: IRectangle;
        data: IObject;
        deltaX: number;
        deltaY: number;
        deltaZ: number;
        destroyPhase: boolean;
        events: IEvents;
        exists: boolean;
        frameData: IFrameData;
        frame: string | number;
        frameName: string;
        fresh: boolean;
        game?: IGame;
        inCamera: boolean;
        input: IInputHandler;
        inWorld: boolean;
        key: string | IRenderTexture | IVideo | ITexture;
        lifespan: number;
        left: number;
        name: string;
        offsetX: number;
        offsetY: number;
        position: IPoint;
        right: number;
        scale: IPoint;
        scaleMax: IPoint;
        scaleMin: IPoint;
        smoothed: boolean;
        top: number;
        z: number;
        src: string;
        animations: IAnimationManager;
        textures: ITexture[];
        inputEnabled: boolean;
        loadFrameData(frameData: IFrameData, frame: string | number): boolean;
        setFrame(frame: string | number, frameData: IFrameData): void;
    }
}
declare namespace ingenuity.bridge {
    interface ILoader {
        onLoadStart: ISignal;
        onLoadComplete: ISignal;
        onPackComplete: ISignal;
        onFileStart: ISignal;
        onFileComplete: ISignal;
        onFileError: ISignal;
        baseURL?: string;
        progressFloat: number;
        progress: number;
        resize?(): void;
        checkKeyExists(type: string, key: string): boolean;
        getAssetIndex(type: string, key: string): number;
        getAsset(type: string, key: string): any;
        reset(hard?: boolean, clearEvents?: boolean): void;
        addToFileList(type: string, key: string, url: string | string[] | object[], properties?: any, overwrite?: boolean, extension?: string): ILoader;
        replaceInFileList(type: string, key: string, url: string, properties: any): ILoader;
        pack(key: string, url: string, data?: any, callbackContext?: any): ILoader;
        image(key: string, url?: any, overwrite?: boolean): ILoader;
        images(keys: string[], urls?: any): ILoader;
        text(key: string, url?: string, overwrite?: boolean): ILoader;
        json(key: string, url?: string, overwrite?: boolean): ILoader;
        shader(key: string, url?: string, overwrite?: boolean): ILoader;
        xml(key: string, url?: string, overwrite?: boolean): ILoader;
        script(key: string, url?: string, callback?: any, callbackContext?: any): ILoader;
        binary(key: string, url?: string, callback?: any, callbackContext?: any): ILoader;
        spritesheet(key: string, url: string, frameWidth: number, frameHeight: number, frameMax: number, margin: number, spacing: number): ILoader;
        audio(key: string, urls?: string | string[] | object[], autoDecode?: boolean): ILoader;
        audioSprite(key: string, urls?: string | string[] | object[], jsonURL?: string, jsonData?: string | object, autoDecode?: boolean): ILoader;
        audiosprite(key: string, urls?: string | string[] | object[], jsonURL?: string, jsonData?: string | object, autoDecode?: boolean): ILoader;
        video(key: string, urls?: string | string[] | object[], loadEvent?: string, asBlob?: boolean): ILoader;
        tilemap(key: string, url?: string, data?: any, format?: number): ILoader;
        bitmapFont(key: string, textureURL?: string, atlasURL?: string, atlasData?: object, xSpacing?: number, ySpacing?: number): ILoader;
        atlasJSONArray(key: string, textureURL: string, atlasURL: string, atlasData?: object): ILoader;
        atlasJSONHash(key: string, textureURL: string, atlasURL: string, atlasData?: object): ILoader;
        atlasXML(key: string, textureURL: string, atlasURL: string, atlasData?: object): ILoader;
        atlas(key: string, textureURL: string, atlasURL: string, atlasData?: object, format?: any): ILoader;
        spine(key: string, url: string): ILoader;
        withSyncPoint(callback: any, callbackContext: object): ILoader;
        addSyncPoint(type: string, key: string): ILoader;
        removeFile(type: string, key: string): void;
        removeAll(): void;
        start(): void;
        processPack(pack: any): void;
    }
}
declare namespace ingenuity.bridge {
    interface IMatrix extends PIXI.Matrix {
    }
}
declare namespace ingenuity.bridge {
    interface IArraySet {
        list: Array<any>;
        position: number;
        total: number;
        next: number;
        add(item: any): any;
        getIndex(item: any): number;
        getByKey(property: string, value: any): any;
        exists(item: any): boolean;
        reset(): void;
        remove(item: any): any;
        setAll(key: any, value: any): void;
        callAll(key: string, ...param: any[]): void;
        removeAll(destroy?: boolean): void;
    }
}
declare namespace ingenuity.bridge {
    interface IDeviceButton {
        parent: IPointer | ISinglePad | any;
        game: IGame;
        event: IObject;
        isDown: boolean;
        isUp: boolean;
        timeDown: number;
        timeUp: number;
        repeats: number;
        altKey: boolean;
        shiftKey: boolean;
        ctrlKey: boolean;
        value: number;
        buttonCode: number;
        onDown: ISignal;
        onUp: ISignal;
        onFloat: ISignal;
        duration: number;
        start(event: IObject, value?: number): void;
        stop(event: IObject, value?: number): void;
        padFloat(value: number): void;
        justPressed(duration: number): boolean;
        justReleased(duration: number): boolean;
        reset(): void;
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IInput {
        game: IGame;
        hitCanvas: HTMLCanvasElement;
        hitContext: CanvasRenderingContext2D;
        moveCallbacks: Array<any>;
        customCandidateHandler: Function;
        customCandidateHandlerContext: Object;
        pollRate: number;
        enabled: boolean;
        multiInputOverride: number;
        position: IPoint;
        speed: IPoint;
        circle: ICircle;
        scale: IPoint;
        maxPointers: number;
        tapRate: number;
        doubleTapRate: number;
        holdRate: number;
        justPressedRate: number;
        justReleasedRate: number;
        recordPointerHistory: boolean;
        recordRate: number;
        recordLimit: number;
        pointer1: IPointer;
        pointer2: IPointer;
        pointer3: IPointer;
        pointer4: IPointer;
        pointer5: IPointer;
        pointer6: IPointer;
        pointer7: IPointer;
        pointer8: IPointer;
        pointer9: IPointer;
        pointer10: IPointer;
        pointers: IPointer[];
        activePointer: IPointer;
        mousePointer: IPointer;
        mouse: IMouse;
        keyboard: IKeyboard;
        touch: ITouch;
        mspointer: IMSPointer;
        gamepad: Gamepad;
        resetLocked: boolean;
        onDown: ISignal;
        onUp: ISignal;
        onTap: ISignal;
        onHold: ISignal;
        minPriorityID: number;
        interactiveItems: IArraySet;
        x: number;
        y: number;
        pollLocked: boolean;
        totalInactivePointers: number;
        totalActivePointers: number;
        worldX: number;
        boot(): void;
        destroy(): void;
        setInteractiveCandidateHandler(callback: Function, context: any): void;
        addMoveCallback(callback: Function, context: any): void;
        deleteMoveCallback(callback: Function, context: any): void;
        addPointer(): IPointer;
        update(): void;
        reset(hard?: boolean): void;
        resetSpeed(x: number, y: number): void;
        startPointer(event: any): IPointer;
        updatePointer(event: any): IPointer;
        stopPointer(event: any): IPointer;
        getPointer(isActive?: boolean): IPointer;
        getPointerFromId(pointerId: number): IPointer;
        getLocalPosition(displayObject: any, pointer: IPointer, output?: IPoint): IPoint;
        getPointerFromIdentifier(identifier: number): IPointer;
        hitTest(displayObject: any, pointer: IPointer, localPoint: IPoint): boolean;
    }
}
declare namespace ingenuity.bridge {
    interface IInputHandler {
        sprite: IImage;
        game: IGame;
        enabled: boolean;
        checked: boolean;
        priorityID: number;
        useHandCursor: boolean;
        _draggedPointerID?: number;
        isDragged: boolean;
        allowHorizontalDrag: boolean;
        allowVerticalDrag: boolean;
        bringToTop: boolean;
        snapOffset: IPoint;
        snapOnDrag: boolean;
        snapOnRelease: boolean;
        snapX: number;
        snapY: number;
        snapOffsetX: number;
        snapOffsetY: number;
        pixelPerfectOver: boolean;
        pixelPerfectClick: boolean;
        pixelPerfectAlpha: number;
        draggable: boolean;
        boundsRect: IRectangle;
        boundsSprite: IImage;
        scaleLayer: boolean;
        dragOffset: IPoint;
        dragFromCenter: boolean;
        dragStopBlocksInputUp: boolean;
        dragStartPoint: IPoint;
        dragDistanceThreshold: number;
        dragTimeThreshold: number;
        downPoint: IPoint;
        snapPoint: IPoint;
        start(priority?: number, useHandCursor?: boolean): IImage | any;
        reset(): void;
        stop(): void;
        destroy(): void;
        validForInput(highestID: number, highestRenderID: number, includePixelPerfect?: boolean): boolean;
        isPixelPerfect(): boolean;
        pointerX(pointerId?: number): number;
        pointerY(pointerId?: number): number;
        pointerDown(pointerId?: number): boolean;
        pointerUp(pointerId?: number): boolean;
        pointerTimeDown(pointerId?: number): boolean;
        pointerTimeUp(pointerId?: number): number;
        pointerOver(pointerId: number): boolean;
        pointerOut(pointerId: number): boolean;
        pointerTimeOver(pointerId?: number): number;
        pointerTimeOut(pointerId?: number): number;
        pointerDragged(pointerId?: number): number;
        checkPointerDown(pointer: IPointer, fastTest?: boolean): boolean;
        checkPointerOver(pointer: IPointer, fastTest?: boolean): boolean;
        checkPixel(x: number, y: number, pointer?: IPointer): boolean;
        update(pointer?: IPointer): boolean;
        justOver(pointerId?: number, delay?: number): boolean;
        justOut(pointerId?: number, delay?: number): boolean;
        justPressed(pointerId?: number, delay?: number): boolean;
        justReleased(pointerId?: number, delay?: number): boolean;
        overDuration(pointerId?: number): number;
        downDuration(pointerId?: number): number;
        enableDrag(lockCenter?: boolean, bringToTop?: boolean, pixelPerfect?: boolean, alphaThreshold?: number, boundsRect?: IRectangle, boundsSprite?: IImage): void;
        disableDrag(): void;
        startDrag(pointer: IPointer): void;
        globalToLocalX(x: number): number;
        globalToLocalY(y: number): number;
        stopDrag(pointer: IPointer): void;
        setDragLock(allowHorizontal?: boolean, allowVertical?: boolean): void;
        enableSnap(snapX: number, snapY: number, onDrag?: boolean, onRelease?: boolean, snapOffsetX?: number, snapOffsetY?: number): void;
        disableSnap(): void;
        checkBoundsRect(): void;
        checkBoundsSprite(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IKey {
        game: IGame;
        event: KeyboardEvent;
        isDown: boolean;
        isUp: boolean;
        altKey: boolean;
        ctrlKey: boolean;
        shiftKey: boolean;
        timeDown: number;
        duration: number;
        timeUp: number;
        repeats: number;
        keyCode: number;
        onDown: ISignal;
        onHoldCallback: Function;
        onHoldContext: Object;
        onUp: ISignal;
        justDown: boolean;
        justUp: boolean;
        enabled: boolean;
        update(): void;
        processKeyDown(event: KeyboardEvent): void;
        processKeyUp(event: KeyboardEvent): void;
        reset(hard?: boolean): void;
        downDuration(duration?: number): boolean;
        upDuration(duration?: number): boolean;
    }
}
declare namespace ingenuity.bridge {
    interface IKeyboard {
        game: IGame;
        enabled: boolean;
        event: KeyboardEvent;
        pressEvent: KeyboardEvent;
        callbackContext: Object;
        onDownCallback: Function;
        onPressCallback: Function;
        onUpCallback: Function;
        lastChar: string;
        lastKey: IKey;
        addCallbacks(context: object, onDown: Function, onUp: Function, onPress: Function): void;
        addKey(keycode: number): IKey;
        addKeys(keys: IObject): IObject;
        removeKey(keycode: number): void;
        createCursorKeys(): IObject;
        start(): void;
        stop(): void;
        destroy(): void;
        addKeyCapture(keycode: any): void;
        removeKeyCapture(keycode: number): void;
        clearCaptures(): void;
        update(): void;
        reset(hard?: boolean): void;
        downDuration(keycode: number, duration: number): boolean;
        upDuration(keycode: number, duration: number): boolean;
        isDown(keycode: number): boolean;
    }
}
declare namespace ingenuity.bridge {
    interface IMouse {
        game: IGame;
        input: IInput;
        callbackContext: any;
        mouseDownCallback: Function;
        mouseUpCallback: Function;
        mouseOutCallback: Function;
        mouseOverCallback: Function;
        mouseMoveCallback: Function;
        mouseWheelCallback: Function;
        capture: boolean;
        button: number;
        wheelDelta: number;
        enabled: boolean;
        locked: boolean;
        stopOnGameOut: boolean;
        pointerLock: ISignal;
        event: MouseEvent;
        start(): void;
        onMouseUp(event: MouseEvent): void;
        onMouseDown(event: MouseEvent): void;
        onMouseMove(event: MouseEvent): void;
        onMouseUpGlobal(event: MouseEvent): void;
        onMouseOutGlobal(event: MouseEvent): void;
        onMouseOut(event: MouseEvent): void;
        onMouseOver(event: MouseEvent): void;
        onMouseWheel(event: MouseEvent): void;
        requestPointerLock(): void;
        pointerLockChange(event: any): void;
        releasePointerLock(): void;
        stop(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IMSPointer {
        game: IGame;
        input: IInput;
        callbackContext: Object;
        pointerDownCallback: Function;
        pointerMoveCallback: Function;
        pointerUpCallback: Function;
        capture: boolean;
        button: number;
        event: MSPointerEvent;
        enabled: boolean;
        start(): void;
        onPointerDown(event: any): void;
        onPointerMove(event: any): void;
        onPointerUp(event: any): void;
        onPointerUpGlobal(event: any): void;
        onPointerOut(event: any): void;
        onPointerOver(event: any): void;
        stop(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IPointer {
        game: IGame;
        id: number;
        pointerMode: number;
        type: number;
        exists: boolean;
        identifier: number;
        pointerId: number;
        target: any;
        button: number;
        leftButton: IDeviceButton;
        middleButton: IDeviceButton;
        rightButton: IDeviceButton;
        backButton: IDeviceButton;
        forwardButton: IDeviceButton;
        eraserButton: IDeviceButton;
        withinGame: boolean;
        clientX: number;
        clientY: number;
        pageX: number;
        pageY: number;
        screenX: number;
        screenY: number;
        rawMovementX: number;
        rawMovementY: number;
        movementX: number;
        movementY: number;
        x: number;
        y: number;
        isMouse: boolean;
        isDown: boolean;
        isUp: boolean;
        timeDown: number;
        timeUp: number;
        previousTapTime: number;
        totalTouches: number;
        msSinceLastClick: number;
        targetObject: any;
        interactiveCandidates: Array<any>;
        active: boolean;
        dirty: boolean;
        position: IPoint;
        positionDown: IPoint;
        positionUp: IPoint;
        circle: ICircle;
        duration: number;
        resetButtons(): void;
        updateButtons(event: MouseEvent): void;
        start(event: any): IPointer;
        update(): void;
        move(event: MouseEvent | PointerEvent, fromClick?: boolean): IPointer;
        processInteractiveObjects(fromClick: boolean): boolean;
        swapTarget(newTarget: IInputHandler | any, silent: boolean): void;
        leave(event: MouseEvent | PointerEvent): void;
        stop(event: MouseEvent | PointerEvent | TouchEvent | any): IPointer;
        justPressed(duration: number): boolean;
        justReleased(duration: number): boolean;
        addClickTrampoline(name: string, callback: Function, callbackContext: any, callbackArgs: any[]): void;
        processClickTrampolines(): void;
        reset(): void;
        resetMovement(): void;
    }
}
declare namespace ingenuity.bridge {
    interface ISinglePad {
        game: IGame;
        index: number;
        connected: boolean;
        callbackContext: any;
        onConnectCallback: Function;
        onDisconnectCallback: Function;
        onDownCallback: Function;
        onUpCallback: Function;
        onAxisCallback: Function;
        onFloatCallback: Function;
        deadZone: number;
        addCallbacks(context: any, callbacks: any): void;
        getButton(buttonCode: number): IDeviceButton;
        pollStatus(): void;
        connect(rawPad: IObject): void;
        disconnect(): void;
        destroy(): void;
        processAxisChange(index: number, value: any): void;
        processButtonDown(buttonCode: number, value: any): void;
        processButtonUp(buttonCode: number, value: any): void;
        processButtonFloat(buttonCode: number, value: any): void;
        axis(axisCode: number): boolean;
        isDown(buttonCode: number): boolean;
        isUp(buttonCode: number): boolean;
        justReleased(buttonCode: number, duration: number): boolean;
        justPressed(buttonCode: number, duration: number): boolean;
        buttonValue(buttonCode: number): number;
        reset(): void;
    }
}
declare namespace ingenuity.bridge {
    interface ITouch {
        game: IGame;
        touchLockCallbacks: any[];
        preventDefault: boolean;
        enabled: boolean;
        callbackContext: IObject;
        touchMoveCallback: Function;
        touchEnterCallback: Function;
        touchLeaveCallback: Function;
        touchCancelCallback: Function;
        active: boolean;
        start(): void;
        addTouchLockCallback(callback: Function, context: Object, onEnd?: boolean): void;
        removeTouchLockCallback(callback: Function, context: Object): boolean;
        onTouchMove(event: TouchEvent): void;
        onTouchLeave(event: TouchEvent): void;
        onTouchStart(event: TouchEvent): void;
        onTouchEnd(event: TouchEvent): void;
        onTouchEnter(event: TouchEvent): void;
        onTouchCancel(event: TouchEvent): void;
        stop(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IWheelEventProxy {
        type: string;
        deltaMode: number;
        deltaX: number;
        deltaY: number;
        deltaZ: number;
        makeBinder(name: string): Function;
        bindEvent(event: any): IWheelEventProxy;
    }
}
declare namespace ingenuity.bridge {
    interface IObjectCreator {
        container: IContainer;
        image: IImage;
        graphics: IGraphics;
        filter?: IFilter;
    }
}
declare namespace ingenuity.bridge {
    interface IObjectFactory {
        game: IGame;
        tween(object: any): ITween;
        emitter(particleParent: PIXI.Container | IContainer | null, emitterData: IEmitterData, config: any): IEmitter;
        audioSprite(key: string): ISoundManager;
        text(x: number, y: number, text?: string, style?: ITextStyleBridge, canvas?: HTMLCanvasElement): IText;
        filter?(filterType: string | number, ...params: any[]): IFilter;
    }
}
declare namespace ingenuity.bridge {
    interface IPlugin {
    }
}
declare namespace ingenuity.bridge {
    interface IPluginManager {
        plugins: IPlugin[];
        add<T extends IPlugin>(plugin: any, ...parameters: any[]): T;
        destroy(): void;
        postRender(): void;
        postUpdate(): void;
        preUpdate(): void;
        remove(plugin: IPlugin, destroy?: boolean): void;
        removeAll(): void;
        render(): void;
        update(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IPointLike {
        x: number;
        y: number;
        set(x: number, y?: number): void;
        copy(point: IPointLike): void;
    }
    interface IPoint extends IPointLike {
        set(x?: number, y?: number): IPoint;
        clone(): IPoint;
        copyFrom(sourcePoint: IPoint): IPoint;
    }
}
declare namespace ingenuity.bridge {
    interface IPolygon {
        clone(): IPolygon;
        contains(x: number, y: number): boolean;
        setTo(points: Array<Array<number> | IPoint | number>): IPolygon;
    }
}
declare namespace ingenuity.bridge {
    interface IRectangle {
        left: number;
        right: number;
        top: number;
        bottom: number;
        contains(x: number, y: number): boolean;
        scale(x: number, y?: number): IRectangle;
        setTo(x: number, y: number, width: number, height: number): IRectangle;
        resize(width: number, height: number): IRectangle;
    }
}
declare namespace ingenuity.bridge {
    interface IRenderer extends PIXI.Renderer {
        generateTexture(displayObject: PIXI.DisplayObject, scaleMode?: number, resolution?: number, region?: PIXI.Rectangle): PIXI.Texture;
    }
    interface ICanvasRenderer extends PIXI.CanvasRenderer {
        generateTexture(displayObject: PIXI.DisplayObject, scaleMode?: number, resolution?: number, region?: PIXI.Rectangle): PIXI.Texture;
    }
    interface IMaskManager {
        pushMask(maskData: IMaskData, renderSession: IRenderSession): void;
        popMask(renderSession: IRenderSession): void;
    }
    interface IMaskData {
        alpha: number;
        worldTransform: number[];
    }
    interface IRenderSession {
        context: CanvasRenderingContext2D;
        maskManager: IMaskManager;
        smoothProperty: string;
        roundPixels: boolean;
    }
    interface IFilterBlock {
        visible: boolean;
        renderable: boolean;
    }
    interface IFilterManager {
        filterStack: IFilter[];
        transparent: boolean;
        offsetX: number;
        offsetY: number;
        applyFilterPass(filter: IFilter, filterArea: ITexture, width: number, height: number): void;
        begin(renderSession: IRenderSession, buffer: ArrayBuffer): void;
        destroy(): void;
        initShaderBuffers(): void;
        popFilter(): void;
        pushFilter(filterBlock: IFilterBlock): void;
        setContext(gl: WebGLRenderingContext): void;
    }
    interface IStencilManager {
        stencilStack: any[];
        reverse: boolean;
        count: number;
        bindGraphics(graphics: IGraphics, webGLData: any[], renderSession: IRenderSession): void;
        destroy(): void;
        popStencil(graphics: IGraphics, webGLData: any[], renderSession: IRenderSession): void;
        pushStencil(graphics: IGraphics, webGLData: any[], renderSession: IRenderSession): void;
        setContext(gl: WebGLRenderingContext): void;
    }
    interface IBlendModeManager {
        currentBlendMode: number;
        destroy(): void;
        setBlendMode(blendMode: number): boolean;
        setContext(gl: WebGLRenderingContext): void;
    }
}
declare namespace ingenuity.bridge {
    interface IRenderTexture extends PIXI.RenderTexture {
    }
}
declare namespace ingenuity.bridge {
    interface IRoundedRectangle {
        clone(): IRoundedRectangle;
        contains(x: number, y: number): boolean;
    }
}
declare namespace ingenuity.bridge {
    interface IScaleManager {
        screenOrientation?: string;
        game: IGame;
        width: number;
        height: number;
        minWidth: number;
        maxWidth: number;
        minHeight: number;
        maxHeight: number;
        forceLandscape?: boolean;
        forcePortrait?: boolean;
        incorrectOrientation?: boolean;
        fullScreenTarget?: HTMLElement;
        aspectRatio: number;
        offset?: IPoint;
        onOrientationChange: ISignal;
        enterIncorrectOrientation?: ISignal;
        leaveIncorrectOrientation?: ISignal;
        hasPixiSetFullScreen: boolean;
        onFullScreenInit: ISignal;
        onFullScreenChange: ISignal;
        onFullScreenError: ISignal;
        scaleFactor?: IPoint;
        scaleFactorInversed?: IPoint;
        compatibility?: {
            supportsFullScreen: boolean;
            orientationFallback: any;
            noMargins: boolean;
            scrollTo?: any;
            forceMinimumDocumentHeight: boolean;
            canExpandParent: boolean;
            clickTrampoline: string;
        };
        margin?: {
            left: number;
            top: number;
            right: number;
            bottom: number;
            x: number;
            y: number;
        };
        bounds?: IRectangle;
        sourceAspectRatio?: number;
        windowConstraints?: {
            bottom: string;
            right: string;
        };
        parentIsWindow?: boolean;
        parentScaleFactor?: IPoint;
        trackParentInterval?: number;
        onSizeChange: ISignal;
        parentNode?: HTMLElement;
        isFullScreen?: boolean;
        currentScaleMode?: number;
        boundingParent?: HTMLElement;
        isPortrait?: boolean;
        isLandscape?: boolean;
        scaleMode: number;
        fullScreenScaleMode?: number;
        pageAlignHorizontally?: boolean;
        pageAlignVertically?: boolean;
        isGamePortrait?: boolean;
        isGameLandscape?: boolean;
        boot(): void;
        parseConfig(config: IGameConfig): void;
        setupScale?(width: number, height: number): void;
        getParentBounds?(target?: IRectangle, parent?: HTMLElement): IRectangle;
        setGameSize?(width: number, height: number): void;
        setUserScale?(hScale: number, vScale: number, hTrim?: number, vTrim?: number, queueUpdate?: boolean, force?: boolean): void;
        setResizeCallback?(callback: Function, context: IObject): void;
        setMinMax?(minWidth: number, minHeight: number, maxWidth?: number, maxHeight?: number): void;
        preUpdate?(): void;
        forceOrientation?(forceLandscape: boolean, forcePortrait?: boolean): void;
        refresh?(): void;
        createFullScreenTarget?(): HTMLDivElement;
        startFullScreen?(antialias?: boolean, allowTrampoline?: boolean): boolean;
        stopFullScreen?(): boolean;
        scaleSprite(sprite: ISprite | IImage | any, width?: number, height?: number, letterBox?: boolean): ISprite | IImage | any;
        destroy?(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IScaleModes {
    }
}
declare namespace ingenuity.bridge {
    interface ISignal {
        memorize: boolean;
        active: boolean;
        boundDispatch: boolean | Function;
        validateListener(listener: Function, fnName: string): void;
        has(listener: Function, context?: any): boolean;
        add(listener: Function, listenerContext?: any, priority?: number, ...args: any[]): ISignalBinding;
        addOnce(listener: Function, listenerContext?: any, priority?: number, ...args: any[]): ISignalBinding;
        remove(listener: Function, context?: any): Function;
        removeAll(context?: any): void;
        getNumListeners(): number;
        halt(): void;
        dispatch(...params: any[]): void;
        forget(): void;
        dispose(): void;
        toString(): string;
    }
}
declare namespace ingenuity.bridge {
    interface ISignalBinding {
        context: any;
        callCount: number;
        active: boolean;
        params: any;
        listener: Function;
        execute(paramsArr?: any[]): void;
        detach(): Function;
        isBound(): boolean;
        isOnce(): boolean;
        getListener(): Function;
        getSignal(): ISignal;
        toString(): string;
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    interface ISound {
        onMarkerComplete: ISignal;
        onLoop: ISignal;
        key?: string;
        volume: number;
        muted?: boolean;
        mute: boolean;
        soundPlaying: boolean;
        loop: boolean;
        play(loop?: boolean): ISound;
        pause(): ISound;
        stop(): ISound;
        fade(toVolume: number, duration?: number, tocallback?: Function): ISound;
    }
}
declare namespace ingenuity.bridge {
    interface ISoundGroup {
        add(sound: ISound): ISoundGroup;
        muteGroup(): ISoundGroup;
        unmuteGroup(): ISoundGroup;
        stopGroup(): ISoundGroup;
    }
}
declare namespace ingenuity.bridge {
    interface ISoundManager {
        noAudio: boolean;
        touchLocked: boolean;
        context?: AudioContext;
        usingWebAudio?: boolean;
        usingAudioTag?: boolean;
        channels?: number;
        masterGain?: GainNode;
        onLoadComplete: ISignal;
        game: IGame;
        allowMultiple?: boolean;
        enabled: boolean;
        muted: boolean;
        volume: number;
        add(sound: string | Array<any> | IObject, key: string): ISoundManager;
        play(soundId: string, volume?: number, loop?: boolean, key?: string): ISound;
        pause(soundId: string, key: string): void;
        resume(soundId: string, key: string): void;
        isSoundPlaying(soundId: string, key: string): boolean;
        stop(soundId: string, key: string): void;
        muteSound(value: boolean, soundId: string, key: string): void;
        unmuteSound(soundId: string, key: string): void;
        isSoundMuted(soundId: string, key: string): boolean;
        addSprite(sound?: string): ISoundManager;
        getSoundByKey(soundId: string, key: string): ISound | undefined;
        addGroup(groupId: string): ISoundGroup;
        getGroup(groupId: string): ISoundGroup | undefined;
        pauseAllSounds(): void;
        resumeAllSounds(): void;
        stopAllSounds(): void;
        setMasterVolume(volume: number): ISoundManager;
        getMasterVolume(): number;
        destroy?(key: string): void;
        boot(): void;
        setTouchLock(): void;
        unlock(): boolean;
        setTouchUnlock(): void;
        resumeWebAudio(): Promise<void>;
    }
}
declare namespace ingenuity.bridge {
    interface ISpine {
        game: IGame;
        anchor: IPoint;
        onEvent: ISignal;
        onComplete: ISignal;
        onEnd: ISignal;
        onInterrupt: ISignal;
        onStart: ISignal;
        onDispose: ISignal;
        events: IEvents;
        input: IInputHandler;
        onInputOver: ISignal;
        onInputOut: ISignal;
        onInputDown: ISignal;
        onInputUp: ISignal;
        angle: number;
        inputEnabled: boolean;
        setToSetupPose(): void;
    }
}
declare namespace ingenuity.bridge {
    interface ISprite {
        anchor: PIXI.ObservablePoint;
        blendMode: any;
        exists: boolean;
        shader: PIXI.Filter | PIXI.Shader;
        texture: any;
        tint: number;
        alive: boolean;
        angle: number;
        animations: any;
        autoCull: boolean;
        bottom: number;
        centerX: number;
        centerY: number;
        checkWorldBounds: boolean;
        components: any;
        cropRect: IRectangle;
        customRender: boolean;
        data: any;
        frame?: string | number;
        frameName?: string;
        fresh: boolean;
        inputEnabled: boolean;
        inWorld: boolean;
        key: string | IRenderTexture | IVideo | ITexture;
        left: number;
        lifespan: number;
        maxHealth: number;
        name: string;
        offsetX: number;
        offsetY: number;
        previousPosition: IPoint;
        previousRotation: number;
        position: IPoint;
        right: number;
        scale: IPoint;
        scaleMin: IPoint;
        scaleMax: IPoint;
        smoothed: boolean;
        top: number;
        tintedTexture: HTMLCanvasElement;
        transformCallback: Function;
        transformCallbackContext: any;
        world: IPoint;
        x: number;
        y: number;
        z: number;
        setTexture?(texture: PIXI.Texture | ITexture, destroyBase?: boolean): void;
        alignIn?(container: IRectangle | ISprite | IImage | IText | IBitmapText | IButton | IGraphics, position?: number, offsetX?: number, offsetY?: number): any;
        alignTo?(container: IRectangle | ISprite | IImage | IText | IBitmapText | IButton | IGraphics, position?: number, offsetX?: number, offsetY?: number): any;
        bringToTop?(): ISprite;
        crop?(rect: IRectangle, copy: boolean): void;
        checkTransform?(wt: IMatrix): void;
        destroy(options?: Object | boolean | {
            children?: boolean;
            texture?: boolean;
            baseTexture?: boolean;
        }): void;
        drawPolygon?(): void;
        loadTexture?(key: string | IRenderTexture | IVideo | ITexture, frame?: string | number, stopAnimation?: boolean): void;
        moveUp?(): ISprite;
        moveDown?(): ISprite;
        overlap?(displayObject: ISprite | IImage | IButton | IDisplayObject): boolean;
        postUpdate?(): void;
        preUpdate?(): void;
        reset?(x: number, y: number, health?: number): ISprite;
        resetFrame?(): void;
        resizeFrame?(parent: any, width: number, height: number): void;
        sendToBack?(): ISprite;
        setFrame(frame: IFrame): void;
        setScaleMinMax?(minX?: number, minY?: number, maxX?: number, maxY?: number): void;
        updateCrop?(): void;
    }
    interface IPixiShader {
        fragmentSrc: string[];
        gl: WebGLRenderingContext;
        program: WebGLProgram;
        vertexSrc: string[];
        destroy(): void;
        init(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IStage {
        exists: boolean;
        currentRenderOrderID: number;
        smoothed: boolean;
        children: any[];
        height: number;
        width: number;
        ignoreChildInput: boolean;
        disableVisibilityChange: boolean;
        boot?(): void;
        add(): void;
        preUpdate(): void;
        update(): void;
        render(): void;
        postUpdate(): void;
        updateTransform(): void;
        checkVisibility(): void;
        destroy(): void;
        visibilityChange(event: Event): void;
    }
}
declare namespace ingenuity.bridge {
    /**
     * This is a base State class which can be extended if you are creating your own game.
     * It provides quick access to common functions such as the camera, cache, input, match, sound and more.
     *
     * #### Callbacks
     *
     * | start | preload     | loaded     | paused       | stop     |
     * |-------|-------------|------------|--------------|----------|
     * | init  |             |            |              |          |
     * |       | preload     | create     | paused       |          |
     * |       | loadUpdate* | update*    | pauseUpdate* |          |
     * |       |             | postUpdate*|              |          |
     * |       |             | preRender* |              |          |
     * |       | loadRender* | render*    | render*      |          |
     * |       |             |            | resumed      |          |
     * |       |             |            |              | shutdown |
     *
     * Update and render calls (*) are repeated.
     *
     * If your State has a constructor, it will be invoked exactly once, during bridge.StateManager#add()
     */
    interface IState {
        game: IGame;
        key: string;
        add: IObjectFactory;
        camera: ICamera;
        cache: ICache;
        input: IInput;
        load: ILoader;
        math?: any;
        sound?: ISoundManager;
        scale?: IScaleManager;
        stage: IStage;
        state: IStateManager;
        time: ITime;
        tweens?: ITween;
        particles?: any;
        enabled?: boolean;
        created?: boolean;
        create(game?: IGame): void;
        init(...args: any[]): void;
        loadRender(game?: IGame): void;
        loadUpdate(game?: IGame): void;
        paused(game?: IGame): void;
        pauseUpdate(game?: IGame): void;
        preload(game?: IGame): void;
        preRender(game?: IGame, elapsedTime?: number): void;
        render(game?: IGame): void;
        resize(width?: number, height?: number): void;
        resumed(game?: IGame): void;
        shutdown(game?: IGame): void;
        update(game?: IGame): void;
    }
}
declare namespace ingenuity.bridge {
    interface IStateManager {
        current: string;
        states: IObject;
        onInitCallback: Function;
        onPreloadCallback: Function;
        onCreateCallback: Function;
        onUpdateCallback: Function;
        onRenderCallback: Function;
        onResizeCallback: Function;
        onPreRenderCallback: Function;
        onLoadUpdateCallback: Function;
        onLoadRenderCallback: Function;
        onPausedCallback: Function;
        onResumedCallback: Function;
        onPauseUpdateCallback: Function;
        onShutDownCallback: Function;
        link(key: string): void;
        unlink(key: string): void;
        getCurrentState(): IState | any;
        setCurrentState(key: string): void;
        boot?(): void;
        add(key: string, state: IState | any, autoStart?: boolean): IState | any;
        checkState(key: string): boolean;
        clearCurrentState(): void;
        destroy(): void;
        loadComplete(): void;
        preRender(elapsedTime: number): void;
        preUpdate(): void;
        render(): void;
        remove(key: string): void;
        resume(): void;
        restart(clearWorld?: boolean, clearCache?: boolean, ...args: any[]): void;
        resize(width: number, height: number): void;
        start(key: string, clearWorld?: boolean, clearCache?: boolean, ...args: any[]): void;
        update(): void;
        dummy(): void;
        loadUpdate(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IText {
        game?: IGame;
        boundsAlignH: string;
        boundsAlignV: string;
        lineSpacing: number;
        fontSize: number | string;
        setShadow(x?: number, y?: number, color?: string, blur?: number, shadowStroke?: boolean, shadowFill?: boolean): IText;
        setText(text: string, immediate?: boolean): IText;
        setTextBounds(x?: number, y?: number, width?: number, height?: number): IText;
        updateTexture(): void;
        setStyle(style?: ITextStyleBridge, update?: boolean): IText;
    }
}
declare namespace ingenuity.bridge {
    interface ITextStyleBridge {
        font?: string;
        fontStyle?: string;
        fontVariant?: string;
        fontWeight?: string;
        fontSize?: string | number;
        backgroundColor?: string;
        fill?: string;
        align?: string;
        valign?: string;
        boundsAlignH?: string;
        boundsAlignV?: string;
        stroke?: string | number;
        lineSpacing?: number;
        strokeThickness?: number;
        wordWrap?: boolean;
        wordWrapWidth?: number;
        maxLines?: number;
        tabs?: number;
        /**
         * The lineJoin property sets the type of corner created, it can resolve spiked text issues. Default is 'miter' (creates a sharp corner).
         */
        lineJoin?: string;
    }
    /**
     * It stores the textStyle options as needed by PIXI.
     */
    interface ITextStylePIXI extends PIXI.TextStyle {
        boundsAlignH?: string;
        boundsAlignV?: string;
    }
}
declare namespace ingenuity.bridge {
    interface ITexture {
        frame: IRectangle;
        crop: IRectangle;
        noFrame: boolean;
        baseTexture: IBaseTexture;
        trim: IRectangle;
        valid: boolean;
        isTiling: boolean;
        requiresUpdate: boolean;
        requiresReTint: boolean;
        scope: any;
        rotated: boolean;
        height: number;
        width: number;
        onBaseTextureLoaded(): void;
        destroy(destroyBase: boolean): void;
        setFrame(frame: IRectangle): void;
    }
    interface IBaseTexture extends PIXI.BaseTexture {
    }
}
declare namespace ingenuity.bridge {
    interface ITime {
        advancedTiming: boolean;
        desiredFpsMult: number;
        elapsed: number;
        events: ITimer;
        elapsedMS: number;
        fps: number;
        fpsMax: number;
        fpsMin: number;
        frames: number;
        game: IGame;
        lastTime: number;
        msMax: number;
        msMin: number;
        now: number;
        pausedTime: number;
        pauseDuration: number;
        physicsElapsed: number;
        physicsElapsedMS: number;
        prevTime: number;
        renders: number;
        rps: number;
        slowMotion: number;
        suggestedFps: number;
        time: number;
        timeExpected: number;
        timeToCall: number;
        updates: number;
        ups: number;
        desiredFps: number;
        boot(): void;
        add(timer: ITimer): ITimer;
        create(autoDestroy?: boolean): ITimer;
        removeAll(): void;
        refresh(): void;
        update(time: number): void;
        updateTimers(): void;
        updateAdvancedTiming(): void;
        countUpdate(): void;
        countRender(): void;
        gamePaused(): void;
        gameResumed(): void;
        totalElapsedSeconds(): number;
        elapsedSince(since: number): number;
        elapsedSecondsSince(since: number): number;
        reset(): void;
    }
    interface ITimerEvent {
        args: any[];
        callback: Function;
        callbackContext: any;
        delay: number;
        loop: boolean;
        pendingDelete: boolean;
        repeatCount: number;
        tick: number;
        timer: ITimer;
    }
    interface ITimer {
        autoDestroy: boolean;
        events: ITimerEvent[];
        expired: boolean;
        game: IGame;
        nextTick: number;
        onComplete: ISignal;
        running: boolean;
        paused: boolean;
        next: number;
        duration: number;
        length: number;
        ms: number;
        seconds: number;
        create(delay: number, loop: boolean, repeatCount: number, callback: Function, callbackContext: any, args: any): ITimerEvent;
        add(delay: number, callback: (...args: any[]) => void, callbackContext?: any, ...args: any[]): ITimerEvent;
        repeat(delay: number, repeatCount: number, callback: (...args: any[]) => void, callbackContext?: any, ...args: any[]): ITimerEvent;
        loop(delay: number, callback: (...args: any[]) => void, callbackContext?: any, ...args: any[]): ITimerEvent;
        start(startDelay?: number): void;
        stop(clearEvents?: boolean): void;
        remove(event: ITimerEvent): boolean;
        order(): void;
        sortHandler(a: any, b: any): number;
        clearPendingEvents(): void;
        update(time: number): boolean;
        pause(): void;
        adjustEvents(baseTime: number): void;
        resume(): void;
        removeAll(): void;
        destroy(): void;
    }
}
declare namespace ingenuity.bridge {
    interface ITween {
        chainedTween?: ITween;
        current: number;
        frameBased?: boolean;
        isRunning: boolean;
        isPaused: boolean;
        manager?: ITweenManager;
        onChildComplete: ISignal;
        onComplete: ISignal;
        onLoop: ISignal;
        onRepeat: ISignal;
        onStart: ISignal;
        pendingDelete?: boolean;
        properties?: IObject;
        repeatCounter: number;
        reverse: boolean;
        target: any;
        timeline: Array<ITweenData>;
        timeScale: number;
        game: IGame;
        totalDuration: number;
        to(properties: IObject, duration?: number, ease?: string | Function, autoStart?: boolean, delay?: number, repeat?: number, yoyo?: boolean): ITween;
        from(properties: IObject, duration?: number, ease?: string | Function, autoStart?: boolean, delay?: number, repeat?: number, yoyo?: boolean): ITween;
        start(index?: number): ITween;
        stop(complete?: boolean): ITween;
        updateTweenData(property: string, value: number | Function | any, index?: number): ITween;
        delay(duration: number, index?: number): ITween;
        repeat(total: number, repeatDelay?: number, index?: number): ITween;
        repeatDelay(duration: number, index?: number): ITween;
        yoyo?(enable: boolean, yoyoDelay?: number, index?: number): ITween;
        yoyoDelay?(duration: number, index?: number): ITween;
        easing(ease: string | Function, index?: number): ITween;
        interpolation?(interpolation: Function, context?: any, index?: number): ITween;
        repeatAll?(total?: number): ITween;
        chain(...args: any[]): ITween;
        loop(value?: boolean): ITween;
        onUpdateCallback?(callback: Function, callbackContext?: any): ITween;
        pause(): void;
        resume(): void;
        update(time: number): boolean;
        generateData?(frameRate?: number, data?: any): any[];
    }
}
declare namespace ingenuity.bridge {
    interface ITweenData {
        parent: ITween;
        game: IGame;
        repeatTotal: number;
        vEnd: IObject;
        duration: number;
        percent: number;
        value: number;
        repeatCounter: number;
        repeatDelay: number;
        interpolate: boolean;
        yoyo: boolean;
        inReverse: boolean;
        delay: number;
        dt: number;
        startTime: number;
        easingFunction: Function;
        interpolationFunction: Function;
        interpolationContext: Object;
        isRunning: boolean;
        isFrom: boolean;
        yoyoDelay: number;
        [key: string]: number | string | boolean | any;
        [key: number]: number | string | boolean | any;
        to(properties: IObject, duration?: number, ease?: string | Function, delay?: number, repeat?: number, yoyo?: boolean): ITweenData;
        from(properties: IObject, duration?: number, ease?: string | Function, delay?: number, repeat?: number, yoyo?: boolean): ITweenData;
        start(): ITweenData;
        loadValues(): ITweenData;
        update(time: number): number;
        generateData(frameRate?: number): Array<any>;
    }
}
declare namespace ingenuity.bridge {
    interface ITweenManager {
        frameBase: boolean;
        game: IGame;
        easeMap?: IObject;
        getAll(): ITween[];
        removeAll(): void;
        removeFrom(obj: any, children?: boolean): void;
        add(tween: ITween): ITween;
        create(obj: any): ITween;
        remove(tween: ITween): ITween;
        update(): boolean;
        isTweening(obj: any, checkIsRunning?: boolean): boolean;
        pauseAll(): void;
        resumeAll(): void;
    }
}
declare namespace ingenuity.bridge {
    interface IVideo {
        game: IGame;
        video: HTMLVideoElement;
        key?: string;
        url: string;
        baseTexture: IBaseTexture;
        type: number;
        disableTextureUpload: boolean;
        touchLocked: boolean;
        onPlay: ISignal;
        onChangeSource?: ISignal;
        onComplete?: ISignal;
        onAccess?: ISignal;
        onError?: ISignal;
        onTimeout?: ISignal;
        timeout?: number;
        videoStream: MediaStream;
        isStreaming: boolean;
        retryLimit: number;
        retry: number;
        retryInterval: number;
        textureFrame: PIXI.Rectangle | IRectangle;
        playbackRate: number;
        loop: boolean;
        playing: boolean;
        paused: boolean;
        currentTime: number;
        duration: number;
        progress: number;
        mute: boolean;
        volume: number;
        connectToMediaStream(video: HTMLVideoElement, stream: MediaStream): IVideo;
        startMediaStream(captureAudio?: boolean, width?: number, height?: number): IVideo | boolean;
        createVideoTexture(key: string, url?: string): void;
        forceLoaded(width: number, height: number): void;
        unlock(): boolean;
        createVideoFromURL(url: string, autoplay?: boolean): IVideo;
        createVideoFromBlob(blob: Blob): IVideo;
        setTouchLock(): void;
        updateTexture(event?: any, width?: number, height?: number): void;
        changeSource(src: string, autoplay?: boolean): this;
        complete(): void;
        play(loop?: boolean, playbackRate?: number): this;
        destroy(): void;
        removeVideoElement(): void;
        stop(): this;
    }
}
declare namespace ingenuity.bridge {
    /**
     * The Emitter class interface.
     */
    interface IEmitter {
        name: string;
        game: IGame;
        focusPause(): IEmitter;
        focusResume(): IEmitter;
        getId(): string;
    }
}
declare namespace ingenuity.bridge {
    /**
     * Bridge supports three types of Emitters as described in the enum - IEmitterType.
     */
    enum IEmitterType {
        NORMAL = 0,
        ANIM = 1,
        PATH = 2,
    }
    /**
     * Emitter Data for normal Emitter.
     * @param image name of image/spritesheet, or an array of spritesheets.
     * @param frames {optional} frames from spritesheet(s).
     * @param {IEmitterType} [emitterType = IEmitterType.NORMAL]
     * @param {boolean} [generateFrames = false] whether to generate frames. Useful when you want a sequence of frames.
     * @param {boolean} [useParticleContainer = false] whether to use particleContainer, or just a normal bridge.Container
     * @param {number} [stepColors = 0] Number of steps, if the color settings should be manually stepped.
     * @param {boolean} [autoStart = true] Whether to create emitter started.
     *
     * @example IEmitterData - {image: "red_block"} - for an image called "red_block.png"
     * @example IEmitterData - {image: ["red_block", - "green_block"]} for images named as such.
     * @example IEmitterData - {image: "blocks", frames: ["red_block.png", "green_block.png"] } - for images from spritesheet.
     * @example IEmitterData - {image: "blocks", frames: [2,3,4,8]} - for indexed frames from spritesheet.
     * @example IEmitterData - {image: "blocks", generateFrames: true} - for all the frames from spritesheet.
     * @example IEmitterData - {image: "blocks", generateFrames: true, frames:[4,10]} for frames [4...to...10] - from the spritesheet. @ref bridge.Maths#getRange method.
     */
    interface IEmitterData {
        image?: string | Array<string>;
        frames?: string | number | Array<string | number>;
        emitterType?: IEmitterType;
        generateFrames?: boolean;
        useParticleContainer?: boolean;
        stepColors?: number;
        autoStart?: boolean;
        id?: string;
    }
    /**
     * Emitter Data for individial animations for anim emitters.
     * @param image
     * @param framerate - Animation speed as number of frames per second.
     * A value of "matchLife" causes the animation to match the lifetime of an individual particle,
     * instead of at a constant framerate. This causes the animation to play through one time, completing when the particle expires.
     * @param {boolean} [loop=true]
     * @param {boolean} [generateFrames=false]
     * @param frames
     */
    interface ISingleAnimEmitterData {
        image: string | Array<string>;
        framerate?: number | string;
        loop?: boolean;
        generateFrames?: boolean;
        frames?: string | number | Array<string | number>;
    }
    /**
     * Emitter Data for Anim Emitter.
     * @param {IEmitterType} - specify as emitterType = IEmitterType.ANIM or emitterType = 1.
     * @param {boolean} [useParticleContainer = false] whether to use particleContainer, or just a normal bridge.Container
     * @param {number} [stepColors = 0] Number of steps, if the color settings should be manually stepped.
     * @param {boolean} [autoStart = true] Whether to create emitter started.
     * @param animConfig - An array of individual animation config.
     */
    interface IAnimEmitterData {
        emitterType: IEmitterType;
        useParticleContainer?: boolean;
        stepColors?: number;
        autoStart?: boolean;
        animConfig: Array<ISingleAnimEmitterData>;
        id?: string;
    }
}
declare namespace ingenuity.bridge {
    interface IDOM {
    }
}
/**
 * Defines the namespace
 */
declare namespace ingenuity {
    let baseURL: string;
}
declare namespace ingenuity.bridge {
}
