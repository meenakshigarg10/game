// BaseCore
///<reference path="Game/BaseCore/BaseView.ts"/>
///<reference path="Game/BaseCore/Bitmap.ts"/>


// Base Game
///<reference path="Game/Base/Controller/BaseController.ts"/>
///<reference path="Game/Base/Controller/ButtonController.ts"/>
///<reference path="Game/Base/Controller/MetersController.ts"/>
///<reference path="Game/Base/Controller/ReelPanelController.ts"/>
///<reference path="Game/Base/Model/Model.ts"/>
///<reference path="Game/Base/Controller/WinPresentationController.ts"/>
///<reference path="Game/Base/View/View.ts"/>
///<reference path="Game/Base/View/AdvancedButton.ts"/>

// Constants
///<reference path="Game/BehaviorConstants/SlotEventDispatchers.ts"/>
///<reference path="Game/BehaviorConstants/SlotConstants.ts"/>
///<reference path="Game/BehaviorConstants/SoundConstants.ts"/>

// Big Win
///<reference path="Game/BigWin/BigWinController.ts"/>
///<reference path="Game/BigWin/BigWinView.ts"/>

// Free Game
///<reference path="Game/Free/Controller/ButtonController.ts"/>
///<reference path="Game/Free/Controller/FreeGameController.ts"/>
///<reference path="Game/Free/Controller/MetersController.ts"/>
///<reference path="Game/Free/Controller/ReelPanelController.ts"/>
///<reference path="Game/Free/Controller/WinPresentationController.ts"/>
///<reference path="Game/Free/Model/Model.ts"/>
///<reference path="Game/Free/View/View.ts"/>

// Logic
///<reference path="Game/Logic/SlotGameLogic.ts"/>

// Player Messages
///<reference path="Game/PlayerMessage/PlayerMsgController.ts"/>
///<reference path="Game/PlayerMessage/PlayerMsgView.ts"/>

// Reel Panel
///<reference path="ReelPanel/CoreModuleList.ts"/>

// Intro Outro
///<reference path="Game/IntroOutro/IntroOutroController.ts"/>
///<reference path="Game/IntroOutro/IntroOutroView.ts"/>

// States
///<reference path="Game/State/BaseGameState.ts"/>
///<reference path="Game/State/FreeGameStates.ts"/>

// Post Loading
///<reference path="Game/PostLoading/PostLoadingView.ts"/>
///<reference path="Game/PostLoading/PostLoadingController.ts"/>

// Background
///<reference path="Game/Background/BackgroundView.ts"/>
///<reference path="Game/Background/BackgroundController.ts"/>

// UI
///<reference path="Game/ui/BigWinMeterBitmap.ts"/>
///<reference path="Game/ui/MeterBitmap.ts"/>
///<reference path="Game/ui/WinTickupMeterBitmap.ts"/>
///<reference path="Game/BaseCore/BSButtonBase.ts"/>
///<reference path="Game/ui/AnimationBase.ts"/>

// sound popup
///<reference path="Game/SoundPopup/SoundPopupView.ts"/>
///<reference path="Game/SoundPopup/SoundPopupController.ts"/>

// reel panal
///<reference path ="ReelPanel/ReelPanel.ts" />

///<reference path="Game/GameIntro/Controller.ts"/>
///<reference path="Game/GameIntro/GameIntroView.ts"/>

///<reference path ="Game/BigSymbol/BigSymbolView.ts" />
///<reference path ="Game/BigSymbol/BigSymbolController.ts" />

// Gamble
///<reference path ="Game/Gamble/View.ts" />
///<reference path ="Game/Gamble/Controller.ts" />

// SettingPannel
///<reference path ="Game/SettingPannel/SettingPannelController.ts" />
///<reference path ="Game/SettingPannel/SettingPannelView.ts" />
///<reference path ="Game/PixiBridge/SoundManager.ts" />

namespace ingenuity.core.constructors {
    export let bsBehavior = {
        BaseController: BehaviorCore.BaseGame.BaseController,
        ButtonController: BehaviorCore.BaseGame.ButtonController,
        MetersController: BehaviorCore.BaseGame.MetersController,
        ReelPanelController: BehaviorCore.BaseGame.ReelPanelController,
        WinPresentationController: BehaviorCore.BaseGame.WinPresentationController,
        BaseModel: BehaviorCore.BaseGame.Model,
        BaseView: ingenuity.BehaviorCore.BaseGame.View,

        SlotConstants: BehaviorCore.slotConstants.SlotConstants,
        SlotEventConstants: BehaviorCore.slotConstants.SlotEventConstants,
        SoundConstants: BehaviorCore.slotConstants.SoundConstant,

        BigWinController: BehaviorCore.BigWin.BigWinController,
        BigWinView: BehaviorCore.BigWin.BigWinView,

        FreeGameButtonController: BehaviorCore.FreeGame.ButtonController,
        FreeGameController: BehaviorCore.FreeGame.FreeGameController,
        FreeGameMetersController: BehaviorCore.FreeGame.MetersController,
        FreeGameReelPanelController: BehaviorCore.FreeGame.ReelPanelController,
        FreeGameWinPresentationController: BehaviorCore.FreeGame.WinPresentationController,
        FreeGameModel: BehaviorCore.FreeGame.Model,
        FreeGameView: BehaviorCore.FreeGame.View,

        Logic: BehaviorCore.Logic.SlotGameLogic,

        PlayerMsgController: BehaviorCore.PlayerMsg.PlayerMsgController,
        PlayerMsgView: BehaviorCore.PlayerMsg.PlayerMsgView,

        IntroOutroController: BehaviorCore.IntroOutro.Controller,
        IntroOutroView: BehaviorCore.IntroOutro.IntroOutroView,

        BaseGameState: BehaviorCore.BaseGameState,
        FreeGameState: BehaviorCore.FreeGameState,

        BigWinMeterBitmap: BehaviorCore.behaviourUI.BigWinMeterBitmap,

        PostLoadingController: BehaviorCore.PostLoadingController,
        PostLoadingView: BehaviorCore.PostLoadingView,
        SoundPopupController: ingenuity.BehaviorCore.SoundPopup.SoundPopupController,
        SoundPopupView: ingenuity.BehaviorCore.SoundPopup.SoundPopupView,
        GameIntroController: ingenuity.BehaviorCore.GameIntro.Controller,
        GameIntroView: ingenuity.BehaviorCore.GameIntro.GameIntroView,
        BackGroundView: BehaviorCore.BackgroundView,
        BackgroundController: BehaviorCore.BackgroundController,
        BigSymbolView: BehaviorCore.bigSymbol.BigSymbolView,
        BigSymbolController: BehaviorCore.bigSymbol.BigSymbolController,

        GambleView: ingenuity.BehaviorCore.Gamble.View,
        GambleController: ingenuity.BehaviorCore.Gamble.Controller,

        SettingPannelController: BehaviorCore.BaseGame.SettingPannelController,
        SettingPannelView: BehaviorCore.BaseGame.SettingPannelView
    };
    base.AdvancedButton = BehaviorCore.BaseGame.AdvancedButton;
    base.AnimationBase = BehaviorCore.behaviourUI.BsAnimationBase;
    base.AudioController = BehaviorCore.AudioController;
    base.MeterBitmap = BehaviorCore.behaviourUI.WinTickupMeterBitmap;
    base.ButtonBase = BehaviorCore.BSButtonBase;
    reelPanel.ReelPanel = BehaviorCore.reelPanel.ReelPanel;
    ui.Bitmap = BehaviorCore.Bitmap;
    bridge.SoundManager = BehaviorCore.SoundManager;
}

