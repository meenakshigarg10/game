/**
 * Background controller for Game
 */

/// <reference path ="../../Interfaces.ts"/>
namespace ingenuity.BehaviorCore {
    export class BackgroundController {
        protected view: BackgroundView;
        protected basegameBgContainer: ui.Container;
        protected freegameBgContainer: ui.Container;
        protected gameIntroBgContainer: ui.Container;
        protected selectionScreenBGContainer: ui.Container;

        constructor(view: BackgroundView) {
            this.view = view;
            this.initializeElements();
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.CHANGE_BACKGROUND, this.changeBackground, this);
        }

        protected initializeElements(): void {
            this.basegameBgContainer = this.view.getContainerByID("basegameBgContainer");
            this.freegameBgContainer = this.view.getContainerByID("freegameBgContainer");
            this.gameIntroBgContainer = this.view.getContainerByID("gameIntroBgContainer");
            this.selectionScreenBGContainer = this.view.getContainerByID("SelectionScreenBGContainer");
        }

        protected changeBackground(evt: IEvent): void {
            this.hideAllBg();
            switch (evt.data) {
                case BehaviorCore.slotConstants.SlotConstants.GAME_INTRO_BG_SHOW:
                    this.showGameIntroBg();
                    break;
                case BehaviorCore.slotConstants.SlotConstants.BASEGAME_BG_SHOW:
                    this.showBaseGameBg();
                    this.showBaseGameBottomStrip();
                    break;
                case BehaviorCore.slotConstants.SlotConstants.SELECTION_SCREEN_BG_SHOW:
                    this.showSelectionScreenBg();
                    break;
                case BehaviorCore.slotConstants.SlotConstants.FREEGAME_BG_SHOW:
                    this.showFreeGameBg();
                    this.showFreegameBottomStrip();
            }
        }

        /**to showw basegame bg bottom strip */
        protected showBaseGameBottomStrip(): void {
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                (this.view.bgBottomStrip) && (this.view.bgBottomStrip.parent.addChild(this.view.bgBottomStrip));
                (this.view.bgBottomStrip) && (this.view.bgBottomStrip.visible = true);
            }
        }

        /**to show freegame bg bottom strip */
        protected showFreegameBottomStrip(): void {
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                (this.view.fgBottomStrip) && (this.view.fgBottomStrip.parent.addChild(this.view.fgBottomStrip));
                (this.view.fgBottomStrip) && (this.view.fgBottomStrip.visible = true);
            }
        }

        protected hideAllBg(): void {
            this.basegameBgContainer.visible =  false;
            this.freegameBgContainer.visible =  false;
            this.gameIntroBgContainer.visible =  false;
            this.selectionScreenBGContainer.visible = false;

        }

        protected showGameIntroBg(): void {
            this.gameIntroBgContainer.visible = true;
        }

        protected showBaseGameBg(): void {
            this.basegameBgContainer.visible = true;
        }
        protected showSelectionScreenBg(): void {
            this.selectionScreenBGContainer.visible = true;
        }

        protected showFreeGameBg(): void {
            this.freegameBgContainer.visible = true;
        }

    }
}
