/**
 * BackgroundView
 */
/// <reference path ="../../Interfaces.ts"/>

namespace ingenuity.BehaviorCore {
    export class BackgroundView extends BehaviorCore.BaseView {
        public bgBottomStrip: ui.Bitmap;
        public fgBottomStrip: ui.Bitmap;

        constructor(json: {}) {
            super(json);
            this.initElements();
        }

        /**overrided to set pivots of bg and fg background bottom strips pivots.*/
        protected initElements(): void {
            this.bgBottomStrip = this.getImageById("basegameBackground_bottomStrip");
            this.fgBottomStrip = this.getImageById("freegameBackground_bottomStrip");
            (this.bgBottomStrip) && this.bgBottomStrip.pivot.set(configData.width / 2, configData.height / 2);
            (this.fgBottomStrip) && this.fgBottomStrip.pivot.set(configData.width / 2, configData.height / 2);
        }

        protected resize(evt?: IEvent): void {
            super.resize(evt);
            this.x = innerWidth / 2;
            this.y = innerHeight / 2;
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.pivot.set(configData.height / 2, configData.width / 2);
                const scale: number = Math.max((innerHeight / configData.width), (innerWidth / configData.height));
                this.scale.set(scale, scale);
            } else {
                this.pivot.set(configData.width / 2, configData.height / 2);
                const scale: number = Math.min((innerHeight / configData.height), (innerWidth / configData.width));
                this.scale.set(scale, scale);

            }

            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState) {
                    (this.bgBottomStrip) && (this.bgBottomStrip.parent.addChild(this.bgBottomStrip));
                }
                if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                    (this.fgBottomStrip) && (this.fgBottomStrip.parent.addChild(this.fgBottomStrip));
                }
            }
        }

    }
}
