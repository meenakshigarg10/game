/*
* We have overrided this class directly for Pixi-bridge.
* version of Pixi-bridge used in the game uses an instance of `SoundManager` to load sound file and we have
* another instance of subclass `AudioController` which is initialized at bheaviour level to play
* and pause the sound. Hence to load the sound from CDN we have to change the request path for which we
* are overriding the SoundManager class.
*
*/



namespace ingenuity.BehaviorCore {
    export class SoundManager extends bridge.SoundManager {
        public add(sound: string | Array<any> | IObject, key: string): ingenuity.bridge.SoundManager {
            const urlKey: any = "urls";
            let urls: Array<any> = sound[urlKey];
            for (let i: number = 0; i < urls.length; i++) {
                let url: string = urls[i];
                urls[i] = ingenuity.baseURL + url;
            }
            return super.add(sound, key);
        }

    }
}

