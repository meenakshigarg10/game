///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.Platform {
    export class Parser extends platform.aruze.Parser {
        protected model: BehaviorCore.Platform.ParserModel;

        /**to handle total bet in ways game using bet multiplier */
        protected processConfig(data: any): void {
            data.betMultiplier && this.model.setBetMultiplier(data.betMultiplier);
            super.processConfig(data);
        }

       protected updateBalance(evt: any): void {
            this.model.setBalance(evt.data.balance);
            this.model.setUserBalance(evt.data.balance);
            ingenuity.dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.UPDATE_CREDIT_VALUE, { value: this.model.getBalance() });
       }
    }
}