///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.Platform {
    export class ParserModel extends platform.aruze.Model {

        protected betMultiplier: number;
        // landingSounds
        protected setLandingObj: IObject[][];

        /**to set and get betMultiplier for Ways game */
        public setBetMultiplier(value: number): void {
            this.betMultiplier = value;
        }

        public getBetMultiplier(): number {
            return this.betMultiplier;
        }

        /**overrided to update total bet if game is ways */
        public setCurrentTotalBet(value: number): void {
            let waysTotalBet: number = value;
            if (configData.waysBetMultiplier && this.getBetMultiplier()) {
                waysTotalBet = this.updateCurrentTotalBet(value);
            }
            super.setCurrentTotalBet(waysTotalBet);
        }

        /**to update game total bet */
        public updateCurrentTotalBet(value: number): number {
            return Number(((value * this.getBetMultiplier()) / this.getCurrentNumPaylines()).toFixed(1));
        }

        /**to set and get landing symbol objects along with some data */
        public setLandingSoundOnReel(value: IObject[][]): void {
            this.setLandingObj = value;
        }

        public getLandingSoundOnReel(): IObject[][] {
            return this.setLandingObj;
        }
    }
}