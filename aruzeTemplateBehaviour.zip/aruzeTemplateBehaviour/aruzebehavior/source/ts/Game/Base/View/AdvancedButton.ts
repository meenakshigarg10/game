///<reference path="../../../Interfaces.ts" />
/**
 * Purpose of this class override to play blink animation.
 *
 */

namespace ingenuity.BehaviorCore.BaseGame {
    export class AdvancedButton extends ui.AdvancedButton {

        /**
         * overrided to display posterframe (hiding in parent class) in case of idle animation of advanced button
         * @param event
         */
        protected onCompleteIdleAnim(event?: IEvent) {
            (this.animations.out) && (this.animations.out.stopAnim());
        }

        /**
         * Overrided to change as per Betsson behavior
         */
        public changeStateFrame(state: string) {
            this.containers.out && (this.containers.out.visible = false);
            this.containers.up && (this.containers.up.visible = false);
            this.containers.down && (this.containers.down.visible = false);
            this.containers.disable && (this.containers.disable.visible = false);
            this.containers.over && (this.containers.over.visible = false);
            if (this.idleTimer > 0) {
                if (state === "disable") {
                    this.containers.disable && (this.containers.disable.visible = true);
                    this.containers.out && (this.containers.out.visible = false);
                    return;
                } else if (state !== "out") {
                    this.containers.out && (this.containers.out.visible = true);
                } else {
                    utils.killDelayedCall("idleInterval");
                    utils.delayedLoopCall("idleInterval", this.idleTimer, () => {
                        (this.animations.out) && (this.animations.out.visible = true);
                        (this.animations.out) && (this.animations.out.playAnim("anim", this.onCompleteIdleAnim, this));
                    });
                }
            }
            this.containers[state] && (this.containers[state].visible = true);
        }
    }
}
