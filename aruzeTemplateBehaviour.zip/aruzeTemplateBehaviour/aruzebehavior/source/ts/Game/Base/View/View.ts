///<reference path="../../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.BaseGame {
    export class View extends slot.BaseGame.View {
        protected freePlayCancelButton: ui.ButtonBase;
        protected maskImageObj: ui.Bitmap;
        protected baseGameAlpha: ui.Container;
        protected fiveOfkindTimer: number;
        protected lblWinValue: BehaviorCore.behaviourUI.MeterBitmap;
        protected anticipation: ui.AnimationBase;
        protected reelPanel: BehaviorCore.reelPanel.ReelPanel;
        protected autoPlayOnPortrait: ui.ButtonBase;
        protected autoPlayOffPortrait: ui.ButtonBase;
        private bigSymbolView: bigSymbol.BigSymbolView;
        protected CurrentOrientation: string = "";
        protected portraitButtonsContainer: ui.Container;
        protected PortraitplayerMsgContainer: ui.Container;
        protected buttonContainer: ui.Container;

        constructor(viewJson: any) {
            super(viewJson);
            this.initializeComponents();
            this.subscribeEvents();
            this.BaseGamePortraitLandscapeViewChange();
            this.resize({ data: deviceEnv.update() });
        }

        protected initializeComponents(): void {
            this.lblWinValue = this.getMeterById(ingenuity.BehaviorCore.slotConstants.SlotConstants.WIN_VALUE) as BehaviorCore.behaviourUI.MeterBitmap;
            if (BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID && BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID.length > 0) {
                this.initializeBigSymbolView();
            }
            this.portraitButtonsContainer = this.getContainerByID("portraitButtonsContainer");
            this.PortraitplayerMsgContainer = this.getContainerByID("PortraitplayerMsgContainer");
            this.buttonContainer = this.getContainerByID("buttonsContainer");
        }

        public setWinReelView(value: slot.reelPanel.WinPresentationPanel, pos?: number, parentId?: string): void {
            super.setWinReelView(value, pos, parentId);
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.winView.x = this.reelView.json.portraitX;
                this.winView.y = this.reelView.json.portraitY;
            } else if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                //
            }
            this.resize(new ingenuity.events.Event(ingenuity.events.EventConstants.RESIZE, ingenuity.deviceEnv.update()));
        }

        public setReelView(reelView: BehaviorCore.reelPanel.ReelPanel, pos?: number, parentId?: string): void {
            this.reelView = reelView;
            this.addChildAt(this.getImageById("reelBG"), 0);
            this.addChildAt(reelView, 1);
            const container: ui.Container = this.getContainerByID("reelsContainer");
            this.addChildAt(container, 2);
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.reelView.x = this.reelView.json.portraitX;
                this.reelView.y = this.reelView.json.portraitY;
            } else if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                //
            }
        }

        protected initializeBigSymbolView(): void {
            this.bigSymbolView = new ingenuity.core.constructors.bsBehavior.BigSymbolView(ingenuity.assetsData.getJSONById("main_data").bigSymbolPresentation);
            this.getContainerByID(ingenuity.BehaviorCore.slotConstants.SlotConstants.reelsContainer).addChildAt(this.bigSymbolView, 0);
        }

        public getBigSymbolView(): bigSymbol.BigSymbolView {
            return this.bigSymbolView;
        }

        /**
         * to put all listeners in one place for this class that can be listened on same time
         */
        protected subscribeEvents(): void {
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_BASEGAME_WIN_ALPHA, this.showAlpha, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA_ON_SYMBOL, this.hideAlphaOnSymbol, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA, this.hideAlpha, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.RESET_BASEGAME_WIN_ALPHA, this.showAlpha, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SUBSCRIBE_BASEVIEW_EVENTS, this.subscribeEvents, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEVIEW_EVENTS, this.unsubscribeEvents, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.PLAY_LANDING_SOUNDS, this.checkAndPlayLandingSounds, this);
        }

        protected unsubscribeEvents(): void {
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_BASEGAME_WIN_ALPHA, this.showAlpha, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA_ON_SYMBOL, this.hideAlphaOnSymbol, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA, this.hideAlpha, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.RESET_BASEGAME_WIN_ALPHA, this.showAlpha, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.PLAY_LANDING_SOUNDS, this.checkAndPlayLandingSounds, this);
        }


        /**
         * to hide all symbols alpha which are present on grid
         */
        protected showAlpha(): void {
            if (this.reelView) {
                for (let reel = 0; reel < 5; reel++) {
                    for (let symbol = 0; symbol < 4; symbol++) {
                        this.reelView.getSymbolByPos(reel, symbol).getStatic().tint = 0x999999;
                        const anim: ui.Sprite = this.reelView.getSymbolByPos(reel, symbol).getAnimation() as ui.Sprite;
                        if (anim.name === "symbol_scatter") {
                            const child: bridge.Sprite = anim.children[0] as bridge.Sprite;
                            if (child !== undefined) {
                                child.tint = 0x999999;
                            }
                        }
                    }
                }
            }
        }

        /**
         * to unhide all symbols alpha which are present on grid
         */
        protected hideAlpha(): void {
            if (this.reelView) {
                for (let reel = 0; reel < 5; reel++) {
                    for (let symbol = 0; symbol < 4; symbol++) {
                        this.reelView.getSymbolByPos(reel, symbol).getStatic().tint = 0xffffff;
                        const anim: ui.Sprite = this.reelView.getSymbolByPos(reel, symbol).getAnimation() as ui.Sprite;
                        if (anim.name === "symbol_scatter") {
                            const child: bridge.Sprite = anim.children[0] as bridge.Sprite;
                            if (child !== undefined) {
                                child.tint = 0xffffff;
                            }
                        }
                    }
                }
            }
        }

        /**
         * to unhide symbols alpha which are part of winning line
         */
        protected hideAlphaOnSymbol(evt: IEvent): void {
            if (this.reelView) {
                this.showAlpha();
                if (evt && evt.data) {
                    for (const winSymData of evt.data) {
                        this.reelView.getSymbolByPos(winSymData[0], winSymData[1]).getStatic().tint = 0xffffff;
                        const anim: ui.Sprite = this.reelView.getSymbolByPos(winSymData[0], winSymData[1]).getAnimation() as ui.Sprite;
                        if (anim.name === "Scatter") {
                            const child: bridge.Sprite = anim.children[0] as bridge.Sprite;
                            if (child !== undefined) {
                                child.tint = 0xffffff;
                            }
                        }
                    }
                }
            }
        }

        /**
         * Overrided to animate Layered symbol
         */
        public landingAnimation(data: any, callback?: () => void, callbackScope?: any): void {
            const reelgrid = data[0];
            const reelview: slot.reelPanel.ReelPanel = data[1];
            const reelId = data[2];
            for (let i = 0; i < reelgrid[reelId].length; i++) {
                if (this.json.reels.symbolData[reelgrid[reelId][i] - 1].hasLanding) {
                    const symbol: slot.symbol.SymbolBase = reelview.getSymbolByPos(reelId, i);
                    const staticSym: slot.symbol.StaticSymbol | slot.symbol.AnimationSymbol = symbol.getStatic();
                    const animSym: slot.symbol.AnimationSymbol | slot.symbol.SpineSymbol | slot.symbol.StaticSymbol | slot.symbol.LayeredAnimationSymbol = symbol.getAnimation();
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.PLAY_LANDING_ANIMATION_SOUND, "scatter_" + reelId);
                    if (animSym instanceof slot.symbol.LayeredAnimationSymbol) {
                        if (staticSym.parent) {
                            staticSym.visible = false;
                            animSym.visible = true;
                            staticSym.parent.addChild(animSym);
                            animSym.playAnim({
                                animName: "landing",
                                stopFrame: (symbol.json.animSym as slot.symbol.IAnimationSymbolData).posterFrame,
                                callback: () => {
                                    staticSym.visible = true;
                                    if (animSym.parent && (staticSym instanceof slot.symbol.StaticSymbol)) {
                                        animSym.parent.addChild(staticSym);
                                        animSym.parent.removeChild(animSym);
                                    }
                                    callback && callbackScope && callback.call(callbackScope);
                                },
                                cbScope: this
                            });
                        }
                    }
                }
            }
        }

        public setView(value: any, pos?: number, parentId?: string): void {
            const container: ui.Container = this.getContainerByID(parentId) || this;
            (pos) ? container.addChildAt(value, pos) : container.addChild(value);
        }

        /**
         * to set winValue in console Winmeter
         */
        public setWinValue(value: string, isValueInCredit: boolean, tickyp?: boolean): void {
            if (isValueInCredit) {
                this.lblWinValue && this.lblWinValue.setCurrencyFormattedValue(value);
            } else {
                const converAmountToCoinFromCurrency: string = Math.round(Number(value) / ingenuity.configData.currentCoinValue).toString();
                this.lblWinValue && this.lblWinValue.setBsCoinFormattedValue(converAmountToCoinFromCurrency, 0);
            }
        }

        public showAnticipation(reel: number, callback?: () => void, callbackScope?: any): void {
            if (typeof this.anticipationContainer === "undefined") {
                this.anticipationContainer = new ui.Container(this.json, this.game);
                this.anticipationContainer.name = slot.slotConstants.SlotConstants.AnticipationConatiner;
                this.addChild(this.anticipationContainer);
            }
            if (this.anticipationContainer.children.length) {
                this.anticipationContainer.removeChildren();
            }
            if (this.json.anticipationAnim) {
                const anticJson: IAnimation = this.json.anticipationAnim;
                anticJson.id = slot.slotConstants.SlotConstants.AnticipationIdPrefix + reel;
                const anticipation: ui.AnimationBase = this.createAnimation(anticJson);
                this.anticipation = anticipation;
                if (anticipation) {
                    anticipation.visible = true;
                    anticipation.x = this.json.reels.reels[reel].x + this.json.reels.x + this.json.anticipationAnim.x;
                    anticipation.y = this.json.reels.reels[reel].y; // + this.json.reels.y + this.json.anticipationAnim.y;
                    this.addChild(this.anticipationContainer);
                    this.anticipationContainer.addChild(anticipation);
                    anticipation.playAnim("", callback);
                }
            }
        }

        /**
         * this function will call everytime when dimension of the game change
         * @param {ingenuity.IEvent} e
         */
        protected resize(e?: IObject): void {
            this.pivot.set(configData.width / 2, configData.height / 2);
            this.x = innerWidth / 2;
            this.y = innerHeight / 2;
            this.BaseGamePortraitLandscapeViewChange();
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.pivot.set(ingenuity.configData.width * slotConstants.SlotConstants.HALF_CONVERTER, 0);
                this.scale.set(e.data.scale);
                this.x = (innerWidth * slotConstants.SlotConstants.HALF_CONVERTER);
                this.y = (innerHeight * ingenuity.core.constructors.bsBehavior.SlotConstants.FIVE_PERCENT) + BehaviorCore.slotConstants.SlotConstants.ADD_IN_Y;

                this.getReelView() && (this.getReelView().x = this.getReelView().json.portraitX);
                this.getReelView() && (this.getReelView().y = this.getReelView().json.portraitY);
                this.getWinReelView() && (this.getWinReelView().x = this.getReelView().json.portraitX);
                this.getWinReelView() && (this.getWinReelView().y = this.getReelView().json.portraitY);
            } else {
                this.pivot.set(ingenuity.configData.width * slotConstants.SlotConstants.HALF_CONVERTER, ingenuity.configData.height * slotConstants.SlotConstants.HALF_CONVERTER);
                this.x = innerWidth * slotConstants.SlotConstants.HALF_CONVERTER;
                this.scale.set(e.data.scale);
                if (deviceEnv.isDesktop) {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_DESKTOP;
                } else {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_MOBILE;
                }
                this.getReelView() && (this.getReelView().x = this.getReelView().json.x);
                this.getReelView() && (this.getReelView().y = this.getReelView().json.y);
                this.getWinReelView() && (this.getWinReelView().x = this.getReelView().json.x);
                this.getWinReelView() && (this.getWinReelView().y = this.getReelView().json.y);
            }

            if (!ingenuity.deviceEnv.isDesktop) {
                if (this.CurrentOrientation !== ingenuity.deviceEnv.getOrientation()) {
                    this.CurrentOrientation = ingenuity.deviceEnv.getOrientation();
                }
            }

            this.addButtonPanelOnTop();
            this.updateOrientation();
            this.portraitHudOnResize();
        }


        /**to handle portrait HUD on resize */
        protected portraitHudOnResize(): void {
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.getImageById("gambleCollectBG").alpha = 0;
                this.onShowPortraitButtonpanel();
            } else {
                this.getImageById("gambleCollectBG").scale.set(1, 1);
                this.getImageById("gambleCollectBG").alpha = 1;
                if (!deviceEnv.isDesktop) {
                    this.onHidePortraitButtonPanel();
                }
            }
        }


        /**to show portrait buttons container
         * points to take care
         * 1. here we are considering reelBG to have no transparent area. reelBG should have no extra canvas area or provide reelbg actual height.
         * 2. Button_Panel_BasePort width should be as that of desktop asset i.e 1280
         * 3. portraitPlayerMsgBgShape is made of static height of spin player mssg. change as in game. Also we have assumed player mssg's
         *    to be contained in height of 40 px. if not so please allign player mssgs in game with in 40 px height.
         * 4. portraitBackgroundShape is a shape of height starting from gamble buttons to spin button bottom.
         */
        public onShowPortraitButtonpanel() {
            if (this.PortraitplayerMsgContainer && this.portraitButtonsContainer) {
                // to add player mssgs in portait below reel bg
                this.PortraitplayerMsgContainer.visible = true;
                this.PortraitplayerMsgContainer.y = this.getImageById("reelBG").y + this.getImageById("reelBG").height;
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ON_CHANGE_PLAYERMSG_PARENT);

                // to find height of portrait bott0m button panel
                const bottomButtonPanelBg: ui.Bitmap = this.getImageById("Button_Panel_BasePort");
                let bottomstripHeight = bottomButtonPanelBg && (bottomButtonPanelBg.height * bottomButtonPanelBg.parent.scale.x);

                // to add console panel buttons in portrait floating buttons container
                this.changeParent(this.portraitButtonsContainer);

                // to find height of player mssgs in portrait
                const playerMssgBg: any = this.getComponentById("portraitPlayerMsgBgShape");
                const portraitPlayerMssgHeight: number = playerMssgBg && playerMssgBg.height;

                // to find height of window till player mssgs bottom
                const viewHeight: number = (this.getImageById("reelBG").y + this.getImageById("reelBG").height + portraitPlayerMssgHeight + BehaviorCore.slotConstants.SlotConstants.PLAYER_MSSG_HEIGHT_SAFEAREA) * this.scale.x + this.y;
                const wrapperBottomBarHeight: number = document.getElementById("gw-bottom-bar") ? document.getElementById("gw-bottom-bar").offsetHeight : 0;

                // to find height avaialable for portait floating button container to be scaled. it is from player mssg bottom to bottom button panel top
                let remainingHeight = window.innerHeight - (viewHeight + wrapperBottomBarHeight + bottomstripHeight);

                const portraitButtonContainerBg: any = this.getComponentById("portraitBackgroundShape");

                // to set scaling of floating button container, not greater than a max limit. Max limit is used for beter UI.
                let availableScaling: number = this.scalingAvailable(remainingHeight, portraitButtonContainerBg);
                if (availableScaling > BehaviorCore.slotConstants.SlotConstants.FLOATING_MAX_SCALE) {
                    availableScaling = BehaviorCore.slotConstants.SlotConstants.FLOATING_MAX_SCALE;
                }
                this.portraitButtonsContainer.scale.set(availableScaling);

                // to find height of game's portrait floating button contianer, which contains final spin, etc buttons
                let portraitButtonContainerBgHeight: number = portraitButtonContainerBg && (portraitButtonContainerBg.height * this.portraitButtonsContainer.scale.x);

                // to find extra space between available space and portait floating button container height.
                remainingHeight = remainingHeight - portraitButtonContainerBgHeight;

                this.portraitButtonsContainer.pivot.set(configData.width / 2, 0);
                this.portraitButtonsContainer.x = window.innerWidth / 2;

                /**
                 * to set portait floating button container y position to - player mssg bottom + half of the extra space available
                 * between portait floating button container height and avaialble height got portait floating button container to be scaled
                 */
                this.portraitButtonsContainer.y = (viewHeight + remainingHeight / 2);

                this.portraitButtonsContainer.alpha = 1;
            }
        }

        /**to find min possible scaling for floating button container */
        protected scalingAvailable(availableHeight: number, buttonContainer: any): number {
            return Math.min(availableHeight / buttonContainer.height, window.innerWidth / buttonContainer.width);
        }

        /**to hide portait button panel */
        protected onHidePortraitButtonPanel() {
            this.portraitButtonsContainer && (this.portraitButtonsContainer.alpha = 0);
            this.changeParent(this.buttonContainer);
            this.PortraitplayerMsgContainer && (this.PortraitplayerMsgContainer.visible = false);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ON_CHANGE_PLAYERMSG_PARENT);
        }

        /**to change console buttons parent in game. diffenrent in portait and landscape  */
        protected changeParent(component: ui.Container): void {
            component && (this.json.newHUDComponents as string[]).forEach((value: string) => {
                component.addChild(this.getComponentById(value));
            }, this);
        }

        // This function is used for bring the Consol Panel on Stage.
        protected addButtonPanelOnTop(): void {
            const buttonsContainer: ui.Container = this.getContainerByID("buttonsContainer");
            ingenuity.currentGame.stage.addChild(buttonsContainer);
            const buttonsContainerWidth: number = buttonsContainer.width;

            const gwBottomBar: HTMLElement = document.getElementById("gw-bottom-bar");
            let gwBottomBarHeight: number = 0;
            gwBottomBar && (gwBottomBarHeight = gwBottomBar.offsetHeight);

            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                buttonsContainer.pivot.set(ingenuity.configData.width / 2, 168);
                buttonsContainer.x = (buttonsContainer.width / 2) + ((window.innerWidth - buttonsContainerWidth) / 2);
                buttonsContainer.y = window.innerHeight - gwBottomBarHeight;
                const scale: number = Math.min((window.innerHeight / ingenuity.configData.height), (window.innerWidth / ingenuity.configData.width));
                buttonsContainer.scale.set(scale, scale);
            } else {
                if (this.CurrentOrientation === "portrait") {
                    const bottomPanelBgPortrait: ui.Bitmap = this.getImageById("Button_Panel_BasePort");
                    bottomPanelBgPortrait && buttonsContainer.pivot.set(bottomPanelBgPortrait.width / 2, bottomPanelBgPortrait.height);
                    buttonsContainer.x = window.innerWidth / 2;
                    buttonsContainer.y = window.innerHeight - gwBottomBarHeight;
                    buttonsContainer.scale.set(deviceEnv.getScale() + deviceEnv.getScale() * core.constructors.bsBehavior.SlotConstants.FIFTEEN_PERCENT);
                }
            }
            this.getContainerByID("portraitButtonsContainer") && ingenuity.currentGame.stage.addChild(this.getContainerByID("portraitButtonsContainer"));
        }


        protected updateOrientation(): void {
            for (const key in this.allComponents) {
                if (this.allComponents.hasOwnProperty(key)) {
                    const comp: any = this.allComponents[key];
                    if (comp.json && comp.json.orientation) {
                        this.updateProperties(comp, comp.json.orientation[this.CurrentOrientation]);
                    }
                }
            }
        }

        protected updateProperties(comp: any, json: any) {
            for (const property in json) {
                if (json.hasOwnProperty(property)) {
                    switch (property) {
                        case "x":
                            comp.x = json[property];
                            break;
                        case "y":
                            comp.y = json[property];
                            break;
                        case "visible":
                            comp.visible = json[property];
                            break;
                        case "scaleX":
                            comp.scale.set(json[property], comp.scale.y);
                            break;
                        case "scaleY":
                            comp.scale.set(comp.scale.x, json[property]);
                            break;
                        case "scale":
                            comp.scale.set(json[property]);
                            break;
                    }
                }
            }
        }

        protected BaseGamePortraitLandscapeViewChange(): void {
            if (ingenuity.deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.handleInPortrait();
            } else {
                if (!deviceEnv.isDesktop && deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                    this.handleInLandscape();
                }
            }
        }

        protected handleInPortrait(): void {
            const allComp = this.getAllcomponents();

            for (const key in allComp) {
                if (allComp[key] && allComp[key].json && key !== "anticipation_2" && key !== "anticipation_3" && key !== "anticipation_4" && key !== "lineWinAmt") {
                    allComp[key].x = allComp[key].json.portraitX ? allComp[key].json.portraitX : allComp[key].json.x;
                    allComp[key].y = allComp[key].json.portraitY ? allComp[key].json.portraitY : allComp[key].json.y;
                    allComp[key].scale.set(allComp[key].json.portraitScale ? allComp[key].json.portraitScale : (allComp[key].json.scale ? allComp[key].json.scale : 1));
                    if (key === "PayLineNumbers") {
                        allComp[key].visible = false;
                    }
                }
            }
        }

        protected handleInLandscape(): void {
            const allComp = this.getAllcomponents();

            for (const key in allComp) {
                if (allComp[key] && allComp[key].json && key !== "anticipation_2" && key !== "anticipation_3" && key !== "anticipation_4" && key !== "lineWinAmt") {
                    allComp[key].x = allComp[key].json.landscapeX ? allComp[key].json.landscapeX : allComp[key].json.x;
                    allComp[key].y = allComp[key].json.landscapeY ? allComp[key].json.landscapeY : allComp[key].json.y;
                    allComp[key].scale.set(allComp[key].json.landscapeScale ? allComp[key].json.landscapeScale : (allComp[key].json.scale ? allComp[key].json.scale : 1));
                }
            }
        }

        /**to play symbol landing sounds
         * @ data has 3 value- landingSymbollId, symbolCount and reelID
         */
        protected checkAndPlayLandingSounds(evt: IEvent): void {
            //
        }
    }
}
