///<reference path="../../../Interfaces.ts" />
/* tslint:disable */
namespace ingenuity.BehaviorCore.BaseGame {

    export class ReelPanelController extends slot.BaseGame.ReelPanelController {

        protected model: Model;
        protected view: View;
        public scatterOnReel: number[];

        constructor(view: View, model: Model) {
            super(view, model);
            this.view = view;
            this.model = model;
            this.resetScatterOnReel();
        }

        /**
         * Overrided this function to have triggring grid in basegame when broken in freegame
         */
        protected init(): void {
            if (parserModel.getNextAction() === BehaviorCore.slotConstants.SlotConstants.FREE_SPIN || parserModel.getNextAction() === BehaviorCore.slotConstants.SlotConstants.FREE_SPIN_CLOSE) {
                if (parserModel.getFreeSpinsRemaining() !== parserModel.getFreeSpinNum()) {
                    parserModel.restoreBaseGame = true;
                }
            }
            super.init();
        }

        /**
         * Override this function to subscribe NOW_SPIN_REEL_AfTER_BROKEN and SHOW_SYMBOLS_ON_GRID event
         */
        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(slotConstants.SlotEventConstants.START_REEL_SPINNING, this.onStartReelSpinning, this);
            dispatcher.on(slotConstants.SlotEventConstants.SHOW_SYMBOLS_ON_GRID, this.showSymbolsOnGrid, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.RESET_SCATTER_ON_REEL, this.resetScatterOnReel, this);
            dispatcher.on(platform.EventConstants.GAME_CLOSE_RESPONSE_RECEIVED, this.enableButtons, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_REEL_SET, this.updateReelsets, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.SHOW_ANTICIPATION, this.playAnticipationSound, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BROKEN_GAME, this.onSpinComplete, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_FEATURE_AFTER_WIN_LIMIT_POPUP, this.enableConsolePanelOnAutoStop, this);
        }

        /**
         * Override this function to unsubscribe NOW_SPIN_REEL_AfTER_BROKEN and SHOW_SYMBOLS_ON_GRID event
         */
        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(slotConstants.SlotEventConstants.START_REEL_SPINNING, this.onStartReelSpinning);
            dispatcher.off(slotConstants.SlotEventConstants.SHOW_SYMBOLS_ON_GRID, this.showSymbolsOnGrid);
            dispatcher.off(platform.EventConstants.GAME_CLOSE_RESPONSE_RECEIVED, this.enableButtons, this);
        }

        protected playAnticipationSound(): void {
            soundManager.play(core.constructors.bsBehavior.SoundConstants.ANTICIPATION_SOUND);
        }

        protected updateReelsets(evt: IEvent): void {
            this.reelView.getModel().setReelsets(this.model.getReelSets() as number[][][]);
        }

        /**
         * to reset "scatter on reel" data
         */
        protected resetScatterOnReel(): void {
            this.scatterOnReel = [0, 0, 0, 0, 0];
        }

        /**
         * Show static reel grid
         * @param evt
         */
        protected showSymbolsOnGrid(evt: IEvent): void {
            const data: number[][] = evt.data.data || evt.data;
            const reelGrid: number[][] = (data.length > 0) ? data : parserModel.getDefaultReelGrid();
            this.reelView.showStaticGrid(reelGrid);
        }

        /**
         * onSpinReel, when broken game, user can spin Reel by dispatching event
         * ingenuity.slotConstants.SlotEventConstants.START_REEL_SPINNING and listen in this
         * Which start Reel Spinning
         * listen in this function
         */
        protected onStartReelSpinning(evt: IEvent): void {
            this.reelView.fireEvent(slot.slotConstants.SlotEventConstants.SPIN);
        }


        /*
         * Override this function to dispatch SET_IS_REEL_SPINNING event
         * @param evt
         */
        protected onSpinReel(evt: IEvent): void {
            utils.delayedCall("spinDelay", 100, () => {
                utils.killDelayedCall("spinDelay");
                this.reelView.fireEvent(slot.slotConstants.SlotEventConstants.SPIN);
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SET_IS_REEL_SPINNING, true);
                if (parserModel.getNextAction() === platform.aruze.Constants.CLOSE_ACTION) {
                    // statement is used, to handle RC during close request
                    parserModel.setTotalWin(0);
                    !configData.endReqSent && dispatcher.fireEvent(platform.EventConstants.GAME_CLOSE);
                } else {
                    this.sendSpinRequest();
                }
            });
        }

        /**
         * to send spin request to server
         * to stop sending the bet request if game in history mode
         */
        protected sendSpinRequest(): void {
            if (parserModel.getGameMode() !== ingenuity.BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                dispatcher.fireEvent(ingenuity.platform.EventConstants.PLACE_BET);
            }
        }

        /**
         * This fucntion is overrided to send gameplay ended.
         * and to send enable all game buttons once close response is received
         * if rc comes during spin request, then just enable the buttons on reel stop
         */
        protected onSpinComplete(evt?: IEvent): void {
            configData.spinComplete = true;
            this.reelView.getModel().quickSpin = false;
            this.reelView.setStopNow(false);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SET_IS_REEL_SPINNING, false);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CHECK_FOR_WIN_AFTER_REEL_STOP);
            dispatcher.off(slot.slotConstants.SlotEventConstants.SHOW_ANTICIPATION, this.showAnticipation);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_STOP_PLAYER_MSG);
            if (!configData.freegameReturning && !this.model.getIsScatterWins()) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.GAMBLE_CHECK_AND_SEND_CLOSE);
            }
            if (parserModel.getErrorOnBet()) {
                parserModel.setErrorOnBet(false);
                configData.endReqSent = true;
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
            }

            /**
            * to end history replay in case of no win
            */
            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE && currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState && !configData.endReqSent) {
                if (!parserModel.getTotalWin() && !this.model.getIsWin()) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END);
                }
            }
        }


        /**
         * this function handles button enable on freegame returning.
         * and also stop autoplay on fg returning.
         * also enable buttons if spin is complete
         */
        protected enableButtons(): void {
            if (configData.freegameReturning) {
                if (this.model.getIsAutoPlayLeft()) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_SPIN_CALL);
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.GAMBLE_BUTTON, BehaviorCore.slotConstants.SlotConstants.COLLECT_BUTTON]);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_BUTTONS);
                }
                !this.model.getIsAutoPlayLeft() && (configData.freegameReturning = false);
            } else {
                this.enableButtonsOnCloseReceived();
            }
        }

        /**
         * to enable game buttons after reels stopped and close response is received
         */
        protected enableButtonsOnCloseReceived(): void {
            if (this.model.getIsAutoPlayLeft()) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_SPIN_CALL);
            } else if (this.model.getIsBigWin() && !this.model.getIsAutoPlayLeft() && !this.model.getIsScatterWins()) {
                /**
                 * this condition arises specifically during gamble + Bigwin
                 */
                if (this.model.getIsBigWinRunning()) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [slotConstants.SlotConstants.SpinBtnId]);
                } else {
                    if (configData.SuitGamble) {
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.GAMBLE_BUTTON, BehaviorCore.slotConstants.SlotConstants.COLLECT_BUTTON]);
                    } else {
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                    }
                }
            } else if (!this.model.getIsBigWin() && !this.model.getIsAutoPlayLeft() && !this.model.getIsScatterWins()) {
                if (configData.SuitGamble) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.GAMBLE_BUTTON, BehaviorCore.slotConstants.SlotConstants.COLLECT_BUTTON]);
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                }
            }
        }

        protected onReelStopped(evt: IEvent): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_SCATTER_LANDING_ON_REELSTOP, utils.toInt(evt.toString()));
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BIG_SYMBOL, utils.toInt(evt.toString()));
        }

        protected checkForlandingAnim(symbolObj: any, listLength: number): void {
            let i: number, j: number;
            let symbolCount = 0;
            let symbolFound = false;
            const symbolNeeded = symbolCount + 1;
            const NumReel = this.reelView.getModel().numReels;
            for (i = 0; i < this.reelView.getModel().numReels; i++) {
                for (j = 0; j < this.model.getReelGrid()[i].length; j++) {
                    if (this.model.getReelGrid()[i][j] === symbolObj.symbolId) {
                        symbolFound = true;
                        break;
                    }
                }
                if (symbolFound) {
                    symbolCount++;
                    if (symbolFound && i < (NumReel - (symbolNeeded - symbolCount))) {
                        this.reelView.getModel().landingOnReel[i] = 1;
                    }
                    symbolFound = false;
                }
            }
        }

        protected checkForAnticipation(symbolObj: any, listLength: any): any {
            let i, j, k, n;
            let symbolCount = 0;
            const anticipation = [];
            let symbolFound = false;
            for (i = 0; i < this.reelView.getModel().numReels - 1; i++) {
                this.reelView.getModel().anticipationSpin[i] = 0;
                if (symbolObj.aniticipationRunOnReel[i] > -1) {
                    if (symbolCount >= symbolObj.symbolCount && symbolObj.aniticipationRunOnReel[i] !== -1) {
                        if (ingenuity.configData.anticipationRunAfterFeature) {
                            anticipation[i] = 1;
                            symbolCount = 0;
                        } else {
                            if (symbolCount >= symbolObj.symbolCount + 1) {
                                anticipation[i] = 0;
                            } else {
                                anticipation[i] = 1;
                            }
                        }
                    }
                }
                for (j = 0; j < this.model.getReelGrid()[i].length; j++) {
                    if (this.model.getReelGrid()[i][j] === symbolObj.symbolId && symbolObj.aniticipationRunOnReel[i] !== -1) {
                        symbolFound = true;
                        break;
                    }
                }
                if (symbolFound) {
                    symbolCount++;
                    symbolFound = false;
                }
            }
            this.anticipationList.push(anticipation);
            if (this.anticipationList.length === listLength) {
                for (k = 0; k < this.anticipationList.length; k++) {
                    for (n = 0; n < this.anticipationList[k].length; n++) {
                        if (this.anticipationList[k][n] === 1) {
                            this.reelView.getModel().anticipationSpin[n] = 1;
                        }
                    }
                }
            }
            this.checkForlandingAnim(symbolObj, listLength);
        }

        /**
         * enable console panel buttons on stop of auto play
         */
        protected enableConsolePanelOnAutoStop(): void {
            if (!parserModel.getHasFreeGamesWin() && !this.model.getIsAutoPlayLeft() && configData.spinComplete) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                configData.spinComplete = false;
            }
        }

        /**overrided to send landing symbols data on every reel */
        protected onReelStoping(evt?: IEvent): void {
            super.onReelStoping(evt);
            for (let m: number = 0; m < parserModel.getLandingSoundOnReel().length; m++) {
                const value: number = parserModel.getLandingSoundOnReel()[m][utils.toInt(evt.toString())];
                value && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.PLAY_LANDING_SOUNDS, value);
            }
        }
    }
}
