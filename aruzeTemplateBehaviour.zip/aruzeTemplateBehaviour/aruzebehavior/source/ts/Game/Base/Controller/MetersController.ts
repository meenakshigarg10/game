///<reference path="../../../Interfaces.ts" />
/**
 *
 * Purpose of below controller to controll all Meters in game
 */

namespace ingenuity.BehaviorCore.BaseGame {
    export class MetersController extends slot.BaseGame.MetersController {
        protected view: View; // base game view
        protected model: Model; // basegame model
        protected centerTickMoveDownTween: bridge.ITween;
        protected winValueMeter: BehaviorCore.behaviourUI.WinTickupMeterBitmap;
        protected deviceWinMtr: ui.Container;

        constructor(view: View, model: Model) {
            super(view, model);
            this.view = view;
            this.model = model;
            this.winValueMeter = this.view.getMeterById(BehaviorCore.slotConstants.SlotConstants.WinMeterId) as BehaviorCore.behaviourUI.WinTickupMeterBitmap;
            this.deviceWinMtr = this.view.getContainerByID("winMeterContainer");
            dispatcher.fireEvent(slotConstants.SlotEventConstants.CLEAR_PAID_METER);
        }

        /**
         * Override this function to subscribe CLEAR_PAID_METER event
         *
         * Below subscribed event to use to handle Meters. subscribeEvents is called When SCBSCRIBE_METER_CONTROLLERS_BG fired.
         */
        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(slotConstants.SlotEventConstants.CLEAR_PAID_METER, this.clearPaidMeter, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.FORCE_STOP_WIN_METER_TICKUP, this.onForceStopWinTickUp, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_WIN_PRESENTATION_CALL, this.autoplayForceStop, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR, this.hideDeviceWinMeter, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.STOP_METER_TICKUP, this.onStopMeterTickup, this);
        }

        /**
         * Override this function to unsubscribeEvents CLEAR_PAID_METER event
         *
         * Below unsubscribed event to use by Meters. unsubscribeEvents is called When UNSCBSCRIBE_METER_CONTROLLERS_BG fired.
         */
        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(slotConstants.SlotEventConstants.CLEAR_PAID_METER, this.clearPaidMeter);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.FORCE_STOP_WIN_METER_TICKUP, this.onForceStopWinTickUp, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_WIN_PRESENTATION_CALL, this.autoplayForceStop, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR, this.hideDeviceWinMeter, this);
            dispatcher.off(slot.slotConstants.SlotEventConstants.STOP_METER_TICKUP, this.onStopMeterTickup, this);
        }

        /***
         * Override this function for show/hide autoplay cvounter
         * onUpdateBetMeter, updates Bet amount in Bet Meter
         * @param evt
         */
        protected onUpdateAutoPlayMeter(evt: IEvent): void {
            if (this.model.getIsAutoPlayLeft() === true && this.autoPlayMeter.getValue() > 0) {
                this.autoPlayMeter && (this.autoPlayMeter.visible = true);
            } else {
                this.autoPlayMeter && (this.autoPlayMeter.visible = false);
            }
        }


        /**
         * case is specific for autoplay is force stopped during tickup is running
         */
        protected autoplayForceStop(): void {
            if (this.winValueMeter.getIsTickUpRunning()) {
                this.winValueMeter.onTickupComplete.addOnce(() => {
                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI);
                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                }, this);
            }
        }

        /***
         * Override this function for update the win tick up behavior
         *
         * onStartWinTickUp, starts win Tickup in win meter in buttonpanel.
         * After tickup completes, update balance
         * @param evt
         */
        protected onStartWinTickUp(evt: IEvent): void {
            if (!deviceEnv.isDesktop) {
                this.view.addChildAt(this.deviceWinMtr, this.view.getIndex(this.view.getWinReelView()) + 1);
            }
            this.winValueMeter && (this.winValueMeter.startTick(parserModel.getGameWinAmt(), this.model.getIsCredits(), false, this.model.getWinMeterTickUpDuration(), true, this.updateBalance.bind(this)));
            soundManager.playSound(this.model.getWinMeterTickUpSound());
            if (this.model.getIsAutoPlayLeft() && !this.model.getIsScatterWins()) {
                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.SpinBtnId]);
            }
        }

        /**
         *
         * @param evt called when spin is clicked to force stop the button panel winmeter tickup if running and then send next spin request.
         * also show stop button as sson as spin is clicked, if meter is ticking.
         * if not ticking, then to show stop button is being handled in slotlogic
         * Autoplay:  when tickup is finished, hold the win amount for some time in meter
         * and then send call for next spin.
         * Autoplay: since there is no bounce on game force stop, so delay is added before sending next spin call
         */
        protected onForceStopWinTickUp(evt?: IEvent): void {
            if (this.winValueMeter.getIsTickUpRunning()) {
                if (configData.isAutoplayActive) {
                    this.stopWinMeterTickupInAutoPlay();
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN);
                    soundManager.stop(this.model.getWinMeterTickUpSound());
                    this.winValueMeter.forceStop(this.model.getIsCredits(), false, true, 700, () => {
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK);
                    });
                }
            } else if (this.model.getIsAutoPlayLeft()) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN);
                this.winValueMeter.stopTickupAndDelay(700, () => {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK);
                });
            } else {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK);
            }
        }

        /**
         * called after wintickup ends by itself.
         * overrided to call for next spin in case of autoplay.
         * also send history end if gamble not played in case of win.
         */
        protected updateBalance(): void {
            super.updateBalance();
            if (configData.isAutoplayActive) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_IN_AUTOPLAY_IF_WIN);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
            }
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_WRAPPER_WIN);
            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                if (this.model.getGambleDrawnCard() && this.model.getGambleDrawnCard().length) {
                    //
                } else {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END);
                }
            }
        }

        /**only for mobile
         * to hide winmeter container on spin clicked
         */
        protected hideDeviceWinMeter(): void {
            this.deviceWinMtr.visible = false;
        }

        /***
         * Override this function for update the win tick up behavior when returning back to basegame
         *
         * onStartWinTickUp, starts win Tickup in win meter
         * @param evt
         * send close and reset autoplay on freegame returning
         * and then continue with presentations
         */
        protected onReturningFreegameUpdateMeter(evt: IEvent): void {
            this.model.setAnimationSequenceCounter(this.model.getAnimationSequence().length - 1);
            parserModel.getGameMode() !== BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.FREEGAME_RETURN_SEND_CLOSE);
            !deviceEnv.isDesktop && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getTotalWinAmt()) });
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_WIN_TOGGLE_PLAYER_MSG);
        }

        /***
         * Override this function to fireEvent CLEAR_PAID_METER instead of UPDATE_PAID_METER
         *
         * onResetMeters, resets all meters available in games
         * @param evt
         */
        protected onResetMeters(evt: IEvent): void {
            dispatcher.fireEvent(slotConstants.SlotEventConstants.CLEAR_PAID_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_BET_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_TOTAL_BET_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_STAKE_METER);
            if (this.model.getTotalAutoSpins().toString().toString() === "∞") {
                this.autoPlayMeter && (this.autoPlayMeter.setValue(1));
                this.autoPlayMeter && (this.autoPlayMeter.setText("∞"));
            } else {
                this.autoPlayMeter && (this.autoPlayMeter.setValue(this.model.getTotalAutoSpins() + 1 - this.model.getCurrentAutoSpinIndex()));
            }
        }

        /***
         * Override this function for update the win tick up behavior
         *
         * onUpdatePaidMeter, updates Win amount in Win Meter
         * @param evt
         */
        protected onUpdatePaidMeter(evt: IEvent): void {
            const currWinAmnt: number = this.model.getCurrentWinAmt();
            if (this.winMeter) {
                if (this.winMeter.isTicking) {
                    this.winMeter.stopTick(this.model.getIsCredits(), false, true);
                    utils.delayedCall(slotConstants.SlotConstants.ClearWinDelay, slotConstants.SlotConstants.setDelayForClearWin || 300, () => {
                        utils.killDelayedCall(slotConstants.SlotConstants.ClearWinDelay);
                        if (this.model.getIsCredits()) {
                            this.winMeter.setCurrencyFormattedValue(this.model.getCurrentWinAmt().toString());
                        } else {
                            this.winMeter.setFormattedValue(this.model.getCurrentWinAmt() + "");
                        }
                        (currWinAmnt === 0) ? this.winMeter.visible = false : this.winMeter.visible = true;
                    });
                } else {
                    if (this.model.getIsCredits()) {
                        this.winMeter.setCurrencyFormattedValue(this.model.getCurrentWinAmt().toString());
                    } else {
                        this.winMeter.setFormattedValue(this.model.getCurrentWinAmt() + "");
                    }
                    (currWinAmnt === 0) ? this.winMeter.visible = false : this.winMeter.visible = true;
                }
            }
        }

        /**
         * Clear win meter
         */
        protected clearPaidMeter(): void {
            const currWinAmnt: number = 0;
            if (this.winMeter) {
                if (this.winMeter.isTicking) {
                    this.winMeter.stopTick(this.model.getIsCredits(), false, true);
                    utils.delayedCall(slotConstants.SlotConstants.ClearWinDelay, slotConstants.SlotConstants.setDelayForClearWin || 300, () => {
                        utils.killDelayedCall(slotConstants.SlotConstants.ClearWinDelay);
                        if (this.model.getIsCredits()) {
                            this.winMeter.setCurrencyFormattedValue(currWinAmnt.toString());
                        } else {
                            this.winMeter.setFormattedValue(currWinAmnt.toString());
                        }
                        this.winMeter.visible = false;
                    });
                } else {
                    if (this.model.getIsCredits()) {
                        this.winMeter.setCurrencyFormattedValue(currWinAmnt.toString());
                    } else {
                        this.winMeter.setFormattedValue(currWinAmnt.toString());
                    }
                    this.winMeter.visible = false;
                }
            }
        }

        protected onUpdateBetMeter(evt: IEvent): void {
            if (this.betMeter) {
                this.betMeter.setCurrencyFormattedValue(String(this.model.getCurrentBet()));
            }
        }

        /**
         * overrided since winmeter used in game is different from slot
         */
        protected onStopWinTickUp(): void {
            if (this.winValueMeter.isTicking) {
                this.winValueMeter.stopTick(this.model.getIsCredits(), false, true);
                soundManager.stop(this.model.getWinMeterTickUpSound());
            }
        }

        protected stopWinMeterTickupInAutoPlay(): void {
            if (this.winValueMeter.getIsTickUpRunning()) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN);
                soundManager.stop(this.model.getWinMeterTickUpSound());
                this.winValueMeter.forceStop(this.model.getIsCredits(), false, true, 100, function () {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_IN_AUTOPLAY_IF_WIN);
                });
            }
        }
    }
}
