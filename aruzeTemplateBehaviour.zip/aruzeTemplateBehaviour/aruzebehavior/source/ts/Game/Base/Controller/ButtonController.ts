///<reference path="../../../Interfaces.ts" />

/**
 * Override this class for update the buttons behavior according to Pocker stars
 *
 * Purpose of this class to control all buttons functionalities in game
 * like, if user click "SPIN" button, it will be first listened here and required action will be taken
 */
namespace ingenuity.BehaviorCore.BaseGame {

    export class ButtonController extends slot.BaseGame.ButtonController {
        protected view: View;
        protected model: Model;

        protected maxBetBtn: ingenuity.ui.ButtonBase;
        protected turboBtnOn: ingenuity.ui.ButtonBase;
        protected turboBtnOff: ingenuity.ui.ButtonBase;
        protected autoPlayBtn: ingenuity.ui.ButtonBase;

        protected settingButton: ui.ButtonBase;
        protected infoBtn: ui.ButtonBase;
        protected gambleButton: BehaviorCore.BSButtonBase;
        protected collectButton: BehaviorCore.BSButtonBase;
        protected gambleBtnBG: ui.Bitmap;

        /**
         * button panel constructor, which initializes all buttons , binds events on them and subscribes events
         * handles by buttons
         * @param view
         * @param model
         */
        constructor(view: View, model: Model) {
            super(view, model);

            /** hide spin stop and turbo buttons as per compliance */
            !parserModel.getIsTurboEnable() && this.hideTurboButtons();
            // hide Autoplay button as per compliance"
            !parserModel.getIsAutoPlayEnable() && this.hideAutoplayButtons();
            if (!parserModel.getIsSpinStopAvailable()) {
                this.hideSpinStopButton();
            } else if (configData.turboEnabled) {
                this.hideSpinStopButton();
            }
        }

        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(slot.slotConstants.SlotEventConstants.AUTOPLAY_RESET, this.resetAutoPlay, this);
        }

        /**
         * Override this function to initialize more buttons
         *  Initialize all game buttons by taking their reference from Base Game View
         * @param view
         */
        protected initializeButtons(view: View): void {
            super.initializeButtons(view);
            this.maxBetBtn = view.getButtonById(slotConstants.SlotConstants.MaxBetBtn) as ui.ButtonBase;
            this.turboBtnOn = view.getButtonById("turboModeEnableBtn") as ui.ButtonBase;
            this.turboBtnOff = view.getButtonById("turboModeDisableBtn") as ui.ButtonBase;
            this.settingButton = this.view.getButtonById(ingenuity.BehaviorCore.slotConstants.SlotConstants.SETTING_BUTTON) as ui.ButtonBase;
            this.infoBtn = this.view.getButtonById(ingenuity.BehaviorCore.slotConstants.SlotConstants.INFO_BUTTON) as ui.ButtonBase;
            this.gambleButton = view.getButtonById("gambleButton") as BehaviorCore.BSButtonBase;
            this.collectButton = view.getButtonById("collectButton") as BehaviorCore.BSButtonBase;
            this.betPlusBtn = view.getButtonById(slot.slotConstants.SlotConstants.BetPlusBtnId) as ui.ButtonBase;
            this.betMinusBtn = view.getButtonById(slot.slotConstants.SlotConstants.BetMinusBtnId) as ui.ButtonBase;
            this.gambleBtnBG = this.view.getImageById("gambleCollectBG");
        }

        /**
         * Override this function to bind events on other buttons which are not there in super function
         * bindHandlers, binds events on all buttons
         * like when user clicks on SPIN btn in game, it will trigger onSpinPressUp event
         */
        protected bindHandlers(): void {
            super.bindHandlers();
            this.maxBetBtn && this.maxBetBtn.on(ingenuity.ui.ButtonBase.UP, this.onMaxBetPressUp, this);
            this.turboBtnOn && this.turboBtnOn.on(ingenuity.ui.ButtonBase.UP, this.onturboBtnOnPressUp, this);
            this.turboBtnOff && this.turboBtnOff.on(ingenuity.ui.ButtonBase.UP, this.onturboBtnOffPressUp, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.DISABLE_CONSOLE_BUTTONS, this.disableConsoleButtons, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.ENABLE_CONSOLE_BUTTONS, this.enableConsoleButtons, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.ENABLE_STAGE_CLICK, this.enableStageClick, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_AUTOPLAY_ON_BTN, this.hideAutoplayOnBtn, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_AUTOPLAY_OFF_BTN, this.showAutoplayOffBtn, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN, this.showStopBtn, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_BTN, this.showSpinBtn, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.REASSIGN_STOP_BTN, this.reassignStopBtn, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.BS_STOP_AUTOPLAY, this.onAutoPlayOffPressUp, this);
            this.settingButton && this.settingButton.on(ingenuity.ui.ButtonBase.UP, this.onSettingButtonPress, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ENABLED_SETTING_BTN, this.enabledSettingButton, this);
            this.gambleButton && this.gambleButton.on(ingenuity.ui.ButtonBase.UP, this.onGamblePressUp, this);
            this.collectButton && this.collectButton.on(ingenuity.ui.ButtonBase.UP, this.onCollectPressUp, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.DISABLE_COLLECT_BTN, this.disableCollectButton, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_COLLECT_BTN, this.enableCollectButton, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_BUTTONS, this.hideGambleButtons, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_GAMBLE_BUTTONS, this.onEnableGambleButtons, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_GAMBLE_BUTTON, this.enableGambleButton, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.START_GAMBLE, this.startGamble, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.ENABLE_AUTOPLAY_FROM_WRAPPER, this.enableAutoPlayFromWrapper, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_DISABLE_SETTING_COIN_BT, this.resetButtons, this);
        }
        protected resetButtons(): void {
            this.changeBetButtonStates();
        }

        /**
         * To handle unbinding on gamble and collect buttons
         */
        protected unBindHandlers(): void {
            super.unBindHandlers();
            this.gambleButton && this.gambleButton.off(ingenuity.ui.ButtonBase.UP);
            this.collectButton && this.collectButton.off(ingenuity.ui.ButtonBase.UP);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.DISABLE_COLLECT_BTN, this.disableCollectButton, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_COLLECT_BTN, this.enableCollectButton, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_BUTTONS, this.hideGambleButtons, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_GAMBLE_BUTTONS, this.onEnableGambleButtons, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_GAMBLE_BUTTON, this.enableGambleButton, this);
        }

        /**
         * To enable gamble and collect buttons for gamble play, only if server response allows.
         */
        public onEnableGambleButtons(evt: IEvent): void {
            this.toggleButtonStates();
        }
        /**
         * To hide gamble buttons for base game play
         */

        public hideGambleButtons(): void {
            this.gambleButton.visible = false,
            this.collectButton.visible = false;
            this.gambleBtnBG.visible = false;
            this.resetGambleButtonsToggling();
        }

        /**
         * To hide gamble feature on collect button press up
         * and send game close request
         */
        protected onCollectPressUp(): void {
            parserModel.setIsGambleAvailable(false);
            this.resetGambleButtonsToggling();
            if (this.model.getIsTurboModeOn()) {
                this.view.getButtonById("turboModeDisableBtn").visible = true;
            }
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.STOP_SYMBOL_SOUND);
            !this.model.getIsBigWin() && dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.STOP_WIN_TICK_UP);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_WIN_ON_GAMBLE_START);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_BUTTONS);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_VIEW);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_AFTER_GAMBLE);
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SoundConstant.COLLECT_BTN);
            /**to handle wintickup amount in case of broken and history of gamble */
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getTotalWinAmt()) });
            this.disableCollectButton();
        }

        /**
        * To show gamble view on gamble button press up
        * BigWIn: If gamble is pressed before bigwin starts, then sumup bigwin and then show gamble view.
        * if gamble is pressed, after bigwin presentation finishes,  then just suspend presentation and open gamble view.
        *
        */
        protected onGamblePressUp(): void {
            this.resetGambleButtonsToggling();
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SoundConstant.GAMBLE_BTN);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.STOP_SYMBOL_SOUND);
            configData.stopSymbolSound = true;
            !this.model.getIsBigWin() && dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.STOP_WIN_TICK_UP);
            /**to handle wintickup amount in case of broken and history of gamble */
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getTotalWinAmt()) });
            this.onDisabledAllButtons();
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_GAMBLE);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_WIN_ON_GAMBLE_START);
        }

        /**to show gamble view. method will be used only after gamble assets are loaded */
        private startGamble(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.START_GAMBLE_FEATURE);
            if (parserModel.getGameMode() !== BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                this.enableCollectButton();
            } else {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_POTENTIAL_WIN);
                this.hideGambleButtons();
            }
        }

        /**
         * To enable collect button
         */
        private enableCollectButton(): void {
            this.collectButton.enableAndTint();
            this.collectButton.alpha = 1;
        }

        /**
         * To disable collect button
         */

        private disableCollectButton(): void {
            this.collectButton.disableAndTint();
        }

        /**
         * to enable gamble button
         */
        private enableGambleButton(): void {
            this.gambleButton.enableAndTint();
            this.gambleButton.alpha = 1;
            this.collectButton.visible = true;
            this.collectButton.disableAndTint();
        }


        /**
         * to make menu panel open on setting button click
         * and disable spacebar when menu panel is open
         */
        protected onSettingButtonPress(): void {
            this.suspendWinWhenButtonPressed();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.ADD_SETTING_PANNEL);
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SlotConstants.SettingBtnId);
        }

        /**
        * to make Info Screen open. Only for Wheels GO Round Games button panel
        */
        protected onInfoPressUp(): void {
            this.suspendWinWhenButtonPressed();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.ADD_SETTING_PANNEL);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.OPEN_INFO_SCREEN);
        }

        /**
         * to disable setting button along with all other buttons
         */
        protected disabledSettingButton(): void {
            this.settingButton.disableAndTint();
        }

        /**
         * to enaable setting button along with all other buttons
         */
        protected enabledSettingButton(): void {
            this.settingButton.enableAndTint();
        }

        /**
         * to reassign stop button during normal spin mode
         */
        protected reassignStopBtn(): void {
            this.spinStopBtn = this.view.getButtonById(slotConstants.SlotConstants.SpinStopBtnId) as ui.ButtonBase;
        }

        /**
         * to hide AutoplayOn Button
         */
        protected hideAutoplayOnBtn(): void {
            if (ingenuity.deviceEnv.isDesktop) {
                this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.AutoPlayBtnId).visible = false;
            }
        }

        /**
         * to show AutoplayOff Button
         */
        protected showAutoplayOffBtn(): void {
            this.view.getContainerByID("AutoPlayOffBtnContainer").visible = true;
            this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.AutoPlayOffBtnId).visible = true;
            this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.AutoPlayOffBtnId).alpha = 1;
        }

        /**
         * to make stage click work on big win show
         */
        protected enableStageClick(evt: IEvent): void {
            if ((parserModel.getNextAction() !== "freespin") && parserModel.getGameMode() !== BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, evt.data);
            }
            configData.enableStageClick = true;
        }

        /*Overrided this function to enable spacebar durinmg bigwin */
        protected onEnabledButton(evt: IEvent): void {
            let btnId: string | number;
            const eventArguments = evt.data ? (typeof evt.data === "string" ? [evt.data] : evt.data) : [];
            if (eventArguments.length) {
                for (btnId = 0; btnId < eventArguments.length; btnId++) {
                    if (typeof eventArguments[btnId] === "string") {
                        (this.view.getbuttonArray()[eventArguments[btnId]] as ui.ButtonBase).enableAndTint();
                        if (eventArguments[btnId] === slot.slotConstants.SlotConstants.SpinBtnId) {
                            const spinButtn: ui.ButtonBase = this.view.getbuttonArray()[eventArguments[btnId]] as ui.ButtonBase;
                            if (spinButtn.visible === true && spinButtn.alpha === 1) {
                                !configData.brokenOnClose && (configData.enableSpacebar = true);
                            }
                        }
                    } else {
                        eventArguments[btnId].enableAndTint();
                    }
                }
            }
            if (this.model.getIsAutoPlayLeft()) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLE_BUTTON, this.settingBtn);
            }
        }

        /**
        * Overrided to add player msg behavior on space btn press.
        * Overrided to start keyboard functionality only when buttons are enableAndTint.
        * Space bar functionality should be enable when:
        *        - Skip button is in enable state and we can send spin request.
        *        - Stop button is in enable state and we Force stop the reel spin.
        *        - To suspend Win Presentation Skip button should be in enable state else presentation cannot skip with spaceBar.
        **/
        protected spaceKeyBoardEvent(): void {
            if (configData.subscribeSpaceBarToSpin) {
                window.addEventListener("keyup", (event: KeyboardEvent) => {
                    if (event.keyCode === 32 && configData.enableSpacebar && parserModel.getGameState() === ingenuity.BehaviorCore.slotConstants.SlotConstants.WRAPPER_ACTIVE_STATE) {
                        if (ingenuity.currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState) {
                            if (!this.model.getIsTurboModeOn() && this.spinStopBtn && this.spinStopBtn.visible && this.spinStopBtn.input.enabled) {
                                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FORCE_STOP);
                                configData.enableSpacebar = false;
                                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS, [slot.slotConstants.SlotConstants.SpinBtnId]);
                                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_BTN);
                            } else if (this.spinBtn && this.spinBtn.visible && this.spinBtn.input.enabled) {
                                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED);
                                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_PLAYER_MSG);
                            }
                        } else if (event.ctrlKey && (event.which === 61 || event.which === 107 || event.which === 173 || event.which === 109 || event.which === 187 || event.which === 189)) {
                            event.preventDefault();
                        }
                    }
                });
            }
            if (configData.preventMouseWheelZoom) {
                const mouseWheel = function (event: any) {
                    const e = event ? event : window.event;
                    if (e.ctrlKey) {
                        if (e.preventDefault) {
                            e.preventDefault();
                        } else {
                            e.returnValue = false;
                        }
                        return false;
                    }
                };

                document.body.addEventListener("DOMMouseScroll", mouseWheel, false);
                document.body.addEventListener("mousewheel", mouseWheel, false);
            }
        }

        /**
         * Override this function to add delay before dispatching force stop
         *
         * onSpinStopPressUp, when STOP btn pressed in game
         * it force stops all reels , first disabled all btns and enable and visible SPIN btn and invisible STOP btn
         */
        protected onSpinStopPressUp(): void {
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, slotConstants.SlotConstants.SpinStopBtnId);
            if (this.spinStopBtn && this.spinStopBtn.visible) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                this.spinBtn.visible = true;
                this.spinStopBtn.visible = false;
            }
            if (this.model.getIsAutoPlayLeft()) {
                //
            }
            dispatcher.fireEvent(slotConstants.SlotEventConstants.ON_SPIN_STOP_CLICKED);
        }

        /**
         * Override this function to show/hide the auto play panel on press AutoPlay button
         *
         * onAutoPlayPressUp, when user clicks AUTOPLAY btn in game, this function will be called
         * This is handled most of the time at on behaviour level
         */
        protected onAutoPlayPressUp(): void {
            this.suspendWinWhenButtonPressed();
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SlotConstants.AutoPlayBtnId);
            dispatcher.fireEvent(slotConstants.SlotEventConstants.ON_AUTO_PLAY_CLICKED);
        }

        /**
         * Override this function to reset the auto paly on/off button visibility
         *
         * reset Auto play When auto Play Finished.
         * @param evt
         */
        protected resetAutoPlay(evt: IEvent): void {
            super.resetAutoPlay(evt);
            this.autoPlayBtn && (this.autoPlayBtn.visible = true);
            this.autoPlayOffBtn && (this.autoPlayOffBtn.visible = false);

            // hide Autoplay button as per compliance"
            !parserModel.getIsAutoPlayEnable() && this.hideAutoplayButtons();
        }

        /**
         * Override this function to reset the auto play buttons visibility and update auto play meters
         * onAutoPlayOffPressUp calls When Auto Play Off Button Clicked.
         * ON_STOP_AUTO_PLAY_CLICKED for sending request to wrapper to stop autoplay
         * SEND_NEXT_WIN_PRESENTATION_CALL will check if winmeter is ticking during autoplay stopped , if so
         * will call next win presentation.
         * isAutoplayActive variable is useed to handle gamble and close call on reel stop. In any autoplay spin, gamble won,t be enabled using this variable
         */
        protected onAutoPlayOffPressUp(): void {
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SlotConstants.AutoPlayOffBtnId);
            super.onAutoPlayOffPressUp();
            this.autoPlayBtn && (this.autoPlayBtn.visible = true);
            this.autoPlayOffBtn && (this.autoPlayOffBtn.visible = false);
            dispatcher.fireEvent(slotConstants.SlotEventConstants.ON_STOP_AUTO_PLAY_CLICKED);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_WIN_PRESENTATION_CALL);
        }

        /**
         * Override this function to add delay befor enabling all buttons when there is no win
         *
         * onShowSpinBtnHideStopBtn, below hides STOP btns and show SPIN btn to user
         * use when forcestop clicks or all Reels are stopped, coming back to STOP btn to SPIN btn
         * @param evt
         */
        protected onShowSpinBtnHideStopBtn(evt: IEvent): void {
            if (this.spinStopBtn) {
                this.spinStopBtn.visible = false;
                this.spinBtn.visible = true;
            }
            if (this.model.scatterWinData.length > 0) {
                this.spinBtn.disableAndTint();
            }
        }

        /**
         * disableConsoleButtons, for disable console buttons only
         */
        protected disableConsoleButtons(): void {
            this.spinBtn && (this.spinBtn.disableAndTint());
            this.autoPlayBtn && (this.autoPlayBtn.disableAndTint());
            this.settingButton && (this.settingButton.disableAndTint());
            this.infoBtn && (this.infoBtn.disableAndTint());
            this.maxBetBtn && (this.maxBetBtn.disableAndTint());
            this.betPlusBtn && (this.betPlusBtn.disableAndTint());
            this.betMinusBtn && (this.betMinusBtn.disableAndTint());
            if (this.turboBtnOff.visible === true) {
                this.turboBtnOff.disableAndTint();
            } else {
                this.turboBtnOn.disableAndTint();
            }
        }

        /**
         * enableConsoleButtons, for enable console buttons only
         */
        protected enableConsoleButtons(): void {
            this.spinBtn && (this.spinBtn.enableAndTint());
            this.autoPlayBtn && (this.autoPlayBtn.enableAndTint());
            this.settingButton && (this.settingButton.enableAndTint());
            this.infoBtn.enableAndTint();
            this.changeBetButtonStates(); // Max and Bet button enable accoding to `ArrayNumChips`
            if (this.turboBtnOff.visible === true) {
                this.turboBtnOff.enableAndTint();
            } else {
                this.turboBtnOn.enableAndTint();
            }
        }

        // /**
        //  * hidePopupsAndEnableConsoleButtons, for hide popups and enable console buttons only
        //  */
        // protected hidePopupsAndEnableConsoleButtons(): void {
        //     this.enableConsoleButtons();
        // }

        /**
         * Overrided to add functionality of enabling the buttons of bottom panel - common UI on 4th reel stop,
         * without any dependency of reel spinning for fastplay
         * @param {ingenuity.IEvent} evt
         */
        protected onEnableAllButtons(evt: IEvent): void {
            let btnId;
            for (btnId in this.view.getbuttonArray()) {
                if (this.view.getbuttonArray().hasOwnProperty(btnId)) {
                    (this.view.getbuttonArray()[btnId] as ui.ButtonBase).enableAndTint();
                }
            }
            if (this.model.getIsAutoPlayLeft()) {
                ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLE_BUTTON, this.settingBtn);
            }
            // dispatcher.fireEvent(uiConstants.eventConstants.ENABLED_BS_BOTTOM_PANEL);
            !configData.brokenOnClose && (configData.enableSpacebar = true);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_PLAYER_MSG);

            if (this.turboBtnOn.visible) {
                this.turboBtnOn.enableAndTint();
            } else {
                this.turboBtnOff.enableAndTint();
            }
            this.autoPlayBtn = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.AutoPlayBtnId) as ui.ButtonBase;
            this.changeBetButtonStates();
        }

        /**
         * Overrided to add functionality of disabling the buttons of bottom panel - common UI
         * @param evt
         */

        protected onDisabledAllButtons(evt?: IEvent) {
            super.onDisabledAllButtons(evt);
            configData.enableSpacebar = false;
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_STOP_PLAYER_MSG);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_PLAYER_MSG);
            // dispatcher.fireEvent(uiConstants.eventConstants.DISABLED_BS_BOTTOM_PANEL);

            if (this.turboBtnOn.visible) {
                this.turboBtnOn.disableAndTint();
            } else {
                this.turboBtnOff.disableAndTint();
            }

        }

        /**
         * onMaxBetPressUp, when Bet Max button is pressed in game
         * @param {ingenuity.ui.ButtonBase} btn
         */

        protected onMaxBetPressUp(btn?: ui.ButtonBase): void {
            dispatcher.fireEvent(events.EventConstants.BUTTON_RELESED, core.constructors.bsBehavior.SlotConstants.MaxBetBtn);
            parserModel.setCurrentBetIndex(parserModel.getArrayNumChips().length - 1);
            parserModel.setCurrentBet(parserModel.getArrayNumChips()[parserModel.getCurrentBetIndex()]);
            parserModel.setCurrentTotalBet(parserModel.getCurrentBet() * (parserModel.getCurrentNumPaylines()));
            dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.LOGIC_ONSTAKE_CHANGE);
            this.changeBetButtonStates();
            parserModel.setTotalWin(0);
        }

        /**
        * This Function is overrided.
       * This function enables/disables bet up/down buttons.
       */
        protected onChangeStake(value: number): void {
            if (value > 0) {
                this.model.getNextAvailableBet();
            } else {
                this.model.getPrevAvailableBet();
            }
            this.changeBetButtonStates();
            parserModel.setTotalWin(0);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.LOGIC_ONSTAKE_CHANGE);
        }

        /**
       * This function enables/disables bet up/down buttons.
       * This should be called every time a bet amount is changed.
       * This function also checks if max bet value is reached and enables/disables MAX_BET button accordingly.
       */
        protected changeBetButtonStates(): void {
            if (parserModel.getCurrentBetIndex() === 0) {
                this.betMinusBtn.disableAndTint();
            } else {
                this.betMinusBtn.enableAndTint();
            }

            if (parserModel.getCurrentBetIndex() === parserModel.getArrayNumChips().length - 1) {
                this.betPlusBtn.disableAndTint();
                this.maxBetBtn.disableAndTint();
            } else {
                this.betPlusBtn.enableAndTint();
                this.maxBetBtn.enableAndTint();
            }
        }

        /**
         * to add functionality of TurboOn Btn PressUp
         */
        protected onturboBtnOnPressUp(): void {
            this.suspendWinWhenButtonPressed();
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SoundConstant.TURBO_ENABLE_BTN);
            this.model.setIsTurboModeOn(true);
            configData.turboEnabled = true;
            this.turboBtnOn.visible = false;
            this.turboBtnOff.visible = true;
            this.turboBtnOff.enableAndTint();
        }

        /**
         * to add functionality of TurboOff Btn PressUp
         */
        protected onturboBtnOffPressUp(): void {
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SoundConstant.TURBO_DISABLE_BTN);
            this.model.setIsTurboModeOn(false);
            configData.turboEnabled = false;
            this.turboBtnOn.visible = true;
            this.turboBtnOff.visible = false;
            this.turboBtnOn.enableAndTint();
        }

        /**
         * to add functionality of Begining Freegame
         */

        protected startFreegame(): void {
            ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER);
            ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS);
            ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS);
            ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_BASEGAME_VIEW);
        }

        /**
         * overrided to enable force-stop by keyboard on enable stop button
         */
        protected onEnableStopBtn(evt: IEvent) {
            if (!this.spinStopBtn) {
                this.spinStopBtn = this.view.getButtonById(slotConstants.SlotConstants.SpinStopBtnId) as ui.ButtonBase;
            }
            if (parserModel.getIsSpinStopAvailable()) {
                if (!configData.turboEnabled) {
                    (this.spinStopBtn) && (
                        this.spinBtn.visible = false,
                        this.spinStopBtn.visible = true,
                        configData.enableSpacebar = true,
                        this.spinStopBtn.enableAndTint(),
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [slotConstants.SlotConstants.SpinStopBtnId])
                    );
                }
            }
            if (this.model.getIsAutoPlayLeft()) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.AutoPlayOffBtnId]);
            }
        }

        /**
         * to show Stopbutton
         */
        protected showStopBtn() {
            if (!this.spinStopBtn) {
                this.spinStopBtn = this.view.getButtonById(slotConstants.SlotConstants.SpinStopBtnId) as ui.ButtonBase;
            }
            if (parserModel.getIsSpinStopAvailable()) {
                if (!configData.turboEnabled) {
                    (this.spinStopBtn) && (
                        this.spinBtn.visible = false,
                        this.spinStopBtn.visible = true
                    );
                }
            }
        }

        /**
         * to show SpinButton
         */
        protected showSpinBtn() {
            if (!this.spinBtn) {
                this.spinBtn = this.view.getButtonById(slotConstants.SlotConstants.SpinBtnId) as ui.ButtonBase;
            }
            (this.spinBtn) && (
                this.spinBtn.visible = true,
                this.spinStopBtn.visible = false
            );
        }

        /**
         * overrided to implement the functionality of Infinity
         */
        protected setAutoPlayCounting(evt: IEvent): void {
            const val = evt.data;
            if (val === "∞") {
                this.model.setTotalAutoSpins(val);
            } else if (typeof (val) === "number") {
                this.model.setTotalAutoSpins(evt.data - 1);
            } else {
                this.model.setTotalAutoSpins(-1);
            }
        }

        /**
         * to disable autoplay button
         */
        protected onDisabledAutoPlayBtn(): void {
            (this.autoPlayBtn) && this.autoPlayBtn.disableAndTint();
        }

        /**
         * to hide spin stop button as per Compliance
         */
        protected hideSpinStopButton(): void {
            this.spinStopBtn.visible = false;
        }

        protected hideAutoplayButtons(): void {
            this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer).visible = false);
            this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer).alpha = 0);
            this.view.getImageById("AutoPlayOnBtnContainerglow") && (this.view.getImageById("AutoPlayOnBtnContainerglow").visible = false);
        }

        /**
         * to hide turbo buttons as per compliance
         */
        protected hideTurboButtons(): void {
            this.turboBtnOn && (this.turboBtnOn.visible = false);
            this.turboBtnOff && (this.turboBtnOff.visible = false);
            this.view.getImageById("turboModeEnableBtn_Bg") && (this.view.getImageById("turboModeEnableBtn_Bg").visible = false);
            this.view.getImageById("turboModeEnableBtnglow") && (this.view.getImageById("turboModeEnableBtnglow").visible = false);
        }

        /**
         * to toggle gamble buttons
         */
        protected toggleButtonStates(): void {
            this.gambleBtnBG.visible = true;
            this.gambleButton.visible = true,
            this.gambleButton.enableAndTint();
            this.collectButton.visible = true;
            this.collectButton.enableAndTint();
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.SpinBtnId]);
            this.startButtonToggling();
            this.gambleButton.onInputOver.add(this.restartGambleButtonToggling, this);
            this.collectButton.onInputOver.add(this.restartCollectButtonToggling, this);
        }

        /**
         * to start gamble buttons toggling
         */
        protected startButtonToggling(): void {
            this.gambleButton.toggleStates("Down", "Over", 500, this.gambleButton.name);
            this.collectButton.toggleStates("Over", "Down", 500, this.collectButton.name);
        }

        /**
         * to stop gamble buttons toggling
         */
        protected stopButtonToggling(): void {
            this.gambleButton.clearToggleState(this.gambleButton.name);
            this.collectButton.clearToggleState(this.collectButton.name);
        }

        /**
         * to stop gamble buttons toggling, if is in over state, and then on out, restart toggling
         */
        protected restartGambleButtonToggling(): void {
            this.stopButtonToggling();
            this.gambleButton.setFrame(this.gambleButton.json.frames.over, this.gambleButton.frameData);
            this.gambleButton.onInputOut.add(this.startButtonToggling, this);
        }

        /**
         * to stop gamble buttons toggling, if is in over state, and then on out, restart toggling
         */
        protected restartCollectButtonToggling(): void {
            this.stopButtonToggling();
            this.collectButton.setFrame(this.collectButton.json.frames.over, this.collectButton.frameData);
            this.collectButton.onInputOut.add(this.startButtonToggling, this);
        }

        /**
         * to stop gamble buttons toggling, when buttons pressed
         */
        protected resetGambleButtonsToggling(): void {
            this.gambleButton.clearToggleState(this.gambleButton.name);
            this.collectButton.clearToggleState(this.collectButton.name);
            this.gambleButton.onInputOver.remove(this.restartGambleButtonToggling, this);
            this.collectButton.onInputOver.remove(this.restartCollectButtonToggling, this);
            this.gambleButton.onInputOut.remove(this.startButtonToggling, this);
            this.collectButton.onInputOut.remove(this.startButtonToggling, this);
        }

        protected onAutoPlayButtonOff(): void {
            dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS, [ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnId]);
            this.view.getMeterById("autoPlayMeter") && (this.view.getMeterById("autoPlayMeter").visible = false);
            this.view.getButtonById("autoPlayOnButton") && (this.view.getButtonById("autoPlayOnButton").visible = true);
            this.view.getButtonById("autoPlayOnButton") && (this.view.getButtonById("autoPlayOnButton").alpha = 1);
            this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer).visible = true);
            this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer).alpha = 1);

            // hide Autoplay button as per compliance"
            !parserModel.getIsAutoPlayEnable() && this.hideAutoplayButtons();
        }

        protected onBetMinusPressUp(): void {
            super.onBetMinusPressUp();
            dispatcher.fireEvent(ingenuity.slot.slotConstants.aruze.SlotEventConstants.SET_BET);
        }

        protected onBetPlusPressUp(): void {
            super.onBetPlusPressUp();
            dispatcher.fireEvent(ingenuity.slot.slotConstants.aruze.SlotEventConstants.SET_BET);
        }

        protected enableAutoPlayFromWrapper(evt: any): void {
            if (parserModel.getIsAutoPlayEnable() === true) {
                if (parserModel.getIsAPRequired()) {
                    this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer).visible = true);
                    this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer).alpha = 1);
                } else {
                    this.hideAutoplayButtons();
                    this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnContainer).visible = false);
                    this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnContainer).alpha = 0);
                }
            } else {
                this.hideAutoplayButtons();
                this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnContainer).visible = false);
                this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOffBtnContainer).alpha = 0);
            }
        }


        /**
         * Suspend win while tikcup is running and anyone pressed Info or SettingBtn or
         * Autoplay or turboBtn
         */
        protected suspendWinWhenButtonPressed(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.STOP_SYMBOL_SOUND);
            !this.model.getIsBigWin() && dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.STOP_WIN_TICK_UP);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_WIN_ON_GAMBLE_START);
        }
    }
}
