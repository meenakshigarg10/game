///<reference path="../../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.BaseGame {

    export class BaseController extends slot.BaseGame.BaseController {
        protected view: View;
        protected playerMsgView: BehaviorCore.PlayerMsg.PlayerMsgView;
        protected playerMsgController: BehaviorCore.PlayerMsg.PlayerMsgController;
        protected model: Model;
        protected reelBg: ui.Bitmap;
        protected json: IObject;
        protected autoPlayArray: number[];
        protected reelPanelController: BehaviorCore.BaseGame.ReelPanelController;
        protected isSettingPanelVisible: boolean;
        protected bigSymbolController: bigSymbol.BigSymbolController;
        protected buttonContainer: ui.Container;
        protected balanceMeter: ui.MeterBitmap | ui.Meter;
        protected settingPannelController: SettingPannelController;
        protected settingPannelView: SettingPannelView;

        constructor(view: View, model: Model, json: any, assetManager: any) {
            super(view, model, json, assetManager);
            this.view = view;
            this.model = model;
            this.json = json;
            this.isSettingPanelVisible = false;
            this.reelBg = this.view.getImageById("reelBG");
            this.buttonContainer = this.view.getContainerByID("buttonsContainer");
            this.balanceMeter = this.view.getMeterById("creditValue");
        }

        /**
         * Override this function to subscribe other events which are not subscribed in super function
         */
        protected subscribeEvents(): void {
            super.subscribeEvents();

            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SUBSCRIBE_BASEGAME_EVENTS, this.subscribeEvents, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.SUBSCRIBE_BASEGAME_REELPANEL_EVENTS, this.subscribeReelPanelEvent, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS, this.unsubscribeReelPanelEvent, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.ACTIVATE_TURBO_MODE, this.activateTurboMode, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.DEACTIVATE_TURBO_MODE, this.deactivateTurboMode, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.ADD_SETTING_PANNEL, this.addSettingPannel, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.ADD_PLAYER_MSG_ON_TOP, this.addPlayerMsgOnTop, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, this.updateWinValue, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SET_WIN_VALUE_TO_DEFAULT, this.resetWinValue, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_WIN_METER_BEFORE_CLOSE_IN_BIGWIN, this.updateWinValue, this);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.UPDATE_CREDIT_VALUE, this.updateCreditValue, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ON_CHANGE_PLAYERMSG_PARENT, this.onChangePlayerMessageParent, this);
        }

        protected initializeReelPanelController(): void {
            this.reelPanelController = new ingenuity.core.constructors.bsBehavior.ReelPanelController(this.view, this.model);
        }

        /**
         * to add playermsgview in basegame
         */
        protected addPlayerMsgOnTop(): void {
            this.view.addChild(this.playerMsgView);
        }

        /**
         * to Initialize Reality Check implementations and console panel UI
         */
        protected addSettingPannel(): void {
            if (!this.settingPannelView || !this.settingPannelController) {
                this.settingPannelView = new ingenuity.core.constructors.bsBehavior.SettingPannelView(currentGame.cache.getJSON("main_data").SettingPannel);
                this.settingPannelController = new ingenuity.core.constructors.bsBehavior.SettingPannelController(this.settingPannelView);
                currentGame.stage.addChild(this.settingPannelView);
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_SETTING_PANNEL);
            } else {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_SETTING_PANNEL);
            }
        }

        /**
         * Returns the bet value multiplied by minimum bet of the game
         * @param betValue bet / chip value
         */
        protected multiplyMinBet(betValue: number): number {
            return betValue / ingenuity.configData.minBetMultiplier;
        }

        /**
         * Override this function to subscribe player messages in base game and update events dispathing sequence
         * Fire Events When Returning from free spin. Unsubscribe Free Game related Events and Subscribe Base Game related Events.
         */

        protected onFreeGamereturning(evt: IEvent): void {
            dispatcher.fireEvent(slotConstants.SlotEventConstants.SUBSCRIBE_PLAYER_MESSAGES);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_BG_MODEL);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_BASEGAME_WIN_PRESENTATION_EVENTS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START_BG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_BUTTON_CONTROLLERS_FG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SCBSCRIBE_BUTTON_CONTROLLERS_BG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_FREEGAME_VIEW);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ON_RETURNING_FG_UPDATE_METER);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.RESET_BG);
        }

        /**
         * Override for initialize behavior WinPresentationController
         */
        protected initializeWinPresentationController(): void {
            this.winPresentationController = new ingenuity.core.constructors.bsBehavior.WinPresentationController(this.view, this.model) as slot.BaseGame.WinPresentationController;
        }

        /**
         * Override for initialize behavior ButtonController
         */
        protected initializeButtonController(): void {
            this.buttonController = new ingenuity.core.constructors.bsBehavior.ButtonController(this.view, this.model);
        }

        /**
         * Override for initialize behavior MeterController
         */
        protected initializeMeterController(): void {
            this.meterController = new ingenuity.core.constructors.bsBehavior.MetersController(this.view, this.model);
        }

        /**
         * initializePlayerMsgController, initialize player msg controller
         * to add playermssg in basegame view in mobile portrait. for all other modes, add it on stage.
         */
        protected initializePlayerMsgController(): void {
            this.playerMsgView = new core.constructors.bsBehavior.PlayerMsgView(this.json.playerMsg);
            this.playerMsgController = new core.constructors.bsBehavior.PlayerMsgController(this.playerMsgView, this.model, this.json.playerMsg, this.assets);
            if (deviceEnv.isDesktop) {
                this.buttonContainer.addChild(this.playerMsgView);
            } else {
                this.view.addChild(this.view.getContainerByID("PortraitplayerMsgContainer"));
                this.view.getContainerByID("PortraitplayerMsgContainer").addChild(this.playerMsgView);
            }
        }


        /**
         * to make basegame visible with fade in effect and change background only if autoplay is not running
         */
        protected onShowBaseGame(evt: IEvent): void {
            this.view.getContainerByID("buttonsContainer").visible = true;
            this.view.visible = true;
            this.view.show();
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CHANGE_BACKGROUND, BehaviorCore.slotConstants.SlotConstants.BASEGAME_BG_SHOW);
            this.showBasegameWithAlphaTween();
        }

        protected onHideBaseGame(): void {
            this.view.getContainerByID("portraitButtonsContainer") && (this.view.getContainerByID("portraitButtonsContainer").visible = false);
            this.view.getContainerByID("buttonsContainer").visible = false;
            this.view.visible = false;
        }

        /**
         * Method shows base game view with fade in effect
         *
         */
        protected showBasegameWithAlphaTween(): void {
            this.view.alpha = 0.2;
            const baseGameFadeIn: bridge.ITween = currentGame.add.tween(this.view).to({ alpha: 1 }, ingenuity.BehaviorCore.slotConstants.SlotConstants.BASE_GAME_FADE_IN_TIME, undefined, true);
            baseGameFadeIn.onComplete.add(() => {
                baseGameFadeIn.stop();
                currentGame.tweens.remove(baseGameFadeIn);
                (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) && this.view.onShowPortraitButtonpanel();
                this.view.getContainerByID("portraitButtonsContainer") && (this.view.getContainerByID("portraitButtonsContainer").visible = true);
            }, this);
        }


        /**
         * to implement turbo mode fuctionality
         */
        protected activateTurboMode(): void {
            this.model.setIsTurboModeOn(true);
            this.view.getImageById("turboModeImg").visible = true;
        }

        /**
         * removes turbo mode fuctionality
         */
        protected deactivateTurboMode(): void {
            this.model.setIsTurboModeOn(false);
            this.view.getImageById("turboModeImg").visible = false;
        }

        /**
         * Subscribe reel panel events
         */
        protected subscribeReelPanelEvent(): void {
            this.view.getReelView().on(slot.slotConstants.SlotEventConstants.SPIN_COMPLETE, this.onSpinComplete, this);
            dispatcher.on(events.EventConstants.STOP_SOUND, this.onStopSound);
            dispatcher.on(events.EventConstants.PLAY_SOUND, this.onPlaySound);
            dispatcher.on(events.EventConstants.BUTTON_RELESED, this.onButtonRelesed);
            this.view.getReelView().on(slot.slotConstants.SlotEventConstants.REEL_STOPPING, this.onReelStopping, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.PLAY_SYMBOL_SOUND, this.playSymbolSound, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.STOP_SYMBOL_SOUND, this.stopSymbolSound, this);
        }

        /**
         * Unsubscribe reel panel events
         */
        protected unsubscribeReelPanelEvent(): void {
            this.view.getReelView().off(slot.slotConstants.SlotEventConstants.SPIN_COMPLETE, this.onSpinComplete);
            dispatcher.off(events.EventConstants.STOP_SOUND, this.onStopSound);
            dispatcher.off(events.EventConstants.PLAY_SOUND, this.onPlaySound);
            dispatcher.off(events.EventConstants.BUTTON_RELESED, this.onButtonRelesed);
            this.view.getReelView().off(slot.slotConstants.SlotEventConstants.REEL_STOPPING, this.onReelStopping);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.PLAY_SYMBOL_SOUND, this.playSymbolSound, this);
        }

        protected stopSymbolSound(e?: IEvent): void {
            //
         }

        protected onReelStopping(e?: number): void {
           //
        }


        protected onButtonRelesed(e: IEvent): void {
            //
        }

        protected onPlaySound(e: IEvent): void {
            //
        }

        /**
         * onInitializeAllControllers override to play background sound on initilizing game
         * @param {ingenuity.IEvent} evt
         */
        protected onInitializeAllControllers(evt: IEvent): void {
            this.initializeButtonController();
            this.initializePlayerMsgController();
            this.initializeMeterController();
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_REEL_PANEL_CONTROLLER, this.initializeReelPanelController, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_WIN_PRESENTATION_CONTROLLER, this.initializeWinPresentationController, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SET_GAME_BET_TYPE, this.setGameBetType, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.STOP_AUTOPLAY_BY_WRAPPER, this.autoPlayStopByWrapper, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.JP_METER_DATA_PARSED, this.updateJackpotMeters, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_JP_METERS, this.sendJackpotMetersUpdationRequest, this);
            if (BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID && BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID.length > 0) {
                this.initializeBigSymbolController();
            }
        }

        protected initializeBigSymbolController(): void {
            this.bigSymbolController = new core.constructors.bsBehavior.BigSymbolController(this.view, this.model, this.view.getReelView());
        }

        public setGameBetType(): void {
            this.model.setBetType("BG");
        }


        /**
         * To stop meter tickup and 5OAK sound
         * @param {ingenuity.IEvent} e
         */
        protected onStopSound(e: IEvent): void {
           //
        }

        /**
         * To handle things in spin complete
         * @param {ingenuity.IEvent} e
         */
        protected onSpinComplete(e?: IEvent): void {
            soundManager.stop(core.constructors.bsBehavior.SoundConstants.REEL_SPIN1);
        }

        /**
         * To play symbol specific sound
         * @param {ingenuity.IEvent} e
         */
        protected playSymbolSound(e?: IEvent): void {
            //
        }
        /*
        * If Autoplay is suspend by wrapper due to win limit or loss limit below function will act as callback  at our end
        * Win presentation should suspend if win limit or loss limit reached
        */
        protected autoPlayStopByWrapper(): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.AUTOPLAY_RESET);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.AUTOPLAY_RESET_ENABLE_BUTTONS);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_FEATURE_AFTER_WIN_LIMIT_POPUP);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION);
            const autoPlayBtn: ui.ButtonBase = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.AutoPlayBtnId) as ui.ButtonBase;
            const autoPlayOffBtn: ui.ButtonBase = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.AutoPlayOffBtnId) as ui.ButtonBase;
            autoPlayBtn && (autoPlayBtn.visible = true);
            autoPlayOffBtn && (autoPlayOffBtn.visible = false);
        }

        /**
         * to Update Win Value on win presentation is over
         */
        protected updateWinValue(evt: IEvent): void {
            const winValueObject: IObject = evt.data;
            const winValue: string = winValueObject.value;
            this.view.setWinValue(winValue, true);
            /**
            * check is added to end history on freegame returning, no win scenario.
            */
            if (configData.freegameReturning && parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE && currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState && !configData.endReqSent) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END);
            }
        }

        /**
         * to reset Win Value in new game
         */
        protected resetWinValue(): void {
            this.view.setWinValue(BehaviorCore.slotConstants.SlotConstants.RESET_WIN_VLAUE, true);
        }

        protected updateCreditValue(evt: IEvent): void {
            let balanceValueObj: IObject = evt.data;
            let balanceValue = balanceValueObj.value;
            this.balanceMeter.setCurrencyFormattedValue(balanceValue.toString());
        }

        /**
         * update JP meters in basegame on response received ad JP feature meters too
         */
        protected updateJackpotMeters(): void {
            //
        }

        /**
         * send request to update jackpot meters in basegame and in Jackpot feature. Send periodically
         * to show JP meter updation continuously
         */
        protected sendJackpotMetersUpdationRequest(): void {
            //
        }

        /**in mobile portrait , playermssgs are added in basegameview to show it below reelbg
         * whereas in all other modes player mssgs are added on stage
         */
        protected onChangePlayerMessageParent(): void {
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                this.buttonContainer && this.playerMsgView && this.buttonContainer.addChild(this.playerMsgView);
            } else {
                if (this.view.getContainerByID("PortraitplayerMsgContainer") && this.playerMsgView) {
                    this.view.addChild(this.view.getContainerByID("PortraitplayerMsgContainer"));
                    this.view.getContainerByID("PortraitplayerMsgContainer").addChild(this.playerMsgView);
                }
            }
        }
    }
}
