///<reference path="../../../Interfaces.ts" />
/***
 * Override this class for update the win presentation behavior according to Pocker stars
 * Purpose of this class to Controll All Win Presenatation activities running in game
 */

namespace ingenuity.BehaviorCore.BaseGame {
    export class WinPresentationController extends slot.BaseGame.WinPresentationController {
        protected model: Model; // model requires to access data to make decision for game behavior
        protected view: View;
        protected fiveofkindanimation: ui.AnimationBase;
        public symbolSoundArray: number[] = [];

        /**
         * below function subscribed events used to controll WinPresentation
         */
        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.CHECK_BIG_WIN, this.checkBigWin, this);
            dispatcher.on(slotConstants.SlotEventConstants.BIG_WIN_COMPLETE, this.onBigWinComplete, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.EXECUTE_CALL_BACK, this.executeCallback, this);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.BEGIN_STAGE_CLICK, this.beginStageClick, this);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.DISABLE_STAGE_CLICK, this.disableStageClick, this);
            dispatcher.on(ingenuity.slot.slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI, this.onHideAllSpagetti, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_WIN_ON_GAMBLE_START, this.suspendWinOnGambleStart, this);
        }

        /**
         * Override this function to unsubscribe SCATTER_ANIMATION_ENDED event
         *
         * below function unsubscribed events used to controll WinPresentation
         */
        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(slot.slotConstants.SlotEventConstants.SCATTER_ANIMATION_ENDED, this.onScatterAnimationEnd);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.CHECK_BIG_WIN, this.checkBigWin, this);
            dispatcher.off(slotConstants.SlotEventConstants.BIG_WIN_COMPLETE, this.onBigWinComplete, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.EXECUTE_CALL_BACK, this.executeCallback, this);
            dispatcher.off(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.BEGIN_STAGE_CLICK, this.beginStageClick, this);
            dispatcher.off(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.DISABLE_STAGE_CLICK, this.disableStageClick, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_WIN_ON_GAMBLE_START, this.suspendWinOnGambleStart, this);
        }

        /**
         * It is handler function of STAGE_CLICKED which is fire from BackgroundView as stage click.
         * @param {ingenuity.IEvent} evt
         */
        protected onStageClicked(evt: IEvent): void {
            if (configData.enableStageClick) {
                if (configData.isAutoplayActive) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLE_BUTTON, [slotConstants.SlotConstants.SpinBtnId]);
                }
                if (this.model.getIsBigWinRunning()) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN);
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.CLEAR_BIG_WIN);
                }
                configData.enableStageClick = false;
            }
            if (configData.enableStageClickOnFirstToggle) {
                if (this.paylineView) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_ALL_FRAMES);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_ALL_WIN_PAYLINE);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.STOP_METER_TICKUP);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.STOP_SYMBOL_SOUND);
                    soundManager.stop(this.model.getWinMeterTickUpSound());
                }
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATIONS);
                dispatcher.off(slot.slotConstants.SlotEventConstants.WIN_CYCLE_COMPLETED, this.onWinCycleCompleted);
                configData.stopWinAnimOnSecondToggle = true;
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_STAGE_CLICK_PLAYER_MSG);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                configData.enableStageClickOnFirstToggle = false;
                configData.stopWinAnimOnSecondToggle = false;
            }
        }

        /**
         * Override this function to get toggling started
         * listened when First Toggle Cycle Presentation Starts in Game
         * @param evt
         */
        protected onStartFirstToggleCycle(evt: IEvent): void {
            super.onStartFirstToggleCycle(evt);
            this.reelView.setToggleingContinue(true);
        }

        /**
         *
         */
        protected onShowAllFrames(evt: IEvent): void {
            // to-do: write code here to show win frames on spaghtti
            const windata = ingenuity.parserModel.getLinesWinAllUniquePositions();
            if (ingenuity.configData.animatedLineWinFrames !== undefined && !ingenuity.configData.animatedLineWinFrames) {
                soundManager.playSound(core.constructors.bsBehavior.SlotConstants.LINE_WIN); // in case of not win frame animation in Line games
            }
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_BASEGAME_WIN_ALPHA, windata);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA_ON_SYMBOL, windata);
            if (this.paylineView) {
                this.view.addChild(this.view.getMeterById("winMtr")); // to bring winmeter on top of win frames
                if (this.model.getIsAutoPlayLeft() && !this.model.getIsBigWin() && !this.model.getIsScatterWins()) {
                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_ALL_FRAMES, {
                        callback() {
                            //
                        },
                        callbackScope: this,
                        delayTimer: this.model.getDelayForSpaghttiDispaly(),
                        winData: windata
                    });
                } else if (parserModel.getHasLineWins()) {
                    if (this.model.getIsScatterWins()) {
                        dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_ALL_FRAMES, {
                            callback() {
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.HIDE_ALL_FRAMES);
                                if (this.model.getIsAutoPlayLeft()) {
                                    this.model.setAnimationSequenceCounter(this.model.getAnimationSequence().length - BehaviorCore.slotConstants.SlotConstants.RESET_TO_TRIGGERING_ANIMATION);
                                }
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                            },
                            callbackScope: this,
                            delayTimer: this.model.getDelayForSpaghttiDispaly(),
                            winData: windata
                        });
                    } else {
                        dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_ALL_FRAMES, {
                            callback() {
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.HIDE_ALL_FRAMES);
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                            },
                            callbackScope: this,
                            delayTimer: this.model.getDelayForSpaghttiDispaly(),
                            winData: windata
                        });
                    }
                } else {
                    if (this.model.getIsScatterWins()) {
                        if (this.model.getIsAutoPlayLeft()) {
                            this.model.setAnimationSequenceCounter(this.model.getAnimationSequence().length - BehaviorCore.slotConstants.SlotConstants.RESET_TO_TRIGGERING_ANIMATION);
                        }
                        dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                    }
                }
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
            }

            if (ingenuity.configData.playAllSymbolAnim) {
                dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.PLAY_ALL_SYMBOL_ANIM);
            }
        }

        /**
         * to execute callback functions
         */
        protected executeCallback(evt: IEvent): void {
            let callback;
            let callbackScope = this;
            let delayTimer;
            if (typeof evt === "function") {
                callback = evt;
            } else if (evt.data) {
                callback = evt.data.callback;
                callbackScope = evt.data.callbackScope;
                delayTimer = evt.data.delayTimer;
            }
            (typeof callback === "function") && (ingenuity.utils.delayedCall(slot.slotConstants.SlotConstants.SpaghettiDisplayTimer, delayTimer, callback, callbackScope));
        }

        /**
         * Overtide this function to play symbol sound
         * listened when Every Line Animation in game Ends
         * stop after a cycle of first toggle completes
         * @param evt
         */
        protected onLineAnimStarted(evt: IEvent): void {
            if (!(this.view.getWinReelView() as BehaviorCore.reelPanel.WinPresentationPanel).oneToggleCompletes) {
                this.playSymbolSound(evt.data.no);
            }
        }

        /**
         * Play symbol sound.
         * play symbol sound once per symbol.
         * @param {ingenuity.slot.reelPanel.Icon} Icon
         */
        protected playSymbolSound(sym: number): void {
            let symbolLineCount: number = 0;
            this.symbolSoundArray.push(sym);
            this.symbolSoundArray.forEach((value: number) => {
                (value === sym) && (symbolLineCount++);
            }, this);
            if (symbolLineCount === 1 && !configData.stopSymbolSound) {
                dispatcher.fireEvent(slotConstants.SlotEventConstants.PLAY_SYMBOL_SOUND, sym);
            }
        }

        /**
         * Override this function to show next win presentation
         * @param {ingenuity.IEvent} evt
         */
        protected onHide5OAK(evt: IEvent): void {
            ingenuity.utils.delayedCall("showNextAfter5OfKind", 1000, () => {
                utils.killDelayedCall("showNextAfter5OfKind");
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
            }, this);

        }

        /**
         * Override this function to subscribe LINE_ANIMATION_STARTED event
         *
         * When Reel Spinning Start below function subscribes events for Win Presentation
         * @param evt
         */
        protected onReelStartSubscribeEvents(evt: IEvent): void {
            super.onReelStartSubscribeEvents(evt);
            dispatcher.on(slot.slotConstants.SlotEventConstants.LINE_ANIMATION_STARTED, this.onLineAnimStarted, this);
        }

        /**
         * Override this function to unsubscribe LINE_ANIMATION_STARTED event
         *
         * below stops all running Win Animation in game
         */
        protected onStopAllWinAnimation(): void {
            super.onStopAllWinAnimation();
            // dispatcher.off(slot.slotConstants.SlotEventConstants.LINE_ANIMATION_STARTED, this.onLineAnimStarted);
        }

        /**
         * Override this function to update behavior after big win complete
         * listened to configure Big_WIN_HIDE onReelStartSubscribeEventsevent at the time of Big Win Starts
         */
        protected cofigureEventOnBigWinHide(): void {
            dispatcher.on(slot.slotConstants.SlotEventConstants.BIG_WIN_HIDDEN, this.afterHideBigWin, this, true);
        }

        /**
         * call next win presentation after big win hide
         */
        protected afterHideBigWin(): void {
            dispatcher.fireEvent(slotConstants.SlotEventConstants.AFTER_HIDE_BIG_WIN);
        }

        /**
         * to check bigwin status from basegame model
         */
        public checkBigWin(): boolean {
            const bigWinValue = this.model.getIsBigWin();
            if (bigWinValue > 0 && bigWinValue <= 3) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * to handle the events on ending the bigwin tickup
         */
        protected onStandardTickupEndBeforeBigWin(): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
        }

        /**
         *
         */
        protected onBigWinComplete(): void {
            ingenuity.configData.enableStageClick = false;
            dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.DISABLE_STAGE_CLICK);
            if (!configData.freegameReturning) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
            }
        }

        /**
         * Overrided to make First Toggle cyclic
         */
        protected onStartFirstToggleCycleWays(evt: IEvent) {
            this.reelView.setAnimateSymbol(true);
            if (parserModel.getHasFreeGamesWin() || this.model.getIsAutoPlayLeft()) {
                this.reelView.setToggleingContinue(false);
            } else {
                this.reelView.setToggleingContinue(true);
            }
            this.reelView.WIN_LINE_ANIM_TIMEOUT = BehaviorCore.slotConstants.SlotConstants.WIN_LINE_ANIM_TIMEOUT;
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.START_WAYS_ANIM, this.model.getWaysWinData());
        }


        protected onSuspendWinPresentation(): void {
            if (this.paylineView) {
                if (this.model.getIsWin()) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI);
                }
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_ALL_FRAMES);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_ALL_WIN_PAYLINE);
            }
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_DATA);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATIONS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.RESET_METERS);
            dispatcher.fireEvent(slotConstants.SlotEventConstants.HIDE_TOTAL_WIN_MSG);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_WIN_TOGGLE_PLAYER_MSG);
            // to empty symbol sound array- that keeps the record whether a symbol win has occured previously
            this.symbolSoundArray = [];
            if (ingenuity.configData.playAllSymbolAnim) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.STOP_ALL_SYMBOL_ANIM);
            }
        }

        protected suspendWinOnGambleStart(): void {
            if (this.paylineView) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_ALL_FRAMES);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_ALL_WIN_PAYLINE);
            }
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATIONS);
            dispatcher.fireEvent(slotConstants.SlotEventConstants.HIDE_TOTAL_WIN_MSG);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_WIN_TOGGLE_PLAYER_MSG);
            // to empty symbol sound array- that keeps the record whether a symbol win has occured previously
            this.symbolSoundArray = [];
            if (ingenuity.configData.playAllSymbolAnim) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.STOP_ALL_SYMBOL_ANIM);
            }
        }
        /**
         * Show free game in Broken
         */
        protected brokenHandle(): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED);
        }

        /**
         * to add center tickup presentation on top of all presentations in reel panel during win
         */
        protected addCenterTickupPresentationOnTop(): void {
            //  cv
        }

        /**
         * to start stageclick
         */

        protected beginStageClick(): void {
            currentGame.input.onDown.add(this.onStageClicked, this);
        }

        /**
         * to end the stage click
         */
        protected disableStageClick(): void {
            currentGame.input.onDown.remove(this.onStageClicked, this);
        }

        /**
         *
         * @param evt in case of autoplay, spagetti will be kept on hold, and will be hidden only once winmeter tickup comppletes
         * Autoplay: in case of triggering , hide spagetti and show triggering
         * otherwise will work normally
         *
         */
        protected onShowSpaghtti(evt: IEvent) {
            if (this.paylineView) {
                const windata: IWinLineObject[] = parserModel.getLinesWinAllUniquePositions();
                ingenuity.dispatcher.fireEvent(ingenuity.core.constructors.bsBehavior.SlotEventConstants.SHOW_BASEGAME_WIN_ALPHA, windata);
                ingenuity.dispatcher.fireEvent(ingenuity.core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA_ON_SYMBOL, windata);
                if (this.model.getIsAutoPlayLeft() && !this.model.getIsBigWin() && !this.model.getIsScatterWins()) {
                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_SPAGETTI, (): void => {
                        //
                    });
                    utils.killDelayedCall(slot.slotConstants.SlotConstants.SpaghettiDisplayTimer);
                } else if (parserModel.getHasLineWins()) {
                    if (this.model.getIsScatterWins()) {
                        dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_SPAGETTI, {
                            callback() {
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI);
                                if (this.model.getIsAutoPlayLeft()) {
                                    this.model.setAnimationSequenceCounter(this.model.getAnimationSequence().length - BehaviorCore.slotConstants.SlotConstants.RESET_TO_TRIGGERING_ANIMATION);
                                }
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                            },
                            callbackScope: this,
                            delayTimer: this.model.getDelayForSpaghttiDispaly()
                        });
                    } else {
                        dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_SPAGETTI, {
                            callback() {
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.HIDE_ALL_SPAGETTI);
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                            },
                            callbackScope: this,
                            delayTimer: this.model.getDelayForSpaghttiDispaly()
                        });
                    }
                } else {
                    if (this.model.getIsScatterWins()) {
                        if (this.model.getIsAutoPlayLeft()) {
                            this.model.setAnimationSequenceCounter(this.model.getAnimationSequence().length - BehaviorCore.slotConstants.SlotConstants.RESET_TO_TRIGGERING_ANIMATION);
                        }
                        dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                    }
                }
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
            }
            if (ingenuity.configData.playAllSymbolAnim) {
                dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.PLAY_ALL_SYMBOL_ANIM);
            }
        }
        protected onHideAllSpagetti(evt: IEvent) {
            //
        }

        protected onStartBigWinPresentation(evt: IEvent) {
            this.cofigureEventOnBigWinHide();
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_BIG_WIN, {
                view: this.view,
                type: this.model.getIsBigWin(),
                win: this.model.getCurrentWinAmt()
            });
        }

        /**
         * intentionally kept empty, to stop extra autoplay erequest in fg+autoplay
         */
        protected onScatterAnimationEnd(): void {
            //
        }
    }
}
