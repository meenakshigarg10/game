///<reference path="../../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.BaseGame {
    export class Model extends slot.BaseGame.Model {

        protected isAnyFeature: boolean = false;
        protected isSpinClicked: boolean = false;
        protected isReelSpinningInAutoPlay: boolean = false;
        protected isBigWinRunning: boolean = false;
        protected isBigWinLoaded: boolean = false;
        protected reelSpinning: boolean = false;
        protected isJackportAvailable: boolean = false;
        protected isFreePlayModeOn: boolean = false;
        protected anticipationArray: number[] = [0, 0, 0, 0, 0];
        protected serverModel: ingenuity.platform.aruze.Model;
        protected balance: number = 0;

        constructor(serverModel: ingenuity.platform.aruze.Model) {
            super(serverModel);
            if (ingenuity.configData.animatedLineWinFrames !== undefined && ingenuity.configData.animatedLineWinFrames) {
                this.setAnimationSequence(["showAllFrames", "bigWin", "firstToggle", "triggeringAnimation", "freeSpin", "checkForAutoplay"]);
            } else {
                this.setAnimationSequence(["Spaghtti", "bigWin", "firstToggle", "triggeringAnimation", "freeSpin", "checkForAutoplay"]);
            }
            this.setTickUpDuration(slotConstants.SlotConstants.WinTickUpDuration);
            this.setFiveOfAKindDisplayTime(slotConstants.SlotConstants.FiveOfAKindDisplayTime);
            this.setDelayForSpaghttiDispaly(slotConstants.SlotConstants.setDelayForSpaghettiDispaly);
        }

        /**
         * get selected line
         * @return {any | number}
         */
        public getSelectedLines(): number | number[] {
            return this.serverModel.getSelectedLines();
        }

        /**
         * set current bet
         * @param {number} value
         */
        public setCurrentBet(value: number): void {
            this.serverModel.setCurrentBet(value);
        }

        public getCurrentPayLines(): number {
            return this.serverModel.getCurrentNumPaylines();

        }

        /**
         * set current bet index
         * @param {number} value
         */
        public setCurrentBetIndex(value: number): void {
            this.serverModel.setCurrentBetIndex(value);
        }

        /**
         * set total bet
         * @param {number} value
         */
        public setCurrentTotalBet(value: number): void {
            this.serverModel.setCurrentTotalBet(value);
        }

        /**
         * Set max bet for next spin
         */
        public setMaxBetForSpin(): void {
            this.serverModel.setCurrentBetIndex(this.serverModel.getAllowBetOptions().length - 1);
            this.serverModel.setCurrentBet(this.serverModel.getAllowBetOptions()[this.serverModel.getCurrentBetIndex()]);
            const selectedLines: number = this.serverModel.getSelectedLines() as number;
            this.serverModel.setCurrentTotalBet(this.serverModel.getCurrentBet() * selectedLines);
        }

        /**
         * get is scatter trigger or not
         */
        public getHasScatterWins(): boolean {
            return this.serverModel.getHasScatterWins();
        }

        /**
         * getter for any Feature triggered
         * @returns {boolean}
         */
        public getIsSpinClicked(): boolean {
            return this.isSpinClicked;
        }

        /**
         * setter for any feature triggered
         * @param value {boolean}
         */
        public setIsSpinClicked(value: boolean): void {
            this.isSpinClicked = value;
        }

        /**
         * setter for auto play start
         * @param value {boolean}
         */
        public setIsReelSpinningInAutoPlay(value: boolean): void {
            this.isReelSpinningInAutoPlay = value;
        }

        /**
         * getter for auto play start
         * @return {boolean}
         */
        public getIsReelSpinningInAutoPlay(): boolean {
            return this.isReelSpinningInAutoPlay;
        }

        /**
         * set big win is running
         * @param value {boolean}
         */
        public setIsBigWinRunning(value: boolean): void {
            this.isBigWinRunning = value;
        }

        public setIsBigWinLoaded(value: boolean): void {
            this.isBigWinLoaded = value;
        }

        /**
         * get is big win running or not
         * @return {boolean}
         */
        public getIsBigWinRunning(): boolean {
            return this.isBigWinRunning;
        }

        /**
         * getter for current bet index
         * @returns {number}
         */
        public getCurrentBetIndex(): number {
            return this.serverModel.getCurrentBetIndex();
        }

        /**
         * getter for allow bet option length
         * @returns {number}
         */
        public getAllowBetOptionLength(): number {
            return this.serverModel.getAllowBetOptions().length;
        }

        /**
         * Override this function to update this.serverModel.getTotalWin() from this.serverModel.getTotalWin()
         *
         * getIsBigWin, returns is Big Win available or not in game.
         * @returns {number} returns a number 0 means no big win, a higher number means a bigger win.
         *      1 means big win @ 20 times more

         */
        public getIsBigWin(winAmount?: number): number {
            let win: number = parserModel.getGameWinAmt();
            if (winAmount !== undefined) {
                win = winAmount;
            }
            const currBet = this.serverModel.getCurrentTotalBet();
            if (win >= currBet * 45) {
                return 3;
            } else if (win >= currBet * 20) {
                return 2;
            } else if (win >= currBet * 10) {
                return 1;
            } else {
                return 0;
            }
        }

        public getIsBigWinLoaded(): number {
            if (this.isBigWinLoaded === false) {
                return 0;
            } else {
                return 1;
            }
        }

        /**
        * This function get free spins remaining from server model.
       */
        public getFreeSpinsRemaining(): number {
            return this.serverModel.getFreeSpinsRemaining();
        }

        /**
         * This function get action from server model.
        */
        public getAction(): string {
            return this.serverModel.getAction();
        }

        /**
         * This function get is reel spinning
         */
        public getIsReelSpinning(): boolean {
            return this.reelSpinning;
        }

        /**
         * This function set is reel spinning
         * @param value
         */
        public setIsReelSpinning(value: boolean): void {
            this.reelSpinning = value;
        }

        /**
         * Getter method to detect if FreePlay mode is on or Not
         * @returns - Boolean
         */
        public getFreePlayModeOn(): boolean {
            return this.serverModel.getFreePlayModeOn();
        }

        /**
        * Setter method to set if FreePlay mode is on or Not
        * @param - boolean
        */
        public setFreePlayModeOn(bool: boolean): void {
            this.serverModel.setFreePlayModeOn(bool);
        }

        public setReelGrid(value: number[][]): void {
            this.serverModel.setReelGrid(value);
        }

        /**
         * to get/set anticipation value in basegame
         */
        public getAnticipationArray(): number[] {
            return this.anticipationArray;
        }
        /**
         * Update anticipation array
         */
        public setAnticipationArray(value: number[]): void {
            this.anticipationArray = value;
        }


        public getIsWin(): boolean {
            return (this.serverModel.getHasWin() || (this.serverModel.getTriggerScatterWinData().length > 0 && this.serverModel.getTriggerScatterWinData()[0].win > 0));
        }

        /**
         * overrided to implement autoplay functionality
         */
        public getIsAutoPlayLeft(): boolean {
            if (this.totalAutoSpins.toString() === "∞") {
                return true;
            } else if (typeof (this.totalAutoSpins)) {
                return (this.currentAutoSpinIndex <= this.totalAutoSpins);
            } else {
                return false;
            }
        }

        public setAnimationSequenceCounter(value: number) {
            this.animationSequenceCounter = value;
        }

        /**
         * to get multiple winmeter tickup durations as per tickup sounds
         */
        public getWinMeterTickUpDuration(evt?: number): number {
            const winAmount: number = evt ? evt : parserModel.getGameWinAmt();
            if (this.getIsBigWin() && !this.getIsScatterWins()) {
                if (winAmount >= this.getTotalBet() * 10 && winAmount < this.getTotalBet() * 12) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_18;
                } else if (winAmount >= this.getTotalBet() * 12 && winAmount < this.getTotalBet() * 15) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_19;
                } else if (winAmount >= this.getTotalBet() * 15 && winAmount < this.getTotalBet() * 20) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_20;
                } else if (winAmount >= this.getTotalBet() * 20 && winAmount < this.getTotalBet() * 30) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_21;
                } else if (winAmount >= this.getTotalBet() * 30 && winAmount < this.getTotalBet() * 40) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_22;
                } else if (winAmount >= this.getTotalBet() * 40 && winAmount < this.getTotalBet() * 50) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_23;
                } else if (winAmount >= this.getTotalBet() * 50) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_24;
                }
            } else if (this.getIsTurboModeOn() && !this.getIsScatterWins()) {
                if (winAmount < this.getTotalBet() * 10) {
                    return core.constructors.bsBehavior.SlotConstants.WINTICKUP_4;
                }
            } else if (this.getIsScatterWins()) {
                return core.constructors.bsBehavior.SlotConstants.WINTICKUP_1;
            } else {
                if (winAmount < this.getTotalBet() * 0.1) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_1;
                } else if (winAmount >= this.getTotalBet() * 0.1 && winAmount < this.getTotalBet() * 0.2) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_2;
                } else if (winAmount >= this.getTotalBet() * 0.2 && winAmount < this.getTotalBet() * 0.3) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_3;
                } else if (winAmount >= this.getTotalBet() * 0.3 && winAmount < this.getTotalBet() * 0.4) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_4;
                } else if (winAmount >= this.getTotalBet() * 0.4 && winAmount < this.getTotalBet() * 0.5) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_5;
                } else if (winAmount >= this.getTotalBet() * 0.5 && winAmount < this.getTotalBet() * 0.75) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_6;
                } else if (winAmount >= this.getTotalBet() * 0.75 && winAmount < this.getTotalBet() * 1) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_7;
                } else if (winAmount >= this.getTotalBet() * 1 && winAmount < this.getTotalBet() * 1.25) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_8;
                } else if (winAmount >= this.getTotalBet() * 1.25 && winAmount < this.getTotalBet() * 1.5) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_9;
                } else if (winAmount >= this.getTotalBet() * 1.5 && winAmount < this.getTotalBet() * 2) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_10;
                } else if (winAmount >= this.getTotalBet() * 2 && winAmount < this.getTotalBet() * 3) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_11;
                } else if (winAmount >= this.getTotalBet() * 3 && winAmount < this.getTotalBet() * 4) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_12;
                } else if (winAmount >= this.getTotalBet() * 4 && winAmount < this.getTotalBet() * 5) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_13;
                } else if (winAmount >= this.getTotalBet() * 5 && winAmount < this.getTotalBet() * 6) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_14;
                } else if (winAmount >= this.getTotalBet() * 6 && winAmount < this.getTotalBet() * 7) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_15;
                } else if (winAmount >= this.getTotalBet() * 7 && winAmount < this.getTotalBet() * 8) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_16;
                } else if (winAmount >= this.getTotalBet() * 8 && winAmount < this.getTotalBet() * 10) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_BG_17;
                }
            }
        }


        /**
         * to play multiple win tickup sounds
         */
        public getWinMeterTickUpSound(evt?: number): string {
            const winAmount: number = evt ? evt : parserModel.getGameWinAmt();
            if (this.getIsBigWin() && !this.getIsScatterWins()) {
                if (winAmount >= this.getTotalBet() * 10 && winAmount < this.getTotalBet() * 12) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_18;
                } else if (winAmount >= this.getTotalBet() * 12 && winAmount < this.getTotalBet() * 15) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_19;
                } else if (winAmount >= this.getTotalBet() * 15 && winAmount < this.getTotalBet() * 20) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_20;
                } else if (winAmount >= this.getTotalBet() * 20 && winAmount < this.getTotalBet() * 30) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_21;
                } else if (winAmount >= this.getTotalBet() * 30 && winAmount < this.getTotalBet() * 40) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_22;
                } else if (winAmount >= this.getTotalBet() * 40 && winAmount < this.getTotalBet() * 50) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_23;
                } else if (winAmount >= this.getTotalBet() * 50) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_24;
                }
            } else if (this.getIsTurboModeOn() && !this.getIsScatterWins()) {
                if (winAmount < this.getTotalBet() * 10) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_2;
                }
            } else if (this.getIsScatterWins()) {
                return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_1;
            } else {
                if (winAmount < this.getTotalBet() * 0.1) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_1;
                } else if (winAmount >= this.getTotalBet() * 0.1 && winAmount < this.getTotalBet() * 0.2) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_2;
                } else if (winAmount >= this.getTotalBet() * 0.2 && winAmount < this.getTotalBet() * 0.3) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_3;
                } else if (winAmount >= this.getTotalBet() * 0.3 && winAmount < this.getTotalBet() * 0.4) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_4;
                } else if (winAmount >= this.getTotalBet() * 0.4 && winAmount < this.getTotalBet() * 0.5) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_5;
                } else if (winAmount >= this.getTotalBet() * 0.5 && winAmount < this.getTotalBet() * 0.75) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_6;
                } else if (winAmount >= this.getTotalBet() * 0.75 && winAmount < this.getTotalBet() * 1) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_7;
                } else if (winAmount >= this.getTotalBet() * 1 && winAmount < this.getTotalBet() * 1.25) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_8;
                } else if (winAmount >= this.getTotalBet() * 1.25 && winAmount < this.getTotalBet() * 1.5) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_9;
                } else if (winAmount >= this.getTotalBet() * 1.5 && winAmount < this.getTotalBet() * 2) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_10;
                } else if (winAmount >= this.getTotalBet() * 2 && winAmount < this.getTotalBet() * 3) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_11;
                } else if (winAmount >= this.getTotalBet() * 3 && winAmount < this.getTotalBet() * 4) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_12;
                } else if (winAmount >= this.getTotalBet() * 4 && winAmount < this.getTotalBet() * 5) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_13;
                } else if (winAmount >= this.getTotalBet() * 5 && winAmount < this.getTotalBet() * 6) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_14;
                } else if (winAmount >= this.getTotalBet() * 6 && winAmount < this.getTotalBet() * 7) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_15;
                } else if (winAmount >= this.getTotalBet() * 7 && winAmount < this.getTotalBet() * 8) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_16;
                } else if (winAmount >= this.getTotalBet() * 8 && winAmount < this.getTotalBet() * 10) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_BG_17;
                }
            }
        }

        /**
         * to get gamble won amount received from server
         */
        public getGambleWinAmount(): number {
            return this.serverModel.getGambleWinAmount();
        }

        /**
         * to get gamble avialability received from server
         */
        public getIsGambleAvailable(): boolean {
            return this.serverModel.getIsGambleAvailable();
        }


        /**
         * to get gamble mystery card received from server
         */
        public getGambleDrawnCard(): string[] {
            return this.serverModel.getGambleDrawnCard();
        }
        /**
        * to get gamble mystery card received from server
        */
        public getRandomCardData(): string[] {
            return this.serverModel.getRandomCardData();
        }

        /**
         * to get player choosen gamble symbol from server
         */
        public getPlayerSelectedGambleSymbol(): string {
            return this.serverModel.getPlayerSelectedGambleSymbol();
        }

        public setBetType(value: string): void {
            this.serverModel.setBetType(value);
        }
        public getBetType(): string {
            return this.serverModel.getBetType();
        }

    }
}
