///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.GameIntro {
    export class Controller {
        protected view: GameIntroView;
        protected continueGameIntro: ingenuity.ui.ButtonBase;
        protected continueBtnContainer: ui.Container;
        protected continueAlphaTween: bridge.ITween;
        protected continueButtonTween: bridge.ITween;
        protected gameLogo: ui.Bitmap;
        protected btnGlow: ui.Bitmap;
        protected gameLogoAnimation: ui.AnimationBase;

        constructor(view: GameIntroView) {
            this.view = view;
            this.view.visible = false;
            this.initializeElements();
            this.subscribeEvents();
        }

        protected initializeElements(): void {
            this.btnGlow = this.view.getImageById("gameIntroContinueBaseBtn");
            this.continueBtnContainer = this.view.getContainerByID("continueButtonContainer");
            this.continueGameIntro = this.view.getButtonById(ingenuity.BehaviorCore.slotConstants.SlotConstants.gameIntroContinueBtn) as ui.ButtonBase;

        }

        protected subscribeEvents(): void {
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_GAME_INTRO_VIEW, this.view.hideView, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_GAME_INTRO_VIEW, this.view.showView, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.LAUNCH_GAME_INTRO, this.launchGameIntro, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotConstants.START_GAME_INTRO, this.startIntro, this);
            this.continueGameIntro && this.continueGameIntro.on(ingenuity.ui.ButtonBase.UP, this.onContinuePressUp, this);
        }

        protected unSubscribeEvents(): void {
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_GAME_INTRO_VIEW, this.view.hideView, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_GAME_INTRO_VIEW, this.view.showView, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.LAUNCH_GAME_INTRO, this.launchGameIntro, this);
            this.view.destroy();
        }

        /**
         * to show basegame and kill all tweens on continue button pressup
         */
        protected onContinuePressUp(evt: IEvent): void {
            soundManager.stop(BehaviorCore.slotConstants.SoundConstant.GAME_INTRO_LOOP);
            soundManager.playSound(BehaviorCore.slotConstants.SoundConstant.BASEGAME_BTN_CONTINUE, 5, false, "soundList");
            this.continueButtonTween && this.continueButtonTween.stop();
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
            utils.delayedCall("BasegamealphaUnfade", 1000, () => {
                utils.killDelayedCall("BasegamealphaUnfade");
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                configData.enableSpacebar = true;
            }, this);
            currentGame.tweens.removeFrom(this);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_GAME_INTRO_VIEW);
            this.unSubscribeEvents();
        }

        protected launchGameIntro(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotConstants.STORE_PLAY_TOKEN_LOCAL);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_BASEGAME_VIEW);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SET_GAME_INTRO_SHOW);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_GAME_INTRO_VIEW);
        }

        protected startIntro(): void {
            if (!soundManager.isSoundPlaying(BehaviorCore.slotConstants.SoundConstant.GAME_INTRO_LOOP, "soundList")) {
                ingenuity.soundManager.playSound(BehaviorCore.slotConstants.SoundConstant.GAME_INTRO_LOOP, 1, true, "soundList");
            }
            this.btnGlowTween();
        }

        /**
        * to show continue btn with fade in alpha and then infinte glow on continue button boundary
        */
        protected btnGlowTween(): void {
            this.continueBtnContainer.visible = true;
            this.continueBtnContainer.alpha = 0;
            this.continueAlphaTween = currentGame.add.tween(this.continueBtnContainer).to({ alpha: 1 }, 200, undefined, true, 0, 0);
            this.continueAlphaTween.onComplete.addOnce(() => {
                this.continueAlphaTween && this.continueAlphaTween.stop();
                currentGame.tweens.remove(this.continueAlphaTween);
                this.btnGlow.alpha = 0;
                this.continueButtonTween = currentGame.add.tween(this.btnGlow).to({ alpha: 1 }, 500, undefined, true, 0, Infinity, true);
            }, this);
        }


    }
}
