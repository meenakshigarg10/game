///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.GameIntro {

    export class GameIntroView extends BehaviorCore.BaseView {
        constructor(json: IObject) {
            super(json);
        }

        public destroy(): void {
            dispatcher.off(events.EventConstants.RESIZE, this.resize, this);
            super.destroy();
        }

        protected resize(evt?: IEvent): void {
            super.resize(evt);
            if (ingenuity.deviceEnv.getOrientation() === BehaviorCore.slotConstants.SlotConstants.PORTRAIT) {
                this.pivot.set(ingenuity.configData.width * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER, 0);
                this.x = (innerWidth * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER);
                this.y = 0;
                deviceEnv.update();
                this.scale.set(deviceEnv.getPortraitScale());

            } else  {
                this.pivot.set(BehaviorCore.slotConstants.SlotConstants.BACKGROUND_WIDTH * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER, ingenuity.configData.height * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER);
                this.x = innerWidth * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER;
                this.y = innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER;
                const scale: number = Math.min((innerHeight / configData.height), (innerWidth / configData.width));
                this.scale.set(scale, scale);
            }
        }

        public hideView(): void {
            this.visible = false;
        }

        public showView(): void {
          //  currentGame.stage.addChild(this);
            this.visible = true;
            this.getButtonById(BehaviorCore.slotConstants.SlotConstants.GAME_INTRO_CONTINUE_BTN).visible = true;
            this.getImageById(BehaviorCore.slotConstants.SlotConstants.GAME_INTRO_CONTINUE_BASE_BTN).visible = true;
            ingenuity.dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CHANGE_BACKGROUND, BehaviorCore.slotConstants.SlotConstants.GAME_INTRO_BG_SHOW);
        }

    }
}
