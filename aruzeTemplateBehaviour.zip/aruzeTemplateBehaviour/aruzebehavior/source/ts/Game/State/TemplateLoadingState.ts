namespace ingenuity.BehaviorCore {

    export class TemplateLoadingState extends loader.Loading {
        protected loader: loader.Loader;

        /**
         * This function is override to set loaded data in ingenuity.assetsData.
         */
        protected checkForLoadingStagesComplete(loadingStage: string): void {
            if (loadingStage === core.base.constants.loader.STAGE_BASE_GAME.toLowerCase()) {
                ingenuity.assetsData = this;
            }
            super.checkForLoadingStagesComplete(loadingStage);
        }

        /**
         * This function is used to get json data by tag it.
         * @param {string} key : Tag is of json
         * @returns {any} : json data of tag id
         */
        public getJSONById(key: string): IObject {
            return currentGame.cache.getJSON(key);
        }

        /**
         * This function is used to get Image data by its tag id.
         * @param {string} key : tag id of image.
         * @returns {any}: Image related to tag id.
         */
        public getImageById(key: string): HTMLImageElement {
            return currentGame.cache.getImage(key);
        }

        /**
         * This function is used to get Assets data(Image/font/json) by its tag id.
         * @param {string} key : tag id of Assets.
         * @returns {any}: Assets(Image/font/json) related to tag id.
         */
        public getAssetById(key: string): IObject {
            let asset: {} = currentGame.cache.getImage(key);
            if (!asset) {
                asset = currentGame.cache.getBitmapFont(key);
                if (!asset) {
                    currentGame.cache.getJSON(key);
                }
            }
            return asset;
        }
    }
}
