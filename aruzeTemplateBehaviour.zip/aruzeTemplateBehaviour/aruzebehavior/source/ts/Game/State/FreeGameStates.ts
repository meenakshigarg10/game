///<reference path="../../Interfaces.ts" />

/**
 * Override this state to initialize PlayerMsgView
 */
namespace ingenuity.BehaviorCore {
    export class FreeGameState extends slot.FreegameState {
        protected reelPanel: BehaviorCore.reelPanel.ReelPanel;
        protected freeGameController: BehaviorCore.FreeGame.FreeGameController;
        protected view: BehaviorCore.FreeGame.View;
        protected freeGameIntro: ui.Container;
        protected freeGameIntroMssg: ui.Container;
        protected animHen: ui.Bitmap;
        protected animRays: ui.AnimationBase;
        protected animWindow: ui.AnimationBase;
        protected animContinueBtn: ui.AnimationBase;
        protected introImg: ui.Bitmap;
        protected freeGameIntroMssgWindowAlphaTween: ITween;
        protected freeGameIntroMssgWindowScaleTween: ITween;
        protected model: ingenuity.BehaviorCore.FreeGame.Model;

        /**
        * Initialising Free Game Model and sticky wild model
        */
        protected initializeModel(): void {
            this.model = new core.constructors.bsBehavior.FreeGameModel(parserModel);
            ingenuity.freeGameModel = this.model;
        }

        /**to be able to access model from state */
        public getModel(): ingenuity.BehaviorCore.FreeGame.Model {
            return  ingenuity.freeGameModel = this.model;
        }

        /**
         * Initialising Free Game View
         */
        protected initializeView(): void {
            this.view = new core.constructors.bsBehavior.FreeGameView(assetsData.getJSONById(BehaviorCore.slotConstants.SlotConstants.MAIN_DATA).freeGame);
            currentGame.stage.addChildAt(this.view, 2);
        }

        /**
         * Initialising Free Game controller
         */
        protected initializeController(): void {
            this.freeGameController = new core.constructors.bsBehavior.FreeGameController(this.view, this.model, assetsData.getJSONById(BehaviorCore.slotConstants.SlotConstants.MAIN_DATA), assetsData);
        }

        public init() {
            this.initializeModel();
            this.initializeView();
            this.initializeReelPanel();
            this.initializePayline();
            this.initializeWinReelPresentation();
            this.initializeOverlayWinReelPresentation();
            this.setReelPanelLayering();
            this.initializeController();
            this.initializeBigWinPresentation();
            this.initializePaytable();
            this.initializeIntroOutro();
            this.initializeSound();
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_FG_MODEL);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SETUP_FG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_FREEGAME_VIEW);
            dispatcher.fireEvent(slotConstants.SlotEventConstants.BRING_GUI_ON_TOP);
            configData.freegameReturning = true;
        }

        /**
         * It is called when free game states clears. It remove the free game view.
         */

        public shutdown(): void {
            if (this.model.getFreeSpinsRemaining()) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_FREEGAME_REELPANEL_EVENTS);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_BUTTON_CONTROLLERS_FG);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_FREEGAME_VIEW);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_BUTTON_CONTROLLERS_FG);
                this.freeGameController.shutdown();
                super.shutdown();
            }
        }

        protected initializeReelPanel(): void {
            this.reelModel = new core.constructors.reelPanel.ReelModel();
            this.reelModel.json = assetsData.getJSONById("main_data").freeGame.reels;
            this.reelPanel = new core.constructors.reelPanel.ReelPanel(ingenuity.currentGame, this.reelModel) as BehaviorCore.reelPanel.ReelPanel;
            this.view.setReelView(this.reelPanel);
        }

        /**
         * Method overrided for adding WinFrames at the top
         */
        protected initializeOverlayWinReelPresentation(): void {
            super.initializeOverlayWinReelPresentation();
            this.paylineView.getWinboxContainer().setParent(this.view.getWinReelView());
            this.paylineView.alpha = 0;
        }

        /**
         * This function is overrided for update of setPaylineView function call.
         */
        protected initializePayline(): void {
            this.paylineView = new core.constructors.reelPanel.PaylineView(assetsData.getJSONById(BehaviorCore.slotConstants.SlotConstants.MAIN_DATA).paylineInfo, this.reelModel, this.view.getContainerByID(BehaviorCore.slotConstants.SlotConstants.REELS_CONTAINER_FG));
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_CREATE_WINBOX);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_CREATE_PAYLINE_SPAGGITTE);
            this.view.setPaylineView(this.paylineView, 0, BehaviorCore.slotConstants.SlotConstants.REELS_CONTAINER_FG);
        }
    }
}
