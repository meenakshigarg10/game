///<reference path="../../Interfaces.ts" />

/**
 * Override this state to initialize PlayerMsgView
 */
namespace ingenuity.BehaviorCore {
    export class BaseGameState extends slot.BasegameState {
        protected reelPanel: BehaviorCore.reelPanel.ReelPanel;
        protected gambleView: BehaviorCore.Gamble.View;
        protected gambleController: BehaviorCore.Gamble.Controller;
        protected model: BehaviorCore.BaseGame.Model;
        protected view: ingenuity.BehaviorCore.BaseGame.View;
        protected bigWinPresentation: BehaviorCore.BigWin.BigWinView;
        protected bigWinPresentationController: BehaviorCore.BigWin.BigWinController;

        /**
         * Override this function to initialize PlayerMsgView
         *
         * It is called when base game states starts.
         */
        public init() {
            this.initializeModel();
            this.initializeView();
            this.subscribeEventsGame();
            this.setReelPanelLayering();
            this.initializeController();
            this.initializeBigWinPresentation();
            this.initializePaytable();
            this.initializeSound();
            this.initializeGameIntro();
            this.initializeSoundPopup();
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_BG_MODEL);
            dispatcher.fireEvent(platform.EventConstants.INIT_GAME);
        }

         /**
         * Initialising Big Win presentation
         */
        protected initializeBigWinPresentation(): void {
            if (configData.baseGamePostLoadAssetsLoaded === true) {
                this.model.setIsBigWinLoaded(true);
                this.bigWinPresentation = new core.constructors.bsBehavior.BigWinView(currentGame.cache.getJSON("main_data").baseGame.bigWinPresentation);
                this.bigWinPresentationController = new core.constructors.bsBehavior.BigWinController(this.bigWinPresentation, this.model);
                this.view.addChild(this.bigWinPresentation);
                return;
            }
            dispatcher.on(events.EventConstants.BASEGAME_POSTLOAD_ASSETS_LOADED, (e: IEvent) => {
                configData.baseGamePostLoadAssetsLoaded = true;
                this.model.setIsBigWinLoaded(true);
                this.bigWinPresentation = new core.constructors.bsBehavior.BigWinView(currentGame.cache.getJSON("main_data").baseGame.bigWinPresentation);
                this.bigWinPresentationController = new core.constructors.bsBehavior.BigWinController(this.bigWinPresentation, this.model);
                this.view.addChild(this.bigWinPresentation);
            }, this, true);
        }

         /**
         * Initialising Base Game View
         */
        protected initializeView(): void {
            this.view = new core.constructors.bsBehavior.BaseView(currentGame.cache.getJSON("main_data").baseGame);
            currentGame.stage.addChild(this.view);
        }

        /**
         * Initialising Base Game Controller
         */
        protected initializeController(): void {
            this.basecontroller = new core.constructors.bsBehavior.BaseController(this.view, this.model, currentGame.cache.getJSON("main_data"), ingenuity.assetsData);
        }

        /**
         * Initialising reel Panel
         */
        protected initializeReelPanel(): void {
            this.reelModel = new core.constructors.reelPanel.ReelModel();
            this.reelModel.json = currentGame.cache.getJSON("main_data").baseGame.reels;
            this.reelPanel = new core.constructors.reelPanel.ReelPanel(currentGame, this.reelModel) as BehaviorCore.reelPanel.ReelPanel;
            this.view.setReelView(this.reelPanel);
        }

        protected initializeModel(): void {
            this.model = new ingenuity.core.constructors.bsBehavior.BaseModel(parserModel);
            ingenuity.baseGameModel = this.model;
        }

        /**to be able to access model from state */
        public getModel(): BehaviorCore.BaseGame.Model {
            return ingenuity.baseGameModel;
        }

        protected subscribeEventsGame(): void {
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_REEL_PANEL, this.initializeReelPanel, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_WIN_REEL_PRESENTATION_PANEL, this.initializeWinReelPresentation, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_OVERLAY_WIN_REEL_PRESENTATION_PANEL, this.initializeOverlayWinReelPresentation, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_PAYLINE, this.initializePayline, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_GAMBLE, this.initializeGamble, this);
        }

        protected unSubscribeEvents(): void {
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_REEL_PANEL, this.initializeReelPanel, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_WIN_REEL_PRESENTATION_PANEL, this.initializeWinReelPresentation, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_OVERLAY_WIN_REEL_PRESENTATION_PANEL, this.initializeOverlayWinReelPresentation, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_PAYLINE, this.initializePayline, this);
        }

        protected initializeGamble(): void {
            if (!this.gambleView && !this.gambleController) {
                if (configData.baseGamePostLoadAssetsLoaded === true) {
                    this.gambleView = new core.constructors.bsBehavior.GambleView(currentGame.cache.getJSON("main_data").gamble);
                    this.gambleController = new core.constructors.bsBehavior.GambleController(this.gambleView, this.model);
                    currentGame.stage.addChildAt(this.gambleView, 2);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.START_GAMBLE);
                    this.chackGambleHistoryAndBroken();
                } else {
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER);
                    dispatcher.fireEvent(events.EventConstants.LOAD_STATE, ingenuity.core.base.constants.loader.STAGE_BASE_GAME_POSTLOAD);
                    dispatcher.on(events.EventConstants.BASEGAME_POSTLOAD_ASSETS_LOADED, (e: IEvent) => {
                        configData.baseGamePostLoadAssetsLoaded = true;
                        this.gambleView = new core.constructors.bsBehavior.GambleView(currentGame.cache.getJSON("main_data").gamble);
                        this.gambleController = new core.constructors.bsBehavior.GambleController(this.gambleView, this.model);
                        currentGame.stage.addChildAt(this.gambleView, 2);
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER);
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.START_GAMBLE);
                        this.chackGambleHistoryAndBroken();
                    }, this, true);
                }
            } else {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.START_GAMBLE);
            }
        }

        protected chackGambleHistoryAndBroken(): void {
            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                parserModel.getGambleResponseInHistory() && dispatcher.fireEvent(platform.aruze.EventConstants.GAMBLE_BROKEN_RESPONSE_RECEIVED, parserModel.getGambleResponseInHistory());
                if (configData.SuitGamble) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_HISTORY_IN_SUITE_GAMBLE);
                    parserModel.getGambleResponseInHistory() && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_VIEW_IN_HISTORY);
                } else {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_HISTORY);
                    parserModel.getGambleResponseInHistory() && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_VIEW_IN_HISTORY);
                }
            } else if (parserModel.getAction() === "refresh" && parserModel.getNextAction() === BehaviorCore.slotConstants.SlotConstants.CLOSE_ACTION) {
                if (configData.SuitGamble) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_HISTORY_IN_SUITE_GAMBLE);
                } else {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_HISTORY);
                }
            }
        }

        protected setReelPanelLayering(): void {
            if (currentGame.cache.getJSON("main_data").baseGame.reels.indexing) {
                for (const i of currentGame.cache.getJSON("main_data").baseGame.reels.indexing) {
                    this.view.forEach((comp: ui.Container) => {
                        if (comp.name === i) {
                            this.view.addChild(comp);
                        }
                    }, this);
                }
            }
        }

        /**
         * Initialising Sound Manager
         */
        protected initializeSound(): void {
            soundManager = currentGame.sound;
            soundManager = new ingenuity.core.constructors.base.AudioController();
            soundManager.add(currentGame.cache.getJSON("soundList"), "soundList");
            soundManager.setEnabled(true);
            if (deviceEnv.browser.toLowerCase() === deviceEnvironment.DeviceDetector.BROWSER_NAMES.IE11 ||
                (deviceEnv.isSlowDevice() && deviceEnv.getDeviceOS() !== BehaviorCore.slotConstants.SlotConstants.IOS) && deviceEnv.getBrowser() !== BehaviorCore.slotConstants.SlotConstants.CHROME) {
                soundManager.setEnabled(false);
            }
        }

        protected initializeSoundPopup(): void {
            const soundPopupView: BehaviorCore.SoundPopup.SoundPopupView = new ingenuity.core.constructors.bsBehavior.SoundPopupView(currentGame.cache.getJSON("main_data").SoundPopup);
            new core.constructors.bsBehavior.SoundPopupController(soundPopupView);
            currentGame.stage.addChild(soundPopupView);
        }

        protected initializeGameIntro(): void {
            const gameIntroView: BehaviorCore.GameIntro.GameIntroView = new core.constructors.bsBehavior.GameIntroView(currentGame.cache.getJSON("main_data").gameIntro);
            new core.constructors.bsBehavior.GameIntroController(gameIntroView);
        }

        /**
         * Method overrided for adding WinFrames at the top
         */
        protected initializeOverlayWinReelPresentation(): void {
            super.initializeOverlayWinReelPresentation();
            this.paylineView.getWinboxContainer().setParent(this.view.getWinReelView());
            this.paylineView.alpha = 0;
        }

        /**
         * This function is overrided for update of setPaylineView function call.
         */
        protected initializePayline(): void {
            this.paylineView = new core.constructors.reelPanel.PaylineView(assetsData.getJSONById(BehaviorCore.slotConstants.SlotConstants.MAIN_DATA).paylineInfo, this.reelModel, this.view.getContainerByID(BehaviorCore.slotConstants.SlotConstants.REELS_CONTAINER));
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CREATE_WINBOX);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CREATE_PAYLINE_SPAGGITTE);
            this.view.setPaylineView(this.paylineView, 0, BehaviorCore.slotConstants.SlotConstants.REELS_CONTAINER);
        }
    }
}
