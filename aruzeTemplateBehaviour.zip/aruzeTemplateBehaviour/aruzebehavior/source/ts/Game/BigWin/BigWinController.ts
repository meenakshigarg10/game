///<reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.BigWin {
    export class BigWinController {
        protected standardTickupTime: number;
        protected sumUp: boolean;
        protected gameConfigData: IObject;
        protected bigWinMeter: behaviourUI.BigWinMeterBitmap;
        protected winMeter: behaviourUI.BigWinMeterBitmap;
        protected nextTickUpState: string;
        protected currentWinAmountTickUp: number;
        protected tickupAmountLevel: number;
        protected tickupAmount: number;
        protected particles: string[];
        protected startedTime: number;
        protected coinShowerContainer: ui.Container;
        protected coinConfig: IObject;
        protected emitter: any;
        protected emitter1: any;
        protected emitter2: any;
        protected glowTween: bridge.ITween;
        protected wintext: ui.Bitmap;
        protected bigWintext: ui.Bitmap;
        protected greatWintext: ui.Bitmap;
        protected zoomInTween: bridge.ITween;
        protected fadeInTween: bridge.ITween;
        protected fadeOutTween: bridge.ITween;
        protected winFrameAnimation: ui.AnimationBase;
        protected wnFrameSparkal: ui.AnimationBase;
        protected animNum: number;
        protected fountainAnims: ui.AnimationBase[] = [];

        constructor(protected view: BigWinView, protected model: BaseGame.Model | FreeGame.Model) {
            this.unSubscribeEvents();
            this.subscribeEvents();
            this.view = view;
            this.standardTickupTime = slotConstants.SlotConstants.StandardTickupTime;
            this.model = model;
            this.sumUp = true;
            this.gameConfigData = currentGame.cache.getJSON("main_data").gameConfig;
            this.initializeBigWin(); // initialize big win data
        }

        protected startBigWinCoins(): void {
            const particleData: Object = {
                emitterType: 1,
                id: "coinEmitter",
                autoStart: false,
                animConfig: [{
                    framerate: 20,
                    loop: true,
                    image: "Celebration_Animation",
                    generateFrames: true,
                    frames: [30, 49]
                }]
            };

            const particleData1: Object = {
                emitterType: 1,
                id: "coinEmitter_1",
                autoStart: false,
                animConfig: [{
                    framerate: 20,
                    loop: true,
                    image: "Celebration_Animation",
                    generateFrames: true,
                    frames: [30, 49]
                }]
            };

            const config: any = {
                scale: {
                    start: 0.25,
                    end: 0.75,
                    minimumScaleMultiplier: 0.5
                },
                color: {
                    start: "#ffffff",
                    end: "#ffffff"
                },
                speed: {
                    start: 600,
                    end: 500,
                    minimumSpeedMultiplier: 1
                },
                acceleration: {
                    x: 0,
                    y: 1000
                },
                maxSpeed: 0,
                startRotation: {
                    min: 0,
                    max: 180
                },
                noRotation: false,
                rotationSpeed: {
                    min: 0,
                    max: 360
                },
                lifetime: {
                    min: 4,
                    max: 4
                },
                blendMode: "normal",
                frequency: 0.025,
                emitterLifetime: -1,
                maxParticles: 500,
                pos: {
                    x: 0,
                    y: -100
                },
                addAtBack: false,
                spawnType: "point"
            };

            const config1: any = {
                scale: {
                    start: 0.25,
                    end: 0.75,
                    minimumScaleMultiplier: 0.5
                },
                color: {
                    start: "#ffffff",
                    end: "#ffffff"
                },
                speed: {
                    start: 450,
                    end: 500,
                    minimumSpeedMultiplier: 1
                },
                acceleration: {
                    x: 0,
                    y: 1000
                },
                maxSpeed: 0,
                startRotation: {
                    min: 0,
                    max: 180
                },
                noRotation: false,
                rotationSpeed: {
                    min: 0,
                    max: 360
                },
                lifetime: {
                    min: 4,
                    max: 4
                },
                blendMode: "normal",
                frequency: 0.020,
                emitterLifetime: -1,
                maxParticles: 500,
                pos: {
                    x: 0,
                    y: -100
                },
                addAtBack: false,
                spawnType: "point"
            };
            const coinShowerContainer: ui.Container = this.view.getContainerByID("coinShowerContainer");
            const coinShowerContainer1: ui.Container = this.view.getContainerByID("coinShowerContainer_1");
            this.emitter1 = currentGame.add.emitter(coinShowerContainer1, particleData1, config1);
            this.emitter = currentGame.add.emitter(coinShowerContainer, particleData, config);
            this.startEmitter();
        }

        public startEmitter(): void {
            let em: bridge.Emitter;
            em = currentGame.particles.getEmitterById("coinEmitter");
            if (!em) { return; }
            em.autoUpdate = true;
            em.emit = true;

            em = currentGame.particles.getEmitterById("coinEmitter_1");
            if (!em) { return; }
            em.autoUpdate = true;
            em.emit = true;
        }

        protected startGreatWinCoins(): void {
            const particleData: Object = {
                emitterType: 1,
                id: "greatWinCoinEmitter",
                autoStart: false,
                animConfig: [{
                    framerate: 20,
                    loop: true,
                    image: "Celebration_Animation",
                    generateFrames: true,
                    frames: [88, 87]
                }]
            };

            const config: any = {
                scale: {
                    start: 0.8,
                    end: 1,
                    minimumScaleMultiplier: 0.5
                },
                speed: {
                    start: 600,
                    end: 500,
                    minimumSpeedMultiplier: 1
                },
                acceleration: {
                    x: 0,
                    y: 1000
                },
                maxSpeed: 0,
                startRotation: {
                    min: 0,
                    max: 180
                },
                noRotation: false,
                rotationSpeed: {
                    min: 0,
                    max: 360
                },
                lifetime: {
                    min: 4,
                    max: 4
                },
                blendMode: "normal",
                frequency: 0.070,
                emitterLifetime: -1,
                maxParticles: 500,
                pos: {
                    x: 0,
                    y: -100
                },
                addAtBack: false,
                spawnType: "point"
            };

            const coinShowerContainer: ui.Container = this.view.getContainerByID("coinShowerContainer");
            this.emitter2 = ingenuity.currentGame.add.emitter(coinShowerContainer, particleData, config);
            const em = ingenuity.currentGame.particles.getEmitterById("greatWinCoinEmitter");
            if (!em) { return; }
            em.autoUpdate = true;
            em.emit = true;
        }

        /**
         * unsubscribe events using in big win
         */
        public unSubscribeEvents(): void {
            dispatcher.off(slot.slotConstants.SlotEventConstants.SHOW_BIG_WIN, this.startMeterBeforeBigWin);
            dispatcher.off(slotConstants.SlotEventConstants.HIDE_BIG_WIN, this.hideBigWincall);
            dispatcher.off(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN, this.stopBigWinAndTicker, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_BIG_WIN, this.stopBigWinAndTicker, this);
        }

        public subscribeEvents(): void {
            dispatcher.on(slot.slotConstants.SlotEventConstants.SHOW_BIG_WIN, this.startMeterBeforeBigWin, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_BIG_WIN, this.stopBigWinAndTicker, this);
        }

        protected bringBigWinOnTop() {
            this.view.parent.addChildAt(this.view, this.view.parent.children.length - 1);
        }

        public initializeBigWin(): void {
            this.winMeter = this.view.getMeterById("winMtr") as behaviourUI.BigWinMeterBitmap;
            this.bigWinMeter = this.view.getMeterById("bigWinMtr") as behaviourUI.BigWinMeterBitmap;
            this.coinShowerContainer = this.view.getContainerByID(slotConstants.SlotConstants.CoinShowerContainer);
            this.wintext = this.view.getImageById("winText");
            this.bigWintext = this.view.getImageById("bigWinText");
            this.greatWintext = this.view.getImageById("greatWinText");
            this.wintext.anchor.set(0.5, 0.5);
            this.bigWintext.anchor.set(0.5, 0.5);
            this.greatWintext.anchor.set(0.5, 0.5);
            this.view.getImageById("winTextGlow").alpha = 0;
            this.view.getImageById("bigWinGlowText").alpha = 0;
            this.view.getImageById("greatWinGlowText").alpha = 0;
            this.animNum = 1;
        }

        public startMeterBeforeBigWin(evt: IEvent) {
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIG_WIN, this.hideBigWincall, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN, this.stopBigWinAndTicker, this);
            this.view.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BIGWIN_VIEW);
            this.winMeter.y = this.winMeter.json.y;
            this.winMeter.setValue(0);
            this.bigWinMeter.setValue(0);
            this.winMeter.setVisible(false);
            this.bigWinMeter.setVisible(false);
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.winMeter.y = this.winMeter.json.portraitY;
                this.bigWinMeter.y = this.bigWinMeter.json.portraitY;
            } else {
                this.winMeter.y = this.winMeter.json.y;
                this.bigWinMeter.y = this.bigWinMeter.json.y;
            }

            this.model.setIsBigWinRunning(true);
            this.nextTickUpState = "STANDARD";
            this.currentWinAmountTickUp = parserModel.getGameWinAmt();
            this.startedTime = currentGame.time.now;
            this.tickupAmountLevel = this.model.getIsBigWin();
            dispatcher.fireEvent(events.EventConstants.STOP_SOUND, BehaviorCore.slotConstants.SoundConstant.BASEGAME_BACKGROUND);
            if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.freeGameState) {
                const callback = evt.data ? evt.data : null;
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.FG_EXECUTE_CALL_BACK, callback);
            } else {
                const callback = evt.data ? evt.data : null;
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.EXECUTE_CALL_BACK, callback);
            }
            this.view.parent.addChildAt(this.view, this.view.parent.children.length - 1);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);

            this.showBigWinState();
        }

        /**
         *
         * @param e stop bigwin presentation, reset tweens.
         * called in case of normal presentation end as well as by stage click
         */
        protected hideBigWin(e: IEvent) {
            utils.killDelayedCall("hideBigWin");
            utils.killDelayedCall("glowTweenDelay");
            this.glowTween && this.glowTween.stop();
            this.glowTween && currentGame.tweens.remove(this.glowTween);
            this.zoomInTween && this.zoomInTween.stop();
            this.zoomInTween && currentGame.tweens.remove(this.zoomInTween);
            this.fadeInTween && this.fadeInTween.stop();
            this.fadeInTween && currentGame.tweens.remove(this.fadeInTween);
            this.fadeOutTween && this.fadeOutTween.stop();
            this.fadeOutTween && currentGame.tweens.remove(this.fadeOutTween);
            this.view.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIGWIN_VIEW);
            this.model.setIsBigWinRunning(false);
            if ((this.model.getIsSpinClicked() === false) && !this.model.getIsAutoPlayLeft()) {
                dispatcher.fireEvent(slotConstants.SlotEventConstants.BIG_WIN_COMPLETE);
            }

            if (!this.model.getIsSpinClicked() && !this.model.getIsAutoPlayLeft() && !this.model.getIsScatterWins()) {
                if (parserModel.getNextAction() === "") {
                    if ((this.model as BaseGame.Model).getGambleDrawnCard().length) {
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_GAMBLE_BUTTON);
                    } else {
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END);
                    }
                } else if ((this.model as BaseGame.Model).getIsGambleAvailable()) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_GAMBLE_BUTTONS);
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                }
            }
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_SPIN_CALL);
            dispatcher.off(slotConstants.SlotEventConstants.HIDE_BIG_WIN, this.hideBigWincall);
            dispatcher.off(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN, this.stopBigWinAndTicker, this);
        }

        protected hideBigWincall(e?: IEvent): void {
            this.view.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIGWIN_VIEW);
            this.model.setIsBigWinRunning(false);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.BIG_WIN_HIDDEN);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.CLEAR_BIG_WIN);
        }

        /**to initialize features */
        protected checkForFeature(): void {
            //
        }

        protected bigWinPresentationComplete(): void {
            this.emitter && (this.emitter.emit = false);
            this.emitter1 && (this.emitter1.emit = false);
            this.emitter2 && (this.emitter2.emit = false);
            soundManager.stop(this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpSound(this.currentWinAmountTickUp), "soundList_1");
            soundManager.stop(this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpSound(this.tickupAmount), "soundList_1");
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_WIN_METER_BEFORE_CLOSE_IN_BIGWIN, { value: this.currentWinAmountTickUp });
            utils.delayedCall("hideBigWin", 1000, this.hideBigWin, this);
            if (this.tickupAmountLevel === 1) {
                this.winFrameAnimation.stopAnim();
                this.wnFrameSparkal.stopAnim();
            }
        }

        protected stopBigWinAndTicker() {
            utils.killDelayedCall("hideGreatWinDelay");
            if (this.tickupAmountLevel === 1) {
                this.winMeter.stopTick(false, true, true, null);
                this.winMeter.setCurrencyFormattedValue(String(this.currentWinAmountTickUp));
            } else {
                this.bigWinMeter.stopTick(false, true, true, null);
                this.bigWinMeter.setCurrencyFormattedValue(String(this.currentWinAmountTickUp));
                if (this.nextTickUpState === "GREATWIN") {
                    this.view.getContainerByID("bigWinFrameContainer").visible = false;
                    this.view.getContainerByID("greatWinFrameContainer").visible = true;
                }
            }
            this.bigWinPresentationComplete();
            this.tickupAmountLevel = 0;
        }

        /**overide to handle postload sound playing of bigwin */
        protected showBigWinState() {
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.ENABLE_STAGE_CLICK, [slot.slotConstants.SlotConstants.SpinBtnId]);
            if (this.tickupAmountLevel === 1) {
                this.wintext.alpha = 0;
                soundManager.playSound(this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpSound(this.currentWinAmountTickUp), 1, false, "soundList_1");
                this.view.getContainerByID("winContainer").visible = true;
                this.winMeter.setVisible(true);
                this.winMeter.startTick(this.currentWinAmountTickUp, true, false, this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpDuration(this.currentWinAmountTickUp), true, this.bigWinPresentationComplete.bind(this));
                this.bigWinZoomInTween(1);
                this.bigWinFadeIn(1);
            } else if (this.tickupAmountLevel === 2) {
                this.bigWintext.alpha = 0;
                this.view.getContainerByID("bigGreatWinContainer").visible = true;
                this.view.getContainerByID("bigWinFrameContainer").visible = true;
                this.view.getContainerByID("greatWinFrameContainer").visible = false;
                this.bigWinMeter.setVisible(true);
                soundManager.playSound(this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpSound(this.currentWinAmountTickUp), 1, false, "soundList_1");
                this.bigWinMeter.startTick(this.currentWinAmountTickUp, true, false, this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpDuration(this.currentWinAmountTickUp), true, this.bigWinPresentationComplete.bind(this));
                this.bigWinZoomInTween(2);
                this.bigWinFadeIn(2);
                this.startBigWinCoins();
            } else if (this.tickupAmountLevel === 3) {
                this.bigWintext.alpha = 0;
                this.nextTickUpState = "GREATWIN";
                this.view.getContainerByID("bigGreatWinContainer").visible = true;
                this.view.getContainerByID("bigWinFrameContainer").visible = true;
                this.view.getContainerByID("greatWinFrameContainer").visible = false;
                this.tickupAmount = ingenuity.BehaviorCore.slotConstants.SlotConstants.BigWinMultiplier * this.model.getTotalBet();
                this.bigWinMeter.setVisible(true);
                soundManager.playSound(this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpSound(this.currentWinAmountTickUp), 1, false, "soundList_1");
                this.bigWinMeter.startTick(this.tickupAmount, true, false, core.constructors.bsBehavior.SlotConstants.BIG_WIN_TICKUP_DURATION, true, this.showGreatWinState.bind(this));
                this.bigWinZoomInTween(2);
                this.bigWinFadeIn(2);
                this.startBigWinCoins();
            }
            if (this.tickupAmountLevel === 1) {
                this.winFrameAnimation = this.view.getAnimationById("win_Border_Animation");
                this.wnFrameSparkal = this.view.getAnimationById("win_Border_sparkel");
                this.winFrameAnimation.playAnim();
                this.winFrameSparkalAnimation();
            }
        }

        protected winFrameSparkalAnimation(): void {
            this.wnFrameSparkal.playAnim("anim", () => {
                this.winFrameSparkalAnimation();
            });
        }



        protected showGreatWinState() {
            this.greatWintext.alpha = 0;
            this.view.getContainerByID("bigGreatWinContainer").visible = true;
            this.view.getContainerByID("bigWinFrameContainer").visible = false;
            this.view.getContainerByID("greatWinFrameContainer").visible = true;
            this.tickupAmount = ingenuity.BehaviorCore.slotConstants.SlotConstants.BigWinMultiplier * this.model.getTotalBet();
            if (this.currentWinAmountTickUp > this.tickupAmount) {
                this.bigWinMeter.startTick(this.currentWinAmountTickUp, true, false, core.constructors.bsBehavior.SlotConstants.GREAT_WIN_TICKUP_DURATION, true, this.bigWinPresentationComplete.bind(this));
                this.bigWinFadeOut(2);
                this.bigWinZoomInTween(3);
                this.bigWinFadeIn(3);
                this.startGreatWinCoins();
            } else {
                soundManager.stop(this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpSound(this.currentWinAmountTickUp), "soundList_1");
                soundManager.stop(this.model instanceof BaseGame.Model && this.model.getWinMeterTickUpSound(this.tickupAmount), "soundList_1");
                this.bigWinFadeOut(2);
                this.bigWinZoomInTween(3);
                this.bigWinFadeIn(3);
                this.startGreatWinCoins();
                utils.delayedCall("hideGreatWinDelay", 2000, () => {
                    utils.killDelayedCall("hideGreatWinDelay");
                    this.bigWinPresentationComplete();
                }, this);
            }
        }

        protected tweenGlow(level: number) {
            utils.killDelayedCall("glowTweenDelay");
            this.glowTween && this.glowTween.stop();
            this.glowTween && currentGame.tweens.remove(this.glowTween);
            let glowImage: ui.Bitmap;
            if (level === 1) {
                glowImage = this.view.getImageById("winTextGlow");
                glowImage.scale.set(1.2);
                glowImage.alpha = 0;
            } else if (level === 2) {
                glowImage = this.view.getImageById("bigWinGlowText");
                glowImage.alpha = 0;
            } else if (level === 3) {
                glowImage = this.view.getImageById("greatWinGlowText");
                glowImage.alpha = 0;
            }

            this.glowTween = currentGame.add.tween(glowImage).to({
                alpha: 1
            }, 350, Easing.Linear.None, true);
            this.glowTween.onComplete.add(() => {
                this.glowTween = currentGame.add.tween(glowImage).to({
                    alpha: 0
                }, 500, Easing.Linear.None, true);
                utils.delayedCall("glowTweenDelay", 1000, () => {
                    utils.killDelayedCall("glowTweenDelay");
                    this.tweenGlow(level);
                });
            });
        }

        /**
         *
         * @param level to zoom in bigwin text on start of bigwin presentation
         */
        protected bigWinZoomInTween(level: number): void {
            let zoomImage: ui.Bitmap;
            let scaleText: number;
            this.zoomInTween && this.zoomInTween.stop();
            this.zoomInTween && currentGame.tweens.remove(this.zoomInTween);
            if (level === 1) {
                zoomImage = this.wintext;
                zoomImage.scale.set(4);
                zoomImage.alpha = 1;
                scaleText = 1.2;
            } else if (level === 2) {
                zoomImage = this.bigWintext;
                zoomImage.scale.set(4);
                zoomImage.alpha = 1;
                scaleText = 1;
            } else if (level === 3) {
                zoomImage = this.greatWintext;
                zoomImage.scale.set(4);
                zoomImage.alpha = 1;
                scaleText = 1;
            }
            this.zoomInTween = currentGame.add.tween(zoomImage.scale).to({
                x: scaleText,
                y: scaleText
            }, 200, Easing.Linear.None, true);
            this.zoomInTween.onComplete.addOnce(() => {
                this.zoomInTween.stop();
                currentGame.tweens.remove(this.zoomInTween);
                this.tweenGlow(level);
            }, this);
        }

        /**
         *
         * @param level to fade bigwin frame on start of bigwin presentation
         */
        protected bigWinFadeIn(level: number): void {
            let fadeInFrame: ui.Bitmap;
            this.fadeInTween && this.fadeInTween.stop();
            this.fadeInTween && currentGame.tweens.remove(this.fadeInTween);
            if (level === 1) {
                fadeInFrame = this.view.getImageById("winFrame");
                fadeInFrame.alpha = 0;
            } else if (level === 2) {
                fadeInFrame = this.view.getImageById("bigGreatWinFrame");
                fadeInFrame.alpha = 0;
            } else if (level === 3) {
                fadeInFrame = this.view.getImageById("greatWinFrame");
                fadeInFrame.alpha = 0;
            }
            this.fadeInTween = currentGame.add.tween(fadeInFrame).to({
                alpha: 1
            }, 200, Easing.Linear.None, true);
            this.fadeInTween.onComplete.addOnce(() => {
                this.fadeInTween.stop();
                currentGame.tweens.remove(this.fadeInTween);
            }, this);
        }

        /**
         *
         * @param level to end bigwin with bigwin text fadeout
         */
        protected bigWinFadeOut(level: number): void {
            let fadeOutImage: ui.Bitmap;
            this.fadeOutTween && this.fadeOutTween.stop();
            this.fadeOutTween && currentGame.tweens.remove(this.fadeOutTween);
            if (level === 1) {
                fadeOutImage = this.wintext;
                fadeOutImage.alpha = 1;
            } else if (level === 2) {
                fadeOutImage = this.bigWintext;
                fadeOutImage.alpha = 1;
            } else if (level === 3) {
                fadeOutImage = this.greatWintext;
                fadeOutImage.alpha = 1;
            }
            this.fadeOutTween = currentGame.add.tween(fadeOutImage).to({
                alpha: 0
            }, 100, Easing.Linear.None, true);
            this.fadeOutTween.onComplete.addOnce(() => {
                this.fadeOutTween.stop();
                currentGame.tweens.remove(this.fadeOutTween);
            }, this);
        }


    }
}