///<reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.BigWin {
    export class BigWinView extends BehaviorCore.BaseView {
        /**
         * @access public
         * @param  json , json to access assets
         */
        constructor(json: any) {
            super(json);
            this.subscribeEvents();

        }
        protected subscribeEvents(): void {
            this.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BIGWIN_VIEW, this.show, this);
            this.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIGWIN_VIEW, this.hide, this);
        }
        /**
         * Show big win presentation
         */
        protected show(): void {
            this.getContainerByID("bigWinContainer").visible = true;
            this.visible = true;
            this.alpha = 0;
            this.scaleX = 0;
            this.scaleY = 0;

            currentGame.tweens.removeFrom(this);
            const bigWinViewAlphaTween: ITween = currentGame.add.tween(this);
            const bigWinViewScaleTween: ITween = currentGame.add.tween(this);
            bigWinViewAlphaTween.to({
                alpha: 1,
            }, 500, Easing.Linear.None, true);

            bigWinViewAlphaTween.onComplete.addOnce(function () {
                ingenuity.dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.START_COIN_SHOWER);
            }, this);

            bigWinViewScaleTween.to({
                scaleX: 1,
                scaleY: 1
            }, 500, Easing.Linear.None, true);


        }

        /**
         * Hide big win presentation
         */
        protected hide(): void {
            currentGame.tweens.removeFrom(this);
            const bigWinViewAlphaTween: ITween = currentGame.add.tween(this);
            soundManager.fadeVolume(core.constructors.bsBehavior.SoundConstants.BASEGAME_BACKGROUND, 250, 1);
            bigWinViewAlphaTween.onComplete.addOnce(() => {
                this.visible = false;
                this.getContainerByID("winContainer").visible = false;
                this.getContainerByID("bigGreatWinContainer").visible = false;
                this.getContainerByID("bigWinFrameContainer").visible = false;
                this.getContainerByID("greatWinFrameContainer").visible = false;
            }, this);
            bigWinViewAlphaTween.to({
                alpha: 0
            }, 500, Easing.Linear.None, true);
        }

        /**
         * this function will call everytime when dimenstion of the game change
         * @param {ingenuity.IEvent} e
         */
        protected resize(e?: IEvent): void {
            const bigWinAlpha = this.getShapeById("bg_shape");
            bigWinAlpha.pivot.set(configData.width / 2, configData.height / 2);
            bigWinAlpha.scale.set(10, 10);
            if (ingenuity.deviceEnv.getOrientation() === ingenuity.deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.handleInPortrait();
            } else {
                this.handleInLandscape();
            }

            const coinShowerContainer: ui.Container = this.getContainerByID("coinShowerContainer");
            coinShowerContainer.x = (ingenuity.configData.width / 2);

            const coinShowerContainer1: ui.Container = this.getContainerByID("coinShowerContainer_1");
            coinShowerContainer1.x = (ingenuity.configData.width / 2);
        }

        protected handleInPortrait(): void {
            const allComp = this.getAllcomponents();
            for (const key in allComp) {
                if (allComp[key] && allComp[key].json) {
                    allComp[key].x = allComp[key].json.portraitX ? allComp[key].json.portraitX : allComp[key].json.x;
                    allComp[key].y = allComp[key].json.portraitY ? allComp[key].json.portraitY : allComp[key].json.y;
                }
            }
        }

        protected handleInLandscape(): void {
            const allComp = this.getAllcomponents();
            for (const key in allComp) {
                if (allComp[key] && allComp[key].json) {
                    allComp[key].x = allComp[key].json.landscapeX ? allComp[key].json.landscapeX : allComp[key].json.x;
                    allComp[key].y = allComp[key].json.landscapeY ? allComp[key].json.landscapeY : allComp[key].json.y;
                }
            }
        }

    }
}
