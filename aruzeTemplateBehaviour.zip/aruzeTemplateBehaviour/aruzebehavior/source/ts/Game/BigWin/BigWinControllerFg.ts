///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.BigWin {
    export class BigWinControllerFg extends BehaviorCore.BigWin.BigWinController {
        protected winFrameAnimation: ui.AnimationBase;
        protected wnFrameSparkal: ui.AnimationBase;
        protected animNum: number;
        protected fountainAnims: ui.AnimationBase[] = [];
        protected currentWinAmountTickUpFg: number;
        protected tickupAmount: number;

        constructor(protected view: BigWinViewFg, protected model: BaseGame.Model | FreeGame.Model) {
            super(view, model);
        }

        public initializeBigWin(): void {
            super.initializeBigWin();
            this.animNum = 1;
        }

        public subscribeEvents(): void {
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BIG_WIN_FG, this.startMeterBeforeBigWin, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_BIG_WIN_FG, this.stopBigWinAndTicker, this);
        }

        /**
         * unsubscribe events using in big win
         */
        public unSubscribeEvents(): void {
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BIG_WIN_FG, this.startMeterBeforeBigWin, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SUSPEND_BIG_WIN_FG, this.stopBigWinAndTicker, this);
        }

        protected hideBigWincall(e?: IEvent): void {
            this.view.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIGWIN_VIEW_FG);
            this.model.setIsBigWinRunning(false);
        }


        public startMeterBeforeBigWin(evt: IEvent) {
            this.model.setIsBigWinRunning(true);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIG_WIN_FG, this.hideBigWincall, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SUMUP_BIGWIN_FG, this.stopBigWinAndTicker, this);
            this.view.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BIGWIN_VIEW_FG);
            this.winMeter.y = this.winMeter.json.y;
            this.winMeter.setValue(0);
            this.bigWinMeter.setValue(0);
            this.winMeter.setVisible(false);
            this.bigWinMeter.setVisible(false);
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.winMeter.y = this.winMeter.json.portraitY;
                this.bigWinMeter.y = this.bigWinMeter.json.portraitY;
            } else {
                this.winMeter.y = this.winMeter.json.y;
                this.bigWinMeter.y = this.bigWinMeter.json.y;
            }

            this.nextTickUpState = "STANDARD";
            this.currentWinAmountTickUpFg = this.model.getCurrentWinAmt();
            this.startedTime = currentGame.time.now;
            this.tickupAmountLevel = this.model.getIsBigWin();
            const callback = evt.data ? evt.data : null;
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.FG_EXECUTE_CALL_BACK, callback);
            this.view.parent.addChildAt(this.view, this.view.parent.children.length - 1);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
            if (configData.fadeVolume) {
                configData.fadeVolume = false;
            } else {
                soundManager.fadeVolume(BehaviorCore.slotConstants.SoundConstant.FREGAME_BGLOOP, 250, 0.1, "soundList_1");
            }

            this.showBigWinState();
        }

        protected bigWinPresentationComplete(): void {
            this.emitter && (this.emitter.emit = false);
            this.emitter1 && (this.emitter1.emit = false);
            this.emitter2 && (this.emitter2.emit = false);
            soundManager.stop(BehaviorCore.slotConstants.SoundConstant.BIGWIN_LOOP);
            utils.delayedCall("hideBigWin", 1000, this.hideBigWin, this);
            if (this.tickupAmountLevel === 1) {
                this.winFrameAnimation.stopAnim();
                this.wnFrameSparkal.stopAnim();
            }
            soundManager.stop(this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpSoundFg(this.currentWinAmountTickUpFg), "soundList_1");
            soundManager.stop(this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpSoundFg(this.tickupAmount), "soundList_1");

        }
        protected stopBigWinAndTicker() {
            utils.killDelayedCall("hideGreatWinDelay");
            if (this.tickupAmountLevel === 1) {
                this.winMeter.stopTick(false, true, true, null);
                this.winMeter.setCurrencyFormattedValue(String(this.currentWinAmountTickUpFg));
            } else {
                this.bigWinMeter.stopTick(false, true, true, null);
                this.bigWinMeter.setCurrencyFormattedValue(String(this.currentWinAmountTickUpFg));
                if (this.nextTickUpState === "GREATWIN") {
                    this.view.getContainerByID("bigWinFrameContainer").visible = false;
                    this.view.getContainerByID("greatWinFrameContainer").visible = true;
                }
            }
            this.bigWinPresentationComplete();
            this.tickupAmountLevel = 0;
        }

        protected showBigWinState(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_STAGE_CLICK_FG);
            if (this.tickupAmountLevel === 1) {
                this.wintext.alpha = 0;
                soundManager.playSound(this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpSoundFg(this.currentWinAmountTickUpFg), 1, false, "soundList_1");
                this.view.getContainerByID("winContainer").visible = true;
                this.winMeter.setVisible(true);
                this.winMeter.startTick(this.currentWinAmountTickUpFg, true, false, this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpDurationFg(this.currentWinAmountTickUpFg), true, this.bigWinPresentationComplete.bind(this));
                this.winFrameAnimation = this.view.getAnimationById("win_Border_Animation");
                this.wnFrameSparkal = this.view.getAnimationById("win_Border_sparkel");
                this.winFrameAnimation.playAnim();
                this.winFrameSparkalAnimation();
                this.bigWinZoomInTween(1);
                this.bigWinFadeIn(1);
            } else if (this.tickupAmountLevel === 2) {
                this.bigWintext.alpha = 0;
                this.view.getContainerByID("bigGreatWinContainer").visible = true;
                this.view.getContainerByID("bigWinFrameContainer").visible = true;
                this.view.getContainerByID("greatWinFrameContainer").visible = false;
                this.bigWinMeter.setVisible(true);
                soundManager.playSound(this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpSoundFg(this.currentWinAmountTickUp), 1, false, "soundList_1");
                this.bigWinMeter.startTick(this.currentWinAmountTickUpFg, true, false, this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpDurationFg(this.currentWinAmountTickUpFg), true, this.bigWinPresentationComplete.bind(this));
                this.bigWinZoomInTween(2);
                this.bigWinFadeIn(2);
                this.startBigWinCoins();
            } else if (this.tickupAmountLevel === 3) {
                this.bigWintext.alpha = 0;
                this.nextTickUpState = "GREATWIN";
                this.view.getContainerByID("bigGreatWinContainer").visible = true;
                this.view.getContainerByID("bigWinFrameContainer").visible = true;
                this.view.getContainerByID("greatWinFrameContainer").visible = false;
                this.tickupAmount = ingenuity.BehaviorCore.slotConstants.SlotConstants.BigWinMultiplier * this.model.getTotalBet();
                this.bigWinMeter.setVisible(true);
                soundManager.playSound(this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpSoundFg(this.currentWinAmountTickUpFg), 1, false, "soundList_1");
                this.bigWinMeter.startTick(this.tickupAmount, true, false, core.constructors.bsBehavior.SlotConstants.BIG_WIN_TICKUP_DURATION, true, this.showGreatWinState.bind(this));
                this.bigWinZoomInTween(2);
                this.bigWinFadeIn(2);
                this.startBigWinCoins();
            }
        }

        protected showGreatWinState() {
            this.greatWintext.alpha = 0;
            this.view.getContainerByID("bigGreatWinContainer").visible = true;
            this.view.getContainerByID("bigWinFrameContainer").visible = false;
            this.view.getContainerByID("greatWinFrameContainer").visible = true;
            this.tickupAmount = ingenuity.BehaviorCore.slotConstants.SlotConstants.BigWinMultiplier * this.model.getTotalBet();
            if (this.currentWinAmountTickUpFg > this.tickupAmount) {
                this.bigWinMeter.startTick(this.currentWinAmountTickUpFg, true, false, core.constructors.bsBehavior.SlotConstants.GREAT_WIN_TICKUP_DURATION, true, this.bigWinPresentationComplete.bind(this));
                this.bigWinFadeOut(2);
                this.bigWinZoomInTween(3);
                this.bigWinFadeIn(3);
                this.startGreatWinCoins();
            } else {
                soundManager.stop(this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpSoundFg(this.currentWinAmountTickUp), "soundList_1");
                soundManager.stop(this.model instanceof FreeGame.Model && this.model.getWinMeterTickUpSoundFg(this.tickupAmount), "soundList_1");
                this.bigWinFadeOut(2);
                this.bigWinZoomInTween(3);
                this.bigWinFadeIn(3);
                this.startGreatWinCoins();
                utils.delayedCall("hideGreatWinDelay", 2000, () => {
                    utils.killDelayedCall("hideGreatWinDelay");
                    this.bigWinPresentationComplete();
                }, this);
            }
        }


        protected winFrameSparkalAnimation(): void {
            this.wnFrameSparkal.playAnim("anim", () => {
                this.winFrameSparkalAnimation();
            });
        }



        /**
       *
       * @param e stop bigwin presentation, reset tweens.
       * called in case of normal presentation end as well as by stage click
       */

        protected hideBigWin(e: IEvent) {
            utils.killDelayedCall("hideBigWin");
            utils.killDelayedCall("glowTweenDelay");
            this.glowTween && this.glowTween.stop();
            this.glowTween && currentGame.tweens.remove(this.glowTween);
            this.zoomInTween && this.zoomInTween.stop();
            this.zoomInTween && currentGame.tweens.remove(this.zoomInTween);
            this.fadeInTween && this.fadeInTween.stop();
            this.fadeInTween && currentGame.tweens.remove(this.fadeInTween);
            this.fadeOutTween && this.fadeOutTween.stop();
            this.fadeOutTween && currentGame.tweens.remove(this.fadeOutTween);
            this.view.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIGWIN_VIEW_FG);
            this.model.setIsBigWinRunning(false);
            if (this.model.getIsSpinClicked() === false) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.BIG_WIN_COMPLETE);
            }
            if (parserModel.getIsFreeSpinRetriggered()) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_TOTAL_WIN_MSG);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_FREEGAME_RETRIGGER_POPUP);
            } else {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_SPIN_CALL);
            }
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIG_WIN_FG, this.hideBigWincall);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SUMUP_BIGWIN_FG, this.stopBigWinAndTicker, this);
        }
    }
}