///<reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.BigWin {
    export class BigWinViewFg extends BehaviorCore.BigWin.BigWinView {

        constructor(json: any) {
            super(json);
            this.subscribeEvents();
        }

        /**
         * Overrided this function to subscribe events.
         */
        protected subscribeEvents(): void {
            this.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BIGWIN_VIEW_FG, this.show, this);
            this.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIGWIN_VIEW_FG, this.hide, this);
        }

        /**
         * unsubscribe events using in big win
         */
        public unSubscribeEvents(): void {
            this.off(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BIGWIN_VIEW, this.show, this);
            this.off(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BIGWIN_VIEW, this.hide, this);
        }

        protected hide(): void {
            super.hide();
            soundManager.fadeVolume(BehaviorCore.slotConstants.SoundConstant.FREGAME_BGLOOP, 250, 1, "soundList_1");
        }
    }
}