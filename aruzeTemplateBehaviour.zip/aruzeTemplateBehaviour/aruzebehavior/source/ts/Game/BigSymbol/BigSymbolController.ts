///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.bigSymbol {
    export class BigSymbolController {
        protected view: BehaviorCore.BaseGame.View | BehaviorCore.FreeGame.View;
        protected model: BehaviorCore.BaseGame.Model | BehaviorCore.FreeGame.Model;
        protected reelPanel: ingenuity.slot.reelPanel.ReelPanel;
        protected symbolsList: slot.symbol.StaticSymbol[] = new Array();
        protected animSymbolsList: any = new Array();
        protected staticSymbolsList: Array<slot.symbol.StaticSymbol | slot.symbol.AnimationSymbol>;
        // protected reelspining: boolean = false;

        constructor(view: BehaviorCore.BaseGame.View | BehaviorCore.FreeGame.View, model: BehaviorCore.BaseGame.Model | BehaviorCore.FreeGame.Model, reelPanel: ingenuity.slot.reelPanel.ReelPanel) {
            this.view = view;
            this.model = model;
            this.reelPanel = reelPanel;
            this.bindhandler();
            this.staticSymbolsList = new Array();
        }

        protected bindhandler(): void {
            if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.baseGameState) {
                dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BIG_SYMBOL, this.playLandingAnim, this);
                dispatcher.on(slot.slotConstants.SlotEventConstants.NOW_SPIN_REEL, this.onSpinReel, this);
                dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.RESET_BIG_SYMBOL, this.onSpinReel, this);
            } else {
                dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BIG_SYMBOL_FG, this.playLandingAnim, this);
                dispatcher.on(slot.slotConstants.SlotEventConstants.FG_NOW_SPIN_REEL, this.onSpinReel, this);
            }
        }

        public unbindhandler(): void {
            if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.freeGameState) {
                dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BIG_SYMBOL_FG, this.playLandingAnim, this);
                dispatcher.off(slot.slotConstants.SlotEventConstants.FG_NOW_SPIN_REEL, this.onSpinReel, this);
            }
        }

        protected playLandingAnim(evt: IEvent): void {
            const reelID: number = evt.data;
            const reelGrids: number[][] = this.model.getReelGrid();
            const reelgrid: number[] = reelGrids[reelID];
            let symbolCount: number = 0;
            // const reelID: number = evt.data;
            // let reelgrid: any = parserModel.getReelGrid()[e];

            // for (let a: number = 0; a < reelgrid.length; a++) {
            for (const a of reelgrid) {
                const symbolID: number = a;
                if (symbolID === ingenuity.configData.wildSymID) {
                    const symbol: slot.symbol.SymbolBase = this.view.getReelView().getSymbolByPos(reelID, symbolCount);
                    const staticSym: slot.symbol.StaticSymbol | slot.symbol.AnimationSymbol = symbol.getStatic();
                    const animSym: any = symbol.getAnimation();
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.PLAY_LANDING_ANIMATION_SOUND, "wild");
                    if (staticSym.parent) {
                        staticSym.visible = false;
                        animSym.visible = true;
                        animSym.children[0] && this.view.getReelView().getAnimReels()[reelID].addChild(animSym);
                        this.staticSymbolsList.push(staticSym);
                        this.animSymbolsList.push(animSym);
                        animSym.children[0] && animSym.children[0].animObj.landing.onComplete.removeAll();
                        if (animSym.children[0]) {
                            animSym.playAnim({
                                animName: "landing",
                                stopFrame: (symbol.json.animSym as slot.symbol.IAnimationSymbolData).posterFrame,
                                callback: () => {
                                    staticSym.visible = true;
                                    this.staticSymbolsList.shift();
                                    if (animSym.parent && (staticSym instanceof slot.symbol.StaticSymbol)) {
                                        const reel: any = (animSym.parent);
                                        animSym.visible = false;
                                        animSym.parent.addChild(animSym);
                                        this.animSymbolsList.shift();
                                        this.showBigSymbol(reel.reelId, (animSym.num + 1), animSym.gridPosition);
                                    }
                                },
                                cbScope: this
                            });
                        } else {
                            this.showBigSymbol(reelID, symbolID, symbolCount);
                        }
                    }
                } else {
                    this.showBigSymbol(reelID, symbolID, symbolCount);
                }
                symbolCount++;
            }
        }

        protected showBigSymbol(reelID: number, symbolID: number, symPositionOnReel: number): void {
            if (Array.isArray(BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID)) {
                if (BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID.indexOf(symbolID) !== -1) {
                    const symbol: slot.symbol.StaticSymbol = this.view.getReelView().getSymbolByPos(reelID, symPositionOnReel).getStatic() as slot.symbol.StaticSymbol;
                    const indexValue: number = symbol.gridPosition + 1;
                    symbol.data = { index: indexValue, parent: this.view.getReelView().getSymbolByPos(reelID, symPositionOnReel).parent };
                    symbol.visible = true;
                    this.view.getBigSymbolView().getContainerByID(BehaviorCore.slotConstants.SlotConstants.SYMBOL_CONTAINER + reelID).addChild(symbol);
                    this.symbolsList.push(symbol);
                }
            }
        }


        protected onSpinReel(evt: IEvent): void {
            // this.reelspining = true;
            for (const animsymbol of this.animSymbolsList) {
                // animsymbol.stopAnim();
                // animsymbol.parent.addChild(animsymbol);
                animsymbol.children[0] && animsymbol.children[0].animObj.landing.onComplete.removeAll();
                animsymbol.visible = false;
            }
            this.animSymbolsList.length = 0;

            for (const staticSym of this.staticSymbolsList) {
                staticSym.visible = true;
            }
            this.staticSymbolsList.length = 0;

            if (this.symbolsList.length) {
                for (const symbol of this.symbolsList) {
                    // symbol.data.parent.addChildAt(symbol, symbol.data.index);
                    if (symbol.data.index > symbol.data.parent.children.length - 1) {
                        symbol.data.parent.addChildAt(symbol, symbol.data.parent.children.length - 1);
                    } else {
                        symbol.data.parent.addChildAt(symbol, symbol.data.index);
                    }
                }
            }
            this.symbolsList.length = 0;


        }
    }
}
