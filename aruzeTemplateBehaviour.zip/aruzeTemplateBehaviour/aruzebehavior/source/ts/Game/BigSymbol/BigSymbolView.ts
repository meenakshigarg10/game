///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.bigSymbol {
    export class BigSymbolView extends BehaviorCore.BaseView {

    }
}
