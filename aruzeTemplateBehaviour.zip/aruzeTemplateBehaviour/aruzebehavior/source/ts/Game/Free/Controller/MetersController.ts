///<reference path="../../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.FreeGame {

    export class MetersController extends slot.FreeGame.MetersController {
        protected view: View;
        protected model: Model;
        protected winValueMeterFg: BehaviorCore.behaviourUI.WinTickupMeterBitmap;
        protected deviceWinMtrFg: ui.Container;

        constructor(view: View, model: Model) {
            super(view, model);
            this.view = view;
            this.model = model;
            this.winValueMeterFg = this.view.getMeterById(BehaviorCore.slotConstants.SlotConstants.WinMeterId) as BehaviorCore.behaviourUI.WinTickupMeterBitmap;
            this.deviceWinMtrFg = this.view.getContainerByID("winMeterContainer");
        }

        protected subscribeEvents() {
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_RESET_METERS, this.onResetMeters, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_START_WIN_TICK_UP, this.onStartWinTickUp, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_UPDATE_PAID_METER, this.onUpdatePaidMeter, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_UPDATE_TOTAL_WIN_METER, this.onUpdateTotalWinMeter, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.UPDATE_FREEGAME_LEFT_METER, this.onUpdateFreegameLeftMeter, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.ON_SET_FREEGAME_LEFT, this.onSetFreeGameLeftMeter, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_UPDATE_BALANCE_METER_AFTER, this.onUpdateBalanceMeterAfter, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_UPDATE_BALANCE_METER_AFTER_SPIN_CLICK, this.onUpdateBalanceMeterAfterSpinClick, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_UPDATE_BALANCE_METER, this.onUpdateBalanceMeter, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.STOP_METER_TICKUP, this.onStopMeterTickup, this);
            dispatcher.on(slotConstants.SlotEventConstants.CLEAR_PAID_METER, this.clearPaidMeter, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.FORCE_STOP_WIN_METER_TICKUP_FG, this.onForceStopWinTickUp, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR_FG, this.hideDeviceWinMeter, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.CONSOLE_TOTAL_WIN_METER, this.updateConsoleTotalWinMeter, this);
        }

        protected unsubscribeEvents() {
            super.unsubscribeEvents();
            dispatcher.off(slotConstants.SlotEventConstants.CLEAR_PAID_METER, this.clearPaidMeter);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.FORCE_STOP_WIN_METER_TICKUP_FG, this.onForceStopWinTickUp, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR_FG, this.hideDeviceWinMeter, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.CONSOLE_TOTAL_WIN_METER, this.updateConsoleTotalWinMeter, this);
        }

        /**
         * Override this function to show only free game win in total win meter
         * @param evt
         */
        protected onStartWinTickUp(evt: IEvent): void {
            this.view.addChildAt(this.deviceWinMtrFg, this.view.getIndex(this.view.getWinReelView()) + 1);
            this.deviceWinMtrFg.visible = true;
            this.winValueMeterFg && (this.winValueMeterFg.startTick(this.model.getCurrentWinAmt(), this.model.getIsCredits(), false, this.model.getWinMeterTickUpDurationFg(), true, this.tickUpComplete.bind(this)));
            soundManager.playSound(this.model.getWinMeterTickUpSoundFg(), 1, false, "soundList_1");
        }

        /**only for mobile
         * to hide winmeter container on spin clicked
         */
        protected hideDeviceWinMeter(): void {
            this.deviceWinMtrFg.visible = false;
        }

        /**
         * Override this function to show|hide total win meter
         * @param evt
         */
        protected onUpdateTotalWinMeter(evt: IEvent): void {
            if (this.totalWinMeter) {
                const freegameWin: number = this.model.getFreeSpinWin();
                if (freegameWin === 0) {
                    this.totalWinMeter.visible = false;
                } else {
                    this.totalWinMeter.visible = true;
                }

                if (this.totalWinMeter.isTicking) {
                    this.totalWinMeter.stopTick(this.model.getIsCredits(), false, true);
                }
                if (this.model.getIsCredits()) {
                    this.totalWinMeter.setCurrencyFormattedValue(this.model.getFreeSpinWin() + "");
                } else {
                    this.totalWinMeter.setFormattedValue(this.model.getFreeSpinWin() + "");
                }
            }
        }

        /***
         * Override this function to fireEvent CLEAR_PAID_METER instead of UPDATE_PAID_METER
         * onResetMeters, resets all meters available in games
         * @param evt
         */
        protected onResetMeters(evt: IEvent) {
            dispatcher.fireEvent(slotConstants.SlotEventConstants.CLEAR_PAID_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_BET_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_TOTAL_BET_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_STAKE_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_FREEGAME_LEFT_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_TOTAL_WIN_METER);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SET_WIN_VALUE_TO_DEFAULT);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.INCREASE_BS_BALANCE, { winAmount: parserModel.getUserBalance() });
        }

        /**
         * Override this function to update behavior of paid meter as base game
         */
        protected onUpdatePaidMeter(): void {
            const currWinAmnt: number = this.model.getCurrentWinAmt();
            if (this.winMeter) {
                if (this.winMeter.isTicking) {
                    this.winMeter.stopTick(this.model.getIsCredits(), false, true);
                    utils.delayedCall(slotConstants.SlotConstants.ClearWinDelay, slotConstants.SlotConstants.setDelayForClearWin || 300, () => {
                        utils.killDelayedCall(slotConstants.SlotConstants.ClearWinDelay);
                        if (this.model.getIsCredits()) {
                            this.winMeter.setCurrencyFormattedValue(this.model.getCurrentWinAmt().toString());
                        } else {
                            this.winMeter.setFormattedValue(this.model.getCurrentWinAmt() + "");
                        }
                        (currWinAmnt === 0) ? this.winMeter.visible = false : this.winMeter.visible = true;
                    });
                } else {
                    if (this.model.getIsCredits()) {
                        this.winMeter.setCurrencyFormattedValue(this.model.getCurrentWinAmt().toString());
                    } else {
                        this.winMeter.setFormattedValue(this.model.getCurrentWinAmt() + "");
                    }
                    (currWinAmnt === 0) ? this.winMeter.visible = false : this.winMeter.visible = true;
                }
            }
        }

        /**
         * Clear win meter
         */
        protected clearPaidMeter(): void {
            const currWinAmnt: number = 0;
            if (this.winMeter) {
                if (this.winMeter.isTicking) {
                    this.winMeter.stopTick(this.model.getIsCredits(), false, true);
                    utils.delayedCall(slotConstants.SlotConstants.ClearWinDelay, slotConstants.SlotConstants.setDelayForClearWin || 300, () => {
                        utils.killDelayedCall(slotConstants.SlotConstants.ClearWinDelay);
                        if (this.model.getIsCredits()) {
                            this.winMeter.setCurrencyFormattedValue(currWinAmnt.toString());
                        } else {
                            this.winMeter.setFormattedValue(currWinAmnt.toString());
                        }
                        this.winMeter.visible = false;
                    });
                } else {
                    if (this.model.getIsCredits()) {
                        this.winMeter.setCurrencyFormattedValue(currWinAmnt.toString());
                    } else {
                        this.winMeter.setFormattedValue(currWinAmnt.toString());
                    }
                    this.winMeter.visible = false;
                }
            }
        }

        /**
         * This function is used to send next freespin call, if no retriggering
         * else go for retrigger presentation
         * and show total win amount in fg
         */
        protected tickUpComplete() {
            if (parserModel.getIsFreeSpinRetriggered()) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_FREEGAME_RETRIGGER_POPUP);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED_IN_FREE_GAME);
            }
            dispatcher.fireEvent(slotConstants.SlotEventConstants.SHOW_TOTAL_WIN_MSG);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_WRAPPER_WIN);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_FG_TOTALWIN_IN_HISTORY);
            utils.delayedCall("showWinmeterIdle", 500, () => {
                utils.killDelayedCall("showWinmeterIdle");
                this.hideDeviceWinMeter();
            });
        }

        /**
        * Overriding for controlling number of freegames in case of retrigger
        */
        protected onUpdateFreegameLeftMeter(): void {
            //
        }


        /**
        *
        * @param evt called when spin is clicked to force stop the button panel winmeter tickup if running and after holding it for some time
        * then send next spin request.
        * also show stop button as sson as spin is clicked, if meter is ticking.
        * if not ticking, then to show stop button is being handled in slotlogic
        * since ther is no bounce on game force stop, so delay is added brfore sendinfg next spin call
        */
        protected onForceStopWinTickUp(evt?: IEvent): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
            parserModel.getFreeSpinsRemaining() && dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN_FG);
            if (this.winValueMeterFg.getIsTickUpRunning()) {
                dispatcher.fireEvent(slotConstants.SlotEventConstants.SHOW_TOTAL_WIN_MSG);
                soundManager.stop(this.model.getWinMeterTickUpSoundFg(), "soundList_1");
                this.winValueMeterFg.forceStop(this.model.getIsCredits(), false, true, BehaviorCore.slotConstants.SlotConstants.DELAY_FOR_NEXT_WIN_PRESENTATION, () => {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK_FG);
                });
            } else {
                this.winValueMeterFg.stopTickupAndDelay(BehaviorCore.slotConstants.SlotConstants.DELAY_FOR_NEXT_WIN_PRESENTATION, () => {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK_FG);
                });
            }
        }

        /**
         * To show FreegameTotalWinMeter in console
         */
        protected updateConsoleTotalWinMeter(value: IEvent): void {
            const totalWinMeter: ui.MeterBitmap = this.view.getMeterById("freeGameTotalWinValue") as ui.MeterBitmap;
            totalWinMeter.setValue(game.wrapper.gameWrapper.formatCurrency(parseFloat(value.data)));
        }


    }
}
