///<reference path="../../../Interfaces.ts" />
/* tslint:disable */
namespace ingenuity.BehaviorCore.FreeGame {

    export class ReelPanelController extends slot.FreeGame.ReelPanelController {
        protected model: Model;
        protected view: View;
        public scatterOnReel: number[];

        constructor(view: View, model: Model) {
            super(view, model);
            this.model = model;
            this.scatterOnReel = [0, 0, 0, 0, 0];
        }

        protected init(): void {
            this.reelView.getModel().reelGrid = ingenuity.utils.clone(this.model.getReelGrid());
            super.init();
            const reelCount: number = this.view.json.reels.reels.length;
            for (let a: number = 0; a < reelCount; a++) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BIG_SYMBOL_FG, a);
            }
        }

        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(slotConstants.SlotEventConstants.START_REEL_SPINNING, this.onStartReelSpinning, this);
            dispatcher.on(slotConstants.SlotEventConstants.SHOW_SYMBOLS_ON_GRID, this.showSymbolsOnGrid, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BROKEN_GAME_FG, this.onSpinComplete, this);
        }

        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(slotConstants.SlotEventConstants.START_REEL_SPINNING, this.onStartReelSpinning);
            dispatcher.off(slotConstants.SlotEventConstants.SHOW_SYMBOLS_ON_GRID, this.showSymbolsOnGrid);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BROKEN_GAME_FG, this.onSpinComplete, this);
        }

        /**
         * Show static reel grid
         * @param evt
         */
        protected showSymbolsOnGrid(evt: IEvent): void {
            const data: number[][] = evt.data.data || evt.data;
            const reelGrid: number[][] = (data.length > 0) ? data : this.model.getDefaultReelGrid();
            this.reelView.showStaticGrid(reelGrid);
        }

        protected onStartReelSpinning(evt: IEvent): void {
            this.reelView.fireEvent(slot.slotConstants.SlotEventConstants.SPIN);
            this.reelView.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA_ON_SYMBOL);
        }

        /**
         * Override this function to dispatch SET_IS_REEL_SPINNING event
         * @param evt
         */
        protected onSpinReel(evt: IEvent): void {
            super.onSpinReel(evt);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SET_IS_REEL_SPINNING, true);
        }

        /**
         * This fucntion is overrided to send gameplay ended.
         */

        protected onSpinComplete(evt: any): void {
            this.reelView.getModel().quickSpin = false;
            this.reelView.setStopNow(false);
            dispatcher.fireEvent(slotConstants.SlotEventConstants.SET_IS_REEL_SPINNING, false);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CHECK_FOR_WIN_AFTER_REEL_STOP);
            dispatcher.off(slot.slotConstants.SlotEventConstants.SHOW_ANTICIPATION, this.showAnticipation);

            if (!this.model.getIsWin()) {
                dispatcher.fireEvent(slotConstants.SlotEventConstants.SEND_CLOSE_IF_NO_WIN);
            }
        }

        /**
         * To check bonus landing on reels
         */
        protected checkForlandingAnim(symbolObj: any, listLength: number): void {
            let i: number, j: number;
            let symbolCount = 0;
            let symbolFound = false;
            const symbolNeeded = symbolCount + 1;
            const NumReel = this.reelView.getModel().numReels;
            for (i = 0; i < this.reelView.getModel().numReels; i++) {
                for (j = 0; j < this.model.getReelGrid()[i].length; j++) {
                    if (this.model.getReelGrid()[i][j] === symbolObj.symbolId) {
                        symbolFound = true;
                        break;
                    }
                }
                if (symbolFound) {
                    symbolCount++;
                    if (symbolFound && i < (NumReel - (symbolNeeded - symbolCount))) {
                        this.reelView.getModel().landingOnReel[i] = 1;
                    }
                    symbolFound = false;
                }
            }
        }

        protected checkForAnticipation(symbolObj: any, listLength: any): any {
            let i, j, k, n;
            let symbolCount = 0;
            const anticipation = [];
            let symbolFound = false;
            for (i = 0; i < this.reelView.getModel().numReels - 1; i++) {
                this.reelView.getModel().anticipationSpin[i] = 0;
                if (symbolObj.aniticipationRunOnReel[i] > -1) {
                    if (symbolCount >= symbolObj.symbolCount && symbolObj.aniticipationRunOnReel[i] !== -1) {
                        if (ingenuity.configData.anticipationRunAfterFeature) {
                            anticipation[i] = 1;
                            symbolCount = 0;
                        } else {
                            if (symbolCount >= symbolObj.symbolCount + 1) {
                                anticipation[i] = 0;
                            } else {
                                anticipation[i] = 1;
                            }
                        }
                    }
                }
                for (j = 0; j < this.model.getReelGrid()[i].length; j++) {
                    if (this.model.getReelGrid()[i][j] === symbolObj.symbolId && symbolObj.aniticipationRunOnReel[i] !== -1) {
                        symbolFound = true;
                        break;
                    }
                }
                if (symbolFound) {
                    symbolCount++;
                    symbolFound = false;
                }
            }
            this.anticipationList.push(anticipation);
            if (this.anticipationList.length === listLength) {
                for (k = 0; k < this.anticipationList.length; k++) {
                    for (n = 0; n < this.anticipationList[k].length; n++) {
                        if (this.anticipationList[k][n] === 1) {
                            this.reelView.getModel().anticipationSpin[n] = 1;
                        }
                    }
                }
            }
            this.checkForlandingAnim(symbolObj, listLength);
        }

        protected onReelStopped(evt?: IEvent): void {
            super.onReelStopped(evt);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BIG_SYMBOL_FG, utils.toInt(evt.toString()));
        }

        /**overrided to send landing symbols data on every reel */
        protected onReelStopping(evt?: IEvent): void {
            super.onReelStopping(evt);
            for (let m: number = 0; m < parserModel.getLandingSoundOnReel().length; m++) {
                const value: number = parserModel.getLandingSoundOnReel()[m][utils.toInt(evt.toString())];
                value && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.PLAY_LANDING_SOUNDS_FG, value);
            }
        }
    }
}
