///<reference path="../../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.FreeGame {
    export class WinPresentationController extends slot.FreeGame.WinPresentationController {
        protected model: Model; // model requires to access data to make decision for game behavior
        protected view: View;
        protected fiveofkindanimation: ui.AnimationBase;

        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.CHECK_BIG_WIN, this.checkBigWin, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.FG_EXECUTE_CALL_BACK, this.executeCallback, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_RETRIGGER_ANIMATION, this.onStartRetriggerScatterPresentation, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.MOVE_TO_NEXT_FREESPIN_AFTER_RETRIGGER, this.moveToNextFreeSpinAfterRetriggerPresentation, this);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.BEGIN_STAGE_CLICK, this.fgBeginStageClick, this);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.DISABLE_STAGE_CLICK, this.fgDisableStageClick, this);
            this.subscribeEventForBroken();
        }

        protected subscribeEventForBroken(): void {
            this.togglingCycle = 0;
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_WIN_CYCLE_COMPLETED, this.onWinCycleCompleted, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_LINE_ANIMATION_STARTED, this.onLineAnimStarted, this);
        }

        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.CHECK_BIG_WIN, this.checkBigWin, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.FG_EXECUTE_CALL_BACK, this.executeCallback, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_RETRIGGER_ANIMATION, this.onStartRetriggerScatterPresentation, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.MOVE_TO_NEXT_FREESPIN_AFTER_RETRIGGER, this.moveToNextFreeSpinAfterRetriggerPresentation, this);
            dispatcher.off(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.BEGIN_STAGE_CLICK, this.fgBeginStageClick, this);
            dispatcher.off(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.DISABLE_STAGE_CLICK, this.fgDisableStageClick, this);
        }

        protected onStartRetriggerScatterPresentation(evt: IEvent): void {
            const scattersLength = this.model.getTriggerScatterWinData()[0].positions.length;
            this.view.startFreeSpinRetriggerPresentation(scattersLength);
        }

        protected moveToNextFreeSpinAfterRetriggerPresentation(evt: IEvent) {
            if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.freeGameState) {
                parserModel.setIsFreeSpinRetriggered(false);
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK_FG);
            }
        }

        /**
         * Override this function to get toggling started
         * listened when First Toggle Cycle Presentation Starts in Game
         * @param evt
         */
        protected onStartFirstToggleCycle(evt: IEvent): void {
            this.reelView.setToggleingContinue(false);
            super.onStartFirstToggleCycle(evt);
        }

        /**
         * It is handler function of STAGE_CLICKED which is fire from BackgroundView as stage click.
         * @param {ingenuity.IEvent} evt
         */
        protected onStageClickedFG(evt: IEvent): void {
            if (configData.enableStageClick) {
                if (this.model.getIsBigWinRunning()) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SUMUP_BIGWIN_FG);
                }
                configData.enableStageClick = false;
            }
        }

        protected fgBeginStageClick(): void {
            currentGame.input.onDown.add(this.onStageClickedFG, this);
        }

        protected fgDisableStageClick(): void {
            currentGame.input.onDown.remove(this.onStageClickedFG, this);
        }

        /**
         * Overtide this function to play symbol sound
         * listened when Every Line Animation in game Ends
         * stop after a cycle of first toggle completes
         * @param evt
         */
        protected onLineAnimStarted(evt: IEvent): void {
            if (!(this.view.getWinReelView() as BehaviorCore.reelPanel.WinPresentationPanel).oneToggleCompletes) {
                this.playSymbolSound(evt.data.no);
            }
        }

        /**
         * Play symbol sound
         * @param {ingenuity.slot.reelPanel.Icon} Icon
         */
        protected playSymbolSound(sym: number): void {
            dispatcher.fireEvent(slotConstants.SlotEventConstants.PLAY_SYMBOL_SOUND, sym);
        }

        protected onShowSpaghtti(evt: IEvent) {
            if (this.paylineView) {
                const windata: IWinLineObject[] = parserModel.getLinesWinAllUniquePositions();
                dispatcher.fireEvent(ingenuity.core.constructors.bsBehavior.SlotEventConstants.SHOW_BASEGAME_WIN_ALPHA, windata);
                dispatcher.fireEvent(ingenuity.core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA_ON_SYMBOL, windata);
                if (this.model.getIsWin()) {
                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_SHOW_SPAGETTI, (): void => {
                        //
                    });
                    utils.killDelayedCall(slot.slotConstants.SlotConstants.SpaghettiDisplayTimer);
                } else {
                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_SHOW_SPAGETTI, {
                        callback() {
                            if (this.model.getIsBigWin()) {
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_HIDE_ALL_SPAGETTI);
                                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION);
                            }
                        },
                        callbackScope: this,
                        delayTimer: this.model.getDelayForSpaghttiDispaly()
                    });
                }
            } else {
                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION);
            }
        }

        /**
         * Override this function to subscribe LINE_ANIMATION_STARTED event
         *
         * When Reel Spinning Start below function subscribes events for Win Presentation
         * @param evt
         */
        protected onReelStartSubscribeEvents(evt: IEvent): void {
            super.onReelStartSubscribeEvents(evt);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_LINE_ANIMATION_STARTED, this.onLineAnimStarted, this);
        }

        /**
         * Override this function to unsubscribe LINE_ANIMATION_STARTED event
         *
         * below stops all running Win Animation in game
         */
        protected onStopAllWinAnimation(): void {
            super.onStopAllWinAnimation();
            dispatcher.off(slot.slotConstants.SlotEventConstants.FG_LINE_ANIMATION_STARTED, this.onLineAnimStarted);
        }

        /**
         * call next win presentation after big win hide
         */
        protected afterHideBigWin(): void {
            dispatcher.fireEvent(slotConstants.SlotEventConstants.AFTER_HIDE_BIG_WIN);
        }
        /**
         * overwritten to change the behaviour according to Base game
         */
        protected onShowAllFrames(): void {
            const windata: IWinLineObject[] = parserModel.getLinesWinAllUniquePositions();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_BASEGAME_WIN_ALPHA, windata);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA_ON_SYMBOL, windata);
            if (this.paylineView) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SHOW_ALL_FRAMES, {
                    callback() {
                        if (this.model.getIsBigWin()) {
                            dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION);
                        }
                    },
                    callbackScope: this,
                    delayTimer: this.model.getDelayForSpaghttiDispaly(), // TODO: add it to make it configurable
                    winData: windata
                });
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION);
            }
        }

        protected onStartBigWinPresentation(evt: IEvent) {
            this.cofigureEventOnBigWinHide();
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BIG_WIN_FG, {
                view: this.view,
                type: this.model.getIsBigWin(),
                win: this.model.getCurrentWinAmt()
            });
        }

        /**
         * to check bigwin status from freeGame model
         */
        protected checkBigWin(): boolean {
            const bigWinValue = this.model.getIsBigWin();
            if (bigWinValue > 0 && bigWinValue <= 3) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * to execute callback functions
         */
        protected executeCallback(evt: IEvent): void {
            let callback;
            let callbackScope = this;
            let delayTimer;
            if (typeof evt === "function") {
                callback = evt;
            } else {
                callback = evt.data.callback;
                callbackScope = evt.data.callbackScope;
                delayTimer = evt.data.delayTimer;
            }
            (typeof callback === "function") && (ingenuity.utils.delayedCall(slot.slotConstants.SlotConstants.SpaghettiDisplayTimer, delayTimer, callback, callbackScope));
        }

        /**
         * Overrided to add behavior specific actions on suspending win presentations
         */
        protected onSuspendWinPresentation(): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_DATA);
            if (this.paylineView) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_HIDE_ALL_SPAGETTI);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_HIDE_ALL_FRAMES);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_HIDE_ALL_WIN_PAYLINE);
            }
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.STOP_ALL_WIN_ANIMATION_ON_REEL);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.RESET_METERS);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA);
        }

        /**
        * Overrided to make First Toggle cyclic
        */
        protected onStartFirstToggleCycleWays(evt: IEvent) {
            this.reelView.setAnimateSymbol(true);
            if (parserModel.getHasFreeGamesWin()) {
                this.reelView.setToggleingContinue(false);
            } else {
                this.reelView.setToggleingContinue(true);
            }
            this.reelView.WIN_LINE_ANIM_TIMEOUT = BehaviorCore.slotConstants.SlotConstants.WIN_LINE_ANIM_TIMEOUT;
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.START_WAYS_ANIM, this.model.getWaysWinData());
        }

        /**
         *
         * @param evt overrided and kept empty intentionally
         */
        protected onScatterAnimationEnd(evt?: any): void {
            //
        }
    }
}