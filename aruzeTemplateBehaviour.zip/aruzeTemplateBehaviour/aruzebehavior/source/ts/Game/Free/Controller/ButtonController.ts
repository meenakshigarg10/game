///<reference path="../../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.FreeGame {
    export class ButtonController extends slot.FreeGame.ButtonController {
        protected view: View; // holds free game view
        protected model: Model; // holds free game data
        protected introContinueBtn: ui.ButtonBase;

        constructor(view: View, model: Model) {
            super(view, model);
            this.model = model;
            this.spaceKeyBoardEvent();

            /** hide spin stop and turbo buttons as per compliance */
            !parserModel.getIsTurboEnable() && this.hideTurboButtons();
            // hide Autoplay button as per compliance"
            !ingenuity.parserModel.getIsAutoPlayEnable() && this.hideAutoplayButtons();
            if (!parserModel.getIsSpinStopAvailable()) {
                this.hideSpinStopButton();
            } else if (configData.turboEnabled) {
                this.hideSpinStopButton();
            }
        }

        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN_FG, this.showStopBtn, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BUTTONS_CONTAINER, this.showButtonsContainer, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BUTTONS_CONTAINER, this.hideButtonsContainer, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_STAGE_CLICK_FG, this.enableStageClick, this);
        }

        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN_FG, this.showStopBtn, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BUTTONS_CONTAINER, this.showButtonsContainer, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.HIDE_BUTTONS_CONTAINER, this.hideButtonsContainer, this);
        }

        protected enableStageClick(evt: IEvent): void {
            configData.enableStageClick = true;
        }

        protected hideButtonsContainer(): void {
            this.view.getContainerByID("buttonsContainer").visible = false;
        }

        protected showButtonsContainer(): void {
            this.view.getContainerByID("buttonsContainer").visible = true;
        }

        protected hideAutoplayButtons(): void {
            this.view.getImageById("autoPlayOn") && (this.view.getImageById("autoPlayOn").visible = false);
            this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer).visible = false);
            this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer) && (this.view.getContainerByID(ingenuity.slot.slotConstants.SlotConstants.AutoPlayOnBtnContainer).alpha = 0);
            this.view.getImageById("AutoPlayOnBtnContainerglow") && (this.view.getImageById("AutoPlayOnBtnContainerglow").visible = false);
        }

        protected onSpinStopPressUp(): void {
            configData.spinStopPressed = true;
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, slotConstants.SlotConstants.SpinStopBtnId);
            if (this.spinStopBtn.visible) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                this.skipBtn.visible = true;
                this.spinStopBtn.visible = false;
            }
            dispatcher.fireEvent(slotConstants.SlotEventConstants.ON_SPIN_STOP_CLICKED);
        }

        protected onShowSkipBtnHideStopBtn(evt: IEvent): void {
            if (this.spinStopBtn) {
                this.spinStopBtn && (this.spinStopBtn.visible = false);
                this.skipBtn.visible = true;
                if (!parserModel.getIsFreeSpinRetriggered()) {
                    this.skipBtn.enableAndTint();
                    configData.enableSpacebar = true;
                }
                if (this.model.getIsBigWin() || (!this.model.getIsWin() && ingenuity.parserModel.getFreeSpinsRemaining() === 0)) {
                    this.onDisabledAllButtons();
                }
            }
        }

        protected showStopBtn() {
            if (parserModel.getIsSpinStopAvailable()) {
                if (!configData.turboEnabled) {
                    (this.spinStopBtn) && (
                        this.skipBtn.visible = false,
                        this.spinStopBtn.visible = true
                    );
                }
            }
        }

        protected onDisabledAllButtons(evt?: IEvent): void {
            super.onDisabledAllButtons(evt);
            configData.enableSpacebar = false;
        }

        protected onEnabledButton(evt: IEvent): void {
            let btnId: any;
            const eventArguments = evt.data ? evt.data : [];
            if (eventArguments.length) {
                for (btnId = 0; btnId < eventArguments.length; btnId++) {
                    if (typeof eventArguments[btnId] === "string") {
                        const btn = this.view.getbuttonArray()[eventArguments[btnId]] as ui.ButtonBase;
                        btn.enableAndTint();
                    } else {
                        eventArguments[btnId].enableAndTint();
                    }
                }
            }
        }

        protected onDisabledButton(evt: IEvent): void {
            let btnId: any;
            const eventArguments = evt.data ? evt.data : [];
            if (eventArguments.length) {
                for (btnId = 0; btnId < eventArguments.length; btnId++) {
                    if (typeof eventArguments[btnId] === "string") {
                        const btn = this.view.getbuttonArray()[eventArguments[btnId]] as ui.ButtonBase;
                        btn.disableAndTint();
                    } else {
                        eventArguments[btnId].disableAndTint();
                    }
                }
            }
        }

        protected spaceKeyBoardEvent(): void {
            if (configData.subscribeSpaceBarToSpin) {
                document.onkeydown = this.spaceKeyboardFunctionality.bind(this);
            }
        }

        public removeKeyUpListener(): void {
            document.onkeydown = null;
        }

        /**
        * Overrided to start keyboard functionality only when buttons are enableAndTint.
        * Space bar functionality should be enable when:
        *        - Skip button is in enable state and we can send spin request.
        *        - Stop button is in enable state and we Force stop the reel spin.
        *        - To suspend Win Presentation Skip button should be in enable state else presentation cannot skip with spaceBar.
        *
        **/
        protected spaceKeyboardFunctionality(event: KeyboardEvent): void {
            if (event.keyCode === 32 && configData.enableSpacebar && parserModel.getGameState() === BehaviorCore.slotConstants.SlotConstants.WRAPPER_ACTIVE_STATE) {
                if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                    if (!this.model.getIsTurboModeOn() && this.spinStopBtn && this.spinStopBtn.visible && this.spinStopBtn.input.enabled) {
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_FORCE_STOP);
                        configData.spinStopPressed = true;
                        configData.enableSpacebar = false;
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS, [slot.slotConstants.SlotConstants.SpinBtnId]);
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_BTN);
                    } else if (this.skipBtn && this.skipBtn.visible && this.skipBtn.input.enabled) {
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED_IN_FREE_GAME);
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_PLAYER_MSG);
                    }
                } else if (event.ctrlKey && (event.which === 61 || event.which === 107 || event.which === 173 || event.which === 109 || event.which === 187 || event.which === 189)) {
                    event.preventDefault();
                }
            }
        }

        /**
         * Overriding to check for Bonus if skip press in freegame
         * @param {ingenuity.ui.ButtonBase} btn
         */
        protected onSkipPressUp(btn?: ui.ButtonBase): void {
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SlotConstants.SkipBtnId);
            utils.killDelayedCall(core.constructors.bsBehavior.SlotConstants.DELAY_FOR_NEXT_FREESPIN);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
            utils.killDelayedCall(core.constructors.bsBehavior.SlotConstants.ClearBigWinCompleteDelayer);
            utils.delayedCall(core.constructors.bsBehavior.SlotConstants.ClearBigWinCompleteDelayer, core.constructors.bsBehavior.SlotConstants.ClearBigWinCompleteTimer / 2, () => {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.REMOVE_ALL_LISTNERS_FROM_STAGE);
            });
            dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.STOP_SYMBOL_SOUND);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED_IN_FREE_GAME);
        }

        /**
        * overrided to enable force-stop by keyboard on enable stop button
        */
        protected onEnableStopBtn(evt: IEvent) {
            this.spinStopBtn = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.SpinStopBtnId) as ui.ButtonBase;
            if (parserModel.getIsSpinStopAvailable()) {
                if (!configData.turboEnabled) {
                    (this.spinStopBtn) && (
                        this.skipBtn.visible = false,
                        this.spinStopBtn.visible = true,
                        this.spinStopBtn.enableAndTint(),
                        configData.enableSpacebar = true,
                        dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_ENABLE_BUTTON, [slotConstants.SlotConstants.SpinStopBtnId])
                    );
                }
            }
        }

        /**
         *
         * @param evt overrided and kept empty intentionally
         */
        protected nullSpinButton(evt: IEvent): void {
            //
        }

        /**
         * to hide spin stop button as per Compliance
         */
        protected hideSpinStopButton(): void {
            this.spinStopBtn.visible = false;
        }

        /**
         * to hide turbo buttons as per compliance
         */
        protected hideTurboButtons(): void {
            let turboEnableBtn = this.view.getImageById("turboModeEnableBtnFg");
            let turboDisableBtn = this.view.getImageById("turboModeDisableBtnFg");
            let turboBtnBg = this.view.getImageById("turboModeEnableBtnFg_Bg");
            turboEnableBtn && (turboEnableBtn.visible = false);
            turboDisableBtn && (turboDisableBtn.visible = false);
            turboBtnBg && (turboBtnBg.visible = false);
            this.view.getImageById("turboModeEnableBtnglow") && (this.view.getImageById("turboModeEnableBtnglow").visible = false);
        }
    }
}