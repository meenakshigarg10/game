///<reference path="../../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.FreeGame {
    export class FreeGameController extends slot.FreeGame.FreeGameController {

        protected view: View;
        protected model: Model;
        protected playerMsgView: ingenuity.BehaviorCore.PlayerMsg.PlayerMsgView;
        protected playerMsgController: ingenuity.BehaviorCore.PlayerMsg.PlayerMsgController;
        protected coinBet: ui.Meter;
        protected betMeter: ui.Meter;
        protected freeGameLogoContainer: ui.Container;
        protected isAnticipationSoundPlaying: boolean;
        protected reelPanelController: BehaviorCore.FreeGame.ReelPanelController;
        protected arrChildVisibleState: IObject[] = [];
        protected buttonController: ingenuity.BehaviorCore.FreeGame.ButtonController;
        protected bigSymbolController: bigSymbol.BigSymbolController;
        protected buttonContainer: ui.Container;

        constructor(view: View, model: Model, json: any, assetManager: any) {
            super(view, model, json, assetManager);
            this.view = view;
            this.model = model;
            this.json = json;
            this.setFreeGameValues();
            if ((configData.turboEnabled) && (configData.turboEnabled === true)) {
                this.activateTurboMode();
            } else {
                this.deactivateTurboMode();
            }
            this.buttonContainer = this.view.getContainerByID("buttonsContainer");
            this.checkBrokenGame();
        }

        protected checkBrokenGame(): void {
            if (parserModel.getFreeGameBroken()) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_FREESPIN_LABEL_COUNT, false);
                utils.delayedCall("showFreeGameDelay", 500, function () {
                    utils.killDelayedCall("showFreeGameDelay");
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_RESET_METERS);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BROKEN_GAME_FG);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_FREESPIN_CONTAINER);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_BASEGAME_VIEW);
                    parserModel.setFreeGameBroken(false);
                }, this);
            }
        }

        protected onInitializeAllControllers(evt: IEvent): void {
            super.onInitializeAllControllers(evt);
            if (BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID && BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID.length > 0) {
                this.initializeBigSymbolController();
            }
        }

        protected initializeBigSymbolController(): void {
            this.bigSymbolController = new core.constructors.bsBehavior.BigSymbolController(this.view, this.model, this.view.getReelView());
        }

        protected startspin(): void {
            this.startAutoSpin();
        }

        public freeGameOutroShow(evt: IEvent): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CREATE_INTRO_OUTRO);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_WIN_TOGGLE_PLAYER_MSG);
            ingenuity.utils.killDelayedCall("fadeOutIntro");
            const totalFreeGameWin: number = parserModel.getTotalWin();
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_OUTRO_WIN_AMOUNT, totalFreeGameWin);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.OUTRO_SHOW);
        }

        /**
         * Override this function to subscribe other events which are not subscribed in super function
         */
        protected subscribeEvents(): void {
            super.subscribeEvents();
            this.unsubscribeEventsFG();
            dispatcher.on(events.EventConstants.PLAY_SOUND, this.onPlaySound, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_NOW_SPIN_REEL, this.onSpinReel);
            dispatcher.on(events.EventConstants.BUTTON_RELESED, this.onButtonRelesed, this);
            this.view.getReelView().on(slot.slotConstants.SlotEventConstants.REEL_STOPPING, this.onReelStopping, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.PLAY_SYMBOL_SOUND, this.playSymbolSound, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_SCATTER_ANIMATION_STARTED, this.playScatterTriggeringSound);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, this.updateBottomBarWinValueComponent, this);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.SET_WIN_VALUE_TO_DEFAULT, this.resetWinValue, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.STOP_SYMBOL_SOUND, this.stopSymbolSound, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.SETUP_FG, this.onSetUpFreeGame);
            this.view.getReelView().on(slot.slotConstants.SlotEventConstants.FG_SPIN_COMPLETE, this.onSpinComplete, this);
            dispatcher.on(events.EventConstants.STOP_SOUND, this.onStopSound, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_SHOW_ANTICIPATION, this.playAnticipationSound, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_FREE_SPIN_VIEW, this.hideFreeGameView, this, true);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.ADD_PLAYER_MSG_ON_TOP, this.addPlayerMsgOnTop, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.FG_OUTRO_SHOW, this.freeGameOutroShow, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_FREESPIN_LABEL_COUNT, this.UpdateFreeSpinCounterText, this);
        }

        protected onPlaySound(e: IEvent): void {
            //
        }

        protected onSpinReel(e: IEvent): void {
            //
        }

        protected onButtonRelesed(e: IEvent): void {
            //
        }

        protected onReelStopping(e: IEvent): void {
            //
        }

        protected playSymbolSound(e: IEvent): void {
            //
        }

        protected stopSymbolSound(e?: IEvent): void {
            //
        }

        protected playScatterTriggeringSound(): void {
            //
        }

        /**
         * to implement turbo mode fuctionality
         */
        protected activateTurboMode(): void {
            this.model.setIsTurboModeOn(true);
            this.view.getImageById("turboModeDisableBtnFg").visible = false;
            this.view.getImageById("turboModeEnableBtnFg").visible = true;
        }

        /**
         * removes turbo mode fuctionality
         */
        protected deactivateTurboMode(): void {
            this.model.setIsTurboModeOn(false);
            this.view.getImageById("turboModeEnableBtnFg").visible = false;
            this.view.getImageById("turboModeDisableBtnFg").visible = true;
        }

        /**
        * This method is added to bring the player messages on Top
        */
        protected addPlayerMsgOnTop(): void {
            this.view.addChild(this.playerMsgView);
        }

        /**
         * Override for initialize behavior WinPresentationController
         */
        protected initializeWinPresentationController(): void {

            this.winPresentationController = new core.constructors.bsBehavior.FreeGameWinPresentationController(this.view, this.model) as slot.FreeGame.WinPresentationController;
        }

        /**
         * Override for initialize behavior ButtonController
         */
        protected initializeButtonController(): void {
            this.buttonController = new ingenuity.core.constructors.bsBehavior.FreeGameButtonController(this.view, this.model);
        }

        /**
         * Override for initialize behavior MeterController
         */
        protected initializeMeterController(): void {
            this.meterController = new ingenuity.core.constructors.bsBehavior.FreeGameMetersController(this.view, this.model);
        }

        /**
         * initializePlayerMsgController, initialize player msg controller
         *
         */
        protected initializePlayerMsgController(): void {
            this.playerMsgView = new core.constructors.bsBehavior.PlayerMsgView(this.json.playerMsg);
            this.playerMsgController = new core.constructors.bsBehavior.PlayerMsgController(this.playerMsgView, this.model, this.json.playerMsg, this.assets);
            this.buttonContainer.addChild(this.playerMsgView);
        }

        /**
         * Override for initialize Reel panel controller
         */
        protected initializeReelPanelController() {
            this.reelPanelController = new ingenuity.core.constructors.bsBehavior.FreeGameReelPanelController(this.view, this.model);
        }

        protected hideFreeGameView(): void {
            ingenuity.dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.SET_WIN_VALUE_TO_DEFAULT);
            ingenuity.dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
            ingenuity.dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_FREE_SPIN_OUTRO);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.CHANGE_BACKGROUND, BehaviorCore.slotConstants.SlotConstants.BASEGAME_BG_SHOW);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SUBSCRIBE_BASEVIEW_EVENTS);
            this.playerMsgController.unSubscribeFreeGameEvents();
        }

        protected onShowFreeGame(): void {
            this.showFreeSpinScreen();
            this.playerMsgView.visible = true;
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CHANGE_BACKGROUND, BehaviorCore.slotConstants.SlotConstants.FREEGAME_BG_SHOW);
            this.showFreegameWithAlphaTween();
        }

        protected showFreegameWithAlphaTween(): void {
            this.view.visible = true;
            this.view.alpha = 0.2;
            const freeGameFadeIn: bridge.ITween = currentGame.add.tween(this.view).to({ alpha: 1 }, ingenuity.BehaviorCore.slotConstants.SlotConstants.FREE_GAME_FADE_IN_TIME, undefined, true);
            freeGameFadeIn.onComplete.add(() => {
                (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) && this.view.onShowPortraitButtonpanel();
                this.view.getContainerByID("portraitButtonsContainer") && (this.view.getContainerByID("portraitButtonsContainer").visible = true);
                freeGameFadeIn.stop();
                currentGame.tweens.remove(freeGameFadeIn);
            }, this);
        }

        protected showFreeSpinScreen(): void {
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.ENABLE_FREEGAME_BG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN_FG);
        }
        /**to hide fg view and button containers on stage
          *to remove button container and portrait button container free game objects
          */
        protected onHideFreeGame(): void {
            if (this.view && this.view.getContainerByID("buttonsContainer")) {
                this.view.addChild(this.view.getContainerByID("buttonsContainer"));
                this.view.getContainerByID("buttonsContainer").visible = false;
                this.view.getContainerByID("portraitButtonsContainer") && this.view.addChild(this.view.getContainerByID("portraitButtonsContainer"));
                this.view.getContainerByID("portraitButtonsContainer") && (this.view.getContainerByID("portraitButtonsContainer").visible = false);
                this.view.visible = false;
            }
        }

        // to start spin inside free spins automatically
        protected startAutoSpin(): void {
            ingenuity.utils.killDelayedCall(core.constructors.bsBehavior.SlotConstants.DELAY_FOR_NEXT_FREESPIN);
            const nextAction: string = ingenuity.parserModel.getNextAction();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_TOTAL_WIN_MSG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SUSPEND_WINPRESENTATION);
            utils.killDelayedCall(core.constructors.bsBehavior.SlotConstants.ClearBigWinCompleteDelayer);
            utils.delayedCall(core.constructors.bsBehavior.SlotConstants.ClearBigWinCompleteDelayer, core.constructors.bsBehavior.SlotConstants.ClearBigWinCompleteTimer / 2, () => {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.REMOVE_ALL_LISTNERS_FROM_STAGE);
            });
            this.model.resetForSpin();
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED_IN_FREE_GAME);
            if (nextAction === "" && parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN);
                this.model.resetForSpin();
            }
        }

        /**
         * To unsubscibe freegame events
         */
        protected unsubscribeEventsFG(): void {
            this.buttonController && this.buttonController.removeKeyUpListener();
            this.buttonController = null;
            dispatcher.off(slot.slotConstants.SlotEventConstants.SETUP_FG);
            this.view.getReelView().off(slot.slotConstants.SlotEventConstants.FG_SPIN_COMPLETE, this.onSpinComplete, this);
            dispatcher.off(events.EventConstants.STOP_SOUND, this.onStopSound);
            dispatcher.off(slot.slotConstants.SlotEventConstants.FG_SHOW_ANTICIPATION, this.playAnticipationSound);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_FREE_SPIN_VIEW, this.hideFreeGameView, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.ADD_PLAYER_MSG_ON_TOP, this.addPlayerMsgOnTop, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.FG_OUTRO_SHOW, this.freeGameOutroShow, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_FREESPIN_LABEL_COUNT, this.UpdateFreeSpinCounterText, this);

            this.bigSymbolController && this.bigSymbolController.unbindhandler();

            dispatcher.off(events.EventConstants.PLAY_SOUND, this.onPlaySound);
            dispatcher.off(slot.slotConstants.SlotEventConstants.NOW_SPIN_REEL, this.onSpinReel);
            dispatcher.off(events.EventConstants.BUTTON_RELESED, this.onButtonRelesed);
            this.view.getReelView().off(slot.slotConstants.SlotEventConstants.REEL_STOPPING, this.onReelStopping, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.PLAY_SYMBOL_SOUND, this.playSymbolSound, this);
            dispatcher.off(slot.slotConstants.SlotEventConstants.FG_SCATTER_ANIMATION_STARTED, this.playScatterTriggeringSound);
            dispatcher.off(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, this.updateBottomBarWinValueComponent, this);
            dispatcher.off(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.SET_WIN_VALUE_TO_DEFAULT, this.resetWinValue, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.STOP_SYMBOL_SOUND, this.stopSymbolSound, this);
        }

        /**
         * New function for playing and stopping anticipation
         */
        protected playAnticipationSound(): void {
            if (!this.isAnticipationSoundPlaying) {
                this.isAnticipationSoundPlaying = true;
                soundManager.playSound(core.constructors.bsBehavior.SoundConstants.ANTICIPATION_SOUND);
            }
        }

        /**
         * To stop tickup sound
         * @param {ingenuity.IEvent} e
         */
        protected onStopSound(e: IEvent): void {
            switch (e.data) {
                case core.constructors.bsBehavior.SlotConstants.FREE_GAME_TICKUP:
                    soundManager.stop(core.constructors.bsBehavior.SoundConstants.WIN_TICKUP);
                    break;
            }
        }

        /**
         * To initialise all freegame comtrollers
         */
        protected onSetUpFreeGame(): void {
            dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_FG);
        }
        /**
         * To set freegame meters
         */
        private setFreeGameValues(): void {
            this.coinBet = this.view.getMeterById("bet") as ui.Meter;
            this.betMeter = this.view.getMeterById("totalbet") as ui.Meter;
            if (this.coinBet) {
                this.coinBet.setCurrencyFormattedValue(String(this.model.getCurrentBet()));
            }
            if (this.betMeter) {
                if (this.model.getIsCredits()) {
                    this.betMeter.setCurrencyFormattedValue(this.model.getTotalBet().toString());
                } else {
                    this.betMeter.setFormattedValue(this.model.getTotalBet().toString());
                }
            }

        }

        /**
         * To handle things in spin complete
         * @param {ingenuity.IEvent} e
         */
        protected onSpinComplete(e?: IEvent): void {
            this.reelPanelController.scatterOnReel = [0, 0, 0, 0, 0];
            soundManager.stop(core.constructors.bsBehavior.SoundConstants.REEL_SPIN1);
        }

        protected UpdateFreeSpinCounterText(data: IObject): void {
            if (!parserModel.getIsFreeSpinRetriggered()) {
                this.view.UpdateFreeSpinCounterText(data);
            } else {
                this.view.updateNewAwardedFreespinsNumber();
            }
        }

        /**
         * State events unsubscribe , state shut down, and remove spacebar event listener.
         */
        public shutdown(): void {
            this.unsubscribeEventsFG();
            dispatcher.off(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_FG, this.onInitializeAllControllers, this);
            dispatcher.off(slot.slotConstants.SlotEventConstants.HIDE_FREEGAME_VIEW, this.onHideFreeGame, this);
            dispatcher.off(slot.slotConstants.SlotEventConstants.SHOW_FREEGAME_VIEW, this.onShowFreeGame, this);
            this.view.killView();
        }

        /**
         * to Update Win Value after close request sent and win presentation is over
         */
        protected updateBottomBarWinValueComponent(evt: IEvent): void {
            const winValueObject: IObject = evt.data;
            const winValue: string = winValueObject.value;
            this.view.setWinValue(winValue, true);
        }

        /**
         * to reset Win Value in new game
         */
        protected resetWinValue(): void {
            this.view.setWinValue(BehaviorCore.slotConstants.SlotConstants.RESET_WIN_VLAUE, true);
        }

    }
}
