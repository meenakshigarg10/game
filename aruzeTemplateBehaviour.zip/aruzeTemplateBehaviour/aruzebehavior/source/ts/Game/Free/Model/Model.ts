///<reference path="../../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.FreeGame {
    export class Model extends slot.FreeGame.Model {

        protected isAnyFeature: boolean = false;
        protected isBigWinRunning: boolean = false;
        protected isBigWinLoaded: boolean = false;
        protected reelSpinning: boolean = false;
        protected isSpinClicked: boolean = false;
        protected anticipationArray: number[];
        private isBonusReturningToFG: boolean = false;
        private stickySymbolOffset: number[] = [];

        /**
         * Default Reel Grid
         */
        public defaultReelGrid: number[][] = [
            [8, 6, 2],
            [8, 5, 3],
            [4, 7, 0],
            [1, 6, 3],
            [6, 3, 7]
        ];
        protected serverModel: ingenuity.platform.aruze.Model;

        constructor(serverModel: ingenuity.platform.aruze.Model) {
            super(serverModel);
            if (ingenuity.configData.animatedLineWinFrames !== undefined && ingenuity.configData.animatedLineWinFrames) {
                this.setAnimationSequence(["showAllFrames", "bigWin", "firstToggle", "triggeringAnimation", "bonus", "freeSpin", "checkForAutoplay"]);
            } else {
                this.setAnimationSequence(["Spaghtti", "bigWin", "firstToggle", "secondToggle", "bonus", "freeSpin", "checkForAutoplay"]);
            }
            this.setTickUpDuration(slotConstants.SlotConstants.WinTickUpDuration);
            this.setFiveOfAKindDisplayTime(slotConstants.SlotConstants.FiveOfAKindDisplayTime);
            this.setDelayForSpaghttiDispaly(slotConstants.SlotConstants.setDelayForSpaghettiDispaly);
        }

        /**
         * get bet array
         * @return {any | Array<number>}
         */
        public getAllowBetOptions(): number[] {
            return this.serverModel.getAllowBetOptions();
        }

        /**
         * get selected line
         * @return {any | number}
         */
        public getSelectedLines(): number | number[] {
            return this.serverModel.getSelectedLines();
        }

        /**
         * set current bet
         * @param {number} value
         */
        public setCurrentBet(value: number): void {
            this.serverModel.setCurrentBet(value);
        }

        /**
         * set current bet index
         * @param {number} value
         */
        public setCurrentBetIndex(value: number): void {
            this.serverModel.setCurrentBetIndex(value);
        }

        /**
         * set total bet
         * @param {number} value
         */
        public setCurrentTotalBet(value: number): void {
            this.serverModel.setCurrentTotalBet(value);
        }

        /**
         * get is scatter trigger or not
         */
        public getHasScatterWins(): boolean {
            return this.serverModel.getHasScatterWins();
        }

        /**
         * get is scatter Win Data
         */
        public getScatterWinData(): IWinLineObject[] {
            return this.serverModel.getScatterWinData();
        }

        /**
         * Override this function because this is retuning blank in slot
         *
         * returns is 5OAK available or not in game
         *
         * @returns {any}
         */
        public getIs5OfKindAvailable() {
            return this.serverModel.get5OfKind();
        }

        /**
         * set big win is running
         * @param value {boolean}
         */
        public setIsBigWinRunning(value: boolean): void {
            this.isBigWinRunning = value;
        }

        public setIsBigWinLoaded(value: boolean): void {
            this.isBigWinLoaded = value;
        }
        /**
         * get is big win running or not
         * @return {boolean}
         */
        public getIsBigWinRunning(): boolean {
            return this.isBigWinRunning;
        }

        /**
         * getter for any Feature triggered
         * @returns {boolean}
         */
        public getIsSpinClicked(): boolean {
            return this.isSpinClicked;
        }

        /**
         * setter for any feature triggered
         * @param value {boolean}
         */
        public setIsSpinClicked(value: boolean): void {
            this.isSpinClicked = value;
        }

        /**
         * Override this function to update this.serverModel.getTotalWin() from this.serverModel.getTotalWin()
         *
         * getIsBigWin, returns is Big Win available or not in game.
         * @returns {number} returns a number 0 means no big win, a higher number means a bigger win.
         *      1 means big win @ 10 times more
         */
        public getIsBigWin(winAmount?: number): number {
            if (this.isBigWinLoaded === false) {
                return 0;
            }
            let win: number = this.getCurrentWinAmt();
            if (winAmount !== undefined) {
                win = winAmount;
            }
            const currBet = this.serverModel.getCurrentTotalBet();
            if (win >= currBet * 45) {
                return 3;
            } else if (win >= currBet * 20) {
                return 2;
            } else if (win >= currBet * 10) {
                return 1;
            } else {
                return 0;
            }
        }

        /**
         * This function get action from server model.
        */
        public getAction(): string {
            return this.serverModel.getAction();
        }

        /**
         * This function get free spins remaining from server model.
        */
        public getFreeSpinsRemaining(): number {
            return this.serverModel.getFreeSpinsRemaining();
        }

        /**
         * This function get is reel spinning
         */
        public getIsReelSpinning(): boolean {
            return this.reelSpinning;
        }

        /**
         * This function set is reel spinning
         * @param value
         */
        public setIsReelSpinning(value: boolean): void {
            this.reelSpinning = value;
        }

        /**
        * Getter method to detect if FreePlay mode is on or Not
        * @returns - Boolean
        */
        public getFreePlayModeOn(): boolean {
            return this.serverModel.getFreePlayModeOn();
        }

        /**
        * Setter method to set if FreePlay mode is on or Not
        * @param - boolean
        */
        public setFreePlayModeOn(bool: boolean): void {
            this.serverModel.setFreePlayModeOn(bool);
        }

        public setReelGrid(value: number[][]): void {
            this.serverModel.setReelGrid(value);
        }

        /**
         * to get/set anticipation value in basegame
         */
        public getAnticipationArray(): number[] {
            return this.anticipationArray;
        }
        /**
         * Update anticipation array
         */
        public setAnticipationArray(value: number[]): void {
            this.anticipationArray = value;
        }
        /**
         * to get/set getIsBonusReturningToFG value in freegame
         */
        public getIsBonusReturningToFG(): boolean {
            return this.isBonusReturningToFG;
        }
        /**
         * set setIsBonusReturningToFG
         */
        public setIsBonusReturningToFG(value: boolean): void {
            this.isBonusReturningToFG = value;
        }

        /**
         * getter for default reel grid
         */
        public getDefaultReelGrid(): number[][] {
            return this.defaultReelGrid;
        }

        /**
         * To get/set anticipation value in freegame
         */
        public getStickySymbolOffSet(): number[] {
            return this.stickySymbolOffset;
        }

        /**
         * To set sticky symbol offset in freegame
         */
        public setStickySymbolOffSet(value: number[]): void {
            this.stickySymbolOffset = value;
        }

        public getIsWin(): boolean {
            return (this.serverModel.getHasWin() || (this.serverModel.getTriggerScatterWinData().length > 0 && this.serverModel.getTriggerScatterWinData()[0].win > 0));
        }

        /**
         * to get multiple winmeter tickup durations as per tickup sounds
         */
        public getWinMeterTickUpDurationFg(evt?: number): number {
            // const winAmount: number = evt ? evt : this.getTotalWinAmt();
            const winAmount: number = evt ? evt : this.getCurrentWinAmt();
            if (this.getIsBigWin()) {
                if (winAmount >= this.getTotalBet() * 10 && winAmount < this.getTotalBet() * 12) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_18;
                } else if (winAmount >= this.getTotalBet() * 12 && winAmount < this.getTotalBet() * 15) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_19;
                } else if (winAmount >= this.getTotalBet() * 15 && winAmount < this.getTotalBet() * 20) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_20;
                } else if (winAmount >= this.getTotalBet() * 20 && winAmount < this.getTotalBet() * 30) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_21;
                } else if (winAmount >= this.getTotalBet() * 30 && winAmount < this.getTotalBet() * 40) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_22;
                } else if (winAmount >= this.getTotalBet() * 40 && winAmount < this.getTotalBet() * 50) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_23;
                } else if (winAmount >= this.getTotalBet() * 50) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_24;
                }
            } else {
                if (winAmount < this.getTotalBet() * 0.1) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_1;
                } else if (winAmount >= this.getTotalBet() * 0.1 && winAmount < this.getTotalBet() * 0.2) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_2;
                } else if (winAmount >= this.getTotalBet() * 0.2 && winAmount < this.getTotalBet() * 0.3) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_3;
                } else if (winAmount >= this.getTotalBet() * 0.3 && winAmount < this.getTotalBet() * 0.4) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_4;
                } else if (winAmount >= this.getTotalBet() * 0.4 && winAmount < this.getTotalBet() * 0.5) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_5;
                } else if (winAmount >= this.getTotalBet() * 0.5 && winAmount < this.getTotalBet() * 0.75) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_6;
                } else if (winAmount >= this.getTotalBet() * 0.75 && winAmount < this.getTotalBet() * 1) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_7;
                } else if (winAmount >= this.getTotalBet() * 1 && winAmount < this.getTotalBet() * 1.25) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_8;
                } else if (winAmount >= this.getTotalBet() * 1.25 && winAmount < this.getTotalBet() * 1.5) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_9;
                } else if (winAmount >= this.getTotalBet() * 1.5 && winAmount < this.getTotalBet() * 2) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_10;
                } else if (winAmount >= this.getTotalBet() * 2 && winAmount < this.getTotalBet() * 3) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_11;
                } else if (winAmount >= this.getTotalBet() * 3 && winAmount < this.getTotalBet() * 4) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_12;
                } else if (winAmount >= this.getTotalBet() * 4 && winAmount < this.getTotalBet() * 5) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_13;
                } else if (winAmount >= this.getTotalBet() * 5 && winAmount < this.getTotalBet() * 6) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_14;
                } else if (winAmount >= this.getTotalBet() * 6 && winAmount < this.getTotalBet() * 7) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_15;
                } else if (winAmount >= this.getTotalBet() * 7 && winAmount < this.getTotalBet() * 8) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_16;
                } else if (winAmount >= this.getTotalBet() * 8 && winAmount < this.getTotalBet() * 10) {
                    return BehaviorCore.slotConstants.SlotConstants.WINTICKUP_FG_17;
                }
            }
        }


        /**
        * to play multiple win tickup sounds
        */
        public getWinMeterTickUpSoundFg(evt?: number): string {
            // const winAmount: number = evt ? evt : this.getTotalWinAmt();
            const winAmount: number = evt ? evt : this.getCurrentWinAmt();
            if (this.getIsBigWin()) {
                if (winAmount >= this.getTotalBet() * 10 && winAmount < this.getTotalBet() * 12) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_18;
                } else if (winAmount >= this.getTotalBet() * 12 && winAmount < this.getTotalBet() * 15) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_19;
                } else if (winAmount >= this.getTotalBet() * 15 && winAmount < this.getTotalBet() * 20) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_20;
                } else if (winAmount >= this.getTotalBet() * 20 && winAmount < this.getTotalBet() * 30) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_21;
                } else if (winAmount >= this.getTotalBet() * 30 && winAmount < this.getTotalBet() * 40) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_22;
                } else if (winAmount >= this.getTotalBet() * 40 && winAmount < this.getTotalBet() * 50) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_23;
                } else if (winAmount >= this.getTotalBet() * 50) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_24;
                }
            } else {
                if (winAmount < this.getTotalBet() * 0.1) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_1;
                } else if (winAmount >= this.getTotalBet() * 0.1 && winAmount < this.getTotalBet() * 0.2) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_2;
                } else if (winAmount >= this.getTotalBet() * 0.2 && winAmount < this.getTotalBet() * 0.3) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_3;
                } else if (winAmount >= this.getTotalBet() * 0.3 && winAmount < this.getTotalBet() * 0.4) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_4;
                } else if (winAmount >= this.getTotalBet() * 0.4 && winAmount < this.getTotalBet() * 0.5) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_5;
                } else if (winAmount >= this.getTotalBet() * 0.5 && winAmount < this.getTotalBet() * 0.75) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_6;
                } else if (winAmount >= this.getTotalBet() * 0.75 && winAmount < this.getTotalBet() * 1) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_7;
                } else if (winAmount >= this.getTotalBet() * 1 && winAmount < this.getTotalBet() * 1.25) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_8;
                } else if (winAmount >= this.getTotalBet() * 1.25 && winAmount < this.getTotalBet() * 1.5) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_9;
                } else if (winAmount >= this.getTotalBet() * 1.5 && winAmount < this.getTotalBet() * 2) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_10;
                } else if (winAmount >= this.getTotalBet() * 2 && winAmount < this.getTotalBet() * 3) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_11;
                } else if (winAmount >= this.getTotalBet() * 3 && winAmount < this.getTotalBet() * 4) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_12;
                } else if (winAmount >= this.getTotalBet() * 4 && winAmount < this.getTotalBet() * 5) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_13;
                } else if (winAmount >= this.getTotalBet() * 5 && winAmount < this.getTotalBet() * 6) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_14;
                } else if (winAmount >= this.getTotalBet() * 6 && winAmount < this.getTotalBet() * 7) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_15;
                } else if (winAmount >= this.getTotalBet() * 7 && winAmount < this.getTotalBet() * 8) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_16;
                } else if (winAmount >= this.getTotalBet() * 8 && winAmount < this.getTotalBet() * 10) {
                    return BehaviorCore.slotConstants.SoundConstant.WIN_SOUND_FG_17;
                }
            }
        }
    }
}
