///<reference path="../../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.FreeGame {
    export class View extends slot.FreeGame.View {
        protected spinBtn: ui.ButtonBase;
        protected stopBtn: ui.ButtonBase;
        protected consoleButtonBase: ui.Bitmap;
        protected betLabel: ui.Label;
        protected lineLabel: ui.Label;
        protected paidmeter: ui.Label;
        protected buttonsContainer: ui.Container;
        protected freeGameLogo: ui.Bitmap;
        protected totalbet: ui.Meter;
        protected totalLines: ui.Meter;
        protected playerMsgView: ingenuity.BehaviorCore.PlayerMsg.PlayerMsgView; // using this variable in FreeGameState
        protected freePlayCancelButton: ui.ButtonBase;
        protected maskImageObj: ui.Bitmap;
        protected baseGameAlpha: ui.Container;
        protected counterImage: any;
        protected counterImageX: number;
        protected counterImageY: number;
        protected reteriggerTextContainer: ui.Container;
        protected reteriggerCounterContainer: ui.Container;
        protected autoPlayOn: ui.ButtonBase;
        protected fiveOfkindTimer: number;
        protected totalFreespin: ui.MeterBitmap;
        protected remainingFreespin: ui.MeterBitmap;
        protected lblWinValue: BehaviorCore.behaviourUI.MeterBitmap;
        private bigSymbolView: bigSymbol.BigSymbolView;
        protected FGBalanceMeter: ui.MeterBitmap | ui.Meter;
        protected CurrentOrientation: string = "";
        protected portraitButtonsContainer: ui.Container;
        protected PortraitplayerMsgContainer: ui.Container;

        constructor(viewJson: any) { // ingenuity.currentGame
            super(viewJson);
            this.resize({ data: deviceEnv.update() });
            this.initializeComponents();
            this.subscibeEvents();
            this.initializeElemnets();
            if (ingenuity.deviceEnv.isDesktop) {
                this.autoPlayOn = this.getButtonById("autoPlayOn") as ui.ButtonBase;
            }
            this.FreeGamePortraitLandscapeViewChange();
        }

        protected subscibeEvents(): void {
            this.unsubscribeEvents();
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_BASEGAME_WIN_ALPHA, this.showAlpha, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA_ON_SYMBOL, this.hideAlphaOnSymbol, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA, this.hideAlpha, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.RESET_BASEGAME_WIN_ALPHA, this.showAlpha, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.PLAY_LANDING_SOUNDS_FG, this.checkAndPlayLandingSounds, this);
        }

        protected unsubscribeEvents(): void {
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.PLAY_LANDING_SOUNDS_FG, this.checkAndPlayLandingSounds, this);
        }

        /**
         * to initialize UI components
         */
        protected initializeComponents(): void {
            this.totalFreespin = this.getMeterById("TotalFreespin") as ui.MeterBitmap;
            this.totalFreespin.anchor.set(0.5, 0.5);
            this.remainingFreespin = this.getMeterById("RemainingFreespin") as ui.MeterBitmap;
            this.remainingFreespin.anchor.set(0.5, 0.5);
            this.lblWinValue = this.getMeterById(ingenuity.BehaviorCore.slotConstants.SlotConstants.WIN_VALUE) as BehaviorCore.behaviourUI.MeterBitmap;
            this.FGBalanceMeter = this.getMeterById("creditValue");
            if (BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID && BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID.length > 0) {
                this.initializeBigSymbolView();
            }
            if (parserModel.getGameMode() !== BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                this.FGBalanceMeter.setCurrencyFormattedValue(parserModel.getBalance().toString());
            }
            this.portraitButtonsContainer = this.getContainerByID("portraitButtonsContainer");
            this.PortraitplayerMsgContainer = this.getContainerByID("PortraitplayerMsgContainer");
        }

        protected initializeBigSymbolView(): void {
            if (BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID && BehaviorCore.slotConstants.SlotConstants.BIGSYMBOLID.length > 0) {
                this.bigSymbolView = new ingenuity.core.constructors.bsBehavior.BigSymbolView(ingenuity.assetsData.getJSONById("main_data").bigSymbolPresentationFG);
            }
            this.getContainerByID(BehaviorCore.slotConstants.SlotConstants.REELS_CONTAINER_FG).addChildAt(this.bigSymbolView, 0);
        }

        public getBigSymbolView(): bigSymbol.BigSymbolView {
            return this.bigSymbolView;
        }

        public landingAnimation(data: any, callback?: () => void, callbackScope?: any): void {
            const reelgrid = data[0];
            const reelview: slot.reelPanel.ReelPanel = data[1];
            const reelId = data[2];
            for (let i = 0; i < reelgrid[reelId].length; i++) {
                if (this.json.reels.symbolData[reelgrid[reelId][i] - 1].hasLanding) {
                    const symbol: slot.symbol.SymbolBase = reelview.getSymbolByPos(reelId, i);
                    const staticSym: slot.symbol.StaticSymbol | slot.symbol.AnimationSymbol = symbol.getStatic();
                    const animSym: slot.symbol.AnimationSymbol | slot.symbol.SpineSymbol | slot.symbol.StaticSymbol | slot.symbol.LayeredAnimationSymbol = symbol.getAnimation();
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.PLAY_LANDING_ANIMATION_SOUND, "scatter_" + reelId);
                    if (animSym instanceof slot.symbol.LayeredAnimationSymbol) {
                        const staticSymParent: ui.Container = staticSym.parent as ui.Container;
                        if (staticSymParent) {
                            staticSym.visible = false;
                            animSym.visible = true;
                            staticSymParent.addChild(animSym);
                            animSym.playAnim({
                                animName: "landing",
                                stopFrame: (symbol.json.animSym as slot.symbol.IAnimationSymbolData).posterFrame,
                                callback: () => {
                                    staticSym.visible = true;
                                    callback && callbackScope && callback.call(callbackScope);
                                },
                                cbScope: this
                            });
                        }
                    }
                }
            }
        }

        public startFreeSpinRetriggerPresentation(scatterLength: number) {
            this.showRetriggerCounters(scatterLength);
            this.startRetriggerPresentationApperenrnce();
        }
        protected showRetriggerCounters(scatterLength: number) {
            this.reteriggerCounterContainer = this.getContainerByID("retriggerPresentationCounter");
            this.counterImage = this.getImageById("freespins_Retrigger") as any;
            this.counterImage.visible = true;
            this.counterImage.alpha = 1;
            this.counterImageX = this.counterImage.x;
            this.counterImageY = this.counterImage.y;
            this.counterImage.anchor.set(0.5, 0.5);
            this.addChild(this.reteriggerCounterContainer);
            this.reteriggerCounterContainer.pivot.set(this.reteriggerCounterContainer.width / 2, this.reteriggerCounterContainer.height / 2);
            this.reteriggerCounterContainer.visible = true;
            this.reteriggerCounterContainer.alpha = 0;

        }
        protected startRetriggerPresentationApperenrnce() {
            this.game.add.tween(this.reteriggerCounterContainer).to({ alpha: 1 }, 300, bridge.Easing.Linear.None, true);
            utils.delayedCall("retriggerPresentationFadeout", 2000, this.startnextRetriggerPresentation, this);
        }

        protected startnextRetriggerPresentation() {
            const scaleTween = this.game.add.tween(this.counterImage.scale);
            scaleTween.to({ x: 0, y: 0 }, 400, bridge.Easing.Linear.None, true);
            const counterTween = this.game.add.tween(this.counterImage);
            counterTween.to({ x: 190, y: 650, alpha: 0 }, 400, bridge.Easing.Linear.None, true);
            counterTween.onComplete.add(this.tweenDownToCounter, this);
        }

        protected tweenDownToCounter() {
            this.hideRetriggerPresentation();
            this.counterImage.x = this.counterImageX;
            this.counterImage.y = this.counterImageY;
            this.counterImage.scale.set(1, 1);
            this.counterImage.alpha = 0;
            this.counterImage.visible = false;
            currentGame.tweens.removeFrom(this.reteriggerCounterContainer);
            currentGame.tweens.removeFrom(this.counterImage);
            currentGame.tweens.removeAll();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.MOVE_TO_NEXT_FREESPIN_AFTER_RETRIGGER);
        }

        public hideRetriggerPresentation() {
            this.reteriggerCounterContainer.visible = false;
            const freeSpin5Text = this.getImageById("freespins_Retrigger") as any;
            freeSpin5Text.visible = false;
            freeSpin5Text.alpha = 0;
        }

        /**
        * this function will call everytime when dimenstion of the game change
        * @param {ingenuity.IEvent} e
        */
        protected resize(e?: IObject): void {
            this.FreeGamePortraitLandscapeViewChange();
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                /*this.pivot.set(ingenuity.configData.width * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER, 0);
                this.scale.set(deviceEnv.getScale() + deviceEnv.getScale() * core.constructors.bsBehavior.SlotConstants.FIFTEEN_PERCENT);
                this.x = (innerWidth * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER);
                this.y = BehaviorCore.slotConstants.SlotConstants.WrapperTopBarHeightMobilePortrait;*/

                this.pivot.set(ingenuity.configData.width * slotConstants.SlotConstants.HALF_CONVERTER, 0);
                this.scale.set(e.data.scale);
                this.x = (innerWidth * slotConstants.SlotConstants.HALF_CONVERTER);
                this.y = this.y = (innerHeight * ingenuity.core.constructors.bsBehavior.SlotConstants.FIVE_PERCENT) + BehaviorCore.slotConstants.SlotConstants.ADD_IN_Y;

                this.getReelView() && this.getReelView().scale.set(1);
                this.getReelView() && (this.getReelView().x = this.getReelView().json.portraitX);
                this.getReelView() && (this.getReelView().y = this.getReelView().json.portraitY);
                this.getWinReelView() && this.getWinReelView().scale.set(1);
                this.getWinReelView() && (this.getWinReelView().x = this.getReelView().json.portraitX);
                this.getWinReelView() && (this.getWinReelView().y = this.getReelView().json.portraitY);
            } else {
                this.pivot.set(ingenuity.configData.width * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER, ingenuity.configData.height * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER);
                this.x = innerWidth * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER;
                if (deviceEnv.isDesktop) {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_DESKTOP;
                } else {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_MOBILE;
                }
                this.scale.set(e.data.scale);

                this.getReelView() && (this.getReelView().x = this.getReelView().json.x);
                this.getReelView() && (this.getReelView().y = this.getReelView().json.y);
                this.getWinReelView() && (this.getWinReelView().x = this.getReelView().json.x);
                this.getWinReelView() && (this.getWinReelView().y = this.getReelView().json.y);
            }

            if (!ingenuity.deviceEnv.isDesktop) {
                if (this.CurrentOrientation !== ingenuity.deviceEnv.getOrientation()) {
                    this.CurrentOrientation = ingenuity.deviceEnv.getOrientation();
                }
            }
            this.addButtonPanelOnTop();
            this.updateOrientation();
            this.portraitHudOnResize();
        }

        /**to handle portrait HUD on resize */
        protected portraitHudOnResize(): void {
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.portraitButtonsContainer && this.onShowPortraitButtonpanel();
            } else {
                if (!deviceEnv.isDesktop) {
                    this.onHidePortraitButtonPanel();
                }
            }
        }

        /**to show portrait buttons container
        * points to take care
        * 1. here we are considering reelBG to have no transparent area. reelBG should have no extra canvas area or provide reelbg actual height.
        * 2. Button_Panel_BasePort width should be as that of desktop asset i.e 1280
        * 3. portraitPlayerMsgBgShape is made of static height of spin player mssg. change as in game. Also we have assumed player mssg's
        *    to be contained in height of 40 px. if not so please allign player mssgs in game with in 40 px height.
        * 4. portraitBackgroundShape is a shape of height starting from gamble buttons to spin button bottom.
        */
        public onShowPortraitButtonpanel() {
            if (this.PortraitplayerMsgContainer && this.portraitButtonsContainer) {
                // to add player mssgs in portait below reel bg
                this.PortraitplayerMsgContainer.y = this.getImageById("reelBGFg").y + this.getImageById("reelBGFg").height;
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ON_CHANGE_PLAYERMSG_PARENT);

                // to find height of portrait bott0m button panel
                const bottomButtonPanelBg: ui.Bitmap = this.getImageById("Button_Panel_BasePort");
                let bottomstripHeight = bottomButtonPanelBg && (bottomButtonPanelBg.height * bottomButtonPanelBg.parent.scale.x);

                // to add console panel buttons in portrait floating buttons container
                this.changeParent(this.portraitButtonsContainer);

                // to find height of player mssgs in portrait
                const playerMssgBg: any = this.getComponentById("portraitPlayerMsgBgShape");
                const portraitPlayerMssgHeight: number = playerMssgBg && playerMssgBg.height;

                // to find height of window till player mssgs bottom
                const viewHeight: number = (this.getImageById("reelBGFg").y + this.getImageById("reelBGFg").height + portraitPlayerMssgHeight + BehaviorCore.slotConstants.SlotConstants.PLAYER_MSSG_HEIGHT_SAFEAREA) * this.scale.x + this.y;
                const wrapperBottomBarHeight: number = document.getElementById("gw-bottom-bar") ? document.getElementById("gw-bottom-bar").offsetHeight : 0;

                // to find height avaialable for portait floating button container to be scaled. it is from player mssg bottom to bottom button panel top
                let remainingHeight = window.innerHeight - (viewHeight + wrapperBottomBarHeight + bottomstripHeight);

                // to find height of game's portrait floating button contianer, which contains final spin, etc buttons
                const portraitButtonContainerBg: any = this.getComponentById("portraitBackgroundShape");

                // to set scaling of floating button container, not greater than a max limit. Max limit is used for beter UI.
                let availableScaling: number = this.scalingAvailable(remainingHeight, portraitButtonContainerBg);
                if (availableScaling > BehaviorCore.slotConstants.SlotConstants.FLOATING_MAX_SCALE) {
                    availableScaling = BehaviorCore.slotConstants.SlotConstants.FLOATING_MAX_SCALE;
                }
                this.portraitButtonsContainer.scale.set(availableScaling);

                // to find height of game's portrait floating button contianer, which contains final spin, etc buttons
                let portraitButtonContainerBgHeight: number = portraitButtonContainerBg && (portraitButtonContainerBg.height * this.portraitButtonsContainer.scale.x);

                // to find extra space between available space and portait floating button container height.
                remainingHeight = remainingHeight - portraitButtonContainerBgHeight;

                this.portraitButtonsContainer.pivot.set(configData.width / 2, 0);
                this.portraitButtonsContainer.x = window.innerWidth / 2;

                /**
                 * to set portait floating button container y position to - player mssg bottom + half of the extra space available
                 * between portait floating button container height and avaialble height got portait floating button container to be scaled
                 */
                this.portraitButtonsContainer.y = (viewHeight + remainingHeight / 2);

                this.portraitButtonsContainer.alpha = 1;
            }
        }

        /**to find min possible scaling for floating button container */
        protected scalingAvailable(availableHeight: number, buttonContainer: any): number {
            return Math.min(availableHeight / buttonContainer.height, window.innerWidth / buttonContainer.width);
        }

        /**to hide portait button panel */
        protected onHidePortraitButtonPanel() {
            this.portraitButtonsContainer && (this.portraitButtonsContainer.alpha = 0);
            this.changeParent(this.getContainerByID("buttonsContainer"));
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ON_CHANGE_PLAYERMSG_PARENT);
        }

        /**to change console buttons parent in game. diffenrent in portait and landscape  */
        protected changeParent(component: ui.Container): void {
            component && (this.json.newHUDComponents as string[]).forEach((value: string) => {
                component.addChild(this.getComponentById(value));
            }, this);
        }

        protected updateOrientation(): void {
            for (const key in this.allComponents) {
                if (this.allComponents.hasOwnProperty(key)) {
                    const comp: any = this.allComponents[key];
                    if (comp.json && comp.json.orientation) {
                        this.updateProperties(comp, comp.json.orientation[this.CurrentOrientation]);
                    }
                }
            }
        }

        protected updateProperties(comp: any, json: any) {
            for (const property in json) {
                if (json.hasOwnProperty(property)) {
                    switch (property) {
                        case "x":
                            comp.x = json[property];
                            break;
                        case "y":
                            comp.y = json[property];
                            break;
                        case "visible":
                            comp.visible = json[property];
                            break;
                        case "scaleX":
                            comp.scale.set(json[property], comp.scale.y);
                            break;
                        case "scaleY":
                            comp.scale.set(comp.scale.x, json[property]);
                            break;
                        case "scale":
                            comp.scale.set(json[property]);
                            break;
                    }
                }
            }
        }

        protected FreeGamePortraitLandscapeViewChange(): void {
            if (ingenuity.deviceEnv.getOrientation() === "portrait") {
                this.handleInPortrait();
            } else {
                if (!deviceEnv.isDesktop && deviceEnv.getOrientation() === "landscape") {
                    this.handleInLandscape();
                }
            }
        }

        // This function is used for bring the Consol Panel on Stage.
        protected addButtonPanelOnTop(): void {
            const buttonsContainer: ui.Container = this.getContainerByID("buttonsContainer");
            ingenuity.currentGame.stage.addChild(buttonsContainer);
            const buttonsContainerWidth: number = buttonsContainer.width;

            const gwBottomBar: HTMLElement = document.getElementById("gw-bottom-bar");
            let gwBottomBarHeight: number = 0;
            gwBottomBar && (gwBottomBarHeight = gwBottomBar.offsetHeight);

            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                buttonsContainer.pivot.set(ingenuity.configData.width / 2, 168);
                buttonsContainer.x = (buttonsContainer.width / 2) + ((window.innerWidth - buttonsContainerWidth) / 2);
                buttonsContainer.y = window.innerHeight - gwBottomBarHeight;
                const scale: number = Math.min((window.innerHeight / ingenuity.configData.height), (window.innerWidth / ingenuity.configData.width));
                buttonsContainer.scale.set(scale, scale);
            } else {
                if (this.CurrentOrientation === "portrait") {
                    const bottomPanelBgPortrait: ui.Bitmap = this.getImageById("Button_Panel_BasePort");
                    bottomPanelBgPortrait && buttonsContainer.pivot.set(bottomPanelBgPortrait.width / 2, bottomPanelBgPortrait.height);
                    buttonsContainer.x = window.innerWidth / 2;
                    buttonsContainer.y = window.innerHeight - gwBottomBarHeight;
                    buttonsContainer.scale.set(deviceEnv.getScale() + deviceEnv.getScale() * core.constructors.bsBehavior.SlotConstants.FIFTEEN_PERCENT);
                }
            }
            this.getContainerByID("portraitButtonsContainer") && ingenuity.currentGame.stage.addChild(this.getContainerByID("portraitButtonsContainer"));
        }
        protected handleInPortrait(): void {
            const allComp = this.getAllcomponents();
            for (const key in allComp) {
                if (allComp[key] && allComp[key].json && key !== "anticipation_2" && key !== "anticipation_3" && key !== "anticipation_4" && key !== "lineWinAmtFg") {
                    allComp[key].x = allComp[key].json.portraitX ? allComp[key].json.portraitX : allComp[key].json.x;
                    allComp[key].y = allComp[key].json.portraitY ? allComp[key].json.portraitY : allComp[key].json.y;
                    allComp[key].scale.set(allComp[key].json.portraitScale ? allComp[key].json.portraitScale : (allComp[key].json.scale ? allComp[key].json.scale : 1));
                }
            }
        }
        protected handleInLandscape(): void {
            const allComp = this.getAllcomponents();
            for (const key in allComp) {
                if (allComp[key] && allComp[key].json && key !== "anticipation_2" && key !== "anticipation_3" && key !== "anticipation_4" && key !== "lineWinAmtFg") {
                    allComp[key].x = allComp[key].json.landscapeX ? allComp[key].json.landscapeX : allComp[key].json.x;
                    allComp[key].y = allComp[key].json.landscapeY ? allComp[key].json.landscapeY : allComp[key].json.y;
                    allComp[key].scale.set(allComp[key].json.landscapeScale ? allComp[key].json.landscapeScale : (allComp[key].json.scale ? allComp[key].json.scale : 1));
                }
            }
        }

        /**
        * to hide all symbols alpha which are present on grid
        */
        protected showAlpha(): void {
            for (let reel = 0; reel < 5; reel++) {
                for (let symbol = 0; symbol < 4; symbol++) {
                    this.reelView.getSymbolByPos(reel, symbol).getStatic().tint = 0x999999;
                    const anim: ingenuity.slot.symbol.AnimationSymbol = this.reelView.getSymbolByPos(reel, symbol).getAnimation() as ingenuity.slot.symbol.AnimationSymbol;
                    if (anim.name === "symbol_scatter") {
                        const child: bridge.Sprite = anim.children[0] as bridge.Sprite;
                        if (child !== undefined) {
                            child.tint = 0x999999;
                        }
                    }
                }
            }
        }

        /**
         * to unhide all symbols alpha which are present on grid
         */
        protected hideAlpha(): void {
            for (let reel = 0; reel < 5; reel++) {
                for (let symbol = 0; symbol < 4; symbol++) {
                    // this.reelView.getSymbolByPos(reel, symbol).getStatic().alpha = 1;
                    this.reelView.getSymbolByPos(reel, symbol).getStatic().tint = 0xffffff;
                    const anim: ingenuity.slot.symbol.AnimationSymbol = this.reelView.getSymbolByPos(reel, symbol).getAnimation() as ingenuity.slot.symbol.AnimationSymbol;
                    if (anim.name === "symbol_scatter") {
                        const child: bridge.Sprite = anim.children[0] as bridge.Sprite;
                        if (child !== undefined) {
                            // child.alpha = 1;
                            child.tint = 0xffffff;
                        }
                    }
                }
            }
        }

        /**
         * to unhide symbols alpha which are part of winning line
         */
        protected hideAlphaOnSymbol(evt: IEvent): void {
            this.showAlpha();
            if (evt && evt.data) {
                for (const winSymData of evt.data) {
                    // this.reelView.getSymbolByPos(winSymData[0], winSymData[1]).getStatic().alpha = 1;
                    this.reelView.getSymbolByPos(winSymData[0], winSymData[1]).getStatic().tint = 0xffffff;
                    const anim: ingenuity.slot.symbol.AnimationSymbol = this.reelView.getSymbolByPos(winSymData[0], winSymData[1]).getAnimation() as ingenuity.slot.symbol.AnimationSymbol;
                    if (anim.name === "symbol_scatter") {
                        const child: bridge.Sprite = anim.children[0] as bridge.Sprite;
                        // child.alpha = 1;
                        child.tint = 0xffffff;
                    }
                }
            }
        }

        /**
         * to initialize UI elements
         */
        protected initializeElemnets(): void {
            this.spinBtn = this.getButtonById("skip") as ui.ButtonBase;
            this.stopBtn = this.getButtonById("spinStop") as ui.ButtonBase;
            this.consoleButtonBase = this.getImageById("Button_Panel_Base");
            this.betLabel = this.getLabelById("TXT_betLabel") as ui.Label;
            this.lineLabel = this.getLabelById("TXT_lineLabel") as ui.Label;
            this.paidmeter = this.getLabelById("TXT_paidmeter") as ui.Label;
            this.totalbet = this.getMeterById("totalbet") as ui.Meter;
            this.totalLines = this.getMeterById("totalLines") as ui.Meter;
            this.freeGameLogo = this.getImageById("freeGameLogoContainer") as ui.Bitmap;
        }

        /**
         * Following function reprosition elemnts based on the JSON values
         * @param {ingenuity.IEvent} e
         */
        protected rePositionElements(elem: IObject): void {
            const elememt: IObject = elem;
            const orientation: string = deviceEnv.getOrientation();
            let newValues: IObject;
            newValues = elememt.json[orientation];
            for (const i in elememt.json[orientation]) {
                if (i === "images") {
                    elememt.loadTexture(newValues[i], 0, false);
                } else if (i === "scale") {
                    elememt.scale.set(newValues[i], newValues[i]);
                } else if (i === "style") {
                    elememt.json.style = newValues[i];
                    elememt.label.setStyle(newValues[i]);
                } else {
                    elememt[i] = newValues[i];
                }
            }
        }

        public UpdateFreeSpinCounterText(obj: IObject): void {
            const freeSpinTotalNum: number = parserModel.getFreeSpinNum();
            let freeSpinLeftNum: number;
            let checkFreeSpinLeft: number;
            if (obj.data === false) {
                freeSpinLeftNum = parserModel.getFreeSpinsRemaining().toString();
            } else {
                if (parserModel.getFreeSpinsRemaining() === 0) {
                    freeSpinLeftNum = (parserModel.getFreeSpinsRemaining()).toString();
                    checkFreeSpinLeft = -1;
                } else {
                    freeSpinLeftNum = (parserModel.getFreeSpinsRemaining() - 1);
                }
            }
            this.totalFreespin.setValue(freeSpinTotalNum);
            this.remainingFreespin.setValue(freeSpinTotalNum - freeSpinLeftNum);
            /**
            * tweens for freespin remaining counter and text
            */
            if (checkFreeSpinLeft !== -1 && (!parserModel.getFreeGameBroken())) {
                const fadeInTween: bridge.ITween = currentGame.add.tween(this.remainingFreespin.scale).to({ x: 1.2, y: 1.1 }, 300, undefined, true, 0, 0, true);
                fadeInTween.onComplete.addOnce(() => {
                    fadeInTween.stop();
                    currentGame.tweens.remove(fadeInTween);
                }, this);
            }
        }

        public updateNewAwardedFreespinsNumber(): void {
            const freespinTotalNum: number = parserModel.getFreeSpinNum();
            const freespinLeftNum: number = parserModel.getFreeSpinsRemaining();
            let newFreeSpinsAwarded: number = freespinTotalNum;
            let newFreeSpinsRemaining: number = 0;
            if (parserModel.getFreeGameBroken()) {
                newFreeSpinsAwarded = (freespinTotalNum - parserModel.getRetriggerFreeSpins());
                newFreeSpinsRemaining = (freespinTotalNum - freespinLeftNum);
            } else if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                newFreeSpinsAwarded = (freespinTotalNum - parserModel.getRetriggerFreeSpins());
                newFreeSpinsRemaining = (freespinTotalNum - (freespinLeftNum - 1));
            } else {
                newFreeSpinsRemaining = (freespinTotalNum - (freespinLeftNum - 1));
            }
            this.totalFreespin.setValue(newFreeSpinsAwarded);
            this.remainingFreespin.setValue(newFreeSpinsRemaining);
        }

        public setWinValue(value: string, isValueInCredit: boolean, tickyp?: boolean): void {
            if (isValueInCredit) {
                this.lblWinValue.setCurrencyFormattedValue(value);
            } else {
                const converAmountToCoinFromCurrency: string = Math.round(Number(value) / ingenuity.configData.currentCoinValue).toString();
                this.lblWinValue.setBsCoinFormattedValue(converAmountToCoinFromCurrency, 0);
            }
        }

        public killView(): void {
            dispatcher.off(events.EventConstants.RESIZE, this.resize, this);
        }

        public setReelView(reelView: BehaviorCore.reelPanel.ReelPanel, pos?: number, parentId?: string): void {
            this.reelView = reelView;
            this.addChildAt(this.getImageById("reelBGFg"), 1);
            this.addChildAt(reelView, 2);
            const container: ui.Container = this.getContainerByID("reelsContainerFg");
            this.addChildAt(container, 3);
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.reelView.x = this.reelView.json.portraitX;
                this.reelView.y = this.reelView.json.portraitY;
            } else if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                //
            }
            this.resize(new ingenuity.events.Event(ingenuity.events.EventConstants.RESIZE, ingenuity.deviceEnv.update()));
        }

        public setWinReelView(value: slot.reelPanel.WinPresentationPanel, pos?: number, parentId?: string): void {
            super.setWinReelView(value, pos, parentId);
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.winView.x = this.reelView.json.portraitX;
                this.winView.y = this.reelView.json.portraitY;
            } else if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                //
            }
            this.resize(new ingenuity.events.Event(ingenuity.events.EventConstants.RESIZE, ingenuity.deviceEnv.update()));
        }

        /**to play symbol landing sounds
         * @ data has 3 value- landingSymbollId, symbolCount and reelID
         */
        protected checkAndPlayLandingSounds(evt: IEvent): void {
            //
        }
    }
}
