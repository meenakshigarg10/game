///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.PlayerMsg {
    export class PlayerMsgController {
        protected view: PlayerMsgView;
        protected model: BaseGame.Model;
        protected json: any;
        protected winSymbolOnLine: ingenuity.ui.Bitmap;
        protected winText: ingenuity.ui.Bitmap;
        protected winAmtOnLine: ui.MeterBitmap | ui.Meter;
        protected symbolScale: number;
        protected symLen: number;
        public cashMeter: ingenuity.ui.MeterBitmap;
        protected lineText: ingenuity.ui.Bitmap;
        protected lineIdLbl: ui.MeterBitmap | ui.Meter;
        protected scatterSymbolImg: ui.Bitmap;

        constructor(view: PlayerMsgView, model: any, json: any, assetManager: any) {
            this.view = view;
            this.model = model;
            this.json = json;
            this.subscribeEvents();
            this.initializeElements();
        }

        /**
         * initialize player message lables
         */
        protected initializeElements(): void {
            this.winText = this.view.getImageById("playerMsg_winText");
            this.winAmtOnLine = this.view.getMeterById("playerMsg_winAmtOnLine");
            this.lineText = this.view.getImageById("playerMsg_lineText");
            this.lineIdLbl = this.view.getMeterById("playerMsg_lineId");
            this.scatterSymbolImg = this.view.getImageById("playerMsg_scatterImg");
            ingenuity.dispatcher.fireEvent(ingenuity.core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_PLAYER_MSG);

            if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                if (parserModel.getTotalWin() > 0) {
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_TOTAL_WIN_MSG_FG_BROKEN);
                }
            }
        }

        /**
         * subscribeEvents, subscribes Listeners to controll Player Msgs
         * show player msg, hide player msg, show WinLine Msg, showGood Luck msg
         * etc..
         *
         */
        protected subscribeEvents(): void {
            dispatcher.on(slotConstants.SlotEventConstants.SUBSCRIBE_PLAYER_MESSAGES, this.subscribeEvents, this);
            dispatcher.on(slotConstants.SlotEventConstants.RESET_PLAYER_MESSAGES, this.resetMsg, this);
            dispatcher.on(slotConstants.SlotEventConstants.UNSUBSCRIBE_PLAYER_MESSAGES, this.unSubscribeEvents, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_PLAYER_MSG, this.view.showSpinPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_PLAYER_MSG, this.view.hideSpinPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_STAGE_CLICK_PLAYER_MSG, this.view.showStageClickPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_STAGE_CLICK_PLAYER_MSG, this.view.hideStageClickPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_STOP_PLAYER_MSG, this.view.showSpinStopPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_STOP_PLAYER_MSG, this.view.hideSpinStopPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_FREESPIN_PLAYER_MSG, this.view.showFreeSpinPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_FREESPIN_PLAYER_MSG, this.view.hideFreeSpinPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.LINE_ANIMATION_STARTED, this.showWinLineMessage, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_WIN_TOGGLE_PLAYER_MSG, this.showWinTogglePlayerMsg, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_WIN_TOGGLE_PLAYER_MSG, this.hideWinTogglePlayerMsg, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_SCATTER_WIN_MSSG, this.showScatterWinMssg, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_TOTAL_WIN_MSG, this.view.showTotalWinMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_TOTAL_WIN_MSG, this.view.hideTotalWinMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_TOTAL_WIN_MSG_FG_BROKEN, this.view.showTotalWinMsgInFgBroken, this.view);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.SHOW_FREESPIN_CONTAINER, this.view.showFreeSpinCounterText, this.view);
            dispatcher.on(slotConstants.SlotEventConstants.UPDATE_FREESPIN_LABEL_COUNT, this.UpdateFreeSpinCounterText, this);
            dispatcher.on(slotConstants.SlotEventConstants.UPDATE_TOGGLE_MSG, this.togglePlayerMsgAllignment, this);
            dispatcher.on(slotConstants.SlotEventConstants.UPDATE_TOGGLE_MSG, this.scatterPlayerMsgAllignment, this);
            dispatcher.on(slotConstants.SlotEventConstants.UPDATE_FG_MSG, this.view.freegameWinAmount, this.view);
            dispatcher.on(slotConstants.SlotEventConstants.UPDATE_FG_MSG, this.view.freegameLeftMeter, this.view);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_PLAYER_MSG, this.hidePlayerMsg, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_PLAYER_MSG, this.showPlayerMsg, this);
        }

        protected unSubscribeEvents(): void {
            dispatcher.off(slotConstants.SlotEventConstants.RESET_PLAYER_MESSAGES, this.resetMsg, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_PLAYER_MSG, this.view.showSpinPlayerMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_PLAYER_MSG, this.view.hideSpinPlayerMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_STAGE_CLICK_PLAYER_MSG, this.view.showStageClickPlayerMsg, this.view);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_STAGE_CLICK_PLAYER_MSG, this.view.hideStageClickPlayerMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_STOP_PLAYER_MSG, this.view.showSpinStopPlayerMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_SPIN_STOP_PLAYER_MSG, this.view.hideSpinStopPlayerMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_FREESPIN_PLAYER_MSG, this.view.showFreeSpinPlayerMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_FREESPIN_PLAYER_MSG, this.view.hideFreeSpinPlayerMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.LINE_ANIMATION_STARTED, this.showWinLineMessage, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_WIN_TOGGLE_PLAYER_MSG, this.showWinTogglePlayerMsg, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_WIN_TOGGLE_PLAYER_MSG, this.hideWinTogglePlayerMsg, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SHOW_SCATTER_WIN_MSSG, this.showScatterWinMssg, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_TOTAL_WIN_MSG, this.view.showTotalWinMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_TOTAL_WIN_MSG, this.view.hideTotalWinMsg, this.view);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_TOTAL_WIN_MSG_FG_BROKEN, this.view.showTotalWinMsgInFgBroken, this.view);
            dispatcher.off(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.SHOW_FREESPIN_CONTAINER, this.view.showFreeSpinCounterText, this.view);
            dispatcher.off(slotConstants.SlotEventConstants.UPDATE_FREESPIN_LABEL_COUNT, this.UpdateFreeSpinCounterText, this);
            dispatcher.off(slotConstants.SlotEventConstants.UPDATE_TOGGLE_MSG);
            dispatcher.off(slotConstants.SlotEventConstants.UPDATE_FG_MSG);
        }

        /*** hide player msg*/
         protected hidePlayerMsg(evt: IEvent): void {
           this.view.visible = false;
        }

         /*** show player msg*/
         protected showPlayerMsg(evt: IEvent): void {
            this.view.visible = true;
         }

        /**
         * to show Line / Way win on toggle
         */
        protected showWinTogglePlayerMsg(evt: IEvent): void {
            if (evt.data.id === -1) {
                this.scatterPlayerMsgAllignment();
                this.winAmtOnLine.text = ingenuity.game.wrapper.gameWrapper.formatCurrency(evt.data.win);
                this.scatterSymbolImg.visible = true;
                this.lineIdLbl.visible = false;
                this.lineText.visible = false;
                this.winText.visible = true;
                this.winAmtOnLine.visible = true;
            } else {
                this.togglePlayerMsgAllignment();
                this.showWinPlayerMsg_Text();
                this.scatterSymbolImg.visible = false;
                let actualValue: string = "";
                actualValue = ingenuity.game.wrapper.gameWrapper.formatCurrency(evt.data.win);
                const lineNo: string = String(evt.data.id);
                this.showWinPlayerMsg_Amt(actualValue, lineNo);
            }
        }

        /*** following function is overrided for toggle player msg localization allignment */
        protected togglePlayerMsgAllignment(): void {
            this.lineIdLbl.x = this.lineText.x + this.lineText.texture.frame.width;
            this.winText.x = this.lineIdLbl.x + this.lineIdLbl.json.w - 3;
            this.winAmtOnLine.x = this.winText.x + this.winText.texture.frame.width + 7;
        }

        /*** following function is overrided for scatter player msg localization allignment */
        protected scatterPlayerMsgAllignment(): void {
            this.winText.x = this.scatterSymbolImg.x + this.scatterSymbolImg.json.w + 5;
            this.winAmtOnLine.x = this.winText.x + this.winText.texture.frame.width + 8;
        }

        /*** following function is overrided for scatter player msg localization allignment during freegame triggering */
        protected showScatterWinMssg(evt: IEvent): void {
            if (evt && evt.data) {
                const actualValue: string = String(evt.data[0].win);
                this.winAmtOnLine.text = ingenuity.game.wrapper.gameWrapper.formatCurrency(parseFloat(actualValue));
                this.scatterPlayerMsgAllignment();
                this.scatterSymbolImg.visible = true;
                this.lineIdLbl.visible = false;
                this.lineText.visible = false;
                this.winText.visible = true;
                this.winAmtOnLine.visible = true;
            }
        }

        /**
         * to hide line / way win player msg on toggle
         */
        protected hideWinTogglePlayerMsg(): void {
            this.lineIdLbl.visible = false;
            this.lineText.visible = false;
            this.winText.visible = false;
            this.winAmtOnLine.visible = false;
            this.scatterSymbolImg.visible = false;
        }

        /**
         * to show "win" text in player message
         */
        protected showWinPlayerMsg_Text(): void {
            this.lineText.visible = true;
            this.winText.visible = true;
        }

        /**
         * to show win amount player message
         */
        protected showWinPlayerMsg_Amt(win: string, lineId: string): void {
            this.winAmtOnLine.text = win;
            this.lineIdLbl.text = lineId;
            this.lineIdLbl.visible = true;
            this.winAmtOnLine.visible = true;
        }

        /**
         * To hide the Free spin counter text container
         */
        protected UpdateFreeSpinCounterText(data: IObject): void {
            if (!parserModel.getIsFreeSpinRetriggered()) {
                this.view.UpdateFreeSpinCounterText(data);
            } else {
                this.view.updateNewAwardedFreespinsNumber();
            }
        }

        /**
         * Override for showing bonus messages
         * @param {ingenuity.IEvent} evt
         */
        protected showWinLineMessage(evt: IEvent): void {
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_WIN_TOGGLE_PLAYER_MSG, evt.data);
        }

        public shutdown(): void {
            this.unSubscribeEvents();
        }

        public unSubscribeFreeGameEvents(): void {
            this.unSubscribeEvents();
            dispatcher.off(slotConstants.SlotEventConstants.SUBSCRIBE_PLAYER_MESSAGES, this.subscribeEvents, this);
            dispatcher.off(slotConstants.SlotEventConstants.UNSUBSCRIBE_PLAYER_MESSAGES, this.unSubscribeEvents, this);
        }

        protected resetMsg(): void {
            this.hideWinTogglePlayerMsg();
            this.view.hideFreeSpinPlayerMsg();
            this.view.showSpinPlayerMsg();
            this.view.hideSpinStopPlayerMsg();
        }
    }
}
