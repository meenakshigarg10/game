///<reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.PlayerMsg {
    export class PlayerMsgView extends ui.BaseView {
        protected freeSpinsContainer: ui.Container;
        protected freeGameLeftMeter: ui.Label;
        public static OutroWinAmount: number = 0;
        public static totalWinCount: number = 0;
        protected totalWinContainer: ingenuity.ui.Container;
        protected totalWinAmt: ingenuity.ui.LabelBitmap;
        protected spinMsg: ingenuity.ui.Bitmap;
        protected stageClickMsg: ingenuity.ui.Bitmap;
        protected stopMsg: ingenuity.ui.Bitmap;
        protected freeSpinMsg: ingenuity.ui.Bitmap;
        public lblWinValue: ingenuity.ui.MeterBitmap;
        protected totalFreeSpinWinTextImg: ingenuity.ui.Bitmap;

        constructor(json: any) {
            super(json);
            dispatcher.on(events.EventConstants.RESIZE, this.resize, this);
            this.resize({ data: deviceEnv.update() });
            this.spinMsg = this.getImageById("playerMsg_spin");
            this.stageClickMsg = this.getImageById("playerMsg_StageClick");
            this.stopMsg = this.getImageById("playerMsg_stop");
            this.freeSpinMsg = this.getImageById("playerMsg_totalWinTextFG");
            this.totalFreeSpinWinTextImg = this.getImageById("playerMsg_totalFreeSpinWinTextFG");
            this.freeSpinsContainer = this.getContainerByID("playerMsgFreeSpinsLeft");
            this.freeGameLeftMeter = this.getLabelById("playerMsgFreeSpinsLeftMeter") as ingenuity.ui.Label;
            this.totalWinContainer = this.getContainerByID("playerMsg_totalWinContainer");
            this.totalWinAmt = this.getLabelById("playerMsg_totalWinAmtOnLine") as ingenuity.ui.LabelBitmap;
        }

        /**
        * To show the Free spin counter text container
        */
        public showFreeSpinCounterText(): void {
            this.freeSpinsContainer.visible = false;
        }

        /**
         * to show "Press to spin" player message
         */
        public showSpinPlayerMsg(): void {
            if (currentGame.state.getCurrentState().key !== slot.slotConstants.SlotConstants.freeGameState) {
                this.spinMsg && (this.spinMsg.visible = true);
            }
        }

        /**
         * done to stop player mssg visibility of stop button as per compliance
         */
        public showSpinStopPlayerMsg(): void {
            if (parserModel.getIsSpinStopAvailable()) {
                if (!configData.turboEnabled) {
                    this.stopMsg.visible = true;
                }
            }
        }

        public hideSpinStopPlayerMsg(): void {
            this.stopMsg.visible = false;
        }

        public showFreeSpinPlayerMsg(): void {
            this.spinMsg.visible = false;
            this.stopMsg.visible = false;
            this.freeSpinMsg.visible = true;
        }

        public hideFreeSpinPlayerMsg(): void {
            this.freeSpinMsg.visible = false;
        }

        public hideSpinPlayerMsg(): void {
            this.spinMsg.visible = false;
        }

        public showStageClickPlayerMsg(): void {
            this.stageClickMsg.visible = true;
            if (currentGame.state.getCurrentState().key === ingenuity.slot.slotConstants.SlotConstants.freeGameState) {
                this.stageClickMsg.x = BehaviorCore.slotConstants.SlotConstants.STAGECLICKMSGX;
            }
        }

        public hideStageClickPlayerMsg(): void {
            this.stageClickMsg.visible = false;
        }

        /**
         * to show totol win amount in the right part of bottom panel for player messages
         */
        public showTotalWinMsg(evt?: IEvent): void {
            this.showTotalWinMsgInFgBroken();
            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                const totalFreeGameWin: number = parserModel.getFreeSpinWinAmt();
                this.setValueInTotalWinMeter(totalFreeGameWin.toString());
            }
        }

        /**
        * to show total win amount during Freegame Broken only for First spin in Broken, without enabling Spin Button(especially) and also called to show total win msg everytime
        * here is fg scatter win will also be shown
        * Due to change in Behavior, Fg Total win container is hidden in desktop, but is visible in mobile.
        */

        public showTotalWinMsgInFgBroken(): void {
            let totalFreeGameWin: number;
            if (deviceEnv.isDesktop) {
                this.totalWinContainer.visible = false;
            } else {
                //
            }
            if (ingenuity.currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState) {
                this.totalFreeSpinWinTextImg && (this.totalFreeSpinWinTextImg.visible = false);
            } else {
                this.totalFreeSpinWinTextImg && (this.totalFreeSpinWinTextImg.visible = true);
            }
            if (parserModel.getFreeGameBroken()) {
                totalFreeGameWin = parserModel.getTotalWin() - parserModel.getCurrentWin();
            } else {
                totalFreeGameWin = parserModel.getTotalWin();
            }

            this.totalWinAmt.visible = true;
            this.setValueInTotalWinMeter(totalFreeGameWin.toString());
        }

        /**
         * set value in text field.
         * For Desktop, no total win meter in fg playermsg, total win amount will be shown in console.
         */
        protected setValueInTotalWinMeter(actualValue: string): void {
            this.totalWinAmt.text = game.wrapper.gameWrapper.formatCurrency(parseFloat(actualValue));
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CONSOLE_TOTAL_WIN_METER, actualValue);
        }

        /**
         * to hide totol win amount in the right part of bottom panel for player messages
         */
        public hideTotalWinMsg(evt?: IEvent): void {
            this.totalWinContainer.visible = false;
        }

        protected resize(e?: IObject): void {
            this.PlayerMsgPortraitLandscapeViewChange();
            dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotConstants.UPDATE_TOGGLE_MSG);
            dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotConstants.UPDATE_TOGGLE_MSG_SCATTER);
            if (deviceEnv.isDesktop) {
                //
            } else if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                this.getContainerByID(ingenuity.BehaviorCore.slotConstants.SlotConstants.PLAYER_MSG_CONTAINER).scale.set(1, 1);
            } else {
                this.getContainerByID(ingenuity.BehaviorCore.slotConstants.SlotConstants.PLAYER_MSG_CONTAINER).scale.set(1.5, 1.5);
            }
        }

        protected handleInPortrait(): void {
            const allComp = this.getAllcomponents();
            for (const key in allComp) {
                if (allComp[key] && allComp[key].json) {
                    allComp[key].x = allComp[key].json.portraitX ? allComp[key].json.portraitX : allComp[key].json.x;
                    allComp[key].y = allComp[key].json.portraitY ? allComp[key].json.portraitY : allComp[key].json.y;
                }
            }
        }

        protected handleInLandscape(): void {
            const allComp = this.getAllcomponents();
            for (const key in allComp) {
                if (allComp[key] && allComp[key].json) {
                    allComp[key].x = allComp[key].json.landscapeX ? allComp[key].json.landscapeX : allComp[key].json.x;
                    allComp[key].y = allComp[key].json.landscapeY ? allComp[key].json.landscapeY : allComp[key].json.y;
                }
            }
        }

        /**
         * To hide the Free spin counter text container
         */
        public UpdateFreeSpinCounterText(obj: IObject): void {
            const freespinTotalNum: string = parserModel.getFreeSpinNum().toString();
            let freespinLeftNum: string;
            if (obj.data === false) {
                freespinLeftNum = parserModel.getFreeSpinsRemaining().toString();
            } else {
                if (parserModel.getFreeSpinsRemaining() === 0) {
                    freespinLeftNum = (parserModel.getFreeSpinsRemaining()).toString();
                } else {
                    freespinLeftNum = (parserModel.getFreeSpinsRemaining() - 1).toString();
                }
            }

            this.freeGameLeftMeter.setText((freespinLeftNum) + "/" + freespinTotalNum);
        }

        /**
         * This method is to update the Bottom free spins counter in Case of Retrigger.
         */
        public updateNewAwardedFreespinsNumber(): void {
            const freespinTotalNum: number = parserModel.getFreeSpinNum();
            const freespinLeftNum: number = parserModel.getFreeSpinsRemaining();
            const newFreeSpinsAwarded: string = (freespinTotalNum - parserModel.getRetriggerFreeSpins()).toString();
            const newFreeSpinsRemaining: string = (freespinLeftNum - parserModel.getRetriggerFreeSpins()).toString();
            this.freeGameLeftMeter.setText(newFreeSpinsRemaining + "/" + newFreeSpinsAwarded);
        }

        /**
          * to update total win amount position in the right part of bottom panel for player messages
          */
        public freegameWinAmount(): void {
            this.totalWinAmt.x = this.totalFreeSpinWinTextImg.x + (this.totalFreeSpinWinTextImg.texture.width - 13);
        }

        /**
         * To  update freegame left meter position
         */
        public freegameLeftMeter(): void {
            this.freeGameLeftMeter.x = this.getImageById(ingenuity.BehaviorCore.slotConstants.SlotConstants.PLAYER_MSG_FS_LEFT_TXT).x + this.getImageById(ingenuity.BehaviorCore.slotConstants.SlotConstants.PLAYER_MSG_FS_LEFT_TXT).texture.width + 5;
        }

        protected PlayerMsgPortraitLandscapeViewChange(): void {
            if (ingenuity.deviceEnv.getOrientation() === "portrait") {
                this.pivot.set(ingenuity.configData.width * core.constructors.bsBehavior.SlotConstants.HALF_CONVERTER, ingenuity.configData.height * slotConstants.SlotConstants.HALF_CONVERTER);
                this.x = 0;
                this.y = 0;
                this.handleInPortrait();
            } else if (!deviceEnv.isDesktop && ingenuity.deviceEnv.getOrientation() === "landscape") {
                this.pivot.set(ingenuity.configData.width * core.constructors.bsBehavior.SlotConstants.ZERO_CONVERTER, ingenuity.configData.height * slotConstants.SlotConstants.ZERO_CONVERTER);
                this.handleInLandscape();
            }
        }
    }
}
