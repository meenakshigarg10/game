/**
 * Sound constants used here
 */
namespace ingenuity.BehaviorCore.slotConstants {
    export class SoundConstant {
        public static BASEGAME_BACKGROUND: string = "BaseGame_loop";
        public static ANTICIPATION_SOUND: string = "3090sewin10";
        public static INFO_CLOSE: string = "CS_Settings_generic";
        public static INFO_NEXT: string = "CS_InfoPanelNextButton";
        public static INFO_PREV: string = "CS_InfoPanelPrevButton";
        public static BIGWIN_LOOP: string = "BigWinLoop";
        public static PETAL_TRANSITION: string = "Petals_transition";
        public static FADE_TRANSITION: string = "fade_transition";
        public static FREE_SPIN_NUMBER_MOVE: string = "fs_number_move";
        public static SUPERWIN_LOOP: string = "SuperWinLoop";
        public static MEGAWIN_LOOP: string = "MegaWinLoop";
        public static COMMON_WIN_END: string = "common_win_end";
        public static ULTRAWIN_LOOP: string = "ultra_big_win_loop";
        public static BIGWIN_END: string = "BigWinEnd";
        public static SUPERWIN_END: string = "SuperWinEnd";
        public static MEGAWIN_END: string = "MegaWinEnd";
        public static SPAGETTI_SOUND: string = "CS_Spaghetti";
        public static FREGAME_INTRO: string = "CS_Freegame_intro_popup";
        public static FREGAME_OUTRO: string = "CS_Freegame_outro_popup";
        public static FREGAME_BGLOOP: string = "FreeSpins_Loop";
        public static COIN_UP: string = "CS_CoinDenom_Up";
        public static COIN_DOWN: string = "CS_CoinDenom_Down";
        public static BASEGAME_BTN_SPIN: string = "click03";
        public static BASEGAME_BTN_SPIN_STOP: string = "click03";
        public static BASEGAME_BTN_MENU: string = "open";
        public static AUTO_PLAY: string = "click01";
        public static AUTOPLAY_STOP: string = "click01";
        public static BASEGAME_BTN_COINVALUE_INC: string = "click01";
        public static BASEGAME_BTN_COINVALUE_DEC: string = "click01";
        public static BASEGAME_BTN_TURBO_ON: string = "click01";
        public static BASEGAME_BTN_TURBO_OFF: string = "click01";
        public static MAX_BUTTON_SOUND: string = "click01";
        public static GENERIC_BUTTON: string = "click03";
        public static LINE_WIN: string = "line_win";
        public static WIN_TICKUP: string = "Wintickup_center_loop";
        public static FIVE_OFAKIND: string = "5oak";
        public static SCATTER_LANDING: string = "Scatter_HenHouseDoorsClose";
        public static BONUS_LANDING: string = "CS_BonusLanded";
        public static REEL_SPIN1: string = "Reel_spin_V1";
        public static REEL_STOP: string = "Reel_stop4";
        public static WILD_WIN: string = "CS_WildSymbolWin";
        public static HIGH_WIN: string = "CS_High_Win";
        public static MED_WIN: string = "CS_Med_Win";
        public static LOW_WIN: string = "CS_Low_Win";
        public static METER_UP: string = "CS_Meter_up";
        public static CONTINUE_BTN: string = "CS_Continue_button";
        public static CARD_APPEAR: string = "CS_CardAppear";
        public static BONUS_TRIGGER: string = "CS_BonusTrigger";
        public static SCATTER_TRIGGER: string = "Scatter_trigger";
        public static CARD_SELECTION: string = "CS_CardSelection";
        public static CARD_FLIP: string = "CS_Card_Flip";
        public static BONUS_INTRO: string = "CS_BonusPopUp_Intro";
        public static BONUS_OUTRO: string = "CS_BonusPopUp_Outro";
        public static BONUS_WINNING_APPEARANCE: string = "CS_WinAmountAppearance";
        public static BONUS_AMBIENT: string = "CS_BonusPickACard";
        public static COUNT_UP_2FREESPINS: string = "FS_counter_update_2";
        public static COUNT_UP_5FREESPINS: string = "FS_counter_update_5";
        public static TURBO_ENABLE_BTN: string = "turboModeEnableBtn";
        public static TURBO_DISABLE_BTN: string = "turboModeDisableBtn";
        public static FIVEOAK_IN: string = "5OAK_in";
        public static FIVEOAK_OUT: string = "5OAK_out";
        public static CENTER_TICKUP_ONE_SHOT: string = "CENTER_TICKUP_ONE_SHOT";
        public static COIN_PLUS_BUTTON: string = "coinPlusBtn";
        public static COIN_MINUS_BUTTON: string = "coinMinusBtn";
        public static INFO_LOOP: string = "InfoLoop_V3";
        public static TRANSITION_BG_TO_FG: string = "Transitionbasegametofreegame";
        public static GAME_INTRO_LOOP: string = "2001bg000002";
        public static BASEGAME_BTN_CONTINUE: string = "click01";
        public static BASEGAME_INFO_HELP_BTN: string = "open";
        public static BASEGAME_BTN_MENU_CLOSE: string = "click02";
        public static BASEGAME_REEL_SPIN_SOUND: string = "reelspin";

        /**
         * Sound Pop button sounds
         */
        public static SOUND_ON_BTN: string = "volume";
        public static SOUND_OFF_BTN: string = "volume";

        /**
         * Basegame win tickup Sounds
         */

        public static WIN_SOUND_1: string = "1090sewin10";
        public static WIN_SOUND_2: string = "1090sewin03";
        public static WIN_SOUND_3: string = "1090sewin09";
        public static WIN_SOUND_4: string = "1090sewin15";
        public static WIN_SOUND_5: string = "1090sewin21";
        public static WIN_SOUND_6: string = "1090sewin24";
        public static WIN_SOUND_7: string = "1090sewin06";
        public static WIN_SOUND_BG_1: string = "1090sewin01";
        public static WIN_SOUND_BG_2: string = "1090sewin02";
        public static WIN_SOUND_BG_3: string = "1090sewin03";
        public static WIN_SOUND_BG_4: string = "1090sewin04";
        public static WIN_SOUND_BG_5: string = "1090sewin05";
        public static WIN_SOUND_BG_6: string = "1090sewin06";
        public static WIN_SOUND_BG_7: string = "1090sewin07";
        public static WIN_SOUND_BG_8: string = "1090sewin08";
        public static WIN_SOUND_BG_9: string = "1090sewin09";
        public static WIN_SOUND_BG_10: string = "1090sewin10";
        public static WIN_SOUND_BG_11: string = "1090sewin11";
        public static WIN_SOUND_BG_12: string = "1090sewin12";
        public static WIN_SOUND_BG_13: string = "1090sewin13";
        public static WIN_SOUND_BG_14: string = "1090sewin14";
        public static WIN_SOUND_BG_15: string = "1090sewin15";
        public static WIN_SOUND_BG_16: string = "1090sewin16";
        public static WIN_SOUND_BG_17: string = "1090sewin17";
        public static WIN_SOUND_BG_18: string = "1090sewin18";
        public static WIN_SOUND_BG_19: string = "1090sewin19";
        public static WIN_SOUND_BG_20: string = "1090sewin20";
        public static WIN_SOUND_BG_21: string = "1090sewin21";
        public static WIN_SOUND_BG_22: string = "1090sewin22";
        public static WIN_SOUND_BG_23: string = "1090sewin23";
        public static WIN_SOUND_BG_24: string = "1090sewin24";


        // Freegame win Tickup Sounds
        public static WIN_SOUND_FG_1: string = "3090sewin01";
        public static WIN_SOUND_FG_2: string = "3090sewin02";
        public static WIN_SOUND_FG_3: string = "3090sewin03";
        public static WIN_SOUND_FG_4: string = "3090sewin04";
        public static WIN_SOUND_FG_5: string = "3090sewin05";
        public static WIN_SOUND_FG_6: string = "3090sewin06";
        public static WIN_SOUND_FG_7: string = "3090sewin07";
        public static WIN_SOUND_FG_8: string = "3090sewin08";
        public static WIN_SOUND_FG_9: string = "3090sewin09";
        public static WIN_SOUND_FG_10: string = "3090sewin10";
        public static WIN_SOUND_FG_11: string = "3090sewin11";
        public static WIN_SOUND_FG_12: string = "3090sewin12";
        public static WIN_SOUND_FG_13: string = "3090sewin13";
        public static WIN_SOUND_FG_14: string = "3090sewin14";
        public static WIN_SOUND_FG_15: string = "3090sewin15";
        public static WIN_SOUND_FG_16: string = "3090sewin16";
        public static WIN_SOUND_FG_17: string = "3090sewin17";
        public static WIN_SOUND_FG_18: string = "3090sewin18";
        public static WIN_SOUND_FG_19: string = "3090sewin19";
        public static WIN_SOUND_FG_20: string = "3090sewin20";
        public static WIN_SOUND_FG_21: string = "3090sewin21";
        public static WIN_SOUND_FG_22: string = "3090sewin22";
        public static WIN_SOUND_FG_23: string = "3090sewin23";
        public static WIN_SOUND_FG_24: string = "3090sewin24";

        /**
         * Gamble Sounds
         */
        public static COLLECT_BTN: string = "collect";
        public static GAMBLE_BTN: string = "click01";
        public static GAMBLE_CARD: string = "gamble_play_options";
        public static GAMBLE_BG: string = "paysound";
        public static GAMBLE_CARD_LOOSE: string = "gamblelose";
        public static GAMBLE_CARD_WIN: string = "gamblewin";

        // Big Win Fountain Sound
        public static FOUNTAIN_SOUND: string = "1092sewinbell";
        public static FG_WIN_SOUND: string = "3090sewin11";

    }
}
