///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.slotConstants {
    export class SlotConstants extends slot.slotConstants.SlotConstants {

        public static MaxBetBtn: string = "maxBetButton";
        public static PopupCloseBtn: string = "closeBtn";
        public static StakeOkBtn: string = "stakeOkBtn";
        public static SoundSettingBtn: string = "soundSettingBtn";
        public static BetSettingBtn: string = "betSettingBtn";
        public static BaseGamePopupPanelContainer: string = "basegamePopupPanelContainer";
        public static SoundSettingContainer: string = "soundSettingContainer";
        public static BetSettingContainer: string = "betSettingContainer";
        public static CurrentBetMeter: string = "currentBetMeter";
        public static CoinShowerContainer: string = "coinShowerContainer";
        public static FiveOFKind: string = "5OFKind";
        public static FreeBetLabel: string = "TXT_freeBetLabel";

        /**
         * Used in model
         */
        public static WinTickUpDuration: number = 1.6; // value given in second
        public static FiveOfAKindDisplayTime: number = 8000; // value given in millisecond
        public static setDelayForSpaghettiDispaly: number = 200; // value given in millisecond
        public static setDelayForNoWin: number = 1000; // value given in millisecond
        public static NoWinDelay: string = "noWinDelay";
        public static setDelayForClearWin: number = 300; // value given in millisecond
        public static ClearWinDelay: string = "clearWinDelay";
        public static ShortStandardCenterTickup: string = "shortStandardCenterTickup";
        public static setDelayForEnableSpin: number = 300; // value given in millisecond
        public static EnableSpinDelay: string = "enableSpinDelay";
        public static EnableStageClick: string = "enableStageClick";
        public static setDelayForForceStop: number = 500; // value given in millisecond
        public static ForceStopDelay: string = "forceStopDelay";

        public static FreeSpinTimer: number = 500; // value given in millisecond
        public static FREE_SPIN_BTN_ENABLE: string = "freeSpinBtnEnable";

        /**
         * AutoPlay constants
         */
        public static AutoPlayContainer: string = "autoPlayContainer";
        public static AutoPlayCounter: string = "autoPlayCounter";
        public static AutoPlayDelayBigWin: number = 1500;
        public static AutoPlayDelayWin: number = 500;

        /**
         *
         * sound buttons of soundSettingContainer
         */
        public static SoundToggleButton: string = "soundToggleButton";
        public static MusicToggleButton: string = "musicToggleButton";

        /**
         * Big Win constants
         */
        public static BigWinContainer: string = "bigWinContainer";
        public static BigWinMtr: string = "bigWinMtr";
        public static BigWinLbl: string = "lbl_bigWin";
        public static SuperWinLbl: string = "lbl_superWin";
        public static MegaWinLbl: string = "lbl_megaWin";
        public static BigWinState: string = "bigWin";
        public static SuperWinState: string = "superWin";
        public static MegaWinState: string = "megaWin";
        public static ForcedStoppedState: string = "forcedStopped";
        public static CompleteState: string = "complete";
        public static BigWinMultiplier: number = 50;
        public static MegaWinMultiplier: number = 20;
        public static StandardTickupTime: number = 0.1; // in seconds
        public static StandardTickupTimeMs: number = 1000; // in seconds
        public static winTime: number = 6;
        public static BigWinTime: number = 19;
        public static GreatWinTime: number = 24;
        public static BigWinCompleteTimer: number = 2000;
        public static BigWinCompleteDelayer: string = "bigWinCompleteDelayed";
        public static ClearBigWinCompleteTimer: number = 2000;
        public static ClearBigWinCompleteDelayer: string = "clearBigWinCompleteDelayed";
        public static HD: string = "hd";
        public static LD: string = "ld";
        public static BigWinTxtTransitionTime: number = 1000;

        public static BIGWIN_START: string = "bigWinStart";
        public static MEGAWIN_START: string = "megaWinStart";
        public static SUPERWIN_START: string = "superBigWinStart";
        public static ULTRAWIN_START: string = "ultraWinStart";

        constructor() {
            super();
        }

        // Game Intro Screen
        public static gameIntroContinueBtn: string = "gameIntroContinueBtn";
        public static gameIntroDontShowAgainCheckbox: string = "gameIntroDontShowAgain_checkbox";
        public static gameIntroPaginationDot1: string = "gameIntroPaginationBtn_1";
        public static gameIntroPaginationDot2: string = "gameIntroPaginationBtn_2";
        public static gameIntroSlideChangetime: number = 1000;
        public static GameIntroLocalStorageName: string = "showGameIntro";

        // Button Console - tooltip
        public static TooltipMaxBet: string = "tooltip_maxBet";
        public static TooltipSpin: string = "tooltip_spin";
        public static TooltipStop: string = "tooltip_stop";
        public static TooltipAutoplay: string = "tooltip_autoplay";
        public static TooltipAutoplayOff: string = "tooltip_autoplay_off";
        public static ToolTipDelayer: string = "toolTipDelayer";
        public static ToolTipDelayTime: number = 2000;

        // Base Game - Reel Panel
        public static ReelPanelZoomTime: number = 500;
        //  public static WinMeterId: string = "centerWinMeter";
        public static WinMeterId: string = "winValue";

        public static MAIN_DATA: string = "main_data";
        public static PORTRAIT_SCALE_REDUCER = 0.2;
        public static PORTRAIT_SCALE_REDUCER_BASEGAME = 0.21;
        public static PORTRAIT_SCALE_REDUCER_TOPVIEW = 0.25;

        public static DEFAULT_MIN_COINSIZE: number = 20;
        public static DEFAULT_METER_DOWN_Y: number = 60;
        public static WinMtrSettableDelayTime: number = 500;
        public static WinMtrSettableDelay: string = "WinMtrSettableDelay";
        public static WinMeterFadeOutTime: number = 300;

        // sounds
        public static LINE_WIN: string = "line_win";

        // popup on minimum resize
        public static MIN_WIDTH: number = 800;
        public static MIN_HEIGHT: number = 600;

        /**
         *  Template constants pasted here to merge generic template code into Behavior, need to remove extra constants after merging
         * --------------------------------------------------------------------------------------------------------------------------
         */
        public static BONUS: string = "bonus";
        public static FREE_SPIN: string = "freespin";
        public static FREE_SPIN_CLOSE: string = "close";
        public static FREE_GAME: string = "freeGame";
        public static FREE_GAME_TICKUP: string = "freeGameWinMeterTickup";
        public static FREE_GAME_TICKUP_COMPLETE: string = "freeGameWinMeterTickupComplete";
        public static SPIN: string = "spin";
        public static FONT_LIST: string[] = ["Arial", "ArialBlack"];
        public static FONT_PATH: string = "resource/font/";
        public static BASE_GAME: string = "baseGame";
        public static VISIBILITY_CHANGE: string = "visibilitychange";
        public static WEB_VISIBILITY_CHANGE: string = "webkitvisibilitychange";
        public static VISIBLE: string = "visible";
        public static LOADING_PERCENT: string = "loaderPercent";
        public static PROGRESS_DYNAMIC: string = "progressDynamic";
        public static GAME_CONTAINER: string = "gameContainer";
        public static MANIFEST_URL: string = "resource/manifest/mainManifest.json";
        public static MANIFEST_MOBILE_URL: string = "resource/manifest/mainManifestMobile.json";
        public static LOADER: string = "loader";
        public static FONT_LOADER: string = "fontTemp";
        public static NORMAL_TWEEN: string = "toggleStates";
        public static BIGWIN_LOOP: string = "bigWinLoop";
        public static BIGWIN_END: string = "bigWinEnd";
        public static DEFAULT_ANIM: string = "anim";
        public static PARTICLE_COIN1: string = "silver_sparkle";
        public static PARTICLE_COIN2: string = "coin3";
        public static PARTICLE_COIN3: string = "coin4";
        public static PARTICLE_COIN4: string = "coin5";
        public static PARTICLE_DIAMOND: string = "diamondBigWin";
        public static BONUS_CARD1: string = "ClubKing";
        public static BONUS_CARD2: string = "ClubQueen";
        public static BONUS_CARD3: string = "DiamondKing";
        public static BONUS_CARD4: string = "DiamondQueen";
        public static BONUS_CARD5: string = "HeartKing";
        public static BONUS_CARD6: string = "HeartQueen";
        public static BONUS_DISABLE_CARD1: string = "ClubKing_Disable";
        public static BONUS_DISABLE_CARD2: string = "ClubQueen_Disable";
        public static BONUS_DISABLE_CARD3: string = "DiamondKing_Disable";
        public static BONUS_DISABLE_CARD4: string = "DiamondQueen_Disable";
        public static BONUS_DISABLE_CARD5: string = "HeartKing_Disable";
        public static BONUS_DISABLE_CARD6: string = "HeartQueen_Disable";
        public static UNPICK_REVEAL_DELAY: number = 500;
        public static OUTRO_DELAY: number = 1000;
        public static TOTAL_PICK_CARDS: number = 6;
        public static CARD_ROTATION1: number = 0;
        public static CARD_ROTATION2: number = 60;
        public static CARD_ROTATION3: number = -60;
        public static readonly BASEGAMEBACKGROUND: string = "basegame_idle";
        public static readonly BASEGAME_BACKGROUND_IMAGE: string = "basegameBackground";
        public static readonly FREEGAME_BACKGROUND_IMAGE: string = "freegameBackground";
        public static readonly FREEGAME_BACKGROUND_ANIM: string = "freegame_idle";
        public static readonly FREEGAME_INTRO_ANIM: string = "transition";
        public static FREEGAME_BACKGROUND: string = "freeegameBgContainer";
        public static BONUS_BACKGROUND: string = "bonusgameBgContainer";
        public static METER_TICKUP: string = "winMeterTickup";
        public static FIVE_OAK: string = "5OFKind";
        public static SYMBOL_9: string = "Blue_7";
        public static SYMBOL_10: string = "Golden_Chip";
        public static AUTOPLAY_EXPANDABLE_BUTTON: string = "autoPlayExpandButton_";
        public static GDK_POPUP_DELAY: number = 1000;
        public static LANDSCAPE: string = "landscape";
        public static PORTRAIT: string = "portrait";
        public static DELAY_FOR_NEXT_FREESPIN: string = "delayedForNextSpin";
        public static CHEAT_INPUT_BOX: string = "cheat";
        public static IS_FEATURE: boolean = false;
        public static WINDOW_CLICK: string = "click";
        public static SUBMIT_BUTTON: string = "submit";
        public static TIME_SCATTER_ANIMATION_END: number = 3000;
        public static BASE_GAME_FADE_IN_TIME: number = 500;
        public static FREE_GAME_FADE_IN_TIME: number = 500;

        // Background
        public static BASEGAME_BG_STATIC: string = "baseGameStaticBackground";
        public static BASEGAME_BG_STATIC_PORTRAIT: string = "baseGameStaticBackgroundPortrait";
        public static BASEGAME_BG_SHOW: string = "baseGameBackgroundShow";

        public static GAME_INTRO_BG_PORTRAIT: string = "gameIntroBGPortrait";
        public static GAME_INTRO_BG: string = "gameIntroBG";
        public static GAME_INTRO_BG_SHOW: string = "gameIntroBG";

        public static FREEGAME_BG_STATIC: string = "freegameBackground";
        public static FREEGAME_BG_STATIC_PORTRAIT: string = "freegameBackgroundPortrait";
        public static FREEGAME_BG_SHOW: string = "freegameBackgroundShow";

        public static SELECTION_SCREEN_BG_PORTRAIT: string = "selectionScreenPortrait";
        public static SELECTION_SCREEN_BG: string = "selectionScreenBG";
        public static SELECTION_SCREEN_BG_SHOW: string = "selectionScreenBGShow";

        public static BASEGAME_ANIM_BG: string = "baseGameAnim";
        public static BACKGROUND_ANIMATION_BASEGAME: string = "basegame_idle";





        // Game Intro
        public static GAME_INTRO: string = "gameintro";
        public static GameIntroTopLogo: string = "gameIntroTopLogo";

        // paytable
        public static InfoPagesContainer: string = "InfoPagesContainer";
        public static InfoBackBtn: string = "InfoBackBtn";
        public static InfoNextBtn: string = "InfoNextBtn";
        public static InfoPrevBtn: string = "InfoPrevBtn";

        // introoutro
        public static INTRO_CONTINUE_BTN: string = "IntroContinueBtn";
        public static OUTRO_CONTINUE_BTN: string = "OutroContinueBtn";

        // for mobile Version
        public static HALF_CONVERTER: number = 0.5;
        public static ZERO_CONVERTER: number = 0;
        public static SPIN_BUTTON_SCALE_IN_PORTRAIT: number = 1.7;
        public static TOPVIEW_SCALE_IN_PORTRAIT: number = 1.7;
        public static REEL_PANEL_SCALE_IN_PORTRAIT: number = 0.95;
        public static OTHER_BUTTONS_SCALE_IN_PORTRAIT: number = 1.3;
        public static FIVE_PERCENT: number = 0.03125;
        public static FIFTEEN_PERCENT: number = 0.2;
        public static TWENTY_FIVE_PERCENT: number = 0.25;
        public static THIRTY_FIVE_PERCENT: number = 0.35;
        public static LANDSCAPE_SCALE_PERCENTAGE: number = 5.5;

        public static BIGWIN_VIEW_PORTRAIT_UP: number = 460;
        public static DEFAULT_METER_DOWN_BIGWIN_Y: number = 45;
        public static WrapperTopBarHeightMobilePortrait: number = 45;
        public static WrapperTopBarHeightMobileLandscape: number = 10;
        public static WrapperTopBarHeightDesktop: number = 26;
        public static SCALE_PERCENTAGE: number = 14;
        public static WrapperBottomBarHeightDesktop: number = 24;
        public static GAMBLE_VIEW_SLIDE: number = 25;

        // POSTLOAD

        public static BIG_WIN_POSTLOAD: string = "BigWinPostLoadDelay";
        public static BIG_WIN_POSTLOAD_DELAY_INTERVAL: number = 1000;

        // Broken

        public static NEXT_ACTION: string = "freespin";
        public static BROKEN_DELAY_FG: string = "BrokenDelay";
        public static BROKEN_DELAY_AMOUNT: number = 100;
        public static BROKEN_DELAY_AMOUNT_1: number = 100;

        // wrapper states
        public static WRAPPER_ACTIVE_STATE: string = "active";
        public static WRAPPER_PAUSE_STATE: string = "paused";
        public static WRAPPER_ERROR_STATE: string = "error";

        // Basegame centreTickUp

        public static HOLD_WON_AMOUNT_BG: string = "holdWinMount";
        public static WON_AMOUNT_DELAY_BG: number = 200;
        public static HOLD_WON_AMOUNT_FG: string = "holdWinAmountFg";
        public static WON_AMOUNT_DELAY_FG: number = 300;

        // Sound Popup
        public static BG_SHAPE: string = "bg_shape";
        public static HISTORY_MODE: string = "history";

        // Sound PopUp Controller Constants
        public static YES_BTN: string = "yesBtn";
        public static NO_BTN: string = "noBtn";
        public static FREEGAME: string = "freegame";
        public static CLOSE_ACTION: string = "close";
        public static FREE_SPIN_ACTION: string = "freespin";
        public static START_GAME_INTRO: string = "START_GAME_INTRO";

        // Button Controller Constants
        public static SETTING_BUTTON: string = "settingButton";
        public static INFO_BUTTON: string = "infoButton";
        public static WIN_VALUE: string = "winValue";

        // BIGWIN CONSTANTS
        public static EnableBigWinAfterStageTransition: string = "enableBigWinAfterStageTransition";
        public static EnableBigWinAfterStageTransitionDelay: number = 1000;
        public static BIG_WIN_TICKUP_DURATION: number = 50;
        public static GREAT_WIN_TICKUP_DURATION: number = 21;

        // Setting Pannel
        public static coinMinusBtn: string =  "coinMinusBtn";
        public static coinPlusBtn: string = "coinPlusBtn";
        public static coinMeter: string = "coinMeter";
        public static INFO_BUTTON_SETTING_PANNEL: string = "infoMiddlePanelButton";
        public static PAYTABLE_BUTTON_SETTING_PANNEL: string = "paytableMiddlePanelButton";
        public static helpContainer: string = "helpContainer";
        public static payTableContainer: string = "payTableContainer";
        public static BackBtnId: string = "backButton";
        public static helpCloseBtn: string = "helpCloseBtn";
        public static payTableCloseBtn: string = "payTableCloseBtn";
        public static betSettingMiddlePanelButton: string = "betSettingMiddlePanelButton";
        // Removing Bettson Code led the following constant to addition
        public static CloseBtnId: string = "closeBtnId";
        public static RESET_WIN_VLAUE: string = "0";




        // game intro
        public static GAMEINTROPORTRAITVIEWSCALE: number = 0.45;
        public static BACKGROUND_WIDTH: number = 1520;
        public static GAME_INTRO_CONTINUE_BTN: string = "gameIntroContinueBtn";
        public static GAME_INTRO_CONTINUE_BASE_BTN: string = "gameIntroContinueBaseBtn";
        public static STORE_PLAY_TOKEN_LOCAL: string = "STORE_PLAY_TOKEN_LOCAL";

        // Template Base Game State Constants
        public static IOS: string = "ios";
        public static CHROME: string = "CHROME";

        // stage click player message
        public static STAGECLICKMSGX: number = -900;
        public static PLAYER_MSG_FS_LEFT_TXT: string = "playerMsgFreeSpinsLeftTxt";
        public static UPDATE_TOGGLE_MSG: string = "UPDATE_TOGGLE_MSG";
        public static UPDATE_TOGGLE_MSG_SCATTER: string = "UPDATE_TOGGLE_MSG_SCATTER";
        public static PLAYER_MSG_CONTAINER: string = "playerMsgContainer";


        // Win Presentation
        public static RESET_TO_TRIGGERING_ANIMATION: number = 4;

        // tick-up on Force Stop Win
        public static DELAY_FOR_NEXT_WIN_PRESENTATION: number = 700;

        // game Object Main Constants
        public static AVAIL_WIDTH: string = "availWidth";
        public static GAME_CANVAS: string = "#gameCanvas";
        public static HELP_FRAME_CONTAINER: string = "helpIframeContainerScrollChild";
        public static payTableIframeContainer: string = "payTableIframeContainerScrollChild";
        public static GAMECONTENT: string = "gameContent";
        public static WINFRAMES_ON_LINES_ANIMATION: string = "animSequence_";

        // Basegame Win Tickup Durations
        public static WINTICKUP_1: number = 3.5;
        public static WINTICKUP_2: number = 34;
        public static WINTICKUP_3: number = 71;
        public static WINTICKUP_4: number = 0.5;
        public static WINTICKUP_5: number = 1;
        public static WINTICKUP_6: number = 2;
        public static WINTICKUP_BG_1: number = 0.5;
        public static WINTICKUP_BG_2: number = 0.5;
        public static WINTICKUP_BG_3: number = 0.5;
        public static WINTICKUP_BG_4: number = 0.5;
        public static WINTICKUP_BG_5: number = 0.5;
        public static WINTICKUP_BG_6: number = 1;
        public static WINTICKUP_BG_7: number = 1.5;
        public static WINTICKUP_BG_8: number = 1.9;
        public static WINTICKUP_BG_9: number = 1.9;
        public static WINTICKUP_BG_10: number = 3;
        public static WINTICKUP_BG_11: number = 4.9;
        public static WINTICKUP_BG_12: number = 5.9;
        public static WINTICKUP_BG_13: number = 9;
        public static WINTICKUP_BG_14: number = 9;
        public static WINTICKUP_BG_15: number = 9;
        public static WINTICKUP_BG_16: number = 11;
        public static WINTICKUP_BG_17: number = 19;
        public static WINTICKUP_BG_18: number = 19.5;
        public static WINTICKUP_BG_19: number = 23.5;
        public static WINTICKUP_BG_20: number = 29.5;
        public static WINTICKUP_BG_21: number = 34;
        public static WINTICKUP_BG_22: number = 42.5;
        public static WINTICKUP_BG_23: number = 49;
        public static WINTICKUP_BG_24: number = 71;


        // Freegame Tickup Duration
        public static WINTICKUP_FG_1: number = 0.5;
        public static WINTICKUP_FG_2: number = 0.5;
        public static WINTICKUP_FG_3: number = 0.5;
        public static WINTICKUP_FG_4: number = 0.5;
        public static WINTICKUP_FG_5: number = 0.5;
        public static WINTICKUP_FG_6: number = 1;
        public static WINTICKUP_FG_7: number = 1.5;
        public static WINTICKUP_FG_8: number = 1.9;
        public static WINTICKUP_FG_9: number = 1.9;
        public static WINTICKUP_FG_10: number = 3;
        public static WINTICKUP_FG_11: number = 4.9;
        public static WINTICKUP_FG_12: number = 5.9;
        public static WINTICKUP_FG_13: number = 9;
        public static WINTICKUP_FG_14: number = 9;
        public static WINTICKUP_FG_15: number = 9;
        public static WINTICKUP_FG_16: number = 11;
        public static WINTICKUP_FG_17: number = 19;
        public static WINTICKUP_FG_18: number = 19.5;
        public static WINTICKUP_FG_19: number = 23.5;
        public static WINTICKUP_FG_20: number = 29.5;
        public static WINTICKUP_FG_21: number = 34;
        public static WINTICKUP_FG_22: number = 42.5;
        public static WINTICKUP_FG_23: number = 49;
        public static WINTICKUP_FG_24: number = 71;


        // Symbol Constants

        public static SYMBOL_ALPHA: number = 0.1;
        public static reelsContainer: string = "reelsContainer";

        // reel
        public static REELS_CONTAINER_FG: string = "reelsContainerFg";
        public static REELS_CONTAINER: string = "reelsContainer";

        // Big Symbol Controller
        public static SYMBOL_CONTAINER: string = "symbolContainer_";
        public static BIGSYMBOLID: number[] = [];

        // Main Constants
        public static LBL_GAME_ON_BROWSER_ERROR_MSG: string = "lbl_GameOnIEBrowserErrorMsg";

        // Gamble Constants
        public static GAMBLE_BUTTON: string = "gambleButton";

        public static COLLECT_BUTTON: string = "collectButton";
        public static FG_WIN_TICKUP: number = 3;

        //
        public static VIEW_SLIDE_DESKTOP: number = 50;
        public static VIEW_SLIDE_MOBILE: number = 20;
        public static ADD_IN_Y: number = 96;

        // new HUD portrait
        public static PLAYER_MSSG_HEIGHT_SAFEAREA: number = 10;
        public static FLOATING_MAX_SCALE: number = 1.5;

        // toggle
        public static WIN_LINE_ANIM_TIMEOUT: number = 2000;

        // Landing Sounds
        public static REELS_STOPPING_IDS: number[] = [0, 1, 2, 3, 4];
    }
}

/**
 * created to override first toggle time
 */
namespace ingenuity {
    slot.slotConstants.SlotConstants.WinLineAnimTimeOutFirstToggle = 2000;
}

