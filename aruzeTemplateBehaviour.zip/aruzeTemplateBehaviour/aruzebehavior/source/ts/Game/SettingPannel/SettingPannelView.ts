namespace ingenuity.BehaviorCore.BaseGame {
    export class SettingPannelView extends BaseView {
        private backButton: ui.ButtonBase;

        constructor(json: any) {
            super(json);
            this.backButton = this.getButtonById("backButton") as ui.ButtonBase;
            this.backButton.on(ingenuity.ui.ButtonBase.UP, this.hideView, this);
            dispatcher.on("SHOW_SETTING_PANNEL", this.showView, this);
        }

        protected resize(evt: IEvent): void {
            super.resize(evt);
            this.pivot.set(configData.width / 2, configData.height / 2);
            this.x = innerWidth / 2;
            this.y = innerHeight / 2;
            this.scale.set(evt.data.scale);
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.pivot.set(configData.width * slotConstants.SlotConstants.HALF_CONVERTER, 0);
                this.y = this.y = (innerHeight * ingenuity.core.constructors.bsBehavior.SlotConstants.FIVE_PERCENT) + BehaviorCore.slotConstants.SlotConstants.ADD_IN_Y;
            } else {
                if (!deviceEnv.isDesktop) {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_MOBILE;
                } else {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_DESKTOP;
                }
            }
        }

        protected showView(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.STOP_SYMBOL_SOUND);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.DISABLE_CONSOLE_BUTTONS);
            configData.enableSpacebar = false;
            configData.stopSymbolSound = true;
            this.visible = true;
            this.getContainerByID("SettingPannelMainConatiner").visible = true;
        }

        public hideView(evt?: ui.ButtonBase): void {
            if (evt && evt.name === BehaviorCore.slotConstants.SlotConstants.BackBtnId) {
                dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SlotConstants.BackBtnId);
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.ENABLE_CONSOLE_BUTTONS);
            }
            configData.enableSpacebar = true;
            configData.stopSymbolSound = false;
            this.getContainerByID("SettingPannelMainConatiner").visible = false;
            this.visible = false;

        }
    }
}