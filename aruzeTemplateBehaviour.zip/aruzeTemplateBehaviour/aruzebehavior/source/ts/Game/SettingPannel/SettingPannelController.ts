namespace ingenuity.BehaviorCore.BaseGame {
    export class SettingPannelController {
        protected view: SettingPannelView;
        protected coinMinusBtn: ui.ButtonBase;
        protected coinPlusBtn: ui.ButtonBase;
        protected cointMeter: ui.MeterBitmap;
        protected infoButtonSettingPannel: ui.ButtonBase;
        protected paytableButtonSettingPannel: ui.ButtonBase;
        protected betSettingMiddlePanelButton: BehaviorCore.BSButtonBase;
        protected infoContainerDiv: HTMLElement;
        protected payTableContainerDiv: HTMLElement;

        constructor(view: SettingPannelView, model?: Model) {
            this.view = view;
            this.initializeButtons();
            this.subscribeEvents();
            this.onUpdateCoinValue();
        }

        protected initializeButtons(): void {
            this.coinMinusBtn = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.coinMinusBtn) as ui.ButtonBase;
            this.coinPlusBtn = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.coinPlusBtn) as ui.ButtonBase;
            this.cointMeter = this.view.getMeterById(BehaviorCore.slotConstants.SlotConstants.coinMeter) as ui.MeterBitmap;
            this.infoButtonSettingPannel = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.INFO_BUTTON_SETTING_PANNEL) as ui.ButtonBase;
            this.paytableButtonSettingPannel = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.PAYTABLE_BUTTON_SETTING_PANNEL) as ui.ButtonBase;
            this.betSettingMiddlePanelButton = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.betSettingMiddlePanelButton) as BehaviorCore.BSButtonBase;
            this.betSettingMiddlePanelButton.keepSelectedBtn();
            this.infoContainerDiv = document.getElementById(BehaviorCore.slotConstants.SlotConstants.helpContainer);
            this.payTableContainerDiv = document.getElementById(BehaviorCore.slotConstants.SlotConstants.payTableContainer);
        }

        protected subscribeEvents(): void {
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.OPEN_INFO_SCREEN, this.showPaytable, this);
            dispatcher.on(ingenuity.slot.slotConstants.SlotEventConstants.LOGIC_ONSTAKE_CHANGE, this.onUpdateCoinValue, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_DISABLE_SETTING_COIN_BT, this.enableDisableCoinBtn, this);
            this.coinMinusBtn && this.coinMinusBtn.on(ingenuity.ui.ButtonBase.DOWN, this.onBetMinusPressUp, this);
            this.coinPlusBtn && this.coinPlusBtn.on(ingenuity.ui.ButtonBase.DOWN, this.onBetPlusPressUp, this);
            this.infoButtonSettingPannel && this.infoButtonSettingPannel.on(ingenuity.ui.ButtonBase.UP, this.showPaytable, this);
            this.paytableButtonSettingPannel && this.paytableButtonSettingPannel.on(ingenuity.ui.ButtonBase.UP, this.showHelp, this);
        }

        protected enableDisableCoinBtn(): void {
            if (parserModel.getCurrentBet() >= parserModel.getArrayNumChips()[parserModel.getArrayNumChips().length - 1]) {
                this.coinPlusBtn.disableAndTint();
            } else {
                !this.coinPlusBtn.getIsInputEnabled() && this.coinPlusBtn.enableAndTint();
            }
            if (parserModel.getCurrentBet() <= parserModel.getArrayNumChips()[0]) {
                this.coinMinusBtn.disableAndTint();
            } else {
                !this.coinMinusBtn.getIsInputEnabled() && this.coinMinusBtn.enableAndTint();
            }
        }

        protected onBetPlusPressUp(): void {
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SoundConstant.COIN_PLUS_BUTTON);
            this.onChangeStake(ingenuity.slot.slotConstants.SlotConstants.BetIncrement);
            dispatcher.fireEvent(ingenuity.slot.slotConstants.aruze.SlotEventConstants.SET_BET);
        }

        protected onBetMinusPressUp(): void {
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SoundConstant.COIN_MINUS_BUTTON);
            this.onChangeStake(ingenuity.slot.slotConstants.SlotConstants.BetDecrement);
            dispatcher.fireEvent(ingenuity.slot.slotConstants.aruze.SlotEventConstants.SET_BET);
        }

        protected onChangeStake(value: number): void {
            if (value > 0) {
                parserModel.setCurrentBetIndex((parserModel.getCurrentBetIndex() < parserModel.getArrayNumChips().length - 1) ? parserModel.getCurrentBetIndex() + 1 : 0);
                parserModel.setCurrentBet(parserModel.getArrayNumChips()[parserModel.getCurrentBetIndex()]);
                parserModel.setCurrentTotalBet(parserModel.getCurrentBet() * parserModel.getCurrentNumPaylines());
            } else {
                parserModel.setCurrentBetIndex((parserModel.getCurrentBetIndex() > 0) ? parserModel.getCurrentBetIndex() - 1 : parserModel.getArrayNumChips().length - 1);
                parserModel.setCurrentBet(parserModel.getArrayNumChips()[parserModel.getCurrentBetIndex()]);
                parserModel.setCurrentTotalBet(parserModel.getCurrentBet() * parserModel.getCurrentNumPaylines());
            }
            parserModel.setTotalWin(0);
            dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.LOGIC_ONSTAKE_CHANGE);
        }

        protected onUpdateCoinValue(): void {
            this.cointMeter.setCurrencyFormattedValue(String(parserModel.getCurrentBet()));
        }

        /**
         * Method is made to handle the click of info button press or shows the info/paytable page.
         */
        protected showPaytable(): void {
            dispatcher.offForScope(ingenuity.events.EventConstants.RESIZE, this);
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, slot.slotConstants.SlotConstants.InfoBtnId);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.DISABLE_CONSOLE_BUTTONS);

            this.view.hideView();
            this.payTableContainerDiv.style.display = "block";
            document.getElementById("payTableCloseBtn").style.display = "block";
            const payTableCloseBtn: HTMLElement = document.getElementById(BehaviorCore.slotConstants.SlotConstants.payTableCloseBtn);
            payTableCloseBtn.onclick = null;
            payTableCloseBtn.onclick = this.hidePaytable.bind(this);
        }

        protected hidePaytable(): void {
            this.payTableContainerDiv.style.display = "none";
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.ENABLE_CONSOLE_BUTTONS);
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SlotConstants.BackBtnId);
            configData.enableSpacebar = true;
            configData.stopSymbolSound = false;
        }

        protected showHelp(): void {
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, slot.slotConstants.SlotConstants.InfoBtnId);
            dispatcher.offForScope(ingenuity.events.EventConstants.RESIZE, this);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.DISABLE_CONSOLE_BUTTONS);
            this.view.hideView();
            this.infoContainerDiv.style.display = "block";
            document.getElementById("helpCloseBtn").style.display = "block";

            const helpCloseBtn: HTMLElement = document.getElementById(BehaviorCore.slotConstants.SlotConstants.helpCloseBtn);
            helpCloseBtn.onclick = null;
            helpCloseBtn.onclick = this.hideHelp.bind(this);
        }

        protected hideHelp(): void {
            this.infoContainerDiv.style.display = "none";
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.ENABLE_CONSOLE_BUTTONS);
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SlotConstants.BackBtnId);
            configData.enableSpacebar = true;
            configData.stopSymbolSound = false;
        }
    }
}

