/// <reference path ="../../Interfaces.ts"/>

namespace ingenuity.BehaviorCore {
    export class PostLoadingView extends BehaviorCore.BaseView {
        protected resize(e?: IEvent): void {
            super.resize(e);
            this.pivot.set(configData.width / 2, configData.height / 2);
            this.x = innerWidth / 2;
            this.y = innerHeight / 2;
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.scale.set(deviceEnv.getPortraitScale() - core.constructors.bsBehavior.SlotConstants.PORTRAIT_SCALE_REDUCER);
            } else {
                this.scale.set(e.data.scale);
            }

            const postLoadAlpha = this.getShapeById("postLoadingAlpha");
            postLoadAlpha.inputEnabled = true;
            postLoadAlpha.scale.set(10, 10);
            postLoadAlpha.pivot.set(configData.width / 2, configData.height / 2);
            postLoadAlpha.x = configData.width / 2;
            postLoadAlpha.y = configData.height / 2;
        }
    }
}
