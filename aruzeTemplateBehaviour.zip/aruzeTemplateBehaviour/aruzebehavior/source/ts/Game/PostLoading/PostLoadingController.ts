/// <reference path ="../../Interfaces.ts"/>
namespace ingenuity.BehaviorCore {
    export class PostLoadingController {

        protected view: PostLoadingView;
        protected loadingAnim: ui.AnimationBase;
        /**
         * @param view
         */
        constructor(view: PostLoadingView) {
            this.view = view;
            this.initializeElements();
            this.subscribEvents();
        }

        protected initializeElements(): void {
            this.loadingAnim = this.view.getAnimationById("progress");
            this.view.getContainerByID("postLoader").visible = true;

        }

        protected subscribEvents(): void {
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER, this.show, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER, this.hide, this);

        }

        protected unsubscribEvents(): void {
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER, this.show, this);
            dispatcher.off(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER, this.hide, this);
        }

        /**
         * To show post loading screen
         */
        protected show(): void {
            this.view.getContainerByID("postLoader").visible = true;
            currentGame.stage.addChild(this.view);
            this.loadingAnim.playAnim("anim");
        }

        /**
         * Hide Post loading screen on loading complete
         */
        protected hide(): void {
            this.view.getContainerByID("postLoader").visible = false;
            currentGame.stage.removeChild(this.view);
        }
    }
}
