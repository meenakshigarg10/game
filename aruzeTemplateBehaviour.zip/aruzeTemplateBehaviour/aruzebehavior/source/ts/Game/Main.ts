///<reference path="../Interfaces.ts" />

namespace ingenuity.BehaviorCore {
    export class Main extends core.MainGame {

        protected introOutroView: ingenuity.BehaviorCore.IntroOutro.IntroOutroView;
        protected introOutroController: ingenuity.BehaviorCore.IntroOutro.Controller;
        protected clientErrorTriggered: boolean = false;
        protected resizePopUpDiv: HTMLElement;

        constructor(mainDiv: string = core.constructors.bsBehavior.SlotConstants.GAMECONTENT, deviceConfig?: {}, loadStateObj?: IGameStates) {
            super(mainDiv, deviceConfig, loadStateObj);
            const fontPath = ingenuity.baseURL + ingenuity.core.constructors.bsBehavior.SlotConstants.FONT_PATH;
            ingenuity.utils.LoadFonts(ingenuity.core.constructors.bsBehavior.SlotConstants.FONT_LIST, fontPath);
            this.subscribeEvents();
        }

        protected onSizeChange(e?: IEvent): void {
            const deviceEnvUpdate: IDeviceEnvironmentUpdate = e && e.data && e.data.hasOwnProperty(core.constructors.bsBehavior.SlotConstants.AVAIL_WIDTH) ? e.data : deviceEnv.update();
            if (deviceEnv.isDesktop) {
                currentGame.scale.setGameSize(innerWidth, innerHeight);
                currentGame.renderer.autoResize = true;
                currentGame.renderer.resize(deviceEnvUpdate.availWidth, deviceEnvUpdate.availHeight);
            } else {
                currentGame.scale.setGameSize(innerWidth, innerHeight);
                currentGame.renderer.autoResize = true;
                currentGame.renderer.resolution = deviceEnvUpdate.devicePixelRatio;
                currentGame.renderer.resize(deviceEnvUpdate.availWidth, deviceEnvUpdate.availHeight);
            }
            if (deviceEnv) {
                dispatcher.fireEvent(events.EventConstants.RESIZE, deviceEnvUpdate);
            } else {
                dispatcher.fireEvent(events.EventConstants.RESIZE, e);
            }
            this.orientationChanged(deviceEnvUpdate);
        }

        protected updateResizePopup(): void {
            const resizePopUpIFrame: HTMLElement = document.getElementById("resizePopUpframeContainer");
            resizePopUpIFrame.innerHTML = ingenuity.utils.Localization.initiated && ingenuity.utils.Localization.getText("orientationChange");
        }

        /**
        * This function register all events to communicate with internal platform
        */
        protected subscribeEvents(): void {
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.HIDE_GAME_INTRO_VIEW, this.onHideGameIntro, this);
            dispatcher.on(platform.EventConstants.ENVIRONMENT_READY, this.enviornmentReady, this);
            dispatcher.on(platform.EventConstants.OPEN_GAME_PROCESSED, this.openGame, this);
            dispatcher.on(ingenuity.events.EventConstants.UPDATE_LOADING_PROGRESS, this.onLoadingProgress, this);
            dispatcher.on(platform.EventConstants.BROKEN_FREE_GAME, this.onBrokenGameInitiated, this);
            dispatcher.on(platform.EventConstants.BROKEN_BASE_GAME, this.onBrokenGameInitiated, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.CREATE_INTRO_OUTRO, this.initializeIntroOutro, this);
            dispatcher.on(platform.aruze.EventConstants.CHECK_AND_SEND_WRAPPER_READY, this.checkAndSendWrapperReady, this);
            dispatcher.on(platform.EventConstants.HIDE_LOADER, this.hideLoader, this);
        }

        protected checkAndSendWrapperReady(evt: any): void {
            if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_BASE_GAME) && parserModel.getIsGameWrapperReady()) {
                dispatcher.fireEvent(platform.aruze.EventConstants.SEND_WRAPPER_READY);
            }
        }

        protected onHideGameIntro(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_REEL_PANEL);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_REEL_PANEL_CONTROLLER);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_PAYLINE);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_WIN_REEL_PRESENTATION_PANEL);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_WIN_PRESENTATION_CONTROLLER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_BASEGAME_VIEW);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.INITIALIZE_OVERLAY_WIN_REEL_PRESENTATION_PANEL);
            dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.UPDATE_TOTAL_BET_METER);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_DISABLE_SETTING_COIN_BT);
        }

        /*
        * setting language in the model.
        * If the language is not supported by the game model will set to `en` (English).
        */
        protected setLanguage(): void {
            let language: string = "";
            if (ingenuity.game.wrapper.gameWrapper) {
                ingenuity.parserModel.setLanguage(null);
                if (ingenuity.game.wrapper.gameWrapper.getParam(ingenuity.platform.aruze.Constants.LANGUAGE)) {
                    let currentLang = ingenuity.game.wrapper.gameWrapper.getParam(ingenuity.platform.aruze.Constants.LANGUAGE);

                    if (currentLang !== undefined) {
                        if (currentLang.indexOf("_") !== -1) {
                            currentLang = currentLang.split("_")[0];
                            language = currentLang;
                        }
                     } else {
                        ingenuity.parserModel.setLanguage("en");
                        return;
                    }

                    for (let lang of ingenuity.configData.languageSupported) {
                        if (lang === currentLang) {
                            ingenuity.parserModel.setLanguage(currentLang);
                            language = currentLang;
                        }
                    }

                    if (!language) {
                        ingenuity.parserModel.setLanguage("en");
                    }
                }
            }
        }

        /**
         * This handler will be called from event named ENVIROMENT_READY from platform.
         * ENVIROMENT_READY is fired from loadAndLaunchGame function, which is called by wrapper after wrapper initialization.
         * @param {ingenuity.IEvent} evt
         */
        protected enviornmentReady(evt: IEvent): void {
            ingenuity.defaultRenderer = bridge.CANVAS;
            this.setLanguage();
            this.loadHelp();
            this.loadPaytable();
            this.setGameStageWithCanvas(utils.getElement(core.constructors.bsBehavior.SlotConstants.GAME_CANVAS), () => {
                this.registerStates(this.loadStateObj);
                if (deviceEnv.isDesktop) {
                    mainManifestURL = core.constructors.bsBehavior.SlotConstants.MANIFEST_URL;
                } else {
                    mainManifestURL = core.constructors.bsBehavior.SlotConstants.MANIFEST_MOBILE_URL;
                }
                dispatcher.fireEvent(platform.EventConstants.LOADING_STARTED);
            }, this);
            currentGame.stage.smoothed = true;

        }
        /**
         * Preloading the help page.
         */
        protected loadHelp(): void {
            const lang: string = parserModel.getLanguage();
            const helpURL: string = ingenuity.baseURL + "images/common/postload/lang/" + lang + "/help/help.html";

            utils.ajax({
                url: helpURL,
                method: "get",
                receiveType: "text",
                withCredentials: false,
                success: (data: string): void => {
                    const infoContainerIframe: HTMLElement = document.getElementById(core.constructors.bsBehavior.SlotConstants.HELP_FRAME_CONTAINER);
                    let relativePath: string = "images/common/postload";
                    let reg = new RegExp(relativePath, "g");
                    data = data.replace(reg, ingenuity.baseURL + relativePath);
                    infoContainerIframe.innerHTML = data;
                },
                error: (error: IObject): void => { console.log(`Error : ${error}`); }
            });
        }

        protected loadPaytable(): void {
            const lang: string = parserModel.getLanguage();
            const imgTag: string = "<img src = " + ingenuity.baseURL + "images/common/preload/lang/" + lang + "/info/Info.jpg>";

            const payTableIframeContainer: HTMLElement = document.getElementById(core.constructors.bsBehavior.SlotConstants.payTableIframeContainer);
            payTableIframeContainer.innerHTML = imgTag;
        }

        protected initializeIntroOutro(): void {
            if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_FREE_GAME) && !this.introOutroView) {
                this.introOutroView = new core.constructors.bsBehavior.IntroOutroView(ingenuity.assetsData.getJSONById(core.constructors.bsBehavior.SlotConstants.MAIN_DATA).IntroOutro);
                this.introOutroController = new core.constructors.bsBehavior.IntroOutroController(this.introOutroView);
                currentGame.stage.addChildAt(this.introOutroView, 2);
            } else if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_FREE_GAME) && this.introOutroView) {
                //
            } else {
                dispatcher.on(events.EventConstants.FREEGAME_ASSETS_LOADED, this.initializeIntroOutro, this, true, null, 3);
            }
        }

        protected onLoadingProgress(evt: IEvent): void {
            const loadingPercent: number = evt.data;
            if (loadingPercent >= 100) {
                evt.remove();
            } else {
                dispatcher.fireEvent(platform.aruze.EventConstants.UPDATE_LOADER_PERCENTAGE, evt.data);
            }
        }

        protected onAssetsLoaded(evt: IEvent): void {
            configData.width = currentGame.cache.getJSON(core.constructors.bsBehavior.SlotConstants.MAIN_DATA).gameConfig.width;
            configData.height = currentGame.cache.getJSON(core.constructors.bsBehavior.SlotConstants.MAIN_DATA).gameConfig.height;
            currentGame.state.start(core.constructors.bsBehavior.SlotConstants.BASE_GAME, false, false);
            currentGame.stage.disableVisibilityChange = true;
            currentGame.stage.smoothed = true;
            this.addBackgroundView();
            this.addPostLoaderView();
            dispatcher.fireEvent(ingenuity.core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER);
            dispatcher.fireEvent(platform.aruze.EventConstants.CHECK_AND_SEND_WRAPPER_READY);
        }

        /**
         * Initialising background view and controller from here
         */
        protected addBackgroundView(): void {
            const backgroundView: any = new core.constructors.bsBehavior.BackGroundView(currentGame.cache.getJSON("main_data").background);
            new core.constructors.bsBehavior.BackgroundController(backgroundView);
        }

        /**
         * Initialising PostLoading view and controller from here
         */
        protected addPostLoaderView(): void {
            const postLoadingView: PostLoadingView = new ingenuity.BehaviorCore.PostLoadingView(currentGame.cache.getJSON("main_data").postLoading);
            new ingenuity.BehaviorCore.PostLoadingController(postLoadingView);
        }

        /**
         * This handler will be called from event named OPEN_GAME_PROCESSED from platform after parsing "gameRefresh" response.
         */
        protected openGame(evt: IEvent): void {
            this.resize();
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_BG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_SLOT_LOGIC);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_ANIMATION_COMPLETE);
            this.hideLoader();
        }

        /**
         * Hide loading screen when assets load complete
         */
        protected hideLoader(): void {
            this.resize(); // to handle Button Panel Positions during Slow Networks, as Top Bar and Bottom Bar height comes 0.
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_LOADER_PERCENTAGE, 100);
            // Event Fired to update wrapper winamount on game refresh
            dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.LOGIC_ONSTAKE_CHANGE);
            // Popup show in IE 11 for performance
            if (deviceEnv.browser.toLowerCase() === deviceEnvironment.DeviceDetector.BROWSER_NAMES.IE11) {
                ingenuity.game.wrapper.gameWrapper.ui.showMessage(ingenuity.utils.Localization.getText(BehaviorCore.slotConstants.SlotConstants.LBL_GAME_ON_BROWSER_ERROR_MSG));
            }

            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                dispatcher.fireEvent(platform.aruze.EventConstants.GET_TICKET_DATA);
            }

            dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.SHOW_SOUND_POPUP);
            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE ||
                parserModel.getNextAction() === BehaviorCore.slotConstants.SlotConstants.FREE_SPIN_ACTION ||
                ingenuity.configData.brokenOnClose) {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_GAME_INTRO_VIEW);
            } else {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.LAUNCH_GAME_INTRO);
            }
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER);

            currentGame.onResume.add((evt: any) => {
                soundManager && soundManager.unmuteAllSounds();
            }, this);
            currentGame.onPause.add((evt: any) => {
                soundManager && soundManager.muteAllSounds();
            }, this);

            /**
             * scalemode has been changed since in mobile devices canvas height was breaching the permissible limits
             */
            if (deviceEnv.isDesktop) {
                currentGame.scale.scaleMode = ingenuity.bridge.ScaleManager.RESIZE;
            } else {
                currentGame.scale.scaleMode = ingenuity.bridge.ScaleManager.SHOW_ALL;
            }
        }

        /**
         *
         * @param evt to send close request as soon as request response is parsed in broken for Fastplay
         * Show default reel during Broken processed
         */
        protected onBrokenGameInitiated(evt: IEvent): void {
            if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_BASE_GAME.toLowerCase())) {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER);
                this.resize();
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_BG);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_SLOT_LOGIC);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START);
                dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.SHOW_STATIC_REEL_GRID);
                if (parserModel.getNextAction() === platform.aruze.Constants.CLOSE_ACTION && !parserModel.getHasFreeGamesWin()) {
                    // to stop loader hide from here and do it after gamble response received. To Handle Postloading.
                    dispatcher.fireEvent(platform.aruze.EventConstants.GAMBLE_ENABLE_REQUEST);
                } else {
                    this.hideLoader();
                }
            } else {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER);
                dispatcher.on(events.EventConstants.BASEGAME_ASSETS_LOADED, this.onBrokenGameInitiated, this);
            }
        }
    }
}