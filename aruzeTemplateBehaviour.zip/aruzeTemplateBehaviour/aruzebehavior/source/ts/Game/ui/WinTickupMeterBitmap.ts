///<reference path="MeterBitmap.ts" />
namespace ingenuity.BehaviorCore.behaviourUI {
    export class WinTickupMeterBitmap extends MeterBitmap {
       protected winAmtDelay: number = 0;
       protected forceStopcallback: () => void;
       protected delayInCallback: () => void;

        /**
         *
         * @param showCurrency
         * @param showNumOnly
         * @param onlyNumber
         * @param delay
         * @param callback
         * overrided to be able to hold win amount in win meter for some time, while tickup is running.
         */
        public forceStop(showCurrency: boolean = true, showNumOnly: boolean = false, onlyNumber = true, delay?: number , callback1?: () => void ) {
            this.winAmtDelay = delay !== undefined && delay !== null ? delay : 0;
            if (this.ticking) {
                if (typeof this.tickupAnim === "undefined" || this.tickupAnim === null) {
                    return;
                }
                this.forceStopcallback = null;
                this.forceStopcallback = callback1;
                this.tickUpRunning = false;
                this.ticking = false;
                this.tickupAnim.stop(false);
                this.tickupAnim.onUpdateCallback(null, this);
                if (onlyNumber) {
                    if (showCurrency) {
                        this.setCurrencyFormattedValue(`${this.endValue}`);
                    } else if (showNumOnly) {
                        this.setValue(utils.toInt(`${this.endValue}`));
                    } else {
                        this.setFormattedValue(`${this.endValue}`);
                    }
                } else {
                    if (showCurrency) {
                        this.setCurrencyFormattedString(this.json.text, `${this.endValue}`);
                    } else {
                        this.setFormattedString(this.json.text, `${this.endValue}`);
                    }
                }

                this.endValue = 0;
                this.duration = 0;
                this.tickupAnim = null;
                this.onTickupComplete.dispatch();
                utils.delayedCall("holdWinAmt", this.winAmtDelay, () => {
                    utils.killDelayedCall("holdWinAmt");
                    if (callback1 !== undefined && callback1 !== null) {
                        this.forceStopcallback && this.forceStopcallback();
                    }
                }, this);
            }
        }

        /**
         * provide a callback with delay after tickup finishes by itself.
         * @param delay
         * @param callback2
         */
        public stopTickupAndDelay(delay?: number , callback2?: () => void ) {
            this.winAmtDelay = delay !== undefined && delay !== null ? delay : 0;
            this.delayInCallback = null;
            this.delayInCallback = callback2;
            utils.delayedCall("holdWinAmtNoTickup", this.winAmtDelay, () => {
                utils.killDelayedCall("holdWinAmtNoTickup");
                if (callback2 !== undefined && callback2 !== null) {
                    this.delayInCallback && this.delayInCallback();
                }
            }, this);
        }

        public getIsTickUpRunning(): boolean {
            return this.tickUpRunning;
        }
    }
}
