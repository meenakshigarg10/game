///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.behaviourUI {
    export class BsAnimationBase extends ui.AnimationBase {

        public constructor(json: IAnimation, game?: bridge.Game, parent?: bridge.DisplayObjectContainer) {
            super(json, game || currentGame, parent);
        }

        /**
         * Play animation
         * @param animName name of animation to play, defaults to "anim"
         * @param callbackFunction function to be executed once the animation completes
         * @param scope scope for callback
         */
        public playAnim(animName: string = "anim", callbackFunction?: () => void, scope?: any): BsAnimationBase {
            if (animName === "") {
                animName = "anim";
            }
            return super.playAnim(animName, callbackFunction, scope);
        }
    }
}
