///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.behaviourUI {
    export class MeterBitmap extends ui.MeterBitmap {
        public updateCallBack: (meter: MeterBitmap) => void;
        public tickUpRunning: boolean = false;

        constructor(json: ILabelBitmap) {
            super(json);
            (json.anchorX && json.anchorY) && (this.anchor.set(json.anchorX, json.anchorY));

        }
        public startTick(value: number, showCurrency?: boolean, showNumOnly?: boolean, duration?: number, onlyNumber?: boolean, callback?: () => void): number {
            if (this.ticking) {
                return value;
            }
            this.tickUpRunning = true;
            this.endValue = value;
            this.callback = callback;
            if (this.value >= value) {
                this.ticking = false;
                this.stopTick(showCurrency, showNumOnly, onlyNumber);
                return value;
            }
            this.ticking = true;
            this.onTickupStart.dispatch();
            this.duration = duration * 1000;

            let divider: number;
            this.tickupAnim = this.game.add.tween(this).to({
                value
            }, this.duration, Easing.Linear.None, true);

            this.tickupAnim.onComplete.addOnce(() => {
                this.stopTick(showCurrency, showNumOnly, onlyNumber);
            }, this);
            this.tickupAnim.onUpdateCallback(() => {
                if (this.value < value) {
                    divider = (value - this.value) / Math.round(this.game.time.fps * duration);
                    this.value += divider;
                    (this.value > value) && (this.value = value);
                    if (onlyNumber) {
                        if (showCurrency) {
                            this.setCurrencyFormattedValue(`${utils.round(this.value, 2)}`);
                        } else if (showNumOnly) {
                            this.setValue(utils.toInt(`${this.value}`));
                        } else {
                            this.setFormattedValue(`${utils.round(this.value, 2)}`);
                        }
                    } else {
                        if (showCurrency) {
                            this.setCurrencyFormattedString(this.json.text, `${utils.round(this.value, 2)}`);
                        } else {
                            this.setFormattedString(this.json.text, `${utils.round(this.value, 2)}`);
                        }
                    }
                    this.updateCallBack && this.updateCallBack(this);
                } else {
                    this.stopTick(showCurrency, showNumOnly, onlyNumber);
                }
            }, this);
        }
        public stopTick(showCurrency: boolean = true, showNumOnly: boolean = false, onlyNumber = true) {
            this.tickUpRunning = false;
            if (this.ticking) {
                if (typeof this.tickupAnim === "undefined" || this.tickupAnim === null) {
                    return;
                }

                this.ticking = false;
                // this.tickUpRunning = false;
                this.tickupAnim.stop(false);
                this.tickupAnim.onUpdateCallback(null, this);
                if (onlyNumber) {
                    if (showCurrency) {
                        this.setCurrencyFormattedValue(`${this.endValue}`);
                    } else if (showNumOnly) {
                        console.info(" ankush :: end ", utils.toInt(`${this.endValue}`));
                        this.setValue(utils.toInt(`${this.endValue}`));
                    } else {
                        this.setFormattedValue(`${this.endValue}`);
                    }
                } else {
                    if (showCurrency) {
                        this.setCurrencyFormattedString(this.json.text, `${this.endValue}`);
                    } else {
                        this.setFormattedString(this.json.text, `${this.endValue}`);
                    }
                }

                this.endValue = 0;
                this.duration = 0;
                this.tickupAnim = null;
                this.onTickupComplete.dispatch();
                this.callback && this.callback();
            }
        }

        public setBsCoinFormattedValue(value: string, decimalPlaces: number): void {
            this.resetMeter();
            this.value = isNaN(Number(value)) ? Number(value.match(/[0-9]+/g).join(".")) : Number(value);
            this.formatedValue = utils.Formatter.toLocaleNum(this.value, decimalPlaces);
            this.setText(this.formatedValue);
        }

        public setCurrencyFormattedValue(value: string): void {
            this.value = isNaN(Number(value)) ? Number(value.match(/[0-9]+/g).join(".")) : Number(value);
            this.currencyFormattedValue = ingenuity.game.wrapper.gameWrapper.formatCurrency(this.value);
            this.setText(this.currencyFormattedValue);
        }

        /**
         * overrided to make value fit inside a fixed space, if value size overflows the given bounds.
         */
        public fitText (): any {
            let fontSize = ingenuity.utils.toFloat(this.label.fontSize.toString());
            if (this.label.width > this.json.w) {
                let scale = this.json.w / this.label.width;
                if (scale < 1) {
                    this.label.fontSize = ingenuity.utils.round(fontSize * scale);
                    this.label.font.size = ingenuity.utils.round(fontSize * scale);
                }
            } else if (this.label.height > this.json.h) {
                let scale = this.json.h / this.label.height;
                if (scale < 1) {
                    this.label.fontSize = ingenuity.utils.round(fontSize * scale);
                    this.label.font.size = ingenuity.utils.round(fontSize * scale);
                }
            }
            return this;
        }

        /**
         * overrided to enable change in font size through json fontsize property
         */
        public resetSizing (): any {
            let fontSize;
            if (this.json.style.fontSize) {
                fontSize = ingenuity.utils.toInt(this.json.style.fontSize);
            } else if (this.json.style.font) {
                fontSize = this.json.style.font.split(" ");
                if (fontSize.length > 2) {
                    throw new Error("Bitmap font cannot have weight etc");
                } else if (fontSize.length === 2) {
                    fontSize = ingenuity.utils.toInt(fontSize[0]);
                } else {
                    fontSize = ingenuity.core.base.constants.DEFAULT_FONT_SIZE;
                }
            } else {
                fontSize = ingenuity.core.base.constants.DEFAULT_FONT_SIZE;
            }
            this.label.fontSize = fontSize;
            this.label.font.size = fontSize;
            return this;
        }
    }
}
