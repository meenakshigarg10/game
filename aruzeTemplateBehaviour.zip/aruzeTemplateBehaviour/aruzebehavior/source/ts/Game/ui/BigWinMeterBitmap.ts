///<reference path="MeterBitmap.ts" />
namespace ingenuity.BehaviorCore.behaviourUI {
    export class BigWinMeterBitmap extends MeterBitmap {
        public updateCallBack: (meter: MeterBitmap) => void;

        public setCurrencyFormattedValue(value: string): void {
            this.value = isNaN(Number(value)) ? Number(value.match(/[0-9]+/g).join(".")) : Number(value);
            this.currencyFormattedValue = ingenuity.game.wrapper.gameWrapper.formatCurrency(this.value);
            this.setText(this.currencyFormattedValue);
        }

        public stopTick(showCurrency: boolean = true, showNumOnly: boolean = false, onlyNumber = true, callback?: () => void ) {
            if (this.ticking) {
                if (typeof this.tickupAnim === "undefined" || this.tickupAnim === null) {
                    return;
                }

                this.ticking = false;
                this.tickupAnim.stop(false);
                this.tickupAnim.onUpdateCallback(null, this);
                if (onlyNumber) {
                    if (showCurrency) {
                        this.setCurrencyFormattedValue(`${this.endValue}`);
                    } else if (showNumOnly) {
                        this.setValue(utils.toInt(`${this.endValue}`));
                    } else {
                        this.setFormattedValue(`${this.endValue}`);
                    }
                } else {
                    if (showCurrency) {
                        this.setCurrencyFormattedString(this.json.text, `${this.endValue}`);
                    } else {
                        this.setFormattedString(this.json.text, `${this.endValue}`);
                    }
                }

                this.endValue = 0;
                this.duration = 0;
                this.tickupAnim = null;
                this.onTickupComplete.dispatch();
                if (callback === undefined) {
                    this.callback && this.callback();
                } else if (callback === null) {
                    this.callback = null;
                } else {
                    this.callback && this.callback();
                }
            }
        }

    }
}
