namespace ingenuity.BehaviorCore.SoundPopup {
    export class SoundPopupView extends BehaviorCore.BaseView {

        private bgShape: IGraphics;

        constructor(json: any) {
            super(json);
            this.bgShape = this.getShapeById(ingenuity.BehaviorCore.slotConstants.SlotConstants.BG_SHAPE);
            this.bgShape.inputEnabled = true;
        }

        public addOnTop(evt: IEvent): void {
            ingenuity.currentGame.stage.addChild(this);
        }

        public hideView(): void {
            this.visible = false;
        }

        public showView(): void {
            this.visible = true;
        }

        protected resize(evt: IEvent): void {
            super.resize(evt);
            const half: number = 2;
            this.pivot.set(ingenuity.configData.width / half, ingenuity.configData.height / half);
            this.x = innerWidth / half;
            this.y = innerHeight / half;
            this.bgShape && this.bgShape.pivot.set(ingenuity.configData.width / half, ingenuity.configData.height / half);
            this.bgShape && this.bgShape.scale.set(10, 10);
            if (!deviceEnv.isDesktop) {
                this.scale.set(1, 1);
            }
        }

        public killView(): void {
            dispatcher.off(events.EventConstants.RESIZE, this.resize, this);
            this.destroy();
        }
    }
}
