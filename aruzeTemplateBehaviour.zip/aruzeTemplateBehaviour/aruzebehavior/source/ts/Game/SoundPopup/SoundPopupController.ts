///<reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.SoundPopup {
    export class SoundPopupController {
        protected view: SoundPopupView;
        protected yesBtn: ingenuity.ui.ButtonBase;
        protected noBtn: ingenuity.ui.ButtonBase;

        constructor(view: SoundPopupView) {
            this.view = view;
            this.initializeElements();
            this.bindHandler();
            soundManager.setMute(true);
        }

        protected initializeElements(): void {
        this.yesBtn = this.view.getButtonById("yesBtn") as ui.ButtonBase;
        this.noBtn = this.view.getButtonById("noBtn") as ui.ButtonBase;
        }

        protected bindHandler(): void {
            this.yesBtn.on(ui.ButtonBase.UP, this.onYesPress, this);
            this.yesBtn.input.priorityID = 1;

            this.noBtn.on(ui.ButtonBase.UP, this.onNoPress, this);
            this.noBtn.input.priorityID = 1;

            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_SOUND_POPUP, this.show, this);
        }

        protected show(): void {
            this.view.showView();
        }

        /**
         *
         * @param button to update sound state in game and wrapper and begin game presentation
         * if in broke, will enable space bar on pressup or spacebar will be enabled on basegaem show
         */
        protected onYesPress(button?: ingenuity.ui.ButtonBase): void {
            soundManager.playSound(BehaviorCore.slotConstants.SoundConstant.SOUND_ON_BTN, 5, false, "soundList");
            soundManager.setMute(false);
            this.view.hideView();
            ingenuity.currentGame.stage.removeChild(this.view);
            this.view.killView();
            configData.brokenOnClose && (configData.enableSpacebar = true);
            this.checkForBrokenGame();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.UPDATE_SOUND_STATE);
        }

        /**
         *
         * @param button to update sound state in game and wrapper and begin game presentation
         * if in broke, will enable space bar on pressup or spacebar will be enabled on basegaem show
         */
        protected onNoPress(button?: ingenuity.ui.ButtonBase): void {
            soundManager.playSound(BehaviorCore.slotConstants.SoundConstant.SOUND_OFF_BTN, 5, false, "soundList");
            soundManager.setMute(true);

            this.view.hideView();
            (currentGame.stage as any).removeChild(this.view);
            this.view.killView();

            configData.brokenOnClose && (configData.enableSpacebar = true);
            this.checkForBrokenGame();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.UPDATE_SOUND_STATE);
        }

        protected checkForBrokenGame(): void {
            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                configData.endReqSent = true;
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED);
                dispatcher.fireEvent(platform.EventConstants.PLACE_BET_RESPONSE, parserModel.getGameHistoryResponse());
                parserModel.getGambleResponseInHistory() && dispatcher.fireEvent(ingenuity.platform.aruze.EventConstants.GAMBLE_BROKEN_RESPONSE_RECEIVED, parserModel.getGambleResponseInHistory());
            } else if (configData.brokenOnClose) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                if (parserModel.getHasFreeGamesWin()) {
                    if (loader.Loading.isStateLoaded(ingenuity.BehaviorCore.slotConstants.SlotConstants.FREEGAME)) {
                        configData.brokenOnClose = false;
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER);
                        configData.endReqSent = false;
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS);
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.UNSUBSCRIBE_PLAYER_MESSAGES);
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEVIEW_EVENTS);
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_FG);
                        parserModel.setFreeGameBroken(true);
                        currentGame.state.start(core.constructors.bsBehavior.SlotConstants.FREE_GAME, false, false, currentGame);
                    } else {
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER);
                        dispatcher.on(events.EventConstants.FREEGAME_ASSETS_LOADED, this.checkForBrokenGame.bind(this));
                    }

                } else {
                    configData.endReqSent = false;
                    configData.brokenOnClose = false;
                    /**done to run wheel animations of JP and if JP is available
                     * game presentation will start after wheels animation finishes.
                     */
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BROKEN_GAME, null);
                }
            } else if (parserModel.getNextAction() === BehaviorCore.slotConstants.SlotConstants.FREE_SPIN_ACTION) {
                if (parserModel.getFreeSpinsRemaining() === parserModel.getFreeSpinNum()) {
                    configData.endReqSent = false;
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                    /**done to run wheel animations of JP and if JP is available
                     * game presentation will start after wheels animation finishes.
                     */
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_BROKEN_GAME, null);
                } else if (parserModel.getFreeSpinsRemaining() !== parserModel.getFreeSpinNum()) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEVIEW_EVENTS);
                    if (loader.Loading.isStateLoaded(BehaviorCore.slotConstants.SlotConstants.FREEGAME)) {
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER);
                        configData.endReqSent = false;
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS);
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.UNSUBSCRIBE_PLAYER_MESSAGES);
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_FG);
                        parserModel.setFreeGameBroken(true);
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_BASEGAME_VIEW);
                        currentGame.state.start(core.constructors.bsBehavior.SlotConstants.FREE_GAME, false, false, currentGame);
                    } else {
                        dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER);
                        dispatcher.on(events.EventConstants.FREEGAME_ASSETS_LOADED, this.checkForBrokenGame.bind(this));
                    }
                }
            }  else {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotConstants.START_GAME_INTRO);
            }
        }
    }
}
