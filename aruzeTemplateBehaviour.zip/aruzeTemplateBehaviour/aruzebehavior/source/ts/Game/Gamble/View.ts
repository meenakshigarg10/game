///<reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.Gamble {
    export class View extends BehaviorCore.BaseView {
        protected gambleContainer: ui.Container;
        /**
         * @access public
         * @param json , json to access assets
         */

        constructor(viewJson: any) {
            super(viewJson);
            this.initializeComponent();

        }
        /**
         * To initialize gamble view
         *
         */
        protected initializeComponent(): void {
            this.gambleContainer = this.getContainerByID("gambleContainer");
        }
        /**
         * To show gamble view
         *
         */

        public showView(): void {
            this.gambleContainer.visible = true;
            this.gambleContainer.pivot.set(ingenuity.configData.width / 2, ingenuity.configData.height / 2);
            this.gambleContainer.alpha = 0;
            const zoomIn: bridge.ITween = currentGame.add.tween(this.gambleContainer).to({ alpha: 1 }, 250, undefined, true);
            zoomIn.onComplete.addOnce(() => {
                zoomIn.stop();
                currentGame.tweens.remove(zoomIn);
                if (parserModel.getGameMode() !== BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                    this.getContainerByID("playCardContainer").children.forEach(function (val, index) {
                        val.enableAndTint();
                    }, this);
                }
            });
        }

        /**
         * To hide gamble view
         *
         */
        public hideView(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_BUTTONS);
            const zoomIn: bridge.ITween = currentGame.add.tween(this.gambleContainer).to({ alpha: 0 }, 250, undefined, true);
            zoomIn.onComplete.addOnce(() => {
                zoomIn.stop();
                currentGame.tweens.remove(zoomIn);
                this.gambleContainer.alpha = 1;
                this.gambleContainer.visible = false;
                configData.stopSymbolSound = false;
                soundManager.stop("paysound");
            });
            this.getContainerByID("playCardContainer").children.forEach(function (val, index) {
                val.disableAndTint();
            }, this);
        }


        /**
         *
         * @param e overrided to change gamble scaling
         */
        protected resize(evt?: IEvent): void {
            super.resize(evt);
            this.pivot.set(ingenuity.configData.width / 2, ingenuity.configData.height / 2);
            this.x = (innerWidth / 2);
            this.y = innerHeight / 2;
            this.scale.set(evt.data.scale);
            if (ingenuity.deviceEnv.getOrientation() === ingenuity.deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                // this.scale.set(ingenuity.deviceEnv.getScale() + ingenuity.deviceEnv.getScale() * ingenuity.core.constructors.bsBehavior.SlotConstants.FIFTEEN_PERCENT);

                this.pivot.set(ingenuity.configData.width * slotConstants.SlotConstants.HALF_CONVERTER, 0);
                // this.scale.set(evt.data.scale);
                this.y = (innerHeight * ingenuity.core.constructors.bsBehavior.SlotConstants.FIVE_PERCENT) + BehaviorCore.slotConstants.SlotConstants.ADD_IN_Y;

            } else {
                if (deviceEnv.isDesktop) {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_DESKTOP;
                } else {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_MOBILE;
                }
            }
        }

    }
}