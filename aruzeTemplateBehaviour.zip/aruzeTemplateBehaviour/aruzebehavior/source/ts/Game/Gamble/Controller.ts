///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.Gamble {
    export class Controller {
        protected view: Gamble.View;
        protected model: BehaviorCore.BaseGame.Model;
        protected gambleHistoryContainer: ui.Container;
        protected historyContainerChildren: ui.Container;
        protected playCardContainer: ui.Container;
        protected gambleAmtMeter: ui.MeterBitmap;
        protected gambleDoubleAmtMeter: ui.MeterBitmap;
        protected counter: number = 0;
        protected winCard: ui.Bitmap;
        protected redCardArray: ui.Bitmap[];
        protected blackCardArray: ui.Bitmap[];
        protected drawnCard: string;
        protected drawnCardArray: string[];
        protected historyGambleCloseBtn: ui.ButtonBase;
        protected endReplyButton: ui.ButtonBase;

        constructor(view: Gamble.View, model: BehaviorCore.BaseGame.Model) {
            this.view = view;
            this.model = model;
            this.subscribeEvents();
            this.initializeGambleComponents();
        }

        /**
         *  To subscribe all events in gamble
         */
        protected subscribeEvents(): void {
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.START_GAMBLE_FEATURE, this.initializeGamble, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_VIEW, this.resetViewAndCloseGame, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.RESET_GAMBLE_VIEW, this.resetView, this);
            dispatcher.on(platform.aruze.EventConstants.GAMBLE_RESPONSE_PROCESSED, this.gambleResponseReceived, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_HISTORY, this.updateHistory, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_HISTORY_IN_SUITE_GAMBLE, this.updateHistoryForSuiteGamble, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_GAMBLE_VIEW_IN_HISTORY, this.updateHistoryView, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HIDE_POTENTIAL_WIN, this.hidePotentialWin, this);
        }

        /**
         * To initialize gamble components
         */
        protected initializeGambleComponents(): void {
            this.gambleHistoryContainer = this.view.getContainerByID("gambleHistoryContainer");
            this.playCardContainer = this.view.getContainerByID("playCardContainer");
            this.gambleAmtMeter = this.view.getMeterById("gambleAmountWinMtr") as ui.MeterBitmap;
            this.gambleDoubleAmtMeter = this.view.getMeterById("gambleDoubleAmountWinMtr") as ui.MeterBitmap;
            this.historyGambleCloseBtn = this.view.getButtonById("historyGambleCloseButton") as ui.ButtonBase;
            this.historyGambleCloseBtn && this.historyGambleCloseBtn.on(ingenuity.ui.ButtonBase.UP, this.historyCloseBtnPressed, this);
            this.endReplyButton = this.view.getButtonById("endReplayButton") as ui.ButtonBase;
            this.endReplyButton && this.endReplyButton.on(ingenuity.ui.ButtonBase.UP, this.endReplayPressed, this);

            this.bindSelectectionEvents();
            if (configData.SuitGamble) {
                this.drawnCardArray = new Array();
                this.addCardsInArray();
            }
        }

        protected landscapeCollectBtnPressUp(): void {
            parserModel.setIsGambleAvailable(false);
            if (this.model.getIsTurboModeOn()) {
                this.view.getButtonById("turboModeDisableBtn").visible = true;
            }
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_VIEW);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_AFTER_GAMBLE);
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SoundConstant.COLLECT_BTN);
        }

        /**
         * To Store Red and Black Cards in Array
         */
        protected addCardsInArray(): void {
            // For Red Cards
            this.redCardArray = new Array();
            this.redCardArray.push(this.view.getImageById("winCardH"));
            this.redCardArray.push(this.view.getImageById("winCardD"));

            // For Black Cards
            this.blackCardArray = new Array();
            this.blackCardArray.push(this.view.getImageById("winCardS"));
            this.blackCardArray.push(this.view.getImageById("winCardC"));

        }

        /**
         * To Shuffle the Cards in Array
         */
        protected shufffleArray(arr: any): number {
            let randomNum: number;
            randomNum = Math.floor(Math.random() * arr.length);
            return randomNum;
        }

        /**
         * To bind pick card buttons
         * note: for future games, if feature contains some new symbols like suit, add their components(that player can select) as button in
         * playCardContainer container.
         * and add their outcome cards in mysteryCardContainer container. Also name these card containers and their childs
         * as per the server response
         */
        protected bindSelectectionEvents(): void {
            const cardsLength: number = this.playCardContainer.children.length;
            for (let i: number = 0; i < cardsLength; i++) {
                (this.playCardContainer.children[i] as ui.ButtonBase).on(ingenuity.ui.ButtonBase.UP, this.onCardClick, this, false);
            }
        }


        /**
         * To handle click event on card
         */
        protected onCardClick(evt: any): void {
            dispatcher.fireEvent(platform.aruze.EventConstants.SELECT_CARD_REQUEST, (evt.name as string).substr(0, 1));
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.DISABLE_COLLECT_BTN);
            this.playCardContainer.children.forEach((val: ui.ButtonBase, index: number) => {
                (val as ui.ButtonBase).disableAndTint();
            }, this);
            (this.view.getButtonById(evt.name) as ui.ButtonBase).enableAndTint();
            (this.view.getButtonById(evt.name) as ui.ButtonBase).setIsInputEnabled(false);
            dispatcher.fireEvent(ingenuity.events.EventConstants.BUTTON_RELESED, BehaviorCore.slotConstants.SoundConstant.GAMBLE_CARD);
        }

        /**
         * to show gamble presentation, once response received from server
         */
        protected gambleResponseReceived(): void {
            this.showRandomCard();
            if (configData.SuitGamble) {
                this.view.getContainerByID("mysteryWinCardContainer" + this.drawnCardArray[0]).visible = true;
                dispatcher.fireEvent(ingenuity.platform.aruze.EventConstants.SET_TICKET_DATA, { type: "gamble", value: this.drawnCardArray.toString() });
                if (this.model.getPlayerSelectedGambleSymbol() === this.model.getGambleDrawnCard()[0]) {
                    this.startTweenOnWinningCard(this.drawnCardArray[0]);
                } else {
                    // statement is used, to handle RC during close request
                    parserModel.setTotalWin(this.model.getGambleWinAmount());
                    this.updateMeters(this.model.getGambleWinAmount());
                    this.updateHistory();
                    soundManager.playSound(BehaviorCore.slotConstants.SoundConstant.GAMBLE_CARD_LOOSE, 5, false, "soundList");
                    dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getGambleWinAmount()) });
                    utils.delayedCall("hideGamble", 2000, () => {
                        utils.killDelayedCall("hideGamble");
                        this.resetViewAndCloseGame();
                        !deviceEnv.isDesktop && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR);
                    }, this);
                }
            } else {
                this.view.getContainerByID("mysteryWinCardContainer" + this.drawnCard).visible = true;
                if (this.model.getPlayerSelectedGambleSymbol() === this.model.getGambleDrawnCard()[0]) {
                    this.startTweenOnWinningCard(this.drawnCard);
                } else {
                    // statement is used, to handle RC during close request
                    parserModel.setTotalWin(this.model.getGambleWinAmount());
                    this.updateMeters(this.model.getGambleWinAmount());
                    this.updateHistory();
                    soundManager.playSound(BehaviorCore.slotConstants.SoundConstant.GAMBLE_CARD_LOOSE, 5, false, "soundList");
                    dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getGambleWinAmount()) });
                    utils.delayedCall("hideGamble", 2000, () => {
                        utils.killDelayedCall("hideGamble");
                        this.resetViewAndCloseGame();
                        !deviceEnv.isDesktop && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR);
                    }, this);
                }
            }
        }

        /** When Response recevied for Color Button
         * then show Random card
         */
        protected showRandomCard(): void {
            if (configData.SuitGamble) {
                if (this.model.getGambleDrawnCard()[0] === "R") {
                    this.drawnCardArray.unshift(this.redCardArray[this.shufffleArray(this.redCardArray)].name.substr(7, 1));
                } else if (this.model.getGambleDrawnCard()[0] === "B") {
                    this.drawnCardArray.unshift(this.blackCardArray[this.shufffleArray(this.blackCardArray)].name.substr(7, 1));
                } else {
                    this.drawnCardArray.unshift(this.model.getGambleDrawnCard()[0]);
                }
            } else {
                this.drawnCard = this.model.getGambleDrawnCard()[0];
            }
        }


        /**
         * To highlight the icon (Heart and Spade) after clicking on the red or black card,
         * update gamble history and enable buttons
         */
        protected startTweenOnWinningCard(dCard: string): void {
            ingenuity.utils.delayedCall("CardTween", 200, function () {
                if (this.counter >= 10) {
                    soundManager.stop(BehaviorCore.slotConstants.SoundConstant.GAMBLE_CARD_WIN);
                    this.view.getImageById("winCard" + dCard).visible = false;
                    // statement is used, to handle RC during close request
                    parserModel.setTotalWin(this.model.getGambleWinAmount());
                    this.updateMeters(this.model.getGambleWinAmount());
                    this.updateHistory();
                    dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getGambleWinAmount()) });
                    this.view.getContainerByID("mysteryWinCardContainer" + dCard).visible = false;
                    this.view.getContainerByID("mysteryFoldedCardContainer").visible = true;
                    if (this.model.getIsGambleAvailable()) {
                        this.playCardContainer.children.forEach((val: ui.ButtonBase, index: number) => {
                            (val as ui.ButtonBase).enableAndTint();
                        }, this);
                        this.counter = 0;
                        ingenuity.utils.killDelayedCall("CardTween");
                        ingenuity.dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_COLLECT_BTN);
                    } else {
                        ingenuity.utils.delayedCall("GambleDelayClose", 2000, function () {
                            this.resetViewAndCloseGame();
                            ingenuity.utils.killDelayedCall("GambleDelayClose");
                        }, this);
                    }
                } else {
                    if (this.counter === 0) {
                        soundManager.playSound(BehaviorCore.slotConstants.SoundConstant.GAMBLE_CARD_WIN, 5, false, "soundList");
                    }
                    this.winCard = this.view.getImageById("winCard" + dCard);
                    this.winCard.visible = !this.winCard.visible;
                    this.counter++;
                    this.startTweenOnWinningCard(dCard);
                }
            }, this);
        }



        /**
         * To reset card buttons, gamble history view and hide gamble view and then send close
         */

        protected resetViewAndCloseGame(): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
            this.resetView();
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_AFTER_GAMBLE);
        }

        protected resetView(): void {
            /** called this function to assign drawncard value from response*/
            if (configData.SuitGamble) {
                this.drawnCardArray.length && (this.view.getContainerByID("mysteryWinCardContainer" + this.drawnCardArray[0]).visible = false);
                this.drawnCardArray = [];
            } else {
                this.model.getGambleDrawnCard() && this.showRandomCard();
                (this.model.getGambleDrawnCard()) && (this.model.getGambleDrawnCard().length) && (this.view.getContainerByID("mysteryWinCardContainer" + this.drawnCard).visible = false);
            }
            this.playCardContainer.children.forEach((val: ui.ButtonBase, index: number) => {
                (val as ui.ButtonBase).enableAndTint();
            }, this);
            this.gambleHistoryContainer.children.forEach((val: ui.Container) => {
                val.visible = false;
            }, this);
            this.view.hideView();
        }


        /**
         * To initialize gamble view with updated win and gamble amount
         */
        protected initializeGamble(): void {
            this.view.showView();
            this.updateMeters(this.model.getTotalWinAmt());
            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                this.historyGambleCloseBtn.visible = true;
                this.endReplyButton.visible = true;
            }
        }

        /**
         * To update gamble amount and gamble double amount as per the selected color (Icon)
         */
        protected updateMeters(evt: number): void {
            this.gambleAmtMeter.setCurrencyFormattedValue(evt.toString());
            const doubleWinAmt: number = evt * 2;
            this.gambleDoubleAmtMeter.setCurrencyFormattedValue(doubleWinAmt.toString());
        }


        /**
         * To update gamble history (The revealed icon as per selected card) in history section
         */
        protected updateHistory(): void {
            if (configData.SuitGamble) {
                this.drawnCardArray && this.drawnCardArray.forEach((choosenCard: string, index: number) => {
                    this.historyContainerChildren = this.view.getContainerByID("gambleHistoryCardContainer" + index);
                    this.historyContainerChildren.children.forEach((val: ui.Bitmap) => {
                        val.visible = false;
                    }, this);
                    this.historyContainerChildren.visible = true;
                    if (configData.SuitGamble) {
                        if (this.model.getGambleDrawnCard()[0] === "R") {
                            this.view.getImageById("gambleHistoryCard" + index + choosenCard).visible = true;
                        } else if (this.model.getGambleDrawnCard()[0] === "B") {
                            this.view.getImageById("gambleHistoryCard" + index + choosenCard).visible = true;
                        } else {
                            this.view.getImageById("gambleHistoryCard" + index + choosenCard).visible = true;
                        }
                    }
                }, this);
            } else {
                this.model.getGambleDrawnCard() && this.model.getGambleDrawnCard().forEach((choosenCard: string, index: number) => {
                    this.historyContainerChildren = this.view.getContainerByID("gambleHistoryCardContainer" + index);
                    this.historyContainerChildren.children.forEach((val: ui.Bitmap) => {
                        val.visible = false;
                    }, this);
                    this.historyContainerChildren.visible = true;
                    this.view.getImageById("gambleHistoryCard" + index + choosenCard).visible = true;
                }, this);
            }
        }

        protected updateHistoryForSuiteGamble(): void {
            this.model.getRandomCardData() && this.model.getRandomCardData().forEach((choosenCard: string, index: number) => {
                this.historyContainerChildren = this.view.getContainerByID("gambleHistoryCardContainer" + index);
                this.historyContainerChildren.children.forEach((val: ui.Bitmap) => {
                    val.visible = false;
                }, this);
                this.historyContainerChildren.visible = true;
                this.view.getImageById("gambleHistoryCard" + index + choosenCard).visible = true;
                this.drawnCardArray.unshift(choosenCard);
            }, this);
        }

        /**
         * to update gamble final view when game is in hisory mode.
         */
        protected updateHistoryView(): void {
            if (configData.SuitGamble) {
                this.view.getContainerByID("mysteryWinCardContainer" + this.model.getRandomCardData()[0]).visible = true;
                this.view.getImageById("staticCard" + this.model.getRandomCardData()[0]).visible = true;
                this.playCardContainer.children.forEach((val: ui.ButtonBase, index: number) => {
                    if (val.name.substr(0, 1) === this.model.getRandomCardData()[this.model.getRandomCardData().length - 1].toLowerCase()) {
                        (val as ui.ButtonBase).enableAndTint();
                        (val as ui.ButtonBase).setIsInputEnabled(false);
                    } else {
                        (val as ui.ButtonBase).disableAndTint();
                    }
                }, this);
            } else {
                this.showRandomCard(); // to store response value in drawn Card Variable
                this.view.getContainerByID("mysteryWinCardContainer" + this.drawnCard).visible = true;
                this.view.getImageById("staticCard" + this.drawnCard).visible = true;
                this.playCardContainer.children.forEach((val: ui.ButtonBase, index: number) => {
                    if (val.name.substr(0, 1) === this.model.getPlayerSelectedGambleSymbol().toLowerCase()) {
                        (val as ui.ButtonBase).enableAndTint();
                        (val as ui.ButtonBase).setIsInputEnabled(false);
                    } else {
                        (val as ui.ButtonBase).disableAndTint();
                    }
                }, this);
            }
        }

        protected endReplayPressed(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END);
        }

        protected historyCloseBtnPressed(): void {
            this.view.hideView();
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END);
        }

        /**
         * to hide potentail win container in case of History.
         */
        protected hidePotentialWin(): void {
            const potentialContainer: ui.Container = this.view.getContainerByID("gambleDoubleAmountContainer");
            potentialContainer.visible = false;
        }

    }
}