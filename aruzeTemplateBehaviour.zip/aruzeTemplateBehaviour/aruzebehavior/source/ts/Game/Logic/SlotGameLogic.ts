/// <reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.Logic {

    export class SlotGameLogic extends slot.Logic.SlotGameLogic {
        public static isGamePaused: boolean = false;
        protected model: any; // model requires to access data to make decision for game behavior
        protected scatterSoundPause: boolean = false;

        constructor() {
            super();
            this.handleVisibilityChange();
        }

        /**
         * Override this function to subscribe events which are not there in super function
         * subscribeEvents,subscribes events to listen in game and to make decision for game behavior
         */
        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(slotConstants.SlotEventConstants.ON_STOP_AUTO_PLAY_CLICKED, this.onStopAutoPlayClicked, this);
            dispatcher.on(slotConstants.SlotEventConstants.NOW_SPIN_REEL_AFTER_BROKEN, this.nowSpinReelAfterBroken, this);
            dispatcher.on(slotConstants.SlotEventConstants.SHOW_STATIC_REEL_GRID, this.showStaticReelGrid, this);
            dispatcher.on(slotConstants.SlotEventConstants.RESET_REEL_SPINNING_AND_RESPONSE_RECIEVED, this.resetReelSpinningAndServerResponseReceived, this);
            dispatcher.on(slotConstants.SlotEventConstants.SET_IS_REEL_SPINNING, this.setIsReelSpinning, this);
            dispatcher.on(slotConstants.SlotEventConstants.ON_SPIN_STOP_CLICKED, this.onSpinStopClicked, this);
            dispatcher.on(slotConstants.SlotEventConstants.ON_BET_PLUS_CLICKED, this.onBetPlusClicked, this);
            dispatcher.on(slotConstants.SlotEventConstants.ON_BET_MINUS_CLICKED, this.onBetMinusClicked, this);
            dispatcher.on(slotConstants.SlotEventConstants.AFTER_HIDE_BIG_WIN, this.afterHideBigWin, this);
            dispatcher.on(slotConstants.SlotEventConstants.UPDATE_PAID_METERS_AFTER_HIDE_BIG_WIN, this.updatePaidMetersAfterHideBigWin, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.CLICK_BS_START_AUTOPLAY, this.startAutoPlayClicked, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SET_GAME_INTRO_SHOW, this.setGameIntroShow, this);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SET_GAME_INTRO_HIDE, this.setGameIntroHide, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.SHOW_FREEGAME_RETRIGGER_POPUP, this.startFreeGameRetriggerScatterPresentation, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.FG_SCATTER_ANIMATION_ENDED, this.freeGameRetriggerPopup, this);
            dispatcher.on(slotConstants.SlotEventConstants.BIG_WIN_END, this.onBigWinEnd, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK, this.resetPresentationsOnSpinClick, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK_FG, this.resetPresentationsOnSpinClickFg, this);
            dispatcher.on(slotConstants.SlotEventConstants.SEND_CLOSE_IF_NO_WIN, this.sendCloseRequest, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.FREEGAME_RETURN_SEND_CLOSE, this.sendCloseRequest, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_AFTER_GAMBLE, this.sendCloseRequest, this);

            // listener for wrapper pause/resume
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.WRAPPER_PAUSE, this.onWrapperPause, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.WRAPPER_RESUME, this.onWrapperResume, this);
            dispatcher.on(slot.slotConstants.SlotEventConstants.SCATTER_ANIMATION_ENDED, this.startNextWinPresentation);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_SPIN_CALL, this.sendNextSpinCall, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END, this.historyEnd, this);
            // listener for gamble
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.GAMBLE_CHECK_AND_SEND_CLOSE, this.checkGambleStatus, this);
            dispatcher.on(platform.aruze.EventConstants.GAMBLE_ENABLE_RESPONSE_RECEIVED, this.onGambleResponseReceived, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_IN_AUTOPLAY_IF_WIN, this.sendCloseRequest, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_AFTER_GAMBLE, this.closeSentByGamble, this);
        }

        protected onGambleResponseReceived(evt: IEvent): void {
            //
        }

        protected startNextWinPresentation(evt: IEvent): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
        }

        /**
         * Override this function to unsubscribe events which are not there in super function
         */
        protected unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(slotConstants.SlotEventConstants.ON_STOP_AUTO_PLAY_CLICKED, this.onStopAutoPlayClicked);
            dispatcher.off(slotConstants.SlotEventConstants.NOW_SPIN_REEL_AFTER_BROKEN, this.nowSpinReelAfterBroken);
            dispatcher.off(slotConstants.SlotEventConstants.SHOW_STATIC_REEL_GRID, this.showStaticReelGrid);
            dispatcher.off(slotConstants.SlotEventConstants.RESET_REEL_SPINNING_AND_RESPONSE_RECIEVED, this.resetReelSpinningAndServerResponseReceived);
            dispatcher.off(slotConstants.SlotEventConstants.SET_IS_REEL_SPINNING, this.setIsReelSpinning);
            dispatcher.off(slotConstants.SlotEventConstants.ON_SPIN_STOP_CLICKED, this.onSpinStopClicked);
            dispatcher.off(slotConstants.SlotEventConstants.ON_BET_PLUS_CLICKED, this.onBetPlusClicked);
            dispatcher.off(slotConstants.SlotEventConstants.ON_BET_MINUS_CLICKED, this.onBetMinusClicked);
            dispatcher.off(slotConstants.SlotEventConstants.AFTER_HIDE_BIG_WIN, this.afterHideBigWin);
            dispatcher.off(slotConstants.SlotEventConstants.UPDATE_PAID_METERS_AFTER_HIDE_BIG_WIN, this.updatePaidMetersAfterHideBigWin);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK, this.resetPresentationsOnSpinClick, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.RESET_WIN_PRESENTATION_ON_SPIN_CLICK_FG, this.resetPresentationsOnSpinClickFg, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SEND_NEXT_SPIN_CALL, this.sendNextSpinCall, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.FREEGAME_RETURN_SEND_CLOSE, this.sendCloseRequest, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END, this.historyEnd, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.GAMBLE_CHECK_AND_SEND_CLOSE, this.checkGambleStatus, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_AFTER_GAMBLE, this.sendCloseRequest, this);
            dispatcher.off(platform.aruze.EventConstants.GAMBLE_ENABLE_RESPONSE_RECEIVED, this.onGambleResponseReceived, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_AFTER_GAMBLE, this.closeSentByGamble, this);
        }

        // handler to check wrapper pause
        protected onWrapperPause(evt: IEvent): void {
            //
        }

        // handler to check wrapper resume
        protected onWrapperResume(evt: IEvent): void {
            //
        }

        protected onCheckForWinAfterReelStop(evt: IEvent): void {
            if (parserModel.getIsFreeSpintriggered() || parserModel.getIsFreeSpinRetriggered()) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_SPIN_BTN_HIDE_STOP_BTN);
            }

            if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                (this.model.getIsWin() || parserModel.getFreeSpinsRemaining() === 0) && dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_SHOW_SPIN_BTN_HIDE_STOP_BTN);
            }

            this.model instanceof BaseGame.Model && this.model.setIsReelSpinningInAutoPlay(false);

            if (this.model.getIsWin() && parserModel.getTotalWin() || parserModel.getHasFreeGamesWin()) {
                if (this.model.getIsAutoPlayLeft()) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_AUTOPLAY_STOP_BTN);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_AUTOPLAY_BTN);
                }
                this.setWinlineAndWaysData();
                utils.killDelayedCall(BehaviorCore.slotConstants.SlotConstants.BROKEN_DELAY_FG);
                if (parserModel.getHasFreeGamesWin() && currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState) {
                    if (deviceEnv.browser !== "EDGE" && deviceEnv.browser !== "IE10" && deviceEnv.browser !== "IE11") {
                        soundManager.playSound(core.constructors.bsBehavior.SoundConstants.SCATTER_TRIGGER, 1);
                        soundManager.getSoundInstance(core.constructors.bsBehavior.SoundConstants.SCATTER_TRIGGER).onMarkerComplete.addOnce(() => {
                            this.showNextWinPresentation();
                        }, this);
                    } else {
                        this.showNextWinPresentation();
                    }
                } else {
                    this.showNextWinPresentation();
                }
            } else {
                utils.killDelayedCall(slotConstants.SlotConstants.NoWinDelay);
                utils.delayedCall(slotConstants.SlotConstants.NoWinDelay, slotConstants.SlotConstants.setDelayForNoWin, () => {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_CONTAINERS, slotConstants.SlotConstants.ButtonsContainerId);
                });
            }
        }

        /**
         * Pause all activity when receive event from gdk
         * @param {ingenuity.IEvent} evt
         */
        protected onGamePause(evt: any): void {
            currentGame.gamePaused(evt);
            soundManager.setMute(true);
            SlotGameLogic.isGamePaused = true;
        }

        /**
         * Resume all activity whatever paused when receive event from gdk
         * @param {ingenuity.IEvent} evt
         */
        protected onGameResume(evt: any): void {
            SlotGameLogic.isGamePaused = false;
            currentGame.gameResumed(evt);
            soundManager.setMute(false);
        }

        /**
         * Override this function to update "Spaghtti" case and remove timer
         *
         * onShowNextWinPresentation, it execute win presentation one by one in sequence defind in model
         * @param evt
         */
        protected onShowNextWinPresentation(evt?: IEvent) {
            const winSequenceCounter: number = this.model.getAnimationSequenceCounter(); // animation sequence counter , which increase its value agter every win sequence execution
            if (winSequenceCounter >= this.model.getAnimationSequence().length) {
                return;
            }
            const sequenceArray: String[] = this.model.getAnimationSequence(); // animation sequence array
            const currentWinEventToShow: String = sequenceArray[winSequenceCounter]; // current win presentation to show from win sequence
            this.updateAnimationSequenceCounter(); // update sequnce number after every current sequence pick and to execute next sequence
            switch (currentWinEventToShow) {
                case "Spaghtti":
                    this.onShowSpaghtti();
                    break;
                case "showAllFrames":
                    this.onShowAllFrames();
                    break;
                case "bigWin":
                    this.onShowBigWin();
                    break;
                case "firstToggle":
                    this.onFirstToggle();
                    break;
                case "firstToggleWays":
                    this.onFirstToggleWays();
                    break;
                case "secondToggle":
                    this.onSecondToggle();
                    break;
                case "secondToggleWays":
                    this.onSecondToggleWays();
                    break;
                case "triggeringAnimation":
                    this.onTriggeringAnimation();
                    break;
                case "freeSpin":
                    this.onFreeSpinPresentation();
                    break;
                case "checkForAutoplay":
                    this.onCheckForAutoPlay();
                    break;
            }

        }

        /**
         *
         * onShowSpaghtti, shows spaghtti in game, by fireing an event "slotConstants.SlotEventConstants.SHOW_SPAGHTTI"
         */
        protected onShowSpaghtti() {
            if (ingenuity.currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SHOW_SPAGHTTI);
                if (this.model.getIsWin()) {
                    this.startWinMeterTickUP();
                }
            } else {
                ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_SPAGHTTI);
                if (!this.model.getIsBigWin() || this.model.getIsScatterWins()) {
                    this.startWinMeterTickUP();
                }
            }
        }

        /**
         * overrided to prevent starting win meter tickup immediately on showing all win frames
         */
        protected onShowAllFrames(): void {
            if (this.model.getIsWin()) {
                if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SHOW_ALL_WIN_FRAMES);
                    if (!this.model.getIsBigWin()) {
                        this.startWinMeterTickUP();
                    }
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_ALL_WIN_FRAMES);
                    if (!this.model.getIsBigWin() || this.model.getIsScatterWins()) {
                        this.startWinMeterTickUP();
                    }
                }
            }
        }

        protected onShowBigWin(): void {
            if (this.model.getIsBigWin() && !parserModel.getHasScatterWins()) {
                if (ingenuity.loader.Loading.isStateLoaded(ingenuity.core.base.constants.loader.STAGE_BASE_GAME_POSTLOAD)) {
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER);
                    this.startTheBigWinPresentation();
                    dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.BEGIN_STAGE_CLICK);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.BRING_GUI_ON_TOP);
                } else {
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                    dispatcher.on(ingenuity.events.EventConstants.BASEGAME_POSTLOAD_ASSETS_LOADED, (e: IEvent) => {
                        utils.delayedCall(BehaviorCore.slotConstants.SlotConstants.BIG_WIN_POSTLOAD, BehaviorCore.slotConstants.SlotConstants.BIG_WIN_POSTLOAD_DELAY_INTERVAL, () => {
                            utils.killDelayedCall(BehaviorCore.slotConstants.SlotConstants.BIG_WIN_POSTLOAD);
                            this.onShowBigWin();
                        }, this);
                    }, this, true);
                }
            } else {
                if (this.model.getIsBigWin() && ingenuity.currentGame.state.getCurrentState().key === ingenuity.slot.slotConstants.SlotConstants.freeGameState) {
                    this.startTheBigWinPresentation();
                    dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.BEGIN_STAGE_CLICK);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.BRING_GUI_ON_TOP);
                } else {
                    if (this.model.getIsScatterWins()) {
                        if (this.model.getIsAutoPlayLeft()) {
                            this.model.setAnimationSequenceCounter(this.model.getAnimationSequence().length - BehaviorCore.slotConstants.SlotConstants.RESET_TO_TRIGGERING_ANIMATION);
                        }
                    }

                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                }
            }
        }

        /**
         * call next win presentation after big win hide
         */
        protected afterHideBigWin(): void {
            if (!(this.model.getIsAutoPlayLeft() || this.model.getIsScatterWins() || this.model.getIsAnyFeature())) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
            }
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
        }

        protected onFirstToggle(): void {
            configData.showWinBoxOnFirstToggle = false;
            if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.baseGameState) {
                if (parserModel.getHasFreeGamesWin()) {
                    dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.BEGIN_STAGE_CLICK);
                    configData.enableStageClickOnFirstToggle = true;
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_STAGE_CLICK_PLAYER_MSG);
                }
            } else if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.freeGameState) {
                dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.DISABLE_STAGE_CLICK);
                if (ingenuity.parserModel.getIsFreeSpinRetriggered()) {
                    dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.BEGIN_STAGE_CLICK);
                    configData.enableStageClickOnFirstToggle = true;
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_STAGE_CLICK_PLAYER_MSG);
                }
            }
            super.onFirstToggle();
        }

        protected onSecondToggle(): void {
            configData.showWinBoxOnFirstToggle = true;
            if (this.model.getIsAutoPlayLeft()) {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA);
            }
            if (ingenuity.currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.DISABLE_STAGE_CLICK);
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_STAGE_CLICK_PLAYER_MSG);
                /**
                 * Done so that when freespin is retriggered and there is no line win then consolePanel win meter get updated
                 */
                if (parserModel.getIsFreeSpinRetriggered() && !this.model.getIsLineWins()) {
                    //
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SUSPEND_WINPRESENTATION);
                }
            }
            configData.enableStageClickOnFirstToggle = false;
            super.onSecondToggle();
        }

        protected onTriggeringAnimation(): void {
            configData.enableStageClickOnFirstToggle = false;
            dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.DISABLE_STAGE_CLICK);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_STAGE_CLICK_PLAYER_MSG);
            super.onTriggeringAnimation();
        }

        protected startScatterPresentation(): void {
            if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_START_SCATTER_PRESENTATION);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.START_SCATTER_PRESENTATION);
            }
        }

        protected onSpinClicked(evt: IEvent): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.RESET_REEL_SPINNING_AND_RESPONSE_RECIEVED);
            utils.killDelayedCall("autoplaydelay");
            utils.killDelayedCall(slot.slotConstants.SlotConstants.SpaghettiDisplayTimer);
            configData.enableStageClickOnFirstToggle = false;
            configData.enableSpacebar = false;
            configData.enableStageClick = false;
            configData.freegameReturning = false;
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_BUTTONS);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.RESET_GAMBLE_VIEW);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.FORCE_STOP_WIN_METER_TICKUP);
            configData.spinComplete = false;
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.STOP_AUTOPLAY_BY_WRAPPER, this.onStopAutoPlayClicked, this);
        }

        /**
         * splitted from spinclicked function so that presentation is suspended after winmeter tickup stops
         */
        protected resetPresentationsOnSpinClick(): void {
            if (this.model.getIsBigWinRunning()) {
                this.model.setIsSpinClicked(true);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN);
                /**to show winamount in winmeter for some time on spin click
                 * reset it after some delay
                 */
            } else if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (0) });
            } else {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getTotalWinAmt()) });
            }
            !deviceEnv.isDesktop && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_STOP_BTN);
            utils.killDelayedCall("SHOW_SPAGHTTI");
            utils.killDelayedCall("5OKind");
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_UKGC_LIMITS_MSGS);
            if (this.model.serverModel.getFreeSpinsRemaining() > 0) {
                utils.killDelayedCall(slotConstants.SlotConstants.ClearBigWinCompleteDelayer);
                utils.delayedCall(slotConstants.SlotConstants.ClearBigWinCompleteDelayer, slotConstants.SlotConstants.ClearBigWinCompleteTimer / 2, () => {
                    this.onFreeSpinPresentation();
                });
            } else {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.PLAYER_MSG_SPIN_CLICK);
                if (!this.model.getIsBigWinRunning()) {
                    this.processingSpinClicked();
                    this.model.setIsBigWinRunning(false);
                }
            }
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.STOP_AUTOPLAY_BY_WRAPPER, this.onStopAutoPlayClicked, this);
        }

        protected onBigWinEnd(): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getTotalWinAmt()) });
            this.processingSpinClicked();
            this.model.setIsBigWinRunning(false);
        }

        /**
         * Created this function to optimize onSpinClicked function
         */
        protected processingSpinClicked() {
            if (ingenuity.configData.isAutoplayActive) {
                if (!ingenuity.parserModel.getIsCloseResponseReceived()) {
                    if (ingenuity.parserModel.getCloseResponse() !== null && ingenuity.parserModel.getCloseResponse() !== undefined) {
                        return;
                    }
                }
            }
            /**
             * done to show winamount in console meter if fastplayed during bigwin and also for gamble
             * broken
             */
            utils.delayedCall("resetConsoleWinMeter", 500, () => {
                utils.killDelayedCall("resetConsoleWinMeter");
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SET_WIN_VALUE_TO_DEFAULT);
            }, this);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_AUTOPLAY_BUTTONS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_SPIN_TIMER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.REMOVE_ALL_LISTNERS_FROM_STAGE);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_DATA);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.VALIDATE_BET);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_AUTOPLAY_METERS);
            if (!this.model.getIsAutoPlayLeft()) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.AUTOPLAY_RESET);
            } else {
                dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.AutoPlayOffBtnId]);
            }
        }

        /**
         * Created this function to optimize onSkipClicked function
         */
        protected processingSkipClicked() {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_FREEGAME_REELPANEL_EVENTS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS);
            dispatcher.off(slot.slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START_FG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_WINPRESENTATION_PANEL_FG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_METER_CONTROLLERS_FG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SCBSCRIBE_METER_CONTROLLERS_BG);
        }

        /**
         * Override this function to update player message and clear win presentation
         *
         * doNextSpin is called in free spin  when free spin remaining. And when free spin count is zero then it calls the outro of free game.
         */
        protected doNextSpin(evt: IEvent): void {
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.PLAYER_MSG_SPIN_CLICK);
            if (!(this.model instanceof FreeGame.Model && this.model.getFreeSpinsRemaining())) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION);
            }
            if (this.model instanceof slot.FreeGame.Model && this.model.getFreeSpinsRemaining()) {
                this.model.resetForSpin();
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED_IN_FREE_GAME);
            } else {
                utils.delayedCall(slot.slotConstants.SlotConstants.TimerForDisplayOutro, ingenuity.configData.freeSpinTimer, function () {
                    utils.killDelayedCall(slot.slotConstants.SlotConstants.TimerForDisplayOutro);
                    this.unSubscribeReelPanelControllerEvents();
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SUSPEND_WINPRESENTATION);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_FREEGAME_REELPANEL_EVENTS);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_FREEGAME_WIN_PRESENTATION_EVENTS);
                    dispatcher.off(slot.slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START_FG);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_WINPRESENTATION_PANEL_FG);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_METER_CONTROLLERS_FG);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SCBSCRIBE_METER_CONTROLLERS_BG);
                    dispatcher.fireEvent(events.EventConstants.STOP_SOUND, "freeGameBGMusic");
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.FG_OUTRO_SHOW);
                }, this);
            }
        }

        /**
         *
         * onFreeSpinPresentation, shows presenatation for FreeSpin
         */
        protected onFreeSpinPresentation(): void {
            if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState && parserModel.getFreeSpinsRemaining() > 0) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_ALL_EVENTS_ON_REEL_PANEL_CONTROLLER);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEGAME_REELPANEL_EVENTS);
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UNSUBSCRIBE_PLAYER_MESSAGES);
                if (loader.Loading.isStateLoaded(core.base.constants.loader.STAGE_FREE_GAME)) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CREATE_INTRO_OUTRO);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_BASEGAME_VIEW);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INTRO_SHOW);
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEVIEW_EVENTS);
                } else {
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_POST_LOADER);
                    dispatcher.on(events.EventConstants.FREEGAME_ASSETS_LOADED, function () {
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CREATE_INTRO_OUTRO);
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_BASEGAME_VIEW);
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.INTRO_SHOW);
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UNSUBSCRIBE_BASEVIEW_EVENTS);
                    }, this, true, null, 2);
                }
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
            }
        }

        /**
         * Override this function for add one more check for big win
         */
        protected autoplayReset(): void {
            //
        }

        /**
         * Override this function to reset the autoplay when it finished
         * call checkForAutoPlay for again spinning.
         */
        protected checkForAutoPlayCondition(): void {
            /**
             * to stop autoplay on freegame returning
             */
            if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState) {
                if (this.model.getIsAutoPlayLeft()) {
                    utils.killDelayedCall(BehaviorCore.slotConstants.SlotConstants.NoWinDelay);
                    this.model instanceof BaseGame.Model && this.model.setIsReelSpinningInAutoPlay(true);
                    this.checkForAutoPlay();
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.AUTOPLAY_RESET);
                    if (!parserModel.getHasFreeGamesWin()) {
                        ingenuity.dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                    }
                }
            }
        }

        /**.
         * overrided to add a delay for big win
         */
        protected checkForAutoPlay(): void {
            let delayTime: number = 0;
            if (this.model.getIsBigWin()) {
                delayTime = BehaviorCore.slotConstants.SlotConstants.AutoPlayDelayBigWin;
            } else if (this.model.getIsWin()) {
                delayTime = BehaviorCore.slotConstants.SlotConstants.AutoPlayDelayWin;
            }
            utils.delayedCall("autoplaydelay", delayTime, () => {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED);
            });
        }

        /**
         *
         * @param evt This is handler function of AUTOPLAY_EXPEND_BUTTON_PRESSUP event, which is fire from ButtonController
         * isAutoplayActive variable is useed to handle gamble and close call on reel stop. In any autoplay spin, gamble won,t be enabled using this variable
         */
        protected startAutoPlayClicked(evt: IEvent): void {
            configData.isAutoplayActive = true;
            this.model instanceof BaseGame.Model && this.model.setIsReelSpinningInAutoPlay(true);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.RESET_METERS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.AUTOPLAY_COUNT, evt.data);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CHECK_FOR_AUTOPLAY_CONDITION);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_AUTOPLAY_ON_BTN);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_AUTOPLAY_OFF_BTN);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.AutoPlayOffBtnId]);
        }

        /**
         * This is handler function of NOW_SPIN_REEL_AFTER_BROKEN event which is fire from Template, to start spinning after broken.
        */
        protected nowSpinReelAfterBroken(evt: IEvent): void {
            dispatcher.fireEvent(slotConstants.SlotEventConstants.START_REEL_SPINNING);
        }

        /**
         *
         * This is handler function of NOW_SPIN_REEL_AFTER_BROKEN event.
         * This function fires SHOW_SYMBOLS_ON_GRID  event, which is handled in ReelPanelController to show symbols on grid.
         */
        protected showStaticReelGrid(evt: IEvent): void {
            dispatcher.fireEvent(slotConstants.SlotEventConstants.SHOW_SYMBOLS_ON_GRID, evt);
        }

        /**
         * This function reset AllReelSpinning and ServerResponseReceived for broken reel spin
         */
        protected resetReelSpinningAndServerResponseReceived(): void {
            this.model.setServerResponseReceived(false);
            this.model.setAllReelSpinning(false);
        }

        /**
         * Set reel spinning
         * @param evt
         */
        protected setIsReelSpinning(evt: IEvent): void {
            this.model.setIsReelSpinning(evt.data);
        }

        /**
         * This function called when spinStop button clicked
         * @param evt
         */
        protected onSpinStopClicked(evt: IEvent): void {
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.CLEAR_RIGHT_PLAYER_MSG);
            if (ingenuity.currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_FORCE_STOP);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FORCE_STOP);
            }
        }

        /**
         * This function called when bet plus button clicked
         * @param evt
         */
        protected onBetPlusClicked(evt: IEvent): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION);
        }

        /**
         * This function called when bet minus button clicked
         * @param evt
         */
        protected onBetMinusClicked(evt: IEvent): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION);
        }


        /**
         * This function called for update paid meters after big win complete
         * @param evt
         */
        protected updatePaidMetersAfterHideBigWin(evt: IEvent): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_PAID_METER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_TOTAL_WIN_METER);
        }

        /**
         * overrided to communicate to common UI
         * if spin is clicked while gamble buttons are enable, allow sending request to server.
         */
        protected onValidateBet(evt: IEvent): void {
            parserModel.getIsGambleAvailable() && (configData.endReqSent = true);
            /**undefined condition is temporary. Used to stop game stuck on game load. */
            if (configData.endReqSent === undefined || configData.endReqSent === true) {
                configData.endReqSent = false;
                this.model.reSetAnimationSequenceCounter(0);
                if (!this.model.getReSpinIdentifier()) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_BALANCE_METER_AFTER_SPIN_CLICK);
                }
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.RESET_METERS);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_EVENTS_ON_REEL_START);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
                if (this.model.getIsTurboModeOn()) {
                    this.model.setIsStopReel(true);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN);
                } else {
                    this.model.setIsStopReel(false);
                    dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.REASSIGN_STOP_BTN);
                }
                (this.model.getIsAutoPlayLeft()) && dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [BehaviorCore.slotConstants.SlotConstants.AutoPlayOffBtnId]);
                (configData.onSpinBtnPanelHide) && dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_CONTAINERS);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.NOW_SPIN_REEL);

            } else if (!configData.endReqSent) {
                return;
            } else {
                if (this.model.getIsAutoPlayLeft()) {
                    this.model.resetAutoPlay();
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CHECK_FOR_AUTOPLAY_CONDITION);
                }
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLED_ALL_BUTTONS, slotConstants.SlotConstants.ButtonsContainerId);
            }
        }

        /**
         * overrided to start first toggle for ways game in case of win
         */
        protected onFirstToggleWays(): void {
            if (this.model.getIsWin() && !this.model.getIsAutoPlayLeft()) {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.RESET_BASEGAME_WIN_ALPHA);
                if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_START_FIRST_TOGGLE_CYCLE_WAYS);
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.START_FIRST_TOGGLE_CYCLE_WAYS);
                }
            } else {
                this.showNextWinPresentation();
            }
        }

        /**
         * Overrided to trigger event for Common UI
         * It is called when on All Reel Spinning and Spin Response Received.
         */
        protected OnreelSpiningAndServerResponseReceived(): void {
            if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.baseGameState && !this.model.getIsTurboModeOn()) {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_SPIN_STOP_PLAYER_MSG);
            }
            this.model.setServerResponseReceived(false);
            this.model.setAllReelSpinning(false);
            if (this.model.getIsStopReel()) {
                if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_STOP_REEL_NOW);
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.STOP_REEL_NOW);
                }
            }
            if (this.model.getIsTurboModeOn()) {
                if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN);
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_REELVIEW_MODEL_FOR_QUICKSPIN);
                }
            } else {
                if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_ENABLE_STOP_BTN);
                } else {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_STOP_BTN);
                }
            }
            (this.model.getIsAutoPlayLeft() && !this.model.getIsTurboModeOn()) && dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_STOP_BTN);
            dispatcher.off(platform.EventConstants.SPIN_RESPONSE_PROCESSED);
            if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_CHECK_FOR_ANTICIPATION_ON_REELS);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_UPDATE_SYMBOLS_ON_GRID);
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CHECK_FOR_LANDING_SOUNDS_ON_REELS_FG);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CHECK_FOR_ANTICIPATION_ON_REELS);
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_SYMBOLS_ON_GRID);
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.CHECK_FOR_LANDING_SOUNDS_ON_REELS);
            }
        }

        /**
         * to mute all sounds of the game
         */
        protected muteAllSounds(): void {
            ingenuity.soundManager.pauseAll();
        }

        /**
         * to unmute all sounds of the game
         */
        protected unmuteAllSounds(): void {
            ingenuity.soundManager.resumeAll();
        }

        /**
         * override to handle bonus/freegame flow after intro hide
         */
        protected IntroHideComplete(): void {
            const nextAction: string = ingenuity.parserModel.getNextAction();
            if (nextAction === core.constructors.bsBehavior.SlotConstants.FREE_SPIN) {
                if (parserModel.getRetriggerFreeSpins()) {
                    ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.RESET_METERS);
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DO_NEXT_SPIN);
                } else {
                    ingenuity.dispatcher.off(slot.slotConstants.SlotEventConstants.SCBSCRIBE_BUTTON_CONTROLLERS_BG);
                    ingenuity.dispatcher.off(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_BUTTON_CONTROLLERS_BG);
                    ingenuity.dispatcher.off(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_BG);
                    ingenuity.dispatcher.off(slot.slotConstants.SlotEventConstants.INITIALIZE_ALL_CONTROLLERS_BG);
                    ingenuity.dispatcher.off(slot.slotConstants.SlotEventConstants.SCBSCRIBE_METER_CONTROLLERS_BG);
                    ingenuity.dispatcher.off(slot.slotConstants.SlotEventConstants.UNSCBSCRIBE_METER_CONTROLLERS_BG);
                    ingenuity.currentGame.state.start(core.constructors.bsBehavior.SlotConstants.FREE_GAME, false, false, ingenuity.currentGame);
                }
            }
        }

        /**
         * OutroHideComplete calls when Outro hides complete and then clear free game state and calls shutdown of state.
         */
        protected OutroHideComplete(): void {
            currentGame.state.clearCurrentState();
            currentGame.state.current = core.constructors.bsBehavior.SlotConstants.BASE_GAME;
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ON_FREEGAME_RETURNING);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_WINPRESENTATION_PANEL_BG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_SPACEBAR_EVENTS);
        }

        /**
         * sets game-intro state to hide
         */
        protected setGameIntroHide(): void {
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SET_GAME_INTRO_STATE_LOCALLY, "hide");
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.UPDATE_CHECKBOX_GAME_INTRO, false);
        }

        /**
         * sets game-intro state to show
         */
        protected setGameIntroShow(): void {
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SET_GAME_INTRO_STATE_LOCALLY, "show");
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.UPDATE_CHECKBOX_GAME_INTRO, true);
        }

        protected handleVisibilityChange(): void {
            window.addEventListener(core.constructors.bsBehavior.SlotConstants.VISIBILITY_CHANGE, (evt) => {
                this.onVisibilityChange(evt);
            }, false);

            document.addEventListener(core.constructors.bsBehavior.SlotConstants.VISIBILITY_CHANGE, (evt) => {
                this.onVisibilityChange(evt);
            }, false);

            document.addEventListener(core.constructors.bsBehavior.SlotConstants.WEB_VISIBILITY_CHANGE, (evt) => {
                this.onVisibilityChange(evt);
            }, false);
        }

        protected onVisibilityChange(evt: IObject): void {
            if (evt.target.visibilityState === "visible") {
                if (!parserModel.getIsSoundMute()) {
                    soundManager.setMute(false);
                    if (ingenuity.deviceEnv.browser !== "EDGE" && ingenuity.deviceEnv.browser !== "IE10" && ingenuity.deviceEnv.browser !== "IE11") {
                        if (this.scatterSoundPause) {
                            soundManager.playSound(core.constructors.bsBehavior.SoundConstants.SCATTER_TRIGGER, 0.1);
                            this.scatterSoundPause = false;
                            soundManager.getSoundInstance(core.constructors.bsBehavior.SoundConstants.SCATTER_TRIGGER).onMarkerComplete.addOnce(() => {
                                this.showNextWinPresentation();
                            }, this);
                        }
                    }
                }
            } else {
                soundManager.setMute(true);
                if (ingenuity.deviceEnv.browser !== "EDGE" && ingenuity.deviceEnv.browser !== "IE10" && ingenuity.deviceEnv.browser !== "IE11") {
                    if (soundManager.isSoundPlaying(core.constructors.bsBehavior.SoundConstants.SCATTER_TRIGGER)) {
                        soundManager.pause(core.constructors.bsBehavior.SoundConstants.SCATTER_TRIGGER);
                        this.scatterSoundPause = true;
                    }
                }
            }
        }

        /* method is overrided to send game close request once winmeter got updated */
        protected sendCloseRequest(): void {
            if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.baseGameState && !configData.endReqSent) {
                if (!parserModel.getHasFreeGamesWin()) {
                    dispatcher.fireEvent(platform.EventConstants.GAME_CLOSE);
                    configData.endReqSent = true;
                }
            } else if (currentGame.state.getCurrentState().key === slot.slotConstants.SlotConstants.freeGameState) {
                if (!parserModel.getIsFreeSpinRetriggered() && !this.model.getIsWin()) {
                    if (this.logicRunningFor === slot.slotConstants.SlotConstants.LogicScopeFG || this.model.getReSpinIdentifier()) {
                        ingenuity.dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.DO_NEXT_SPIN);
                    }
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_CONTAINERS, slot.slotConstants.SlotConstants.ButtonsContainerId);
                }
            }
        }

        /**
         *
         * @param evt bigwin: this function will work if spin clicked while bigwin was running and will
         * send next spin call after bigwin suspend
         */
        protected sendNextSpinCall(evt: IObject): void {
            if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.baseGameState) {
                if (configData.isAutoplayActive && this.model.getIsBigWin() && !this.model.getIsScatterWins()) {
                    if (this.model.getIsSpinClicked()) {
                        this.model.setIsSpinClicked(false);
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getTotalWinAmt()) });
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_IN_AUTOPLAY_IF_WIN);
                        this.model.setIsBigWinRunning(false);
                    } else {
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SEND_CLOSE_IN_AUTOPLAY_IF_WIN);
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CHECK_FOR_AUTOPLAY_CONDITION);
                    }
                } else if (this.model.getIsBigWin() && !this.model.getIsScatterWins()) {
                    if (this.model.getIsSpinClicked()) {
                        this.model.setIsSpinClicked(false);
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BS_WIN, { value: (this.model.getTotalWinAmt()) });
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SET_WIN_VALUE_TO_DEFAULT);
                        this.processingSpinClicked();
                        this.model.setIsBigWinRunning(false);
                    } else if (!this.model.getIsAutoPlayLeft()) {
                        //
                    } else {
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CHECK_FOR_AUTOPLAY_CONDITION);
                    }
                } else if (this.model.getIsAutoPlayLeft() && !this.model.getIsScatterWins()) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CHECK_FOR_AUTOPLAY_CONDITION);
                }
            } else if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.freeGameState) {
                this.model.setIsBigWinRunning(false);
                if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                    dispatcher.fireEvent(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.UPDATE_FG_TOTALWIN_IN_HISTORY);
                } else {
                    parserModel.setTotalWin(parserModel.getTotalWin());
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_TOTAL_WIN_MSG);
                }
                if (this.model.getIsSpinClicked()) {
                    this.model.setIsSpinClicked(false);
                } else {
                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SPIN_CLICKED_IN_FREE_GAME);
                }
            }
        }

        protected startFreeGameRetriggerScatterPresentation(): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_START_SCATTER_WIN_ANIM, this.model.getTriggerScatterWinData());
        }

        protected freeGameRetriggerPopup(): void {
            utils.delayedCall("freegameretriggerpopup", 600, function () {
                utils.killDelayedCall("freegameretriggerpopup");
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_RETRIGGER_ANIMATION);
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR_FG);
            }, this);
        }

        /**
         *
         * @param evt overrided to check whether winmeter was running during spin clicked
         * and then carry forward the presentation
         */
        protected onSpinClickedInFreeGame(evt: IEvent): void {
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.FORCE_STOP_WIN_METER_TICKUP_FG);
        }

        /**
         * send the call for next spin . Works on spin clicked
         */

        protected resetPresentationsOnSpinClickFg(): void {
            configData.enableSpacebar = false;
            ingenuity.utils.killDelayedCall("SHOW_SPAGHTTI");
            utils.killDelayedCall(slot.slotConstants.SlotConstants.TimerForNextFreeSpin);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR_FG);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SUSPEND_WINPRESENTATION);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_SPIN_TIMER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.REMOVE_ALL_LISTNERS_FROM_STAGE);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_CLEAR_DATA);
            if (this.model.getFreeSpinsRemaining() === 0) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DO_NEXT_SPIN);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.VALIDATE_BET_IN_FREEGAME);
            }
            dispatcher.fireEvent(slotConstants.SlotEventConstants.UPDATE_FREESPIN_LABEL_COUNT);
            if (this.model.getIsBigWinRunning()) {
                this.model.setIsSpinClicked(true);
            }
        }

        protected onStakeChange(): void {
            super.onStakeChange();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_BASEGAME_WIN_ALPHA);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUSPEND_WINPRESENTATION);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_DISABLE_SETTING_COIN_BT);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SET_WIN_VALUE_TO_DEFAULT);
            dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.STOP_SYMBOL_SOUND);
            !deviceEnv.isDesktop && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_DEVICE_WIN_MTR);
        }

        protected onStopAutoPlayClicked(): void {
            this.model.currentAutoSpinIndex = this.model.totalAutoSpins + 1;
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.UPDATE_AUTOPLAY_METERS);
        }

        protected onSkipClicked(): void {
            ingenuity.utils.killDelayedCall("SHOW_SPAGHTTI");
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_DISABLED_ALL_BUTTONS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SUSPEND_WINPRESENTATION);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUMUP_BIGWIN);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_SPIN_TIMER);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.REMOVE_ALL_LISTNERS_FROM_STAGE);
            utils.killDelayedCall(slot.slotConstants.SlotConstants.TimerForNextFreeSpin);
            utils.delayedCall(slot.slotConstants.SlotConstants.TimerForNextFreeSpin, ingenuity.configData.freeSpinTimer, function () {
                this.model.resetForSpin();
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SPIN_CLICKED_IN_FREE_GAME);
            }.bind(this));
        }

        /**end history replay */
        protected historyEnd(): void {
            if (!parserModel.getHasFreeGamesWin()) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.END_REPLAY);
                parserModel.setFreeSpinCount(0);
                parserModel.setFreeSpinWinAmt(0);
                if (this.model.getGambleDrawnCard() && this.model.getGambleDrawnCard().length) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.DISABLE_COLLECT_BTN);
                } else {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_BUTTONS);
                }
                configData.endReqSent = true;
            }
        }

        /**
         * to check gamble availability status on reels stop and accordingly send close.
         */
        protected checkGambleStatus(): void {
            if (configData.isAutoplayActive) {
                if (!this.model.getIsWin()) {
                    this.sendCloseRequest();
                }
                return;
            }
            if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                if (this.model.getIsBigWin()) {
                    if (!parserModel.getTotalWin()) {
                        dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HISTORY_END);
                    }
                } else if (!this.model.getIsScatterWins() && this.model.getIsWin() && this.model.getGambleDrawnCard().length) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_GAMBLE_BUTTON);
                } else if (!this.model.getIsScatterWins()) {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.HIDE_GAMBLE_BUTTONS);
                }
            } else if (this.model.getIsGambleAvailable()) {
                if (this.model.getIsBigWin()) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ENABLE_BUTTON, [slotConstants.SlotConstants.SpinBtnId]);
                } else {
                    dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.ENABLE_GAMBLE_BUTTONS);
                }
            } else {
                this.sendCloseRequest();
            }
        }

        /**to disable button panel buttons during close request sent by gamble, and enable it after close response Received . To Handle Postloading*/
        protected closeSentByGamble(): void {
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.DISABLED_ALL_BUTTONS);
        }
    }
}
