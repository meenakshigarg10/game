namespace ingenuity.BehaviorCore {
    export class Bitmap extends ingenuity.ui.Bitmap {
        constructor(json: IImage) {
            super(json);

            (json.pivotX || json.pivotY) && (this.pivot.set(json.pivotX || 0, json.pivotY || 0));

            (json.anchorX || json.anchorY) && (this.anchor.set(json.anchorX || 0, json.anchorY || 0));

            (json.alpha) && (this.alpha = json.alpha);
        }
    }
}