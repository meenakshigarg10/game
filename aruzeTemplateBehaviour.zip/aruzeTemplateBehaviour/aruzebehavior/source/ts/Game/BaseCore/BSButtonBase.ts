/// <reference path="../../Interfaces.ts" />
/**
 *
 */
namespace ingenuity.BehaviorCore {
    export class BSButtonBase extends ui.ButtonBase {

        public  toggleStates(state1?: string, state2?: string, toggleTime?: number, buttonName?: any) {
            if (state1 === void 0) {
                state1 = this.ButtonBase.OUT;
            }
            if (state2 === void 0) {
                state2 = this.ButtonBase.OVER;
            }
            if (toggleTime === void 0) {
                toggleTime = 500;
            }
            this.currentState = state1;
            this.freezeFrames = false;
            ingenuity.utils.delayedLoopCall("toggleStates" + buttonName, toggleTime, function () {
                if (this.currentState === state1) {
                    this.currentState = state2;
                    this.changeStateFrame(state2);
                } else {
                    this.currentState = state1;
                    this.changeStateFrame(state1);
                }
            }, this);
            return this;
        }

        public clearToggleState(buttonName?: string): any {
            ingenuity.utils.killDelayedCall("toggleStates" + buttonName);
            this.freezeFrames = false;
            this.currentState = ingenuity.ui.ButtonBase.OUT;
            this.changeStateFrame(ingenuity.ui.ButtonBase.OUT);
            return this;
        }

        /**
         * To set the state of button to specific frame manually .
         * We can pass a optional parameter for the frame we want to set.
         * By default it will set the frame corresponding to 'Down' key define during button creation in json.
            ButtonBase.UP = "Up";
            ButtonBase.DOWN = "Down";
            ButtonBase.OVER = "Over";
            ButtonBase.OUT = "Out";
            ButtonBase.DISABLED = "Disabled";
        **/
        public keepSelectedBtn(state?: string): void {
            if (!state) {
                state = ingenuity.ui.ButtonBase.DOWN;
            }
            this.changeStateFrame(state);
            this.freezeFrames = true;
        }
    }
}
