
namespace ingenuity.BehaviorCore {
    export class BaseView extends ui.BaseView {
        protected CurrentOrientation: string = "";
        constructor(viewJson: IObject) {
            super(viewJson);
            ingenuity.dispatcher.fireEvent(ingenuity.events.EventConstants.RESIZE, ingenuity.deviceEnv.update());
        }

        protected resize(evt: IEvent): void {
            super.resize(evt);
            if (!ingenuity.deviceEnv.isDesktop) {
                if (this.CurrentOrientation !== ingenuity.deviceEnv.getOrientation()) {
                    this.CurrentOrientation = ingenuity.deviceEnv.getOrientation();
                    this.updateOrientation();
                }
            }
        }
        protected updateOrientation(): void {
            for (const key in this.allComponents) {
                if (this.allComponents.hasOwnProperty(key)) {
                    const comp: any = this.allComponents[key];
                    if (comp.json && comp.json.orientation) {
                        this.updateProperties(comp, comp.json.orientation[this.CurrentOrientation]);
                    }
                }
            }
        }
        protected updateProperties(comp: any, json: IObject): void {
            for (const property in json) {
                if (json.hasOwnProperty(property)) {
                    const value: any = json[property];
                    switch (property) {
                        case "x":
                            comp.x = value;
                            break;
                        case "y":
                            comp.y = value;
                            break;
                        case "visible":
                            comp.visible = value;
                            break;
                        case "scaleX":
                            comp.scale.set(value, comp.scale.y);
                            break;
                        case "scaleY":
                            comp.scale.set(comp.scale.x, value);
                            break;
                        case "scale":
                            comp.scale.set(value);
                            break;
                        case "style": {
                            comp.json.style = value;
                            comp.setStyle(value, true);
                            break;
                        }
                    }
                }
            }
        }
        public createDisplayTree(json: any): void {
            switch (json.type.toLowerCase()) {
                case "bigwinmeterbitmap":
                    this.createBigWinMeter(json);
                    break;
                default:
                    super.createDisplayTree(json);
            }
        }

        protected createBigWinMeter(json: ILabelBitmap) {
            const meterObj = new core.constructors.bsBehavior.BigWinMeterBitmap(json);
            meterObj.setText(utils.Localization.getText(json.text, json.replaceText));
            if (json.parent) {
                this.containers[json.parent].addChild(meterObj);
            } else {
                this.addChild(meterObj);
            }
            this.meters[json.id] = meterObj;
            this.allComponents[json.id] = meterObj;
            return meterObj;
        }

        public createShape(json: IShape): ingenuity.bridge.Graphics {
            let objGraphic = new ingenuity.bridge.Graphics(this.game, json.x, json.y);
            objGraphic.lineStyle(json.strokeSize, json.strokeColor, json.strokeAlpha);
            objGraphic.beginFill(json.fillColor, json.fillAlpha);
            switch (json.shape.toLocaleLowerCase()) {
                case "rectangle":
                    objGraphic.drawRect(0, 0, json.w, json.h);
                    break;
                case "roundcornerrectangle":
                    objGraphic.drawRoundedRect(0, 0, json.w, json.h, json.radius);
                    break;
                case "circle":
                    objGraphic.drawCircle(0, 0, json.diameter);
                    break;
                case "custom":
                    if (typeof json.commandArray === "undefined") {
                        throw new Error("Please provide command array for free shape");
                    } else {
                        let commandLen = json.commandArray.length;
                        objGraphic.moveTo(json.commandArray[0][0], json.commandArray[0][1]);
                        for (let i = 1; i < commandLen; i++) {
                            if (json.commandArray[i].length === 4) {
                                objGraphic.quadraticCurveTo(json.commandArray[i][0], json.commandArray[i][1], json.commandArray[i][2], json.commandArray[i][3]);
                            } else {
                                objGraphic.lineTo(json.commandArray[i][0], json.commandArray[i][1]);
                            }
                        }
                    }
                    break;
                default:
            }
            objGraphic.endFill();
            if (json.visible === false) {
                objGraphic.visible = false;
            }
            // To handle scale property from json when the object created
            if (json.scale) {
                objGraphic.scale.set(json.scale, json.scale);
            }
            // Set pivot of the shape if mentioned in json when object created.
            (json.regX || json.regY) && (objGraphic.pivot.set(json.regX || 0, json.regY || 0));

            (json.priorityID) && (objGraphic.input.priorityID = json.priorityID);
            objGraphic.name = json.id;
            this.shapes[json.id] = objGraphic;
            this.allComponents[json.id] = objGraphic;
            if (json.parent) {
                this.containers[json.parent].addChild(objGraphic);
            } else {
                this.addChild(objGraphic);
            }
            return objGraphic;
        }

    }
}