///<reference path="../../Interfaces.ts" />
namespace ingenuity.BehaviorCore.IntroOutro {
    export class Controller extends ingenuity.slot.IntroOutro.Controller {
        protected view: BehaviorCore.IntroOutro.IntroOutroView;
        protected freeGameIntroOutro: ui.Container;
        protected freeGameIntroMssg: ui.Container;
        protected introImg: ui.Bitmap;
        protected outroImg: ui.Bitmap;
        protected outroContinueBtn: ingenuity.ui.ButtonBase;
        protected introContinueBtn: ingenuity.ui.ButtonBase;
        protected OutroWinAmount: ui.MeterBitmap;

        constructor(view: BehaviorCore.IntroOutro.IntroOutroView) {
            super(view);
            this.initializeElements();
        }

        protected initializeElements(): void {
            this.freeGameIntroOutro = this.view.getContainerByID("IntroOutroContainer");
            this.freeGameIntroMssg = this.view.getContainerByID("FreeGameIntroMssgContainer");
            this.introImg = this.view.getImageById("FGIntroImage");
            this.outroImg = this.view.getImageById("FGOutroImage");
            this.OutroWinAmount = this.view.getMeterById("OutroWinAmount") as ui.MeterBitmap;
            this.outroContinueBtn = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.OUTRO_CONTINUE_BTN) as ingenuity.ui.ButtonBase;
            this.introContinueBtn = this.view.getButtonById(BehaviorCore.slotConstants.SlotConstants.INTRO_CONTINUE_BTN) as ingenuity.ui.ButtonBase;
        }

        protected subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.SHOW_OUTRO_WIN_AMOUNT, this.showOutroWinAmount, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.INTRO_CONTINUE_PRESS, this.onIntroContinuePressUp, this);
        }

        protected unSubscribeEvents(): void {
            super.unSubscribeEvents();
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.SHOW_OUTRO_WIN_AMOUNT, this.showOutroWinAmount, this);
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.INTRO_CONTINUE_PRESS, this.onIntroContinuePressUp, this);
        }

        protected onOutroContinuePressUp(): void {
            this.outroContinueBtn.disableAndTint();
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_FREE_SPIN_VIEW);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_FREEGAME_VIEW);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SUBSCRIBE_BASEGAME_REELPANEL_EVENTS);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_BASEGAME_VIEW);
            ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.OUTRO_HIDE);
        }

        protected onIntroContinuePressUp(): void {
            configData.freeGameOnContinuePress = true;
            this.freeGameIntroMssg && (this.freeGameIntroMssg.visible = false);
            this.introContinueBtn && (this.introContinueBtn.visible = false);
            this.introImg && (this.introImg.visible = false);
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.HIDE_BASEGAME_VIEW);
            ingenuity.currentGame.state.start(core.constructors.bsBehavior.SlotConstants.FREE_GAME, false, false, ingenuity.currentGame);

        }

        protected onIntroShow(): void {
            configData.freeGameOnContinuePress = true;
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.HIDE_POST_LOADER);
            super.onIntroShow();
            this.freeGameIntroOutro && (this.freeGameIntroOutro.visible = true);
            this.freeGameIntroMssg && (this.freeGameIntroMssg.visible = true);
            this.introContinueBtn && (this.introContinueBtn.visible = true);
            this.introImg && (this.introImg.visible = true);
            dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.CHANGE_BACKGROUND, BehaviorCore.slotConstants.SlotConstants.SELECTION_SCREEN_BG_SHOW);

        }

        protected onOutroShow(): void {
            super.onOutroShow();
            this.freeGameIntroOutro && (this.freeGameIntroOutro.visible = true);
            this.freeGameIntroMssg && (this.freeGameIntroMssg.visible = true);
            this.outroImg && (this.outroImg.visible = true);
        }

        /** to show fg outro win amount in basegame */
        protected showOutroWinAmount(evt: IEvent): void {
            this.OutroWinAmount && (this.OutroWinAmount.visible = true);
            this.OutroWinAmount.setCurrencyFormattedValue(String(evt.data));
            this.OutroWinAmount.scale.set(0.6);
        }

        /**overrided to bind continue button binding for more than once */
        protected bindHandlers(): void {
            this.IntroContinueBtn && this.IntroContinueBtn.on(ingenuity.ui.ButtonBase.UP, this.onIntroContinuePressUp, this);
            this.OutroContinueBtn && this.OutroContinueBtn.on(ingenuity.ui.ButtonBase.UP, this.onOutroContinuePressUp, this);
        }
    }
}
