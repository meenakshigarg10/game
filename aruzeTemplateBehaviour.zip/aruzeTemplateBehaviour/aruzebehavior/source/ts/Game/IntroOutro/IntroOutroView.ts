/**
 * IntroOutro View
 */
namespace ingenuity.BehaviorCore.IntroOutro {
    export class IntroOutroView extends BehaviorCore.BaseView {

        protected resize(evt?: IEvent): void {
            super.resize(evt);
            this.pivot.set(configData.width / 2, configData.height / 2);
            this.x = innerWidth / 2;
            this.y = innerHeight / 2;
            if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.PORTRAIT) {
                this.pivot.set(ingenuity.configData.width * slotConstants.SlotConstants.HALF_CONVERTER, ingenuity.configData.height * slotConstants.SlotConstants.HALF_CONVERTER);
                this.scale.set(deviceEnv.getScale() + deviceEnv.getScale() * core.constructors.bsBehavior.SlotConstants.FIFTEEN_PERCENT);
                this.x = (innerWidth * slotConstants.SlotConstants.HALF_CONVERTER);
                this.y = (innerHeight * core.constructors.bsBehavior.SlotConstants.FIVE_PERCENT) + BehaviorCore.slotConstants.SlotConstants.ADD_IN_Y;
                this.pivot.y = 0;
            } else {
                this.pivot.set(ingenuity.configData.width * slotConstants.SlotConstants.HALF_CONVERTER, ingenuity.configData.height * slotConstants.SlotConstants.HALF_CONVERTER);
                this.x = innerWidth * slotConstants.SlotConstants.HALF_CONVERTER;
                this.y = innerHeight * slotConstants.SlotConstants.HALF_CONVERTER;
                this.scale.set(evt.data.scale);
                if (deviceEnv.isDesktop) {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_DESKTOP;
                } else {
                    this.y = (innerHeight * BehaviorCore.slotConstants.SlotConstants.HALF_CONVERTER) + BehaviorCore.slotConstants.SlotConstants.VIEW_SLIDE_MOBILE;
                }
            }
        }
    }
}
