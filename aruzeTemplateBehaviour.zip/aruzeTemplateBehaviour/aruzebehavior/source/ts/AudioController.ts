namespace ingenuity.BehaviorCore {
    export class AudioController extends base.AudioController {
        public playSound(soundId: string, vol?: number, loop?: boolean, key?: string): void {
            vol = vol || 1;
            this.play(soundId, vol, loop, key);
        }
    }
}
