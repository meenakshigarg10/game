namespace ingenuity.BehaviorCore {
    export class BsDeviceDetector extends ingenuity.deviceEnvironment.DeviceDetector {
        /**
         * Returns the scale for the device
         */
        public getScale(): number {
            if (!this.gameHeight || !this.gameWidth) {
                return 1;
            }
            this.availHeight = Number(window.innerHeight);
            this.availWidth = Number(window.innerWidth);
            if (deviceEnv.isDesktop) {
                this.scale = Math.min(((this.availHeight ) / this.gameHeight), (this.availWidth / this.gameWidth));
            } else if (deviceEnv.getOrientation() === deviceEnvironment.constants.ORIENTATION.LANDSCAPE) {
                this.scale = Math.min(((this.availHeight - (ingenuity.BehaviorCore.slotConstants.SlotConstants.WrapperTopBarHeightMobileLandscape)) / this.gameHeight), (this.availWidth / this.gameWidth));
            } else {
                this.scale = Math.min(((this.availHeight) / this.gameHeight), (this.availWidth / this.gameWidth));
            }
            return this.scale;
        }
    }
}
