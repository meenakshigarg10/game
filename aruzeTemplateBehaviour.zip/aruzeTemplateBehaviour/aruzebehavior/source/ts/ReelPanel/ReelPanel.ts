/* tslint:disable */
namespace ingenuity.BehaviorCore.reelPanel {

    export class ReelPanel extends ingenuity.slot.reelPanel.ReelPanel {
        protected landingSoundList: IObject[][] = [];

        constructor(game: bridge.Game, model: any) {
            super(game, model);
            this.subscribeEvents();
        }

        /**to bind and unbind game specific events */
        protected subscribeEvents(): void {
            this.unsubscribeEvents();
            if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.freeGameState) {
                dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.CHECK_FOR_LANDING_SOUNDS_ON_REELS_FG, this.onCheckingLandingSoundsOnReels, this);
            } else {
                dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.CHECK_FOR_LANDING_SOUNDS_ON_REELS, this.onCheckingLandingSoundsOnReels, this);
            }
        }

        protected unsubscribeEvents(): void {
            if (currentGame.state.getCurrentState().key === BehaviorCore.slotConstants.SlotConstants.freeGameState) {
                dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.CHECK_FOR_LANDING_SOUNDS_ON_REELS_FG, this.onCheckingLandingSoundsOnReels, this);
            } else {
                dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.CHECK_FOR_LANDING_SOUNDS_ON_REELS, this.onCheckingLandingSoundsOnReels, this);
            }
        }

        public showStaticGrid(grid: any): void {
            let reelGrid: number[][];
            const reelLen: number = this.reels.length;
            if (!Array.isArray(grid)) {
                reelGrid = grid.data;
            } else {
                reelGrid = grid;
            }
            for (let i: number = 0; i < reelLen; i++) {
                if (reelGrid[i].length > 0) {
                    this.symAnimReels[i].removeChildren();
                    (this.symAnimOverlayContainers.length) && this.symAnimOverlayContainers[i].removeChildren();
                    this.reels[i].init(reelGrid[i]);
                }
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BIG_SYMBOL, i);
            }
        }

        /**
         * overrided so that during turbo enabled when Anticipation plays, it run for same time as in normal spin. Didnot get disappear suddenly.
         */

        protected stopReel(id: number, allReelSpining: boolean): void {
            if (!allReelSpining) {
                return;
            }

            if (this.reels[id].getIsSpining() && !this.paused) {
                let reelId: number = id;
                if (configData.stopReelViaPos) {
                    this.reels[reelId].setStops(this.model.reelStops[reelId]);
                } else {
                    this.reels[reelId].setStops(this.model.reelGrid[reelId]);
                }
                reelId++;
                if (reelId < this.reels.length) {
                    let delay: number = Array.isArray(this.model.stopDelay) ? this.model.stopDelay[reelId] : this.model.stopDelay;

                    if (this.model.anticipationSpin[reelId]) {

                        delay = this.model.getAnticipationDelay(reelId);

                        utils.delayedCall(slot.slotConstants.SlotConstants.AnticipationDelayTimer + reelId, this.model.getAnticipationRunAfterDelay(reelId), this.setAnticipation.bind(this, reelId));
                    }
                    if (this.model.reelsJson[reelId].noDelay) {
                        this.stopReel.bind(this, reelId, this.isSpining);
                    } else if (ingenuity.configData.stopNowWithDelay && this.stopNow) {
                        if (this.model.anticipationSpin[reelId]) {
                            utils.delayedCall(slot.slotConstants.SlotConstants.StopReelId + reelId, delay, this.stopReel.bind(this, reelId, this.isSpining));
                        } else {
                            utils.delayedCall(slot.slotConstants.SlotConstants.StopReelId + reelId, configData.stopNowWithDelay, this.stopReel.bind(this, reelId, this.isSpining));
                        }
                    } else {
                        utils.delayedCall(slot.slotConstants.SlotConstants.StopReelId + reelId, delay, this.stopReel.bind(this, reelId, this.isSpining));
                    }
                }
            } else {
                if (ingenuity.configData.stopNowWithDelay && this.stopNow) {
                    utils.delayedCall(slot.slotConstants.SlotConstants.StopReelId + id, configData.stopNowWithDelay / 2, this.stopReel.bind(this, id, this.isSpining));
                } else {
                    const delay: number = Array.isArray(this.model.stopDelay) ? this.model.stopDelay[id] : this.model.stopDelay;
                    utils.delayedCall(slot.slotConstants.SlotConstants.StopReelId + id, delay / 4, this.stopReel.bind(this, id, this.isSpining));
                }
            }
        }

        /**to pass on the landing symbols data*/
        protected onCheckingLandingSoundsOnReels(): void {
            let landingConfig: IObject[] = this.getModel().json.landingSounds;
            this.landingSoundList = [];
            parserModel.setLandingSoundOnReel([]);
            for (let i: number = 0; i < landingConfig.length; i++) {
                let j: IObject = landingConfig[i];
                this.checkForLandingSounds(j, landingConfig.length);
            }
        }

        /**to check if to play landing sounds of which symbols */
        protected checkForLandingSounds(landingSymbolObj: IObject, configLength: number): void {
            let symbolCount: number = 0;
            let landingSounds: IObject[] = [];
            let symbolFound: boolean = false;
            let landingSymbollId: number = 0;

            /* use of reelstopid in for loop for iterating and wildReelFeature variable is totally game specific
             *remove these variables from json and from code for new game and use simple for loop for iterating
             */
            let reelStopId: number[] = utils.clone(BehaviorCore.slotConstants.SlotConstants.REELS_STOPPING_IDS);
            if (landingSymbolObj.wildReelFeature) {
                const index: number = parserModel.getWildReelIndex() - 1;
                const deleted: number[] = reelStopId.splice(index, 1);
                reelStopId.unshift(deleted[0]);
            }
            for (let f: number = 0, i: number = reelStopId[f]; f < reelStopId.length; f++, i = reelStopId[f]) {
                for (let j: number = 0; j < this.model.reelGrid[i].length; j++) {
                    if (Array.isArray(landingSymbolObj.symbolId)) {
                        if (landingSymbolObj.symbolId.indexOf(this.model.reelGrid[i][j]) !== -1) {
                            landingSymbollId = this.model.reelGrid[i][j];
                            symbolFound = true;
                            break;
                        }
                    } else {
                        if (this.model.reelGrid[i][j] === landingSymbolObj.symbolId) {
                            landingSymbollId = landingSymbolObj.symbolId;
                            symbolFound = true;
                            break;
                        }
                    }
                }
                if (symbolFound) {
                    symbolCount++;
                }

                if (symbolFound) {
                    for (let k: number = 0; k < landingSymbolObj.obj.length; k++) {
                        let symbolCountTypes: number | number[] = landingSymbolObj.obj[k].symbolCount;
                        if (Array.isArray(symbolCountTypes)) {
                            if (symbolCountTypes.indexOf(symbolCount) !== -1) {
                                if (landingSymbolObj.obj[k].triggerCount) {
                                    if (this.checkLandingSoundsTriggr(landingSymbolObj.obj[k], symbolCount, i)) {
                                        const landingObj: IObject = { landingSymbollId, symbolCount, i };
                                        landingSounds[i] = landingObj;
                                    }
                                } else {
                                    if (this.checkLandingSounds(landingSymbolObj.obj[k], i)) {
                                        const landingObj: IObject = { landingSymbollId, symbolCount, i };
                                        landingSounds[i] = landingObj;
                                    }
                                }
                                break;
                            }
                        } else {
                            if (symbolCountTypes === symbolCount) {
                                if (landingSymbolObj.obj[k].triggerCount) {
                                    if (this.checkLandingSoundsTriggr(landingSymbolObj.obj[k], symbolCount, i)) {
                                        const landingObj: IObject = { landingSymbollId, symbolCount, i };
                                        landingSounds[i] = landingObj;
                                    }
                                } else {
                                    if (this.checkLandingSounds(landingSymbolObj.obj[k], i)) {
                                        const landingObj: IObject = { landingSymbollId, symbolCount, i };
                                        landingSounds[i] = landingObj;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    symbolFound = false;
                }
            }
            this.landingSoundList.push(landingSounds);
            if (this.landingSoundList.length === configLength) {
                parserModel.setLandingSoundOnReel(this.landingSoundList);
            }
        }

        /**to check if landing symbol has any trggering condition */
        protected checkLandingSoundsTriggr(symbolObj: any, symbolCount: number, reelId: number): boolean {
            if ((symbolCount === symbolObj.triggerCount - 1) && reelId <= this.getModel().numReels - 1) {
                return (symbolObj.TriggrReels[reelId] === 1);
            }
        }

        /**to check if landing sound is allowed on a reel */
        protected checkLandingSounds(symbolObj: any, reelId: number): boolean {
            return (symbolObj.allowedReels[reelId] === 1);
        }
    }
}
