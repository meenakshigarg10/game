///<reference path="../Interfaces.ts" />
namespace ingenuity.BehaviorCore.reelPanel {
    export class WinPresentationPanel extends slot.reelPanel.WinPresentationPanel {
        // variable is used to stop symbol sound, once a round of toggle finishes
        public oneToggleCompletes: boolean = false;
        constructor(game: any, reelPanel: slot.reelPanel.ReelPanel) {
            super(game, reelPanel);
            this.WIN_SCATTER_ANIM_TIMEOUT = 3500;
            const reelCount: number = this.reelPanel.getReels().length;
            for (let a: number = 0; a < reelCount; a++) {
                dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.UPDATE_BIG_SYMBOL, a);
            }
        }

        public subscribeEvents(): void {
            super.subscribeEvents();
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.PLAY_ALL_SYMBOL_ANIM, this.animateAllWinLineSymbol, this);
            dispatcher.on(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.STOP_ALL_SYMBOL_ANIM, this.stopAllWinLineSymbol, this);
            dispatcher.on(BehaviorCore.slotConstants.SlotEventConstants.VISIBILITY_WIN_PRESENTATION_PANNEL, this.visibilityhandler, this);
        }

        public unsubscribeEvents(): void {
            super.unsubscribeEvents();
            dispatcher.off(BehaviorCore.slotConstants.SlotEventConstants.VISIBILITY_WIN_PRESENTATION_PANNEL, this.visibilityhandler, this);
            dispatcher.off(ingenuity.BehaviorCore.slotConstants.SlotEventConstants.PLAY_ALL_SYMBOL_ANIM, this.animateAllWinLineSymbol, this);
        }

        protected visibilityhandler(evt: IEvent): void {
            if (evt.data === true) {
                this.visible = true;
            } else {
                this.visible = false;
            }
        }

        protected showWinLine(winLineData: any, currentWinLine: any): void {
            if (winLineData && winLineData[currentWinLine]) {
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_WAY_WIN_AMT, winLineData[currentWinLine]);
                dispatcher.fireEvent(core.constructors.bsBehavior.SlotEventConstants.SHOW_WAY_WIN_AMT_FG, winLineData[currentWinLine]);
            }
            ingenuity.utils.killDelayedCall(slot.slotConstants.SlotConstants.TimerAnimateNextWinLine);
            super.showWinLine(winLineData, currentWinLine);
        }

        protected animateNextWinLine(): void {
            if (this.model.currentWinAnimIndex >= this.model.winLineDataLength) {
                this.model.resetCurrentWinAnimIndex();
            }
            if (this.model.winLineData.length < 1) {
                return;
            }
            if (this.reelPanel.getPause()) {
                utils.delayedCall(slotConstants.SlotConstants.TimerAnimateNextWinLine, this.WIN_LINE_ANIM_TIMEOUT, this.animateNextWinLine, (this));
                return;
            }
            if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_LINE_ANIMATION_ENDED, this.model.winLineData[this.model.currentWinAnimIndex].id);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.LINE_ANIMATION_ENDED, this.model.winLineData[this.model.currentWinAnimIndex].id);
            }
            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.WIN_ON_REELS, this.model.winLineData[this.model.currentWinAnimIndex]);
            console.info("%c Line win toggle for %d line", "background:AntiqueWhite; color:Aqua", this.model.winLineData[this.model.currentWinAnimIndex].id);
            if (!ingenuity.configData.playAllSymbolAnim) {
                this.reelPanel.showAllSymbols();
            }

            if (this.model.nextWinAnimIndex < this.model.winLineDataLength) {
                this.model.playLineWinAnim = true;
                const winLineData = this.model.winLineData[this.model.currentWinAnimIndex];
                if (this.animateSymbol || configData.payingScatterLineIds.indexOf(winLineData.id) > -1) {
                    if (!ingenuity.configData.playAllSymbolAnim) {
                        this.animateWinLineSymbol(this.model.winLineData[this.model.currentWinAnimIndex]);
                    }
                }
                this.showWinLine(this.model.winLineData, this.model.currentWinAnimIndex);
            } else {
                this.stopAllWinAnimations();
                this.oneToggleCompletes = true;
                if (parserModel.getHasScatterWins() || (parserModel.getTriggerScatterWinData().length > 0)) {
                    this.winCycleCompleted();
                    /**done since during History WIN_CYCLE_COMPLETED event get Unsubscribed.*/
                    if (parserModel.getGameMode() === BehaviorCore.slotConstants.SlotConstants.HISTORY_MODE) {
                        if (!dispatcher.hasEvent(slot.slotConstants.SlotEventConstants.WIN_CYCLE_COMPLETED)) {
                            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                        }
                    }
                } else if (this.toggleingContinue) {
                    this.model.resetCurrentWinAnimIndex();
                    const winLineData = this.model.winLineData[this.model.currentWinAnimIndex];
                    if (this.animateSymbol || configData.payingScatterLineIds.indexOf(winLineData.id) > -1) {
                        this.model.playLineWinAnim = true;
                        if (!ingenuity.configData.playAllSymbolAnim) {
                            this.animateWinLineSymbol(this.model.winLineData[this.model.currentWinAnimIndex]);
                        }
                    }
                    this.showWinLine(this.model.winLineData, this.model.currentWinAnimIndex);
                } else {
                    this.winCycleCompleted();
                }
            }
        }

        protected playSymbolTriggerAnimationByID(symbolID: number, reel: number, row: number, opts?: any) {
            const symbol: slot.symbol.SymbolBase = this.reelPanel.getSymbolByPos(reel, row);
            const staticSym: slot.symbol.StaticSymbol | slot.symbol.AnimationSymbol = symbol.getStatic();
            const animSym: any = this.reelPanel.getSymbolByPos(reel, row).getAnimation();

            if (animSym instanceof slot.symbol.LayeredAnimationSymbol) {
                opts = opts ? opts : [
                    "triggering",
                    (symbol.json.animSym as slot.symbol.IAnimationSymbolData).posterFrame,
                    () => {
                        staticSym.visible = true;
                        if (animSym.parent && (staticSym instanceof slot.symbol.StaticSymbol)) {
                            animSym.parent.addChild(staticSym);
                            animSym.parent.removeChild(animSym);
                        }
                    },
                    this
                ];
            }
            const icon: slot.symbol.SymbolBase = this.reelPanel.getReels()[reel].playTriggerAnimByID(symbolID, row, null, opts);
            if (icon.symType.indexOf("animateBehind") < 0) {
                const anim: any = icon.getAnimation();
                return this.reelPanel.getAnimReels()[reel].addChild(anim);
            }
            return icon;
        }

        /**
         * Overrided to keep playing scatter animation while transitioning from base game to free game
         */
        protected playScatterWinAnimations(evt: any) {
            const scatterWinData: IWinLineObject = evt.data;
            let i: number;
            let j: number;
            let symbolID: number;
            if (!parserModel.getRetriggerFreeSpins()) {
                !currentGame.state.getCurrentState().model.getIsAutoPlayLeft() && dispatcher.fireEvent(BehaviorCore.slotConstants.SlotEventConstants.SHOW_SCATTER_WIN_MSSG, baseGameModel.getTriggerScatterWinData());
            }
            if (configData.animationStopInScatterwin) {
                this.stopAllWinAnimations();
            }
            if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SCATTER_ANIMATION_STARTED, scatterWinData);
            } else {
                dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SCATTER_ANIMATION_STARTED, scatterWinData);
            }
            for (i = 0; i < scatterWinData.length; i++) {
                for (j = 0; j < scatterWinData[i].positions.length; j++) {
                    symbolID = this.model.getReelGridElement(scatterWinData[i].positions[j][0], scatterWinData[i].positions[j][1]);
                    this.playSymbolTriggerAnimationByID(symbolID, scatterWinData[i].positions[j][0], scatterWinData[i].positions[j][1]);
                }
            }

            utils.delayedCall(slotConstants.SlotConstants.TimerScatterAnimationEnded, ingenuity.BehaviorCore.slotConstants.SlotConstants.TIME_SCATTER_ANIMATION_END, function () {
                if (currentGame.state.getCurrentState().key === slotConstants.SlotConstants.freeGameState) {
                    dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.FG_SCATTER_ANIMATION_ENDED, scatterWinData);
                } else {
                    /**
                     * delay used if there is a scatter win without line win, for tickup to complete
                     */
                    if (!parserModel.getHasLineWins()) {
                        utils.delayedCall("TickUpComplete", 1500, () => {
                            utils.killDelayedCall("TickUpComplete");
                            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SCATTER_ANIMATION_ENDED, scatterWinData);
                        }, this);
                    } else {
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.SCATTER_ANIMATION_ENDED, scatterWinData);
                    }
                }
                this.reelPanel.showAllSymbols();
                this.clearSymReels();
            }, (this));
        }

        /**
         * overrided to stop symbol sound , once a cycle of first toggle finishes
         * and reset it for a new spin
         * @param evt
         */
        public startWinLineAnimation(evt: any): void {
            this.oneToggleCompletes = false;
            // super.startWinLineAnimation(evt);
            this.model.winLineData = evt.data;
            this.playLineWinAnimations(this.BLINK_ANIM_CYCLES);

        }

        protected playLineWinAnimations(numCycles: number): void {
            this.numCycleCount = numCycles;
            this.model.currentWinAnimIndex = 0;
            this.model.winAnimCycleCount = 0;
            this.model.playLineWinAnim = true;
            console.info("%c Line win animations ", "background:AntiqueWhite; color:Aqua");

            this.showWinLine(this.model.winLineData, this.model.currentWinAnimIndex);
            const winLineData = this.model.winLineData[this.model.currentWinAnimIndex];
            if (!ingenuity.configData.playAllSymbolAnim) {
                if (this.animateSymbol || configData.payingScatterLineIds.indexOf(winLineData.id) > -1) {
                    this.animateWinLineSymbol(winLineData);
                } else {
                    if (this.reelPanel.getModel().animOverlaySymOnToggle) {
                        dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_ANIM_LAYER);
                        for (let i of this.model.winLineData[this.model.currentWinAnimIndex].positions) {
                            dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ADD_SYMBOL_TO_ANIM_OVERLAY_LAYER, [i[0], i[1]]);
                        }
                    }
                }
            }
        }

        protected animateAllWinLineSymbol(): void {
            this.model.playLineWinAnim = true;
            const winLineData: number[][] = ingenuity.utils.clone(parserModel.getLinesWinAllUniquePositions());
            if (winLineData.length < 1) {
                return;
            }
            winLineData.sort(this.sortFirstColumn);
            winLineData.sort(this.sortSecondColumn);

            for (const element of winLineData) {
                this.animateLineSymbol(element);
            }
        }

        protected stopAllWinLineSymbol(): void {
            this.reelPanel.showAllSymbols();
        }

        protected sortFirstColumn(a: number[], b: number[]): number {
            if (a[0] === b[0]) {
                return 0;
            } else {
                return (a[0] < b[0]) ? -1 : 1;
            }
        }

        protected sortSecondColumn(a: number[], b: number[]): number {
            if (a[1] === b[1]) {
                return 0;
            } else {
                return (a[1] < b[1]) ? -1 : 1;
            }
        }

        protected stopAllWinAnimations(): void {
            utils.killDelayedCall(slot.slotConstants.SlotConstants.TimerAnimateNextWinLine);
            utils.killDelayedCall(slot.slotConstants.SlotConstants.TimerAllAnimateWin);
            this.model.playLineWinAnim = false;
        }

        protected animateLineSymbol(winLineData: number[]): void {
            if (!this.isStopSymAnim) {
                if (this.reelPanel.getModel().animOverlaySymOnToggle) {
                    ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.CLEAR_ANIM_LAYER);
                }
                this.playSymbolAnimation(winLineData[0], winLineData[1]);
                if (this.reelPanel.getModel().animOverlaySymOnToggle) {
                    ingenuity.dispatcher.fireEvent(slot.slotConstants.SlotEventConstants.ADD_SYMBOL_TO_ANIM_OVERLAY_LAYER, [winLineData[0], winLineData[1]]);
                }
            }
        }
    }
}
