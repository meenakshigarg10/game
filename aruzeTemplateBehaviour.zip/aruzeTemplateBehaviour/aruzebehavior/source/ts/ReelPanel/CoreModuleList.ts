///<reference path="Paylines.ts"/>
///<reference path="WinPresentationPanel.ts"/>
///<reference path="symbol/StaticSymbol.ts"/>
///<reference path="symbol/LayeredAnimationSymbol.ts"/>

namespace ingenuity.core.constructors {
     reelPanel.WinReelPanel = BehaviorCore.reelPanel.WinPresentationPanel;
     reelPanel.PaylineView = BehaviorCore.reelPanel.Paylines;
     reelPanel.StaticSymbol = BehaviorCore.symbol.StaticSymbol;
     reelPanel.LayeredAnimationSymbol = BehaviorCore.symbol.LayeredAnimationSymbol;
}
