///<reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.symbol {
    export class LayeredAnimationSymbol extends slot.symbol.LayeredAnimationSymbol {
    }
}
