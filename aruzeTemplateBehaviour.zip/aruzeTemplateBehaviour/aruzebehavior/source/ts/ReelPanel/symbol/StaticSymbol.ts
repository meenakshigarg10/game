///<reference path="../../Interfaces.ts" />

namespace ingenuity.BehaviorCore.symbol {
    export class StaticSymbol extends slot.symbol.StaticSymbol {
        constructor(id: number, json: slot.symbol.IStaticSymbolData, name: string, zIndex: number) {
            super(id, json, name, zIndex);
            this.animDefaults = {
                wait: 500,
                time: 500,
                override: true,
                callback: Function,
                scale: 0.7,
                loop: 0,
                sym2Flash: 0,
                sym2Wait: 500,
                brightness: 1,
                contrast: 0,
                startDelay: 100
            };
        }

        protected init(json: slot.symbol.IStaticSymbolData, name?: string): void {
            if (json.regX || json.regY) {
                this.pivot.set(json.regX || 0, json.regY || 0);
            }
            super.init(json, name);
        }


        /**
         * overrided to make changes in Flash effect , if animation not loaded.
         * @param animName
         */
        public playAnim  (animName: IObject): void {
            if (this.animating) {
                return;
            }
            ingenuity.currentGame.tweens.removeFrom(this);
            this.animating = true;
            this.json.time && (this.animDefaults.time = this.json.time);
            this.json.wait && (this.animDefaults.wait = this.json.wait);
            this.json.scaleto && (this.animDefaults.scale = this.json.scaleto);
            this.json.loop && (this.animDefaults.loop = this.json.loop);
            this.json.override && (this.animDefaults.override = this.json.override);
            ingenuity.utils.extendObj(this.animDefaults, animName);
            this.fireEvent(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_STARTED, {
                id: this.num,
                symbol: this
            });
            switch (this.animType) {
                case ingenuity.slot.symbol.SymbolConstants.ANIMATION_BLINK:
                    this.animObj = this.game.add.tween(this);
                    this.animObj.onComplete.addOnce(function () {
                        this.animating = false;
                        ingenuity.currentGame.tweens.removeFrom(this);
                        this.animObj = null;
                        this.fireEvent(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_ENDED, {
                            id: this.num,
                            animation: this.animType,
                            symbol: this
                        });
                    }, this, 1);
                    this.animObj.to({ visible: false }, this.animDefaults.time, "Linear", true, this.animDefaults.startDelay, this.animDefaults.loop as any, true);
                    this.animObj.yoyo(true, this.animDefaults.wait);
                    break;
                case ingenuity.slot.symbol.SymbolConstants.ANIMATION_SCALE:
                    this.resetScaleAnim();
                    console.log("%c inside :: playing animation for %s", "background:GoldenRod;color:white", this.toString(), this.anchor.toString(), this.x, this.oldX);
                    this.animObj = this.game.add.tween(this.scale);
                    if (this.json.regX || this.json.regY) {
                        let rx = (this.json.regX / 2) + 0.5;
                        let ry = (this.json.regY / 2) + 0.5;
                        this.anchor.set(rx, ry);
                    } else {
                        this.anchor.set(0.5);
                    }
                    this.x += ((this.json.width) ? this.json.width / 2 : this.width / 2);
                    this.y += (this.json.height) ? this.json.height / 2 : this.height / 2;
                    this.animObj.onComplete.addOnce(function () {
                        this.animating = false;
                        this.resetScaleAnim();
                        ingenuity.currentGame.tweens.removeFrom(this);
                        this.tweenObj = null;
                        this.fireEvent(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_ENDED, {
                            id: this.num,
                            animation: this.animType,
                            symbol: this
                        });
                    }, this);
                    this.animObj.to({
                        x: this.animDefaults.scale,
                        y: this.animDefaults.scale
                    }, this.animDefaults.time, "Quart.easeOut", true, this.animDefaults.wait, this.animDefaults.loop as any, true);
                    break;
                case ingenuity.slot.symbol.SymbolConstants.ANIMATION_FLASH:
                    this.animObj = this.game.add.tween(this);
                    this.animObj.onComplete.addOnce(function () {
                        ingenuity.currentGame.tweens.removeFrom(this);
                        this.animObj = null;
                        this.animating = false;
                        this.fireEvent(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_ENDED, {
                            id: this.num,
                            animation: this.animType,
                            symbol: this
                        });
                    }, this, 1);
                    this.animObj.to({ alpha: core.constructors.bsBehavior.SlotConstants.SYMBOL_ALPHA }, this.animDefaults.time, "Quart.easeOut", true, this.animDefaults.wait, this.animDefaults.loop as any, true);
                    this.animObj.yoyo(true, this.animDefaults.wait);
                    break;
                default:
                    this.animating = false;
                    this.fireEvent(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_ENDED, {
                        id: this.num,
                        animation: this.animType,
                        symbol: this
                    });
                    console.info("No animation to play for " + this.toString());
                    break;
            }
        }
    }
}
