///<reference path="../Interfaces.ts" />
namespace ingenuity.BehaviorCore.reelPanel {
    export class Paylines extends slot.reelPanel.Paylines {
        protected lineCount: number = 0;
        constructor(game: IContainer, json: any, model: any) {
            super(game, json, model);
            dispatcher.on(core.constructors.bsBehavior.SlotEventConstants.SUBSCRIBE_PAYLINE_EVENTS, this.subscribeEvents, this);
        }

        protected showAllPaylineWinframes(evt: IEvent): void {
            Paylines.winCycleComplete = 0;
            this.secondToggleStart = false;
            let display: boolean = arguments[2] || true;
            let callback: any;
            let callbackScope = this;
            let delayTimer: number;
            if (typeof evt === "function") {
                callback = evt;
            } else {
                callback = evt.data.callback;
                callbackScope = evt.data.callbackScope;
                delayTimer = evt.data.delayTimer;
                display = evt.data.display;
            }
            ingenuity.utils.killDelayedCall(slot.slotConstants.SlotConstants.SpaghettiDisplayTimer);
            let winLines = this.model.winningLines, winLinesLen = winLines.length;
            let uniquePos = [];
            if (winLines && winLinesLen) {
                for (let i = 0; i < winLinesLen; i++) {
                    let pos = [];
                    if (winLines[i].id < this.startIndex) {
                        continue;
                    }
                    if (display || this.isSpaghetti) {
                        for (let k = 0; k < winLines[i].positions.length; k++) {
                            if (uniquePos.indexOf(winLines[i].positions[k].join("_")) < 0) {
                                pos.push(k);
                                uniquePos.push(winLines[i].positions[k].join("_"));
                            }
                        }
                        this.showSpecificPaylineWinbox(winLines[i].id, pos);
                    }
                }
                this.model.spagettiVisible = true;
                (typeof callback === "function") && (ingenuity.utils.delayedCall(slot.slotConstants.SlotConstants.SpaghettiDisplayTimer, delayTimer, callback, callbackScope));

                this.lineCount = 0;
            } else {
                if (ingenuity.currentGame.state.getCurrentState().key === ingenuity.slot.slotConstants.SlotConstants.freeGameState) {
                    dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.FG_SHOW_NEXT_WIN_PRESENTATION);
                } else {
                    ingenuity.dispatcher.fireEvent(ingenuity.slot.slotConstants.SlotEventConstants.SHOW_NEXT_WIN_PRESENTATION);
                }
            }
        }

        protected createWinBox(): void {
            let i: number, j: number, k: number, json: IContainer = this.json;
            if (configData.drawWinFrames) { // check for config entry for drawing win frames if images are not present
                this.drawWinBoxes(); // function to draw win boxes
                return;
            }
            if (configData.winboxAnimate && json.winBoxData.animatedWinBoxData) { // check for config entry for animatedwinbox
                this.createAnimatedWinBox(); // function to create animated win boxes
                return;
            }
            if (Array.isArray(json.winBoxData)) {
                for (const winBoxData of json.winBoxData) {
                    let pickFrameCount: number = 0;
                    for (i = winBoxData.startLineId; i < winBoxData.endLineId; i++) {
                        const winBoxContainer = new ui.Container(winBoxData, this.game);
                        for (j = 0; j < this.numCol; j++) {
                            const numFrames = (ingenuity.configData.waysGame) ? this.numRows : 1;
                            for (k = 0; k < numFrames; k++) {
                                const box = new ui.Sprite(0, 0, winBoxData.image || winBoxData.images, winBoxData.frames[pickFrameCount++]);
                                box.texture.baseTexture.resolution = deviceEnv.update().scaleVariant;
                                box.name = slotConstants.SlotConstants.WinBoxPrefix + i + "_" + j;
                                box.x = winBoxData.x + (((winBoxData.w + (winBoxData.offsetX || 0) + (winBoxData.spacing || 0)) * j));
                                box.y = winBoxData.y + (json.linesValues[i][j] * (winBoxData.h + (winBoxData.offsetY || 0)));
                                if (winBoxData.scale) {
                                    box.scale.set(winBoxData.scale);
                                }
                                if (winBoxData.regX && winBoxData.regY) {
                                    box.pivot.set(winBoxData.regX, winBoxData.regY);
                                }
                                box.visible = false;
                                winBoxContainer.addChild(box);
                            }
                        }
                        winBoxContainer.name = slotConstants.SlotConstants.WinBoxContainerPrefix + i;
                        this.winboxes[i] = winBoxContainer;
                        this.winboxContainer.addChild(winBoxContainer);
                    }
                }
            } else {
                const numLines: number = (ingenuity.configData.waysGame) ? 1 : json.maxPaylines;
                for (i = 0; i < numLines; i++) {
                    const winBoxContainer = new ui.Container(json.winBoxData, this.game);
                    for (j = 0; j < this.numCol; j++) {
                        const numFrames = (ingenuity.configData.waysGame) ? this.numRows : 1;
                        for (k = 0; k < numFrames; k++) {
                            const box = new ui.Sprite(0, 0, json.winBoxData.image || json.winBoxData.images[i], json.winBoxData.frames && json.winBoxData.frames[0]);
                            box.texture.baseTexture.resolution = deviceEnv.update().scaleVariant;
                            box.name = slotConstants.SlotConstants.WinBoxPrefix + i + "_" + j;
                            // box.x = json.winBoxData.x + ((json.winBoxData.w + (json.winBoxData.offsetX || 0)) * j);
                            box.x = json.winBoxData.x + (((json.winBoxData.w + (json.winBoxData.offsetX || 0) + (json.winBoxData.spacing || 0)) * j));
                            box.y = json.winBoxData.y + (json.linesValues[i][j] * (json.winBoxData.h + (json.winBoxData.offsetY || 0)));
                            if (json.winBoxData.scale) {
                                box.scale.set(json.winBoxData.scale);
                            }
                            if (json.winBoxData.regX && json.winBoxData.regY) {
                                box.pivot.set(json.winBoxData.regX, json.winBoxData.regY);
                            }
                            box.visible = false;
                            winBoxContainer.addChild(box);
                        }
                        winBoxContainer.name = slotConstants.SlotConstants.WinBoxContainerPrefix + i;
                        this.winboxes[i] = winBoxContainer;
                        this.winboxContainer.addChild(winBoxContainer);
                    }
                }
                if (json.winBoxData.showScatterWinFrame && configData.waysGame !== true) {
                    configData.showScatterWinFrame = json.winBoxData.showScatterWinFrame;
                    configData.scatterLineIds = json.winBoxData.scatterLineIds;
                    for (i = 0; i < json.winBoxData.scatterCount; i++) {
                        const winBoxContainer = new ui.Container(json.winBoxData, this.game);
                        for (j = 0; j < this.numCol; j++) {
                            const box = new ui.Sprite(0, 0, json.winBoxData.images, json.winBoxData.scatterFrames && json.winBoxData.scatterFrames[0]);
                            box.texture.baseTexture.resolution = deviceEnv.update().scaleVariant;
                            box.name = slotConstants.SlotConstants.WinBoxScatterPrefix + i + "_" + j;
                            box.x = json.winBoxData.x + (((json.winBoxData.w + (json.winBoxData.offsetX || 0)) * j));
                            // box.x = json.winBoxData.x + ((json.winBoxData.w + (json.winBoxData.offsetX || 0)) * j);
                            box.y = json.winBoxData.y + (json.winBoxData.offsetY || 0);
                            if (json.winBoxData.scale) {
                                box.scale.set(json.winBoxData.scale);
                            }
                            if (json.winBoxData.regX && json.winBoxData.regY) {
                                box.pivot.set(json.winBoxData.regX, json.winBoxData.regY);
                            }
                            box.visible = false;
                            winBoxContainer.addChild(box);
                        }
                        winBoxContainer.name = slotConstants.SlotConstants.WinBoxScatterContainerPrefix + i;
                        this.winboxes.push(winBoxContainer);
                        this.winboxContainer.addChild(winBoxContainer);
                    }
                }
            }
        }

        protected showPaylineWinbox(id: number, numSymWin: number | number[][]): void {
            let winBox: ui.Container = this.getWinbox(id - this.startIndex), i: number, len: number;
            const boxCutMaskFillColor: number = 0xFFFFFF;
            if (Array.isArray(numSymWin)) {
                // TODO: handle later
                for (i = 0, len = numSymWin.length; i < len; i++) {
                    const winBoxSprite: ui.Sprite | IGraphics = winBox.getChildAt(numSymWin[i][0]) as ui.Sprite;
                    winBoxSprite.alpha = 1;
                    winBoxSprite.visible = true;
                    if (!(configData.winboxAnimate && Paylines.winCycleComplete === 0)) {
                        (winBoxSprite as ui.Sprite).frameName = "animStop";
                    }
                }
            } else {
                let json: IObject = this.json, lineColor: string;
                lineColor = (json.drawLineData.color.length === 1) ? json.drawLineData.color[0] : json.drawLineData.color[i];
                if (lineColor.charAt(0) === "#") {
                    lineColor = "0x" + lineColor.slice(1);
                }
                this.boxCut.clear();
                this.boxCut.visible = true;
                this.boxCut.lineStyle(0, boxCutMaskFillColor, 1, bridge.Maths.HALF);
                this.boxCut.beginFill(boxCutMaskFillColor);
                if (currentGame.renderType === bridge.RENDERER_TYPE.CANVAS) {
                    // holes don't work in CANVAS. Hence we need to create different mask.
                    this.createMaskSafeArea();
                    this.boxCut.beginFill(boxCutMaskFillColor);
                } else {
                    // implemented using holes
                    // create a bigger rectangle which should cover all the paylines.
                    const boxCutBigX: number = json.winBoxData.x - configData.paylineMaskOuterRectOffset;
                    const boxCutBigY: number = json.winBoxData.y - configData.paylineMaskOuterRectOffset;
                    const boxCutBigW = json.winBoxData.w * json.numReels + configData.paylineMaskOuterRectOffset * bridge.Maths.TWO;
                    const boxCutBigH = json.winBoxData.h * json.drawLineData.numSymbolsOnReel + configData.paylineMaskOuterRectOffset * bridge.Maths.TWO;

                    this.boxCut.moveTo(boxCutBigX, boxCutBigY);
                    this.boxCut.lineTo(boxCutBigX + boxCutBigW, boxCutBigY);
                    this.boxCut.lineTo(boxCutBigX + boxCutBigW, boxCutBigY + boxCutBigH);
                    this.boxCut.lineTo(boxCutBigX, boxCutBigY + boxCutBigH);
                    this.boxCut.closePath();
                    this.boxCut.lineStyle(0, boxCutMaskFillColor, 1, 0.5);
                }

                for (i = 0; i < this.numCol; i++) {
                    const winBoxSprite: ui.Sprite | bridge.Graphics = winBox.getChildAt(i) as ui.Sprite;
                    winBoxSprite.alpha = 1;
                    if (i < numSymWin) {
                        let winBoxData: IObject;
                        winBoxSprite.visible = true;
                        if (currentGame.renderType === bridge.RENDERER_TYPE.CANVAS) {
                            // create the top mask area.
                            winBoxData = this.json.winBoxData;
                            let xx: number, yy: number, ww: number, hh: number;
                            const bottomY: number = winBoxData.y + this.numRows * (winBoxData.h + (winBoxData.offsetY || 0));
                            xx = winBoxData.x + i * (winBoxData.w + (winBoxData.offsetX || 0) + (winBoxData.spacing || 0));
                            yy = winBoxData.y;
                            ww = winBoxData.w + (winBoxData.offsetX || 0);
                            hh = winBoxSprite.y - yy;
                            this.boxCut.drawRect(xx, yy, ww, hh);
                            // create the bottom mask area.
                            yy = winBoxSprite.y + winBoxData.h;
                            hh = bottomY - yy;
                            this.boxCut.drawRect(xx, yy, ww, hh);
                        } else {
                            // implemented for using holes,
                            this.boxCut.beginHole();

                            const offset = configData.winboxCutOffset;
                            const maskCorners: any = {
                                topLeft: [winBoxSprite.x + offset.topLeft[0], winBoxSprite.y + offset.topLeft[1]],
                                topRight: [winBoxSprite.x + winBoxSprite.width + offset.topRight[0], winBoxSprite.y + offset.topRight[1]],
                                bottomLeft: [winBoxSprite.x + offset.bottomLeft[0], winBoxSprite.y + winBoxSprite.height + offset.bottomLeft[1]],
                                bottomRight: [winBoxSprite.x + winBoxSprite.width + offset.bottomRight[0], winBoxSprite.y + winBoxSprite.height + offset.bottomRight[1]]
                            };

                            this.boxCut.moveTo(maskCorners.topLeft[0], maskCorners.topLeft[1]);
                            this.boxCut.lineTo(maskCorners.topRight[0], maskCorners.topRight[1]);
                            this.boxCut.lineTo(maskCorners.bottomRight[0], maskCorners.bottomRight[1]);
                            this.boxCut.lineTo(maskCorners.bottomLeft[0], maskCorners.bottomLeft[1]);
                            this.boxCut.closePath();
                            this.boxCut.endHole();
                        }

                        winBoxData = this.json.winBoxData;
                        // let xx: number, yy: number, ww: number, hh: number;
                        let xxPosition: number, yyPosition: number, wwDimansion: number, hhDimansion: number;
                        xxPosition = winBoxData.x + i * (winBoxData.w + (winBoxData.offsetX || 0) + (winBoxData.spacing || 0)) + winBoxData.w + (winBoxData.offsetX || 0);
                        yyPosition = winBoxData.y;
                        wwDimansion = 15;
                        hhDimansion = 496;
                        this.boxCut.drawRect(xxPosition, yyPosition, wwDimansion, hhDimansion);

                        if (configData.winboxAnimate && Paylines.winCycleComplete === 0) {
                            if (ingenuity.configData.animatedLineWinFrames !== undefined && ingenuity.configData.animatedLineWinFrames) {  // ingenuity.configData.animatedLineWinFrames is set to true from game side, then animated win frames will be visible to player
                                winBoxSprite.animations.play(ingenuity.BehaviorCore.slotConstants.SlotConstants.WINFRAMES_ON_LINES_ANIMATION + this.lineCount);
                            } else {
                                winBoxSprite.animations.play(slot.symbol.SymbolConstants.DEFAULT_ANIMATION_KEY);
                            }
                        } else {
                            winBoxSprite.frame = (this.json.winBoxData && this.json.winBoxData.animatedWinBoxData && Number(this.json.winBoxData.animatedWinBoxData.posterFrame) || 0);
                        }
                    } else {
                        if (currentGame.renderType === bridge.RENDERER_TYPE.CANVAS) {
                            // create the whole col as mask
                            const winBoxData: IObject = this.json.winBoxData;
                            let xxPosition: number, yyPosition: number, wwDimansion: number, hhDimansion: number;
                            const bottomY: number = winBoxData.y + this.numRows * (winBoxData.h + (winBoxData.offsetY || 0));
                            xxPosition = winBoxData.x + i * (winBoxData.w + (winBoxData.offsetX || 0) + (winBoxData.spacing || 0));
                            yyPosition = winBoxData.y;
                            wwDimansion = winBoxData.w + (winBoxData.offsetX || 0) + (winBoxData.spacing || 0);
                            hhDimansion = bottomY - yyPosition;
                            this.boxCut.drawRect(xxPosition, yyPosition, wwDimansion, hhDimansion);
                        }
                        winBoxSprite.visible = false;
                    }
                }
                this.boxCut.endFill();
            }
            if (configData.debugWinBox) {
                this.winboxContainer.addChild(this.boxCut);
            } else {
                this.lines[id - this.startIndex].mask = this.boxCut;
            }
        }

        protected showWinPayline(evt: IEvent, numSymWin?: number[][] | number): void {
            let line: number;
            const displayPayline: IObject = arguments[2] || ingenuity.configData.displayPayline;
            const displayWinbox: IObject = arguments[3] || ingenuity.configData.displayWinbox;
            if (typeof evt === "number") {
                line = Number(evt);
            } else if (typeof evt.data === "object") {
                if (!isNaN(evt.data.id)) {
                    line = Number(evt.data.id);
                }
                if (Array.isArray(evt.data.winSymLen) || typeof evt.data.winSymLen === "number") {
                    numSymWin = evt.data.winSymLen;
                }
                if (ingenuity.configData.scatterLineIds.indexOf(line) !== -1 && ingenuity.configData.showScatterWinFrame) {
                    this.showWinBoxOnly(line, evt.data.positions);
                    return;
                }
            }
            if (ingenuity.configData.waysGame && displayWinbox) {
                this.showWinBoxOnly(line, evt.data.positions);
                return;
            }
            if (line < this.startIndex) {
                return;
            }

            if (ingenuity.configData.animatedLineWinFrames !== undefined && ingenuity.configData.animatedLineWinFrames) {
                this.lineCount = this.lineCount + 1; // ingenuity.configData.animatedLineWinFrames is set to true from game side, then animated win frames will be visible to player
            }

            if (displayPayline && this.isPayline && !ingenuity.configData.animatedLineWinFrames) {
                this.showPayline(line);
            }
            if ((displayWinbox && !ingenuity.configData.animatedPaylines) || (this.isWinbox && !ingenuity.configData.animatedPaylines)) { // ingenuity.configData.animatedLineWinFrames is set to true from game side, then animated win frames will be visible to player
                this.showPaylineWinbox(line, numSymWin);
            }

            if (ingenuity.configData.animatedLineWinFrames !== undefined && ingenuity.configData.animatedLineWinFrames) {
                if (this.lineCount >= 5) {
                    this.lineCount = 0;
                }
            }
        }

        protected showSpecificPaylineWinbox(id: number, numSymWin: number[]): void {
            const winBox: ui.Container = this.getWinbox(id - this.startIndex);
            let i: number = 0;
            for (i = 0; i < numSymWin.length; i++) {
                const winBoxSprite: IObject = winBox.getChildAt(numSymWin[i]);
                winBoxSprite.alpha = 1;
                winBoxSprite.visible = true;
                if (ingenuity.configData.winboxAnimate && Paylines.winCycleComplete === 0) {
                    if (ingenuity.configData.animatedLineWinFrames !== undefined && ingenuity.configData.animatedLineWinFrames) {
                        winBoxSprite.animations.play(ingenuity.BehaviorCore.slotConstants.SlotConstants.WINFRAMES_ON_LINES_ANIMATION + 0);
                    } else {
                        winBoxSprite.animations.play(slot.symbol.SymbolConstants.DEFAULT_ANIMATION_KEY);
                    }
                } else {
                    winBoxSprite.frame = (this.json.winBoxData && this.json.winBoxData.animatedWinBoxData && Number(this.json.winBoxData.animatedWinBoxData.posterFrame) || 0);
                }
            }
        }

    }
}
