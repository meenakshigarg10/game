namespace ingenuity.BehaviorCore.reelPanel {
    export class Reel extends ingenuity.slot.reelPanel.Reel {

        /**
         *
         * @param stopsArray overrided to stop bounce on spin force stop
         */
        public forceStopReel(stopsArray: number[] | number) {
            let newStops;
            if (this.model.isReelLocked(this.reelId)) {
                this.spinDone();
                return;
            }
            if (!this.isSpinning) {
                this.spinDone();
                return;
            }
            this.reelSet = this.model.getCurrentReelset()[this.reelId];
            if (Array.isArray(stopsArray)) {
                newStops = ingenuity.utils.clone(stopsArray);
                this.indx = this.getStopIndex(newStops[0]);
                this.indx = this.indx < 1 ? this.reelSet.length : this.indx;
                newStops.unshift(this.reelSet[--this.indx]);
                let lastIcon = this.indx + this.rows;
                lastIcon = (lastIcon >= (this.reelSet.length - 1)) ? 0 : lastIcon;
                newStops.push(this.reelSet[++lastIcon]);
                this.stops = newStops;
            } else {
                stopsArray = Number(stopsArray);
                stopsArray -= ingenuity.configData.reelStopRow;
                stopsArray = (stopsArray < 0) ? this.reelSet.length + stopsArray : stopsArray;
                newStops = this.reelSubset(stopsArray);
                this.indx = stopsArray;
                this.model.setReelGrid(this.reelId, newStops);
                this.stops = newStops;
            }
            this.y = this.model.reelJson[this.reelId].y;
            this.setStaticReel(this.stops as number[]);
            this.handleReelStop();
            if (this.spinNow && !this.stopSpinNow) {
                this.spinNow = false;
                this.spinDone();
            } else {
                if (this.game.tweens.isTweening(this)) {
                    this.game.tweens.removeFrom(this);
                }
                this.spinDone();
            }
        }

        public playAnimByPos (pos: number, symReel?: ui.Container, opts?: slot.reelPanel.SymAnimReel) {
            const parent: any = this.parent;
            const sym: slot.symbol.SymbolBase2 = parent.getSymbolByPos(this.reelId, pos);
            sym.getStatic().visible = false;
            const icon: slot.symbol.AnimationSymbol | slot.symbol.SpineSymbol | slot.symbol.StaticSymbol | slot.symbol.LayeredAnimationSymbol = sym.getAnimation();
            if (!icon) {
                return;
            }
            if (!icon.hasEvent(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_STARTED)) {
                icon.on(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_STARTED, this.onSymbolAnimationEvent, this);
            }
            if (!icon.hasEvent(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_ENDED)) {
                icon.on(slot.slotConstants.SlotEventConstants.SYMBOL_ANIM_ENDED, this.onSymbolAnimationEvent, this);
            }
            symReel.addChild(icon);
            icon.visible = !sym.forceHide;
            this.hiddenIcons.push(icon);
            if (!this.checkSymbolInArray(icon)) {
                this.AllIcons.push(icon);
            }
            icon.playAnim(opts);
        }

        protected checkSymbolInArray(icon: slot.symbol.AnimationSymbol | slot.symbol.SpineSymbol | slot.symbol.StaticSymbol | slot.symbol.LayeredAnimationSymbol): boolean {
            let isSymbolAavialble: boolean = false;
            for (const element of this.AllIcons) {
                if (element.gridPosition === icon.gridPosition) {
                    isSymbolAavialble = true;
                }
            }
            return isSymbolAavialble;
        }

         /**
         * Here stops all symbols animation.
         */
        public stopAllAnim() {
            if (this.AllIcons) {
                while (this.AllIcons.length) {
                    let icon = this.AllIcons.pop() as slot.symbol.StaticSymbol;
                    icon.stopAnim();
                    icon.parent && icon.parent.removeChild(icon);
                }
            }
            if (this.scatterIcons) {
                while (this.scatterIcons.length) {
                    let icon = this.scatterIcons.pop() as slot.symbol.AnimationSymbol;
                    icon.stopAnim("triggering");
                    icon.parent && icon.parent.removeChild(icon);
                }
            }
            this.symCollection.forEach((symbol: slot.symbol.SymbolBase2) => {
                let icon: slot.symbol.StaticSymbol | slot.symbol.AnimationSymbol = symbol.getStatic();
                if (symbol.gridPosition >= 0 && symbol.gridPosition < this.rows && !symbol.forceHide) {
                    icon.visible = true;
                }
                !icon.parent && this.addChild(icon);
            });
            this.sortIconsOnType();
        }
    }
}