///<reference path="../tsd/platform/platform-core.d.ts"/>
///<reference path="../tsd/slot/slot-core.d.ts"/>
///<reference path="../tsd/base/base-core.d.ts"/>
///<reference path="../tsd/pixi-bridge/pixi-bridge.d.ts"/>
// tslint:disable-next-line
let envConfig: {
    cdn: string;
};

namespace ingenuity.game {
    export let wrapper: IObject = {
        gameWrapper: {}
    };
}
